# Passive GitHub Credential Exposure Review

- Program focus: GitHub Credential Bounty
- Started (UTC): 2026-10-18T00:00:20.583910+00:00
- Finished (UTC): 2026-10-18T00:04:39.335221+00:00
- Queries succeeded: 29/30
- Queries failed: 1
- Unique repository/path pairs: 2586

## Priority breakdown

- P1_REVIEW_FIRST: 188
- P2_REVIEW: 703
- P3_LOW_SIGNAL: 1695

## Candidate results

### 1. P1_REVIEW_FIRST — jasser050/Esprit-PIDEV-3A50-2026-RLIFE

- Path: `.env.1`
- Indicator: `database_url`
- Heuristic score: 6 (not severity)
- File URL: https://github.com/jasser050/Esprit-PIDEV-3A50-2026-RLIFE/blob/5a20e7f1cc2a15dc7b43866473140f2fa6b5b112/.env.1
- Repository URL: https://github.com/jasser050/Esprit-PIDEV-3A50-2026-RLIFE
- Assessment: unconfirmed; do not use or test any credentials.

### 2. P1_REVIEW_FIRST — serebano/tictapp-storage-api

- Path: `.env.1`
- Indicator: `database_url`
- Heuristic score: 6 (not severity)
- File URL: https://github.com/serebano/tictapp-storage-api/blob/31ab25f1990d29992dc9eb2861b568fd8b571514/.env.1
- Repository URL: https://github.com/serebano/tictapp-storage-api
- Assessment: unconfirmed; do not use or test any credentials.

### 3. P1_REVIEW_FIRST — serebano/tictapp-storage-api

- Path: `.env.2`
- Indicator: `database_url`
- Heuristic score: 6 (not severity)
- File URL: https://github.com/serebano/tictapp-storage-api/blob/31ab25f1990d29992dc9eb2861b568fd8b571514/.env.2
- Repository URL: https://github.com/serebano/tictapp-storage-api
- Assessment: unconfirmed; do not use or test any credentials.

### 4. P1_REVIEW_FIRST — 0sm0s1z/subterfuge

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/0sm0s1z/subterfuge/blob/6c912aab938c53b036329ffe74a5648c7d76f74e/credentials.txt
- Repository URL: https://github.com/0sm0s1z/subterfuge
- Assessment: unconfirmed; do not use or test any credentials.

### 5. P1_REVIEW_FIRST — 0xcyphered/remilias.eth

- Path: `.env.org`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/0xcyphered/remilias.eth/blob/9ff0a0c8bd241015c5e43911dbd0d3b95e985214/.env.org
- Repository URL: https://github.com/0xcyphered/remilias.eth
- Assessment: unconfirmed; do not use or test any credentials.

### 6. P1_REVIEW_FIRST — 510908220/jenkins-assistant

- Path: `credentials.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/510908220/jenkins-assistant/blob/2d9659d3ed8f97f06fb892169f6056564e4bcc9d/credentials.md
- Repository URL: https://github.com/510908220/jenkins-assistant
- Assessment: unconfirmed; do not use or test any credentials.

### 7. P1_REVIEW_FIRST — AIxHunter/FileWizardAI

- Path: `.env.md`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/AIxHunter/FileWizardAI/blob/8ca4366a0309b2e4e49db60cce3b92ad40babfbd/.env.md
- Repository URL: https://github.com/AIxHunter/FileWizardAI
- Assessment: unconfirmed; do not use or test any credentials.

### 8. P1_REVIEW_FIRST — AlgyJr/FTP-Protocol

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/AlgyJr/FTP-Protocol/blob/31a7bfdf129f6b71e5db70fa9e5d60bf9f717d9b/credentials.txt
- Repository URL: https://github.com/AlgyJr/FTP-Protocol
- Assessment: unconfirmed; do not use or test any credentials.

### 9. P1_REVIEW_FIRST — AlrzA2003/BinanceTrader

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/AlrzA2003/BinanceTrader/blob/ecd079470d4fad35665c691d250c426efa11920f/credentials.txt
- Repository URL: https://github.com/AlrzA2003/BinanceTrader
- Assessment: unconfirmed; do not use or test any credentials.

### 10. P1_REVIEW_FIRST — ArtemBernatskyy/Facebook_downloader

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/ArtemBernatskyy/Facebook_downloader/blob/256944d0583186900b26b6bc2067cd245e6104af/credentials.txt
- Repository URL: https://github.com/ArtemBernatskyy/Facebook_downloader
- Assessment: unconfirmed; do not use or test any credentials.

### 11. P1_REVIEW_FIRST — BaseMax/tehran-stock-market-watch-nodejs

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/BaseMax/tehran-stock-market-watch-nodejs/blob/0f93cdd790eb856ec5dc4bfc36817b58b150544d/.env.txt
- Repository URL: https://github.com/BaseMax/tehran-stock-market-watch-nodejs
- Assessment: unconfirmed; do not use or test any credentials.

### 12. P1_REVIEW_FIRST — Bekt/startup-pitches

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Bekt/startup-pitches/blob/7cad82a2075cfffbff10e0cba1af47cf0ed9f7ad/credentials.txt
- Repository URL: https://github.com/Bekt/startup-pitches
- Assessment: unconfirmed; do not use or test any credentials.

### 13. P1_REVIEW_FIRST — Bitbox-Connect/Bitbox

- Path: `.env.txt`
- Indicator: `secret_assignment;credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Bitbox-Connect/Bitbox/blob/f7c6a6292a89b8d282940582541c88158178d5c1/.env.txt
- Repository URL: https://github.com/Bitbox-Connect/Bitbox
- Assessment: unconfirmed; do not use or test any credentials.

### 14. P1_REVIEW_FIRST — CapUlDis/to-do-app

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/CapUlDis/to-do-app/blob/3f5e283031d276c5c40684e116d99cdfabba8160/credentials.txt
- Repository URL: https://github.com/CapUlDis/to-do-app
- Assessment: unconfirmed; do not use or test any credentials.

### 15. P1_REVIEW_FIRST — Central-University-IT-prod/2025-final-command-team-13-PROD-Finals-App

- Path: `credentials.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Central-University-IT-prod/2025-final-command-team-13-PROD-Finals-App/blob/5784fe5b07ddaad5002f1435ed404e37a15ed78a/credentials.md
- Repository URL: https://github.com/Central-University-IT-prod/2025-final-command-team-13-PROD-Finals-App
- Assessment: unconfirmed; do not use or test any credentials.

### 16. P1_REVIEW_FIRST — Central-University-IT-prod/2025-final-command-team-15-project

- Path: `CREDENTIALS.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Central-University-IT-prod/2025-final-command-team-15-project/blob/67eeb4238557006fa708f575db0b4627f84a1df1/CREDENTIALS.md
- Repository URL: https://github.com/Central-University-IT-prod/2025-final-command-team-15-project
- Assessment: unconfirmed; do not use or test any credentials.

### 17. P1_REVIEW_FIRST — Central-University-IT-prod/2025-final-command-team-16-backend_and_frontend

- Path: `credentials.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Central-University-IT-prod/2025-final-command-team-16-backend_and_frontend/blob/49f2dcf315476f6dd62fbda1ed2fc1cf600747db/credentials.md
- Repository URL: https://github.com/Central-University-IT-prod/2025-final-command-team-16-backend_and_frontend
- Assessment: unconfirmed; do not use or test any credentials.

### 18. P1_REVIEW_FIRST — Central-University-IT-prod/2025-final-command-team-24-films

- Path: `Credentials.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Central-University-IT-prod/2025-final-command-team-24-films/blob/da0311ec50faeb1c283a42541a973861b9a0ddf5/Credentials.md
- Repository URL: https://github.com/Central-University-IT-prod/2025-final-command-team-24-films
- Assessment: unconfirmed; do not use or test any credentials.

### 19. P1_REVIEW_FIRST — Central-University-IT-prod/2025-final-command-team-25-final

- Path: `credentials.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Central-University-IT-prod/2025-final-command-team-25-final/blob/55767bb7113a51b1c307a9315bd3443421e15f0e/credentials.md
- Repository URL: https://github.com/Central-University-IT-prod/2025-final-command-team-25-final
- Assessment: unconfirmed; do not use or test any credentials.

### 20. P1_REVIEW_FIRST — Central-University-IT-prod/2025-final-command-team-3-backend

- Path: `CREDENTIALS.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Central-University-IT-prod/2025-final-command-team-3-backend/blob/3a233340f750c278b46d2419fb4a16a6d09494f6/CREDENTIALS.md
- Repository URL: https://github.com/Central-University-IT-prod/2025-final-command-team-3-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 21. P1_REVIEW_FIRST — Central-University-IT-prod/2025-final-command-team-40-supernova_team

- Path: `credentials.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Central-University-IT-prod/2025-final-command-team-40-supernova_team/blob/77e8117a9229ac2de6fb1986ec0668ffe4f791b5/credentials.md
- Repository URL: https://github.com/Central-University-IT-prod/2025-final-command-team-40-supernova_team
- Assessment: unconfirmed; do not use or test any credentials.

### 22. P1_REVIEW_FIRST — ChrisFlick/React-Reversi

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/ChrisFlick/React-Reversi/blob/30f1501886656430e4a94266c87b6be11a0bc838/.env.txt
- Repository URL: https://github.com/ChrisFlick/React-Reversi
- Assessment: unconfirmed; do not use or test any credentials.

### 23. P1_REVIEW_FIRST — ChristianJavierMelo/Vehicle-Type-Recognition

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/ChristianJavierMelo/Vehicle-Type-Recognition/blob/d96909998e957fcf6596ed5a5da52e8ed68f2338/.env.txt
- Repository URL: https://github.com/ChristianJavierMelo/Vehicle-Type-Recognition
- Assessment: unconfirmed; do not use or test any credentials.

### 24. P1_REVIEW_FIRST — CodingHusk3y/NutriSense

- Path: `CREDENTIALS.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/CodingHusk3y/NutriSense/blob/634b1ebf8f6b4c0bceb3f30613b91caa0382b57a/CREDENTIALS.md
- Repository URL: https://github.com/CodingHusk3y/NutriSense
- Assessment: unconfirmed; do not use or test any credentials.

### 25. P1_REVIEW_FIRST — Curovearth/Are-you-Drowsy

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Curovearth/Are-you-Drowsy/blob/22230b34d010844ddec8a0330d8c967811c7d373/credentials.txt
- Repository URL: https://github.com/Curovearth/Are-you-Drowsy
- Assessment: unconfirmed; do not use or test any credentials.

### 26. P1_REVIEW_FIRST — Datamine/Archive-Tweets

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Datamine/Archive-Tweets/blob/5303b2f107a35ba07200efdef8d5b898050b7c2e/credentials.txt
- Repository URL: https://github.com/Datamine/Archive-Tweets
- Assessment: unconfirmed; do not use or test any credentials.

### 27. P1_REVIEW_FIRST — DecoraterBot-devs/DecoraterBot

- Path: `Credentials.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/DecoraterBot-devs/DecoraterBot/blob/3362ea90bc2fdb2e799dd064aa6128efbf4cd7a1/Credentials.md
- Repository URL: https://github.com/DecoraterBot-devs/DecoraterBot
- Assessment: unconfirmed; do not use or test any credentials.

### 28. P1_REVIEW_FIRST — EmreErinc/envforge

- Path: `.env.ai.md`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/EmreErinc/envforge/blob/865cd46497f0ad212ed9c15f9a2f084fe2f1ad16/.env.ai.md
- Repository URL: https://github.com/EmreErinc/envforge
- Assessment: unconfirmed; do not use or test any credentials.

### 29. P1_REVIEW_FIRST — EngqvistLab/fetch_microbial_growth_temperatures

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/EngqvistLab/fetch_microbial_growth_temperatures/blob/5f07cdd1a255e3ecb88ceabeb3ecb9b07588f0fa/credentials.txt
- Repository URL: https://github.com/EngqvistLab/fetch_microbial_growth_temperatures
- Assessment: unconfirmed; do not use or test any credentials.

### 30. P1_REVIEW_FIRST — EternalDreamer01/Nyx

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/EternalDreamer01/Nyx/blob/6a16a3c06ac7c0bbc3253d1ada2fd34d56ec174f/.env.txt
- Repository URL: https://github.com/EternalDreamer01/Nyx
- Assessment: unconfirmed; do not use or test any credentials.

### 31. P1_REVIEW_FIRST — GeorgiosIoannouCoder/vera

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/GeorgiosIoannouCoder/vera/blob/683de048d31205b09bbacbef533ea08e62676d71/.env.txt
- Repository URL: https://github.com/GeorgiosIoannouCoder/vera
- Assessment: unconfirmed; do not use or test any credentials.

### 32. P1_REVIEW_FIRST — Hamyrappy/creative-governance-sim

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Hamyrappy/creative-governance-sim/blob/9dd3186583d5cb05dd64027dc2501cb206ab86bd/.env.txt
- Repository URL: https://github.com/Hamyrappy/creative-governance-sim
- Assessment: unconfirmed; do not use or test any credentials.

### 33. P1_REVIEW_FIRST — JakeMcAllen/Decentralized-Crowdfunding-dApp-Backend

- Path: `.env.save.1`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/JakeMcAllen/Decentralized-Crowdfunding-dApp-Backend/blob/5e29ccf0f436eddaf6496c7a57789ce9442004f4/.env.save.1
- Repository URL: https://github.com/JakeMcAllen/Decentralized-Crowdfunding-dApp-Backend
- Assessment: unconfirmed; do not use or test any credentials.

### 34. P1_REVIEW_FIRST — Jarnster/FaceLink

- Path: `CREDENTIALS.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Jarnster/FaceLink/blob/8c8a7fc0ed17c3e804c7775ab841ac1ba1904864/CREDENTIALS.md
- Repository URL: https://github.com/Jarnster/FaceLink
- Assessment: unconfirmed; do not use or test any credentials.

### 35. P1_REVIEW_FIRST — KarenLiuzzi/Acoms_UAA

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/KarenLiuzzi/Acoms_UAA/blob/d202d53a33cbd949c12d9c554a48784296a366c5/credentials.txt
- Repository URL: https://github.com/KarenLiuzzi/Acoms_UAA
- Assessment: unconfirmed; do not use or test any credentials.

### 36. P1_REVIEW_FIRST — Kcorb0/sparta-data22-project

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Kcorb0/sparta-data22-project/blob/a93f4caecbbffa5f0294be7835de154cc11cfc98/.env.txt
- Repository URL: https://github.com/Kcorb0/sparta-data22-project
- Assessment: unconfirmed; do not use or test any credentials.

### 37. P1_REVIEW_FIRST — KubaWernerowski/Crimetrax

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/KubaWernerowski/Crimetrax/blob/163493c3fe7c5113f058c05c0434ccc0762cf3c7/credentials.txt
- Repository URL: https://github.com/KubaWernerowski/Crimetrax
- Assessment: unconfirmed; do not use or test any credentials.

### 38. P1_REVIEW_FIRST — Ladorigvava/thekeyssystemstricoreai

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Ladorigvava/thekeyssystemstricoreai/blob/afbeb9958bc8034a11a91ebeb5e60d5ff5eed9cc/.env.txt
- Repository URL: https://github.com/Ladorigvava/thekeyssystemstricoreai
- Assessment: unconfirmed; do not use or test any credentials.

### 39. P1_REVIEW_FIRST — Macula-Systems-LLC/purview-automation

- Path: `credentials.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Macula-Systems-LLC/purview-automation/blob/96b2f14f81847e5fca59c85076d45850c3ab0f71/credentials.md
- Repository URL: https://github.com/Macula-Systems-LLC/purview-automation
- Assessment: unconfirmed; do not use or test any credentials.

### 40. P1_REVIEW_FIRST — Manjaka13/hauth

- Path: `.env.txt`
- Indicator: `secret_assignment;credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Manjaka13/hauth/blob/1cbfb9b5e9e8f15bd6bf3235310e57c8291a7c6a/.env.txt
- Repository URL: https://github.com/Manjaka13/hauth
- Assessment: unconfirmed; do not use or test any credentials.

### 41. P1_REVIEW_FIRST — Manjaka13/weather-app

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Manjaka13/weather-app/blob/06dab90772b4060b9013677d5d52a53a13abb772/.env.txt
- Repository URL: https://github.com/Manjaka13/weather-app
- Assessment: unconfirmed; do not use or test any credentials.

### 42. P1_REVIEW_FIRST — Marcocholla/e-Shop

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Marcocholla/e-Shop/blob/2277ae27f306496fe514dcbe898ebb0a971de2cf/credentials.txt
- Repository URL: https://github.com/Marcocholla/e-Shop
- Assessment: unconfirmed; do not use or test any credentials.

### 43. P1_REVIEW_FIRST — Musfique-Ahmed/My-Safety-App

- Path: `CREDENTIALS.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Musfique-Ahmed/My-Safety-App/blob/99ec8ca4b7223012442f16dc71f05a4f8dc1a24a/CREDENTIALS.txt
- Repository URL: https://github.com/Musfique-Ahmed/My-Safety-App
- Assessment: unconfirmed; do not use or test any credentials.

### 44. P1_REVIEW_FIRST — Mycelium-Lab/FairFight

- Path: `.env.org`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Mycelium-Lab/FairFight/blob/e301930e6c809bc2b770fdbbd9a6dc78440f223f/.env.org
- Repository URL: https://github.com/Mycelium-Lab/FairFight
- Assessment: unconfirmed; do not use or test any credentials.

### 45. P1_REVIEW_FIRST — Mysticloud/Pterodactyl-Trial-Servers

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Mysticloud/Pterodactyl-Trial-Servers/blob/5cd04a5279087c7b2a9f204936b6193fdd763616/.env.txt
- Repository URL: https://github.com/Mysticloud/Pterodactyl-Trial-Servers
- Assessment: unconfirmed; do not use or test any credentials.

### 46. P1_REVIEW_FIRST — NCEAS/index-monitor

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/NCEAS/index-monitor/blob/1bc0a4700a5a7b2bb957d3bdb17f4295eda99801/credentials.txt
- Repository URL: https://github.com/NCEAS/index-monitor
- Assessment: unconfirmed; do not use or test any credentials.

### 47. P1_REVIEW_FIRST — Nannajpg/IDS-admin-panel

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Nannajpg/IDS-admin-panel/blob/1020ba955dd6c88031cc5795718d684f79fd0109/.env.txt
- Repository URL: https://github.com/Nannajpg/IDS-admin-panel
- Assessment: unconfirmed; do not use or test any credentials.

### 48. P1_REVIEW_FIRST — Nileshsan/taxwisary-project

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Nileshsan/taxwisary-project/blob/ddfceb6fa93993314b12273da57cefcf14951c3e/credentials.txt
- Repository URL: https://github.com/Nileshsan/taxwisary-project
- Assessment: unconfirmed; do not use or test any credentials.

### 49. P1_REVIEW_FIRST — NinoslavVasic/Multi-Blockchain-Wallet-in-Python

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/NinoslavVasic/Multi-Blockchain-Wallet-in-Python/blob/22a354c4714f5be0364f18878817d3ab30848c4e/.env.txt
- Repository URL: https://github.com/NinoslavVasic/Multi-Blockchain-Wallet-in-Python
- Assessment: unconfirmed; do not use or test any credentials.

### 50. P1_REVIEW_FIRST — Ohnoimded/maya_telegram_rag

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Ohnoimded/maya_telegram_rag/blob/516820d7cebb6cf16f1e7686886996bc2883d183/.env.txt
- Repository URL: https://github.com/Ohnoimded/maya_telegram_rag
- Assessment: unconfirmed; do not use or test any credentials.

### 51. P1_REVIEW_FIRST — Prakhar824/java-based-quiz

- Path: `Credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Prakhar824/java-based-quiz/blob/23075c6623d6ef7c54eefb35c3c14ab699e3cbca/Credentials.txt
- Repository URL: https://github.com/Prakhar824/java-based-quiz
- Assessment: unconfirmed; do not use or test any credentials.

### 52. P1_REVIEW_FIRST — PricopeStefan/Filelist-QBitTorrent-Plugin

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/PricopeStefan/Filelist-QBitTorrent-Plugin/blob/f9f2320c6bff639de18adac07fa860ff5cd18828/credentials.txt
- Repository URL: https://github.com/PricopeStefan/Filelist-QBitTorrent-Plugin
- Assessment: unconfirmed; do not use or test any credentials.

### 53. P1_REVIEW_FIRST — ProcessAI/cnhfacil

- Path: `CREDENTIALS.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/ProcessAI/cnhfacil/blob/14c896d2d86b7a57c7ee103dc10d9c268dec697f/CREDENTIALS.md
- Repository URL: https://github.com/ProcessAI/cnhfacil
- Assessment: unconfirmed; do not use or test any credentials.

### 54. P1_REVIEW_FIRST — PuneethReddyHC/inventory_management_system

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/PuneethReddyHC/inventory_management_system/blob/dee022b403272a3984a2d6afe05fa216b9fa98ee/credentials.txt
- Repository URL: https://github.com/PuneethReddyHC/inventory_management_system
- Assessment: unconfirmed; do not use or test any credentials.

### 55. P1_REVIEW_FIRST — Sellbrite/Sellbrite-API

- Path: `credentials.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Sellbrite/Sellbrite-API/blob/b6fddbf9e94894d1e6cbd1040331957d2940af9a/credentials.md
- Repository URL: https://github.com/Sellbrite/Sellbrite-API
- Assessment: unconfirmed; do not use or test any credentials.

### 56. P1_REVIEW_FIRST — Shivamkak19/Dual-Class-Arbitrage-Algorithm

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Shivamkak19/Dual-Class-Arbitrage-Algorithm/blob/e9f2325b5fc2f27bfe24a4dbadffae2f17c606dc/credentials.txt
- Repository URL: https://github.com/Shivamkak19/Dual-Class-Arbitrage-Algorithm
- Assessment: unconfirmed; do not use or test any credentials.

### 57. P1_REVIEW_FIRST — Subham-Maity/MERN_Chat_App

- Path: `.env.txt`
- Indicator: `secret_assignment;credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Subham-Maity/MERN_Chat_App/blob/dbf10d794d4cbc6911869723d111ca60035c76d9/.env.txt
- Repository URL: https://github.com/Subham-Maity/MERN_Chat_App
- Assessment: unconfirmed; do not use or test any credentials.

### 58. P1_REVIEW_FIRST — SydAliHsn/portfolio

- Path: `.env.local.md`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/SydAliHsn/portfolio/blob/3c36ed90c52892e3141edaab06c0ab9dbeace484/.env.local.md
- Repository URL: https://github.com/SydAliHsn/portfolio
- Assessment: unconfirmed; do not use or test any credentials.

### 59. P1_REVIEW_FIRST — Tomochain-Name-Service/tns-contracts

- Path: `.env.org`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Tomochain-Name-Service/tns-contracts/blob/eefdd9d0b88d0e175858be485a6d0eb7023cb5c4/.env.org
- Repository URL: https://github.com/Tomochain-Name-Service/tns-contracts
- Assessment: unconfirmed; do not use or test any credentials.

### 60. P1_REVIEW_FIRST — WolfpackOfOne/Q-agent

- Path: `CREDENTIALS.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/WolfpackOfOne/Q-agent/blob/4ec8ffb7d78fd0183cc36a56d8d7f82b226d0857/CREDENTIALS.md
- Repository URL: https://github.com/WolfpackOfOne/Q-agent
- Assessment: unconfirmed; do not use or test any credentials.

### 61. P1_REVIEW_FIRST — Wondersteve254/dawapharma

- Path: `Credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/Wondersteve254/dawapharma/blob/052f9f2aeb89285b832bc22ded3c898a367917ba/Credentials.txt
- Repository URL: https://github.com/Wondersteve254/dawapharma
- Assessment: unconfirmed; do not use or test any credentials.

### 62. P1_REVIEW_FIRST — ZYY799/tongji_stadium

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/ZYY799/tongji_stadium/blob/e9bfab55d011b00d3882ef0e5995e7afef146517/credentials.txt
- Repository URL: https://github.com/ZYY799/tongji_stadium
- Assessment: unconfirmed; do not use or test any credentials.

### 63. P1_REVIEW_FIRST — aWhereAPI/R-Training-Tutorials

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/aWhereAPI/R-Training-Tutorials/blob/cff22373542abc59cded9722afa4461a73c4280c/credentials.txt
- Repository URL: https://github.com/aWhereAPI/R-Training-Tutorials
- Assessment: unconfirmed; do not use or test any credentials.

### 64. P1_REVIEW_FIRST — aayushkumarmishra/Send-Email

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/aayushkumarmishra/Send-Email/blob/b5eaccee8f6325feac2e5c0b2c7c7c381ab0f91b/credentials.txt
- Repository URL: https://github.com/aayushkumarmishra/Send-Email
- Assessment: unconfirmed; do not use or test any credentials.

### 65. P1_REVIEW_FIRST — aerisweather/react-mapsgl

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/aerisweather/react-mapsgl/blob/7c39fc36d2bdf5eaa264212f03826af74aa2e40f/.env.txt
- Repository URL: https://github.com/aerisweather/react-mapsgl
- Assessment: unconfirmed; do not use or test any credentials.

### 66. P1_REVIEW_FIRST — andygnewman/smart_twits

- Path: `credentials.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/andygnewman/smart_twits/blob/86aee0d75ed2cc1f0636cfa161abd93a00d39af9/credentials.md
- Repository URL: https://github.com/andygnewman/smart_twits
- Assessment: unconfirmed; do not use or test any credentials.

### 67. P1_REVIEW_FIRST — animesh-workplace/GISAID_scrapper

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/animesh-workplace/GISAID_scrapper/blob/d69978580e8c304dad3f0ba315060504db31c86e/credentials.txt
- Repository URL: https://github.com/animesh-workplace/GISAID_scrapper
- Assessment: unconfirmed; do not use or test any credentials.

### 68. P1_REVIEW_FIRST — anyproto/any-ns

- Path: `.env.org`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/anyproto/any-ns/blob/77cc31146e6c5863b5facd8136533671fbe98451/.env.org
- Repository URL: https://github.com/anyproto/any-ns
- Assessment: unconfirmed; do not use or test any credentials.

### 69. P1_REVIEW_FIRST — aqib026/direct-ksa

- Path: `.env.save.1`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/aqib026/direct-ksa/blob/748808bdbcbc41cb4788585f4c90905ccb9c2293/.env.save.1
- Repository URL: https://github.com/aqib026/direct-ksa
- Assessment: unconfirmed; do not use or test any credentials.

### 70. P1_REVIEW_FIRST — arhamhashmi01/Apartment-Management-System

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/arhamhashmi01/Apartment-Management-System/blob/cbc466b3b8ee5e7ef42095fd6da4c478713b606a/credentials.txt
- Repository URL: https://github.com/arhamhashmi01/Apartment-Management-System
- Assessment: unconfirmed; do not use or test any credentials.

### 71. P1_REVIEW_FIRST — ashurai1/HireHeaven

- Path: `credentials.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/ashurai1/HireHeaven/blob/9a1171a576fb708cc24a697d3e5c66aaf6b307af/credentials.md
- Repository URL: https://github.com/ashurai1/HireHeaven
- Assessment: unconfirmed; do not use or test any credentials.

### 72. P1_REVIEW_FIRST — atato/kafka_training

- Path: `.env.5.5`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/atato/kafka_training/blob/3f3dedf7aa9c213650638895ce6d4efbd78f180f/.env.5.5
- Repository URL: https://github.com/atato/kafka_training
- Assessment: unconfirmed; do not use or test any credentials.

### 73. P1_REVIEW_FIRST — basics/blueprint-boilerplate-nuxt

- Path: `.env.md`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/basics/blueprint-boilerplate-nuxt/blob/f96adb64461da2f592785b62be84e5c54627b4ea/.env.md
- Repository URL: https://github.com/basics/blueprint-boilerplate-nuxt
- Assessment: unconfirmed; do not use or test any credentials.

### 74. P1_REVIEW_FIRST — blopit/Cursor-Template-Repo

- Path: `.env.md`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/blopit/Cursor-Template-Repo/blob/2950d74e26ceec6f5d99c7278851344bef69efdd/.env.md
- Repository URL: https://github.com/blopit/Cursor-Template-Repo
- Assessment: unconfirmed; do not use or test any credentials.

### 75. P1_REVIEW_FIRST — bold-ronin/Vee

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/bold-ronin/Vee/blob/cb2d2a552f5467b2ae8f25ade3aaa71d50b23735/.env.txt
- Repository URL: https://github.com/bold-ronin/Vee
- Assessment: unconfirmed; do not use or test any credentials.

### 76. P1_REVIEW_FIRST — boringPpl/Auto-Send-Linkedin-Connect-Request

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/boringPpl/Auto-Send-Linkedin-Connect-Request/blob/ed69e41c78474f5ffa12e240458125d4c7120a2a/credentials.txt
- Repository URL: https://github.com/boringPpl/Auto-Send-Linkedin-Connect-Request
- Assessment: unconfirmed; do not use or test any credentials.

### 77. P1_REVIEW_FIRST — chefworks/cxml-tester

- Path: `.env`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/chefworks/cxml-tester/blob/8cfc44ec0e79cdc08ed1762c5f79c0d6971197d0/.env
- Repository URL: https://github.com/chefworks/cxml-tester
- Assessment: unconfirmed; do not use or test any credentials.

### 78. P1_REVIEW_FIRST — cherifimehdi/Retrieve_Data_Application_Case

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/cherifimehdi/Retrieve_Data_Application_Case/blob/f919aba9b8011e256b46893e37bf73e53289efac/.env.txt
- Repository URL: https://github.com/cherifimehdi/Retrieve_Data_Application_Case
- Assessment: unconfirmed; do not use or test any credentials.

### 79. P1_REVIEW_FIRST — chiranthhd1/Expense-manager-cpp

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/chiranthhd1/Expense-manager-cpp/blob/2d4bb75b5882c2f5ac34b66912d34a4a0333efe3/credentials.txt
- Repository URL: https://github.com/chiranthhd1/Expense-manager-cpp
- Assessment: unconfirmed; do not use or test any credentials.

### 80. P1_REVIEW_FIRST — cloudfoundry-community/cf-containers-broker

- Path: `CREDENTIALS.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/cloudfoundry-community/cf-containers-broker/blob/6a3e75c0ae291f5ac3a821891708840de812c92b/CREDENTIALS.md
- Repository URL: https://github.com/cloudfoundry-community/cf-containers-broker
- Assessment: unconfirmed; do not use or test any credentials.

### 81. P1_REVIEW_FIRST — danangkonang/aplication-poin-of-sale-web-php-codeigniter

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/danangkonang/aplication-poin-of-sale-web-php-codeigniter/blob/1aa774d995fa3e3d89bcdc8eec666a305634d9c2/.env.txt
- Repository URL: https://github.com/danangkonang/aplication-poin-of-sale-web-php-codeigniter
- Assessment: unconfirmed; do not use or test any credentials.

### 82. P1_REVIEW_FIRST — deathbycaptcha/deathbycaptcha-api-client-python

- Path: `CREDENTIALS.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/deathbycaptcha/deathbycaptcha-api-client-python/blob/7fc6e8a41e0805074e341032996f77c6b3dbf34d/CREDENTIALS.md
- Repository URL: https://github.com/deathbycaptcha/deathbycaptcha-api-client-python
- Assessment: unconfirmed; do not use or test any credentials.

### 83. P1_REVIEW_FIRST — dehero/mwscr

- Path: `CREDENTIALS.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/dehero/mwscr/blob/8a0e4c36977b1fe1c535997a30c41dae8c4b3bcd/CREDENTIALS.md
- Repository URL: https://github.com/dehero/mwscr
- Assessment: unconfirmed; do not use or test any credentials.

### 84. P1_REVIEW_FIRST — eclypsium/mikrotik_meris_checker

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/eclypsium/mikrotik_meris_checker/blob/a657f6427992baa6f89e1f704cd2e1719acb0f8f/credentials.txt
- Repository URL: https://github.com/eclypsium/mikrotik_meris_checker
- Assessment: unconfirmed; do not use or test any credentials.

### 85. P1_REVIEW_FIRST — eersnington/zaplineai-backend

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/eersnington/zaplineai-backend/blob/6f2c6263fec414eb97b07006b1f417b0c8ccf663/.env.txt
- Repository URL: https://github.com/eersnington/zaplineai-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 86. P1_REVIEW_FIRST — elliotwutingfeng/the-ghost-of-you-spotify

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/elliotwutingfeng/the-ghost-of-you-spotify/blob/672b082bcadf7a0b37219b22719a8a091b80cd68/.env.txt
- Repository URL: https://github.com/elliotwutingfeng/the-ghost-of-you-spotify
- Assessment: unconfirmed; do not use or test any credentials.

### 87. P1_REVIEW_FIRST — emhart/tweetDB

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/emhart/tweetDB/blob/68de0761d09d0f6828586223ea4a89ce4aba20fd/credentials.txt
- Repository URL: https://github.com/emhart/tweetDB
- Assessment: unconfirmed; do not use or test any credentials.

### 88. P1_REVIEW_FIRST — endlessm/systemd

- Path: `docs/CREDENTIALS.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/endlessm/systemd/blob/262def6554798b4188f1beab4bd0113d400a372b/docs/CREDENTIALS.md
- Repository URL: https://github.com/endlessm/systemd
- Assessment: unconfirmed; do not use or test any credentials.

### 89. P1_REVIEW_FIRST — epfl-si/declprofs

- Path: `.env`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/epfl-si/declprofs/blob/75270a12895a9d47df6c9fbd7a11daf01321a857/.env
- Repository URL: https://github.com/epfl-si/declprofs
- Assessment: unconfirmed; do not use or test any credentials.

### 90. P1_REVIEW_FIRST — eric-zhao-ocado/modular_test_bench_control

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/eric-zhao-ocado/modular_test_bench_control/blob/d441b7cc2f8deb5f8232466ac517c001d114c103/credentials.txt
- Repository URL: https://github.com/eric-zhao-ocado/modular_test_bench_control
- Assessment: unconfirmed; do not use or test any credentials.

### 91. P1_REVIEW_FIRST — eveasian88/The-Bike-Shepherd

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/eveasian88/The-Bike-Shepherd/blob/39867164e97f8848c4c6a79b8df37148c42ae2a1/.env.txt
- Repository URL: https://github.com/eveasian88/The-Bike-Shepherd
- Assessment: unconfirmed; do not use or test any credentials.

### 92. P1_REVIEW_FIRST — f09l/Fidra-Instagram-Accounts-Creator

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/f09l/Fidra-Instagram-Accounts-Creator/blob/740029c48a469a7a55ddb5f7035c8c558a4f3cd6/credentials.txt
- Repository URL: https://github.com/f09l/Fidra-Instagram-Accounts-Creator
- Assessment: unconfirmed; do not use or test any credentials.

### 93. P1_REVIEW_FIRST — felixmariotto/Edelweiss-Editor

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/felixmariotto/Edelweiss-Editor/blob/ec39601ff252e9e8db3101d77a2916c64bc84786/.env.txt
- Repository URL: https://github.com/felixmariotto/Edelweiss-Editor
- Assessment: unconfirmed; do not use or test any credentials.

### 94. P1_REVIEW_FIRST — fkinfred/premsub

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/fkinfred/premsub/blob/ad8bedf500d3b126a95e9a99348909d1eacb3d92/.env.txt
- Repository URL: https://github.com/fkinfred/premsub
- Assessment: unconfirmed; do not use or test any credentials.

### 95. P1_REVIEW_FIRST — formoon/realworld-warp

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/formoon/realworld-warp/blob/5beb7bc4801ca6b590e05a4f81663baacc22a093/.env.txt
- Repository URL: https://github.com/formoon/realworld-warp
- Assessment: unconfirmed; do not use or test any credentials.

### 96. P1_REVIEW_FIRST — franciscoluna-28/envoy

- Path: `CREDENTIALS.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/franciscoluna-28/envoy/blob/88c79830d253d5f603686b9bc11a2b7bc5cd18e3/CREDENTIALS.md
- Repository URL: https://github.com/franciscoluna-28/envoy
- Assessment: unconfirmed; do not use or test any credentials.

### 97. P1_REVIEW_FIRST — hanahaneull/trakteer-ws

- Path: `CREDENTIALS.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/hanahaneull/trakteer-ws/blob/cf5c27d09c437366c750238765ed058bfefff3d8/CREDENTIALS.md
- Repository URL: https://github.com/hanahaneull/trakteer-ws
- Assessment: unconfirmed; do not use or test any credentials.

### 98. P1_REVIEW_FIRST — hellomaxime/data-platform-on-kubernetes

- Path: `credentials.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/hellomaxime/data-platform-on-kubernetes/blob/6da527db0c35e58a55da85d43c1bc21a1ca53181/credentials.md
- Repository URL: https://github.com/hellomaxime/data-platform-on-kubernetes
- Assessment: unconfirmed; do not use or test any credentials.

### 99. P1_REVIEW_FIRST — iancoleman/BitcoinArmory-Daemon

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/iancoleman/BitcoinArmory-Daemon/blob/cbe8dc363ff7bfe04d2580066121e2dd0fe0079a/credentials.txt
- Repository URL: https://github.com/iancoleman/BitcoinArmory-Daemon
- Assessment: unconfirmed; do not use or test any credentials.

### 100. P1_REVIEW_FIRST — ibm-build-lab/terraform-ibm-cloud-pak

- Path: `CREDENTIALS.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/ibm-build-lab/terraform-ibm-cloud-pak/blob/aca14f21541b53902e781ee843f945c464f5f97c/CREDENTIALS.md
- Repository URL: https://github.com/ibm-build-lab/terraform-ibm-cloud-pak
- Assessment: unconfirmed; do not use or test any credentials.

### 101. P1_REVIEW_FIRST — ibm-cloud-docs/cloud-object-storage

- Path: `credentials.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/ibm-cloud-docs/cloud-object-storage/blob/58112f68d3675230c87793e2c3226a7d86328d31/credentials.md
- Repository URL: https://github.com/ibm-cloud-docs/cloud-object-storage
- Assessment: unconfirmed; do not use or test any credentials.

### 102. P1_REVIEW_FIRST — invictus-ir/ALFA

- Path: `CREDENTIALS.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/invictus-ir/ALFA/blob/97ee7c2eb28c94ef1d59d4c513951c4c5a9fb91c/CREDENTIALS.md
- Repository URL: https://github.com/invictus-ir/ALFA
- Assessment: unconfirmed; do not use or test any credentials.

### 103. P1_REVIEW_FIRST — iseeface/A4-discord-bot

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/iseeface/A4-discord-bot/blob/a4f2c940770d76ce75f86a93993b28384cd0c191/.env.txt
- Repository URL: https://github.com/iseeface/A4-discord-bot
- Assessment: unconfirmed; do not use or test any credentials.

### 104. P1_REVIEW_FIRST — ivandj0h/attendant-app

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/ivandj0h/attendant-app/blob/196d25eb4d1f5f2f0ee28a8676bc6552aa89b2f9/.env.txt
- Repository URL: https://github.com/ivandj0h/attendant-app
- Assessment: unconfirmed; do not use or test any credentials.

### 105. P1_REVIEW_FIRST — ivandj0h/budget-tracker

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/ivandj0h/budget-tracker/blob/335a1d0f411ecf95102fd59d2a1b42c39b0afee2/.env.txt
- Repository URL: https://github.com/ivandj0h/budget-tracker
- Assessment: unconfirmed; do not use or test any credentials.

### 106. P1_REVIEW_FIRST — jamesnguyen30/news-spider-project

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/jamesnguyen30/news-spider-project/blob/6f85e2c090f25cbde5f46b722470ffbac054c00b/credentials.txt
- Repository URL: https://github.com/jamesnguyen30/news-spider-project
- Assessment: unconfirmed; do not use or test any credentials.

### 107. P1_REVIEW_FIRST — jasonqng/twitter-streaming-python

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/jasonqng/twitter-streaming-python/blob/3ccc1fa26d185ddc67a5045655146f056722e67e/credentials.txt
- Repository URL: https://github.com/jasonqng/twitter-streaming-python
- Assessment: unconfirmed; do not use or test any credentials.

### 108. P1_REVIEW_FIRST — jbaumann/system_watchdog

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/jbaumann/system_watchdog/blob/de2b4c41436a29d43d539483fcdcb01c91889900/credentials.txt
- Repository URL: https://github.com/jbaumann/system_watchdog
- Assessment: unconfirmed; do not use or test any credentials.

### 109. P1_REVIEW_FIRST — johnerinjery/PDF2Cal

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/johnerinjery/PDF2Cal/blob/dbf2fc9f9fdf1aef690d0f4ca20489bc1c08e505/credentials.txt
- Repository URL: https://github.com/johnerinjery/PDF2Cal
- Assessment: unconfirmed; do not use or test any credentials.

### 110. P1_REVIEW_FIRST — jvf/spatial-weather

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/jvf/spatial-weather/blob/3f7edbeb7df6f2355e6126346972ebbfb5706730/credentials.txt
- Repository URL: https://github.com/jvf/spatial-weather
- Assessment: unconfirmed; do not use or test any credentials.

### 111. P1_REVIEW_FIRST — kristinagligoric/cdi-tutorial

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/kristinagligoric/cdi-tutorial/blob/82053814503bcdcf53625310752c54b790d26822/credentials.txt
- Repository URL: https://github.com/kristinagligoric/cdi-tutorial
- Assessment: unconfirmed; do not use or test any credentials.

### 112. P1_REVIEW_FIRST — labgadget015-dotcom/autonomous-github-agent

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/labgadget015-dotcom/autonomous-github-agent/blob/d70791753a147b3d328e42c58d40d8fc1b4ed780/.env.txt
- Repository URL: https://github.com/labgadget015-dotcom/autonomous-github-agent
- Assessment: unconfirmed; do not use or test any credentials.

### 113. P1_REVIEW_FIRST — lacchain/vc-repository

- Path: `credentials.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/lacchain/vc-repository/blob/b6566a24588f0c66aee0c330b62cfce6c81d1943/credentials.md
- Repository URL: https://github.com/lacchain/vc-repository
- Assessment: unconfirmed; do not use or test any credentials.

### 114. P1_REVIEW_FIRST — lendroidproject/lendroid-ens-loan

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/lendroidproject/lendroid-ens-loan/blob/86e94c2c82b60e5c60926eb0ff41e703f89887ed/credentials.txt
- Repository URL: https://github.com/lendroidproject/lendroid-ens-loan
- Assessment: unconfirmed; do not use or test any credentials.

### 115. P1_REVIEW_FIRST — lrlrlrlr/COMP3331_9331_22t2

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/lrlrlrlr/COMP3331_9331_22t2/blob/2689842be9efdd47dd1396c86b5ed990b64063df/credentials.txt
- Repository URL: https://github.com/lrlrlrlr/COMP3331_9331_22t2
- Assessment: unconfirmed; do not use or test any credentials.

### 116. P1_REVIEW_FIRST — luizeduardo7/sawtooth-water-grant

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/luizeduardo7/sawtooth-water-grant/blob/14ce91161a1d33c8a2bfe24d765cb9e4518e2931/credentials.txt
- Repository URL: https://github.com/luizeduardo7/sawtooth-water-grant
- Assessment: unconfirmed; do not use or test any credentials.

### 117. P1_REVIEW_FIRST — maurosoft1973/Docker-Alpine-LFTP

- Path: `.env.3.18.9`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/maurosoft1973/Docker-Alpine-LFTP/blob/21f1873a37c2978aad98081434cf10a3d5ae82e0/.env.3.18.9
- Repository URL: https://github.com/maurosoft1973/Docker-Alpine-LFTP
- Assessment: unconfirmed; do not use or test any credentials.

### 118. P1_REVIEW_FIRST — maurosoft1973/Docker-Alpine-LFTP

- Path: `.env.3.19.4`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/maurosoft1973/Docker-Alpine-LFTP/blob/21f1873a37c2978aad98081434cf10a3d5ae82e0/.env.3.19.4
- Repository URL: https://github.com/maurosoft1973/Docker-Alpine-LFTP
- Assessment: unconfirmed; do not use or test any credentials.

### 119. P1_REVIEW_FIRST — maurosoft1973/Docker-Alpine-LFTP

- Path: `.env.3.20.3`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/maurosoft1973/Docker-Alpine-LFTP/blob/21f1873a37c2978aad98081434cf10a3d5ae82e0/.env.3.20.3
- Repository URL: https://github.com/maurosoft1973/Docker-Alpine-LFTP
- Assessment: unconfirmed; do not use or test any credentials.

### 120. P1_REVIEW_FIRST — maurosoft1973/Docker-Alpine-MariaDB

- Path: `.env.3.18.9`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/maurosoft1973/Docker-Alpine-MariaDB/blob/0194e1729ad5b2406045308d231d32de03279800/.env.3.18.9
- Repository URL: https://github.com/maurosoft1973/Docker-Alpine-MariaDB
- Assessment: unconfirmed; do not use or test any credentials.

### 121. P1_REVIEW_FIRST — maurosoft1973/Docker-Alpine-MariaDB

- Path: `.env.3.19.4`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/maurosoft1973/Docker-Alpine-MariaDB/blob/0194e1729ad5b2406045308d231d32de03279800/.env.3.19.4
- Repository URL: https://github.com/maurosoft1973/Docker-Alpine-MariaDB
- Assessment: unconfirmed; do not use or test any credentials.

### 122. P1_REVIEW_FIRST — maurosoft1973/Docker-Alpine-MariaDB

- Path: `.env.3.20.3`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/maurosoft1973/Docker-Alpine-MariaDB/blob/0194e1729ad5b2406045308d231d32de03279800/.env.3.20.3
- Repository URL: https://github.com/maurosoft1973/Docker-Alpine-MariaDB
- Assessment: unconfirmed; do not use or test any credentials.

### 123. P1_REVIEW_FIRST — maurosoft1973/Docker-Alpine-Postfix-Relay

- Path: `.env.3.15.1`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/maurosoft1973/Docker-Alpine-Postfix-Relay/blob/adcff107c406c802504afe7cfa771d2d7c6407d9/.env.3.15.1
- Repository URL: https://github.com/maurosoft1973/Docker-Alpine-Postfix-Relay
- Assessment: unconfirmed; do not use or test any credentials.

### 124. P1_REVIEW_FIRST — maurosoft1973/Docker-Alpine-Postfix-Relay

- Path: `.env.3.15.3`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/maurosoft1973/Docker-Alpine-Postfix-Relay/blob/adcff107c406c802504afe7cfa771d2d7c6407d9/.env.3.15.3
- Repository URL: https://github.com/maurosoft1973/Docker-Alpine-Postfix-Relay
- Assessment: unconfirmed; do not use or test any credentials.

### 125. P1_REVIEW_FIRST — maurosoft1973/Docker-Alpine-Postfix-Relay

- Path: `.env.3.15.4`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/maurosoft1973/Docker-Alpine-Postfix-Relay/blob/adcff107c406c802504afe7cfa771d2d7c6407d9/.env.3.15.4
- Repository URL: https://github.com/maurosoft1973/Docker-Alpine-Postfix-Relay
- Assessment: unconfirmed; do not use or test any credentials.

### 126. P1_REVIEW_FIRST — maurosoft1973/Docker-Alpine-Postfix-Relay

- Path: `.env.3.16.1`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/maurosoft1973/Docker-Alpine-Postfix-Relay/blob/adcff107c406c802504afe7cfa771d2d7c6407d9/.env.3.16.1
- Repository URL: https://github.com/maurosoft1973/Docker-Alpine-Postfix-Relay
- Assessment: unconfirmed; do not use or test any credentials.

### 127. P1_REVIEW_FIRST — maurosoft1973/Docker-Alpine-Postfix-Relay

- Path: `.env.3.16.2`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/maurosoft1973/Docker-Alpine-Postfix-Relay/blob/adcff107c406c802504afe7cfa771d2d7c6407d9/.env.3.16.2
- Repository URL: https://github.com/maurosoft1973/Docker-Alpine-Postfix-Relay
- Assessment: unconfirmed; do not use or test any credentials.

### 128. P1_REVIEW_FIRST — maurosoft1973/Docker-Alpine-Postfix-Relay

- Path: `.env.3.16.3`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/maurosoft1973/Docker-Alpine-Postfix-Relay/blob/adcff107c406c802504afe7cfa771d2d7c6407d9/.env.3.16.3
- Repository URL: https://github.com/maurosoft1973/Docker-Alpine-Postfix-Relay
- Assessment: unconfirmed; do not use or test any credentials.

### 129. P1_REVIEW_FIRST — maurosoft1973/Docker-Alpine-Postfix-Relay

- Path: `.env.3.17.1`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/maurosoft1973/Docker-Alpine-Postfix-Relay/blob/adcff107c406c802504afe7cfa771d2d7c6407d9/.env.3.17.1
- Repository URL: https://github.com/maurosoft1973/Docker-Alpine-Postfix-Relay
- Assessment: unconfirmed; do not use or test any credentials.

### 130. P1_REVIEW_FIRST — maurosoft1973/Docker-Alpine-Postfix-Relay

- Path: `.env.3.17.3`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/maurosoft1973/Docker-Alpine-Postfix-Relay/blob/adcff107c406c802504afe7cfa771d2d7c6407d9/.env.3.17.3
- Repository URL: https://github.com/maurosoft1973/Docker-Alpine-Postfix-Relay
- Assessment: unconfirmed; do not use or test any credentials.

### 131. P1_REVIEW_FIRST — megalus/django-google-sso

- Path: `docs/credentials.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/megalus/django-google-sso/blob/f5af8a24f36432411cd405825dbd66315c0addd8/docs/credentials.md
- Repository URL: https://github.com/megalus/django-google-sso
- Assessment: unconfirmed; do not use or test any credentials.

### 132. P1_REVIEW_FIRST — megazordpobeda/DataRush

- Path: `CREDENTIALS.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/megazordpobeda/DataRush/blob/f0bd43a1dd1acb8a9855984eb3fe71e5e0106a3f/CREDENTIALS.md
- Repository URL: https://github.com/megazordpobeda/DataRush
- Assessment: unconfirmed; do not use or test any credentials.

### 133. P1_REVIEW_FIRST — meteor-factory/processes

- Path: `Credentials.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/meteor-factory/processes/blob/d999b235ac79e654d51340c1961fa04306a7257c/Credentials.md
- Repository URL: https://github.com/meteor-factory/processes
- Assessment: unconfirmed; do not use or test any credentials.

### 134. P1_REVIEW_FIRST — michalpiasecki0/BSc-soccer-annotator

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/michalpiasecki0/BSc-soccer-annotator/blob/0cfb0692f859d15bd757502c89a6f425d2fbf5f1/.env.txt
- Repository URL: https://github.com/michalpiasecki0/BSc-soccer-annotator
- Assessment: unconfirmed; do not use or test any credentials.

### 135. P1_REVIEW_FIRST — michalpiasecki0/BSc-soccer-annotator

- Path: `ui/.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/michalpiasecki0/BSc-soccer-annotator/blob/0cfb0692f859d15bd757502c89a6f425d2fbf5f1/ui/.env.txt
- Repository URL: https://github.com/michalpiasecki0/BSc-soccer-annotator
- Assessment: unconfirmed; do not use or test any credentials.

### 136. P1_REVIEW_FIRST — mozammal89/azadijobs

- Path: `Credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/mozammal89/azadijobs/blob/b7efb7ad1fc14caaaacde6283ac02798ecdd8f17/Credentials.txt
- Repository URL: https://github.com/mozammal89/azadijobs
- Assessment: unconfirmed; do not use or test any credentials.

### 137. P1_REVIEW_FIRST — mrbeels/instagram-story-poster-bot

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/mrbeels/instagram-story-poster-bot/blob/2f5546968e63fe50f6d79d9e983897fd325f1f5e/credentials.txt
- Repository URL: https://github.com/mrbeels/instagram-story-poster-bot
- Assessment: unconfirmed; do not use or test any credentials.

### 138. P1_REVIEW_FIRST — muchdogesec/arango_cve_processor

- Path: `.env.markdown`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/muchdogesec/arango_cve_processor/blob/c06eecb4baee5971c299284731dc96c378909067/.env.markdown
- Repository URL: https://github.com/muchdogesec/arango_cve_processor
- Assessment: unconfirmed; do not use or test any credentials.

### 139. P1_REVIEW_FIRST — muchdogesec/arango_taxii_server

- Path: `.env.markdown`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/muchdogesec/arango_taxii_server/blob/abc9d3431def0f2027593d42891969436ff3fa84/.env.markdown
- Repository URL: https://github.com/muchdogesec/arango_taxii_server
- Assessment: unconfirmed; do not use or test any credentials.

### 140. P1_REVIEW_FIRST — muchdogesec/stix2arango

- Path: `.env.markdown`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/muchdogesec/stix2arango/blob/f2dddc36af4f8e6408433e9fcabb34f6990023df/.env.markdown
- Repository URL: https://github.com/muchdogesec/stix2arango
- Assessment: unconfirmed; do not use or test any credentials.

### 141. P1_REVIEW_FIRST — muchdogesec/txt2detection

- Path: `.env.markdown`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/muchdogesec/txt2detection/blob/5f51c5957638865452ebd440bb52a947abdc2909/.env.markdown
- Repository URL: https://github.com/muchdogesec/txt2detection
- Assessment: unconfirmed; do not use or test any credentials.

### 142. P1_REVIEW_FIRST — muchdogesec/txt2stix

- Path: `.env.markdown`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/muchdogesec/txt2stix/blob/625932d0455390cf349175ef5c77c75b29f87b3d/.env.markdown
- Repository URL: https://github.com/muchdogesec/txt2stix
- Assessment: unconfirmed; do not use or test any credentials.

### 143. P1_REVIEW_FIRST — muchdogesec/vulmatch

- Path: `.env.markdown`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/muchdogesec/vulmatch/blob/b242d59593b7bcfe99866ceb0d71c6f02d7eabb4/.env.markdown
- Repository URL: https://github.com/muchdogesec/vulmatch
- Assessment: unconfirmed; do not use or test any credentials.

### 144. P1_REVIEW_FIRST — muhammadwasi81/mern-ecommerce

- Path: `.env.md`
- Indicator: `secret_assignment;credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/muhammadwasi81/mern-ecommerce/blob/f2a7af3082e80adc1bf2318fbbe5909a8cc09555/.env.md
- Repository URL: https://github.com/muhammadwasi81/mern-ecommerce
- Assessment: unconfirmed; do not use or test any credentials.

### 145. P1_REVIEW_FIRST — mython-dev/ssh-brute-force

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/mython-dev/ssh-brute-force/blob/0147673c8b3ef6ec619d3c752b76d7dc11a7bd79/credentials.txt
- Repository URL: https://github.com/mython-dev/ssh-brute-force
- Assessment: unconfirmed; do not use or test any credentials.

### 146. P1_REVIEW_FIRST — nborrmann/gcmreverse

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/nborrmann/gcmreverse/blob/c6c74028aa92a2650e2577691c756dd5c98e7530/credentials.txt
- Repository URL: https://github.com/nborrmann/gcmreverse
- Assessment: unconfirmed; do not use or test any credentials.

### 147. P1_REVIEW_FIRST — neoLsH/gbpx_gd_gov

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/neoLsH/gbpx_gd_gov/blob/61d8c0a697e8effddc20f48d0369e12642288e77/credentials.txt
- Repository URL: https://github.com/neoLsH/gbpx_gd_gov
- Assessment: unconfirmed; do not use or test any credentials.

### 148. P1_REVIEW_FIRST — nishchal-gond/ORMS

- Path: `CREDEntials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/nishchal-gond/ORMS/blob/02587aac6ac718f9078c125816273e589161b917/CREDEntials.txt
- Repository URL: https://github.com/nishchal-gond/ORMS
- Assessment: unconfirmed; do not use or test any credentials.

### 149. P1_REVIEW_FIRST — nodebeats/nodebeats

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/nodebeats/nodebeats/blob/c0a431deb3f3359798f84a85f4b0f0a4b21cf28d/credentials.txt
- Repository URL: https://github.com/nodebeats/nodebeats
- Assessment: unconfirmed; do not use or test any credentials.

### 150. P1_REVIEW_FIRST — opsdisk/coressh

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/opsdisk/coressh/blob/8ed6d86c54eca83fd5e9f76e0891f5e0dbbffaba/credentials.txt
- Repository URL: https://github.com/opsdisk/coressh
- Assessment: unconfirmed; do not use or test any credentials.

### 151. P1_REVIEW_FIRST — pajikos/sms-gammu-gateway

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/pajikos/sms-gammu-gateway/blob/4a45500e5beeb023280cbabb555887a46cbffd3f/credentials.txt
- Repository URL: https://github.com/pajikos/sms-gammu-gateway
- Assessment: unconfirmed; do not use or test any credentials.

### 152. P1_REVIEW_FIRST — pearlsteinj/PennApps2014s

- Path: `Credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/pearlsteinj/PennApps2014s/blob/d796d626ea4bdb3d2d0270b702c83f981a46f506/Credentials.txt
- Repository URL: https://github.com/pearlsteinj/PennApps2014s
- Assessment: unconfirmed; do not use or test any credentials.

### 153. P1_REVIEW_FIRST — pelagecha/LLM-Agents

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/pelagecha/LLM-Agents/blob/a4c5640e499f585a0ee05a703e2bfad5efc78c3d/.env.txt
- Repository URL: https://github.com/pelagecha/LLM-Agents
- Assessment: unconfirmed; do not use or test any credentials.

### 154. P1_REVIEW_FIRST — pl4g4/netflix-account-check

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/pl4g4/netflix-account-check/blob/17750b8a88df74bc21d57c3be905e86f9798261e/credentials.txt
- Repository URL: https://github.com/pl4g4/netflix-account-check
- Assessment: unconfirmed; do not use or test any credentials.

### 155. P1_REVIEW_FIRST — prutxvi/gesture-drop

- Path: `.env.batch2.3`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/prutxvi/gesture-drop/blob/1361cfab48d355dfad28d1faba2f4cd5673f6958/.env.batch2.3
- Repository URL: https://github.com/prutxvi/gesture-drop
- Assessment: unconfirmed; do not use or test any credentials.

### 156. P1_REVIEW_FIRST — quintel/etlauncher

- Path: `CREDENTIALS.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/quintel/etlauncher/blob/da5eae6a5adb0210faa527487c93af46e7b1f02e/CREDENTIALS.md
- Repository URL: https://github.com/quintel/etlauncher
- Assessment: unconfirmed; do not use or test any credentials.

### 157. P1_REVIEW_FIRST — restorecommerce/payment-srv

- Path: `credentials.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/restorecommerce/payment-srv/blob/4b5cf33a10c77ef141770bd6bf14c7e2f64afea9/credentials.md
- Repository URL: https://github.com/restorecommerce/payment-srv
- Assessment: unconfirmed; do not use or test any credentials.

### 158. P1_REVIEW_FIRST — rimmelasghar/twitter-scrapper

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/rimmelasghar/twitter-scrapper/blob/881b3a6f097a433deb7afafb2cd3e81e4478b18d/credentials.txt
- Repository URL: https://github.com/rimmelasghar/twitter-scrapper
- Assessment: unconfirmed; do not use or test any credentials.

### 159. P1_REVIEW_FIRST — rjsebening/n8n-nodes-leadtable

- Path: `CREDENTIALS.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/rjsebening/n8n-nodes-leadtable/blob/f815c74742a63ea601394d8e5e539ca231887c42/CREDENTIALS.md
- Repository URL: https://github.com/rjsebening/n8n-nodes-leadtable
- Assessment: unconfirmed; do not use or test any credentials.

### 160. P1_REVIEW_FIRST — rodentskie/api_clean_architecture

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/rodentskie/api_clean_architecture/blob/925f991bf9affc871695429720a9d359866d8775/.env.txt
- Repository URL: https://github.com/rodentskie/api_clean_architecture
- Assessment: unconfirmed; do not use or test any credentials.

### 161. P1_REVIEW_FIRST — rodentskie/api_typescript

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/rodentskie/api_typescript/blob/3609bc52c8df8845a9883c857cf41ac0d44be870/.env.txt
- Repository URL: https://github.com/rodentskie/api_typescript
- Assessment: unconfirmed; do not use or test any credentials.

### 162. P1_REVIEW_FIRST — ruOpenCart/opencart3-webpack-theme

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/ruOpenCart/opencart3-webpack-theme/blob/b9ec712c2b4fc442afcdcb4138460037264c5c0d/.env.txt
- Repository URL: https://github.com/ruOpenCart/opencart3-webpack-theme
- Assessment: unconfirmed; do not use or test any credentials.

### 163. P1_REVIEW_FIRST — sahad-mk/FireVu

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/sahad-mk/FireVu/blob/087e7ad1c412309befb3960ed832e460e1b47b0a/credentials.txt
- Repository URL: https://github.com/sahad-mk/FireVu
- Assessment: unconfirmed; do not use or test any credentials.

### 164. P1_REVIEW_FIRST — sandipanparia/SoulChat

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/sandipanparia/SoulChat/blob/19fd3929fe6fe94ee1c9ebfee1dd0a06ee32bef1/credentials.txt
- Repository URL: https://github.com/sandipanparia/SoulChat
- Assessment: unconfirmed; do not use or test any credentials.

### 165. P1_REVIEW_FIRST — sh1katagana1/osint

- Path: `credentials.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/sh1katagana1/osint/blob/730a045be17c4db9f1cc651d04a9a406282a405d/credentials.md
- Repository URL: https://github.com/sh1katagana1/osint
- Assessment: unconfirmed; do not use or test any credentials.

### 166. P1_REVIEW_FIRST — shari-sushi/V-Kara-Lists

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/shari-sushi/V-Kara-Lists/blob/7c2096eb63d9d55c2f99c863a343863e056e5947/.env.txt
- Repository URL: https://github.com/shari-sushi/V-Kara-Lists
- Assessment: unconfirmed; do not use or test any credentials.

### 167. P1_REVIEW_FIRST — shawn-sandy/fp-kit

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/shawn-sandy/fp-kit/blob/154e4483640ac2e2af4a425da4766ef066318e92/.env.txt
- Repository URL: https://github.com/shawn-sandy/fp-kit
- Assessment: unconfirmed; do not use or test any credentials.

### 168. P1_REVIEW_FIRST — sherzo/orisa

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/sherzo/orisa/blob/74b07f5057168ccc18af19bc9e150055e21d1ab4/.env.txt
- Repository URL: https://github.com/sherzo/orisa
- Assessment: unconfirmed; do not use or test any credentials.

### 169. P1_REVIEW_FIRST — siteslave/express-onefile

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/siteslave/express-onefile/blob/2005121c4255d78dfcc5dbd833f1a078c9e3eba3/.env.txt
- Repository URL: https://github.com/siteslave/express-onefile
- Assessment: unconfirmed; do not use or test any credentials.

### 170. P1_REVIEW_FIRST — solomongetnet/instagram-clone

- Path: `client/.env.md`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/solomongetnet/instagram-clone/blob/71218fbe8a11e2b5011ac7f10efd1dfc82685d46/client/.env.md
- Repository URL: https://github.com/solomongetnet/instagram-clone
- Assessment: unconfirmed; do not use or test any credentials.

### 171. P1_REVIEW_FIRST — soumyadeeptadas/SecureShare

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/soumyadeeptadas/SecureShare/blob/5f15048a22c66576bb22d3064b095e7af3f51ad5/credentials.txt
- Repository URL: https://github.com/soumyadeeptadas/SecureShare
- Assessment: unconfirmed; do not use or test any credentials.

### 172. P1_REVIEW_FIRST — starwave-protocol/starwaveprotocol

- Path: `.env.2`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/starwave-protocol/starwaveprotocol/blob/2d1808c1e8f07060f1fe019a59026bf48b682b7e/.env.2
- Repository URL: https://github.com/starwave-protocol/starwaveprotocol
- Assessment: unconfirmed; do not use or test any credentials.

### 173. P1_REVIEW_FIRST — starwave-protocol/starwaveprotocol

- Path: `.env.3`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/starwave-protocol/starwaveprotocol/blob/2d1808c1e8f07060f1fe019a59026bf48b682b7e/.env.3
- Repository URL: https://github.com/starwave-protocol/starwaveprotocol
- Assessment: unconfirmed; do not use or test any credentials.

### 174. P1_REVIEW_FIRST — swarm64/s64da-compose

- Path: `.env`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/swarm64/s64da-compose/blob/a56d16ef2e517c74aca09a7e40a18b8472f4cf52/.env
- Repository URL: https://github.com/swarm64/s64da-compose
- Assessment: unconfirmed; do not use or test any credentials.

### 175. P1_REVIEW_FIRST — tabaresjc/HeadUP

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/tabaresjc/HeadUP/blob/f73d54dd5115166a0032ff7e23bd91d07eae6e39/.env.txt
- Repository URL: https://github.com/tabaresjc/HeadUP
- Assessment: unconfirmed; do not use or test any credentials.

### 176. P1_REVIEW_FIRST — tald7344/laravel-exams

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/tald7344/laravel-exams/blob/8f418aae4c5747a2a92101a822a53e76c99f74f5/credentials.txt
- Repository URL: https://github.com/tald7344/laravel-exams
- Assessment: unconfirmed; do not use or test any credentials.

### 177. P1_REVIEW_FIRST — teramotodaiki/youtube-to-twitter

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/teramotodaiki/youtube-to-twitter/blob/afab891c85aea317289c7dc064bde77c63295c7a/.env.txt
- Repository URL: https://github.com/teramotodaiki/youtube-to-twitter
- Assessment: unconfirmed; do not use or test any credentials.

### 178. P1_REVIEW_FIRST — tnotesjs/en-words

- Path: `credentials.md`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/tnotesjs/en-words/blob/4fbfa84287de34f2d4692d8bf549fdf8ef381c90/credentials.md
- Repository URL: https://github.com/tnotesjs/en-words
- Assessment: unconfirmed; do not use or test any credentials.

### 179. P1_REVIEW_FIRST — translated/echo-server

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/translated/echo-server/blob/4022431d527cd5e55b70b36be796c610af533a90/.env.txt
- Repository URL: https://github.com/translated/echo-server
- Assessment: unconfirmed; do not use or test any credentials.

### 180. P1_REVIEW_FIRST — tsjensen/protonmail-bridge-docker

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/tsjensen/protonmail-bridge-docker/blob/f4acd1d0adcf628dcec36c98dee98e9d6158021f/credentials.txt
- Repository URL: https://github.com/tsjensen/protonmail-bridge-docker
- Assessment: unconfirmed; do not use or test any credentials.

### 181. P1_REVIEW_FIRST — tundx0/Telegram-mass-sender

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/tundx0/Telegram-mass-sender/blob/1eae2d5b9b78d70cc7ea22fb2db9e45eba56b4c5/credentials.txt
- Repository URL: https://github.com/tundx0/Telegram-mass-sender
- Assessment: unconfirmed; do not use or test any credentials.

### 182. P1_REVIEW_FIRST — verbocity/streaming

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/verbocity/streaming/blob/bc1a29f8c20d7b161ea516748a79dcd30480f1c2/credentials.txt
- Repository URL: https://github.com/verbocity/streaming
- Assessment: unconfirmed; do not use or test any credentials.

### 183. P1_REVIEW_FIRST — victoni/elasticsearch2

- Path: `.env.1`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/victoni/elasticsearch2/blob/dea22e91446f12247f9d4ac281d023893b33d7a5/.env.1
- Repository URL: https://github.com/victoni/elasticsearch2
- Assessment: unconfirmed; do not use or test any credentials.

### 184. P1_REVIEW_FIRST — web3-identity/cns-metadata-service

- Path: `.env.org`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/web3-identity/cns-metadata-service/blob/0b388cb8e954dcfc03151d8af5fc84f3e52973ef/.env.org
- Repository URL: https://github.com/web3-identity/cns-metadata-service
- Assessment: unconfirmed; do not use or test any credentials.

### 185. P1_REVIEW_FIRST — whyorean/AASTokenGrabber

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/whyorean/AASTokenGrabber/blob/ab1835cd6c726b671f541c909c852e59bfed36f0/credentials.txt
- Repository URL: https://github.com/whyorean/AASTokenGrabber
- Assessment: unconfirmed; do not use or test any credentials.

### 186. P1_REVIEW_FIRST — willywill/ladda

- Path: `.env.md`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/willywill/ladda/blob/4a2fad8265fe1ab341f3730aa22cec6fa9e30767/.env.md
- Repository URL: https://github.com/willywill/ladda
- Assessment: unconfirmed; do not use or test any credentials.

### 187. P1_REVIEW_FIRST — yoscruizer/hack-wifi-zte-f609

- Path: `credentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/yoscruizer/hack-wifi-zte-f609/blob/d11c39f987c3da995c9a716039352c5ebaf67476/credentials.txt
- Repository URL: https://github.com/yoscruizer/hack-wifi-zte-f609
- Assessment: unconfirmed; do not use or test any credentials.

### 188. P1_REVIEW_FIRST — youngaileaderslinz/rag-sec-filling

- Path: `.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 4 (not severity)
- File URL: https://github.com/youngaileaderslinz/rag-sec-filling/blob/cc158f6dbdd1a97c4ad4951c71e23e72ae386e8f/.env.txt
- Repository URL: https://github.com/youngaileaderslinz/rag-sec-filling
- Assessment: unconfirmed; do not use or test any credentials.

### 189. P2_REVIEW — 4linux/540

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/4linux/540/blob/637b0b82463855dde3c3829b891de411c2b00588/id_rsa
- Repository URL: https://github.com/4linux/540
- Assessment: unconfirmed; do not use or test any credentials.

### 190. P2_REVIEW — ASGGroupVic/hackathon-neo4j

- Path: `ssh/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/ASGGroupVic/hackathon-neo4j/blob/befef4d510c3ede51ff51787ce047ba2e2d994fc/ssh/id_rsa
- Repository URL: https://github.com/ASGGroupVic/hackathon-neo4j
- Assessment: unconfirmed; do not use or test any credentials.

### 191. P2_REVIEW — AbdulAHAD968/IAC-Using-Docker-and-Python

- Path: `keys/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/AbdulAHAD968/IAC-Using-Docker-and-Python/blob/c59181a5a0804c38ba2dec745299752845f6a685/keys/id_rsa
- Repository URL: https://github.com/AbdulAHAD968/IAC-Using-Docker-and-Python
- Assessment: unconfirmed; do not use or test any credentials.

### 192. P2_REVIEW — Akash701/Docker-App-Deployment

- Path: `terraform.tfstate.1748562400.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/Akash701/Docker-App-Deployment/blob/36b32906ec1107d1bf6bf22d164328fa924a938e/terraform.tfstate.1748562400.backup
- Repository URL: https://github.com/Akash701/Docker-App-Deployment
- Assessment: unconfirmed; do not use or test any credentials.

### 193. P2_REVIEW — AlexandreRozier/BigDataAnalytics

- Path: `terraform/terraform.tfstate.1550051764.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/AlexandreRozier/BigDataAnalytics/blob/50ac5fe0d87d29a1938b9f19c3785baa59e0b83e/terraform/terraform.tfstate.1550051764.backup
- Repository URL: https://github.com/AlexandreRozier/BigDataAnalytics
- Assessment: unconfirmed; do not use or test any credentials.

### 194. P2_REVIEW — AlexandreRozier/BigDataAnalytics

- Path: `terraform/terraform.tfstate.1550751877.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/AlexandreRozier/BigDataAnalytics/blob/50ac5fe0d87d29a1938b9f19c3785baa59e0b83e/terraform/terraform.tfstate.1550751877.backup
- Repository URL: https://github.com/AlexandreRozier/BigDataAnalytics
- Assessment: unconfirmed; do not use or test any credentials.

### 195. P2_REVIEW — Alexitu01/DevOps_Ducks

- Path: `terraform.tfstate.1776096348.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/Alexitu01/DevOps_Ducks/blob/4aeed5e217f0f7149f3da05878ed7c9cb1a701dc/terraform.tfstate.1776096348.backup
- Repository URL: https://github.com/Alexitu01/DevOps_Ducks
- Assessment: unconfirmed; do not use or test any credentials.

### 196. P2_REVIEW — CSUDUC/intellDrilling

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/CSUDUC/intellDrilling/blob/ce22f9afa6222ce7569fd6cab6c4059f7134b7c9/id_rsa
- Repository URL: https://github.com/CSUDUC/intellDrilling
- Assessment: unconfirmed; do not use or test any credentials.

### 197. P2_REVIEW — CameronBadman/Hippocampus

- Path: `terraform/terraform.tfstate.1760872188.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/CameronBadman/Hippocampus/blob/7fe56a7b56993ffd51980e20e684a575388abefa/terraform/terraform.tfstate.1760872188.backup
- Repository URL: https://github.com/CameronBadman/Hippocampus
- Assessment: unconfirmed; do not use or test any credentials.

### 198. P2_REVIEW — CameronBadman/Hippocampus

- Path: `terraform/terraform.tfstate.1760872192.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/CameronBadman/Hippocampus/blob/7fe56a7b56993ffd51980e20e684a575388abefa/terraform/terraform.tfstate.1760872192.backup
- Repository URL: https://github.com/CameronBadman/Hippocampus
- Assessment: unconfirmed; do not use or test any credentials.

### 199. P2_REVIEW — CidQueiroz/cdkteck-infra

- Path: `terraform.tfstate.1762475125.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/CidQueiroz/cdkteck-infra/blob/ff3078ca2827a6168b78db5a601107fdd28f9656/terraform.tfstate.1762475125.backup
- Repository URL: https://github.com/CidQueiroz/cdkteck-infra
- Assessment: unconfirmed; do not use or test any credentials.

### 200. P2_REVIEW — DevOpsCapeTown/AnsibleWorkshop

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/DevOpsCapeTown/AnsibleWorkshop/blob/991ccb7be76c4c0814364a1d8d01eeba53b0e409/id_rsa
- Repository URL: https://github.com/DevOpsCapeTown/AnsibleWorkshop
- Assessment: unconfirmed; do not use or test any credentials.

### 201. P2_REVIEW — Edderic/breathesafe

- Path: `infra/terraform.tfstate.1774446520.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/Edderic/breathesafe/blob/7fefb822b0ebd8ae5908036046dfb513b2b4f05b/infra/terraform.tfstate.1774446520.backup
- Repository URL: https://github.com/Edderic/breathesafe
- Assessment: unconfirmed; do not use or test any credentials.

### 202. P2_REVIEW — Edderic/breathesafe

- Path: `infra/terraform.tfstate.1774446526.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/Edderic/breathesafe/blob/7fefb822b0ebd8ae5908036046dfb513b2b4f05b/infra/terraform.tfstate.1774446526.backup
- Repository URL: https://github.com/Edderic/breathesafe
- Assessment: unconfirmed; do not use or test any credentials.

### 203. P2_REVIEW — Edderic/breathesafe

- Path: `infra/terraform.tfstate.1774446530.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/Edderic/breathesafe/blob/7fefb822b0ebd8ae5908036046dfb513b2b4f05b/infra/terraform.tfstate.1774446530.backup
- Repository URL: https://github.com/Edderic/breathesafe
- Assessment: unconfirmed; do not use or test any credentials.

### 204. P2_REVIEW — Flor91/AWS-Cloud-Practices

- Path: `trabajo-integrador/terraform/terraform.tfstate.1597773127.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/Flor91/AWS-Cloud-Practices/blob/d1befdfdbaa1b286baeb1fe2ae001b7ede178e39/trabajo-integrador/terraform/terraform.tfstate.1597773127.backup
- Repository URL: https://github.com/Flor91/AWS-Cloud-Practices
- Assessment: unconfirmed; do not use or test any credentials.

### 205. P2_REVIEW — FrelDX/kcos

- Path: `key/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/FrelDX/kcos/blob/6f50dc09000a404baec3e9910fb088e176c2020d/key/id_rsa
- Repository URL: https://github.com/FrelDX/kcos
- Assessment: unconfirmed; do not use or test any credentials.

### 206. P2_REVIEW — IMPIMBA/vagrant-mesh-net

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/IMPIMBA/vagrant-mesh-net/blob/62d05ed6171b79304a0009277a3c88dab06e5bb3/id_rsa
- Repository URL: https://github.com/IMPIMBA/vagrant-mesh-net
- Assessment: unconfirmed; do not use or test any credentials.

### 207. P2_REVIEW — Ima8/Jump_into_DevOps_world

- Path: `ssh/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/Ima8/Jump_into_DevOps_world/blob/f54d19d32dfca42441d0fadb34dc6d04e8edd4cf/ssh/id_rsa
- Repository URL: https://github.com/Ima8/Jump_into_DevOps_world
- Assessment: unconfirmed; do not use or test any credentials.

### 208. P2_REVIEW — Iteam1337/raspberry-pi-swarm-cluster

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/Iteam1337/raspberry-pi-swarm-cluster/blob/06d39847ddaccaa2f6eba3384aaa571297ce7bed/id_rsa
- Repository URL: https://github.com/Iteam1337/raspberry-pi-swarm-cluster
- Assessment: unconfirmed; do not use or test any credentials.

### 209. P2_REVIEW — MaartenSmeets/k8s-prov

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/MaartenSmeets/k8s-prov/blob/80811387a92707e0b8538cd5a0bd9af075a207ae/id_rsa
- Repository URL: https://github.com/MaartenSmeets/k8s-prov
- Assessment: unconfirmed; do not use or test any credentials.

### 210. P2_REVIEW — Maddiezheng/LTA_CarParkAvailability_DE_Project

- Path: `terraform/terraform.tfstate.1742893120.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/Maddiezheng/LTA_CarParkAvailability_DE_Project/blob/d1f6111639b48256016ed5d49f670a67da24bc34/terraform/terraform.tfstate.1742893120.backup
- Repository URL: https://github.com/Maddiezheng/LTA_CarParkAvailability_DE_Project
- Assessment: unconfirmed; do not use or test any credentials.

### 211. P2_REVIEW — MaineK00n/vuls-targets

- Path: `.ssh/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/MaineK00n/vuls-targets/blob/a39dd5f26b7428adda3ff5cc4b06ae0f8ec66d4a/.ssh/id_rsa
- Repository URL: https://github.com/MaineK00n/vuls-targets
- Assessment: unconfirmed; do not use or test any credentials.

### 212. P2_REVIEW — NLKNguyen/alpine-mpich-cluster

- Path: `ssh/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/NLKNguyen/alpine-mpich-cluster/blob/2ba95f2b647ca6581fe64ee18f37a582686f2dcd/ssh/id_rsa
- Repository URL: https://github.com/NLKNguyen/alpine-mpich-cluster
- Assessment: unconfirmed; do not use or test any credentials.

### 213. P2_REVIEW — Naveen15github/Infrastructure-Drift-Detection-Compliance-AI-Agent

- Path: `terraform.tfstate.s3`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/Naveen15github/Infrastructure-Drift-Detection-Compliance-AI-Agent/blob/b2281281174aab0d7fe4b7a6a8163b60fe5f8677/terraform.tfstate.s3
- Repository URL: https://github.com/Naveen15github/Infrastructure-Drift-Detection-Compliance-AI-Agent
- Assessment: unconfirmed; do not use or test any credentials.

### 214. P2_REVIEW — NervesJP/nerves-algyan-devcontainer

- Path: `.ssh/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/NervesJP/nerves-algyan-devcontainer/blob/fd08edb2f0d227cce21ebd29241786d8da23eccd/.ssh/id_rsa
- Repository URL: https://github.com/NervesJP/nerves-algyan-devcontainer
- Assessment: unconfirmed; do not use or test any credentials.

### 215. P2_REVIEW — PacktPublishing/Edge-Computing-Systems-with-Kubernetes

- Path: `ch4/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/PacktPublishing/Edge-Computing-Systems-with-Kubernetes/blob/b1948ce556c61af995c80e9a3b730d39107cdd30/ch4/id_rsa
- Repository URL: https://github.com/PacktPublishing/Edge-Computing-Systems-with-Kubernetes
- Assessment: unconfirmed; do not use or test any credentials.

### 216. P2_REVIEW — QualiSystems/Ixia-Chassis-Shell-2G

- Path: `src/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/QualiSystems/Ixia-Chassis-Shell-2G/blob/cd445ffcca7dbd0be2cee7b2a833023630f90da9/src/id_rsa
- Repository URL: https://github.com/QualiSystems/Ixia-Chassis-Shell-2G
- Assessment: unconfirmed; do not use or test any credentials.

### 217. P2_REVIEW — RJMS-Bull/slurm-tutorial

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/RJMS-Bull/slurm-tutorial/blob/e2feb39542e37336e2e9fa9c19fbce8dd60c0a36/id_rsa
- Repository URL: https://github.com/RJMS-Bull/slurm-tutorial
- Assessment: unconfirmed; do not use or test any credentials.

### 218. P2_REVIEW — RendleLabs/eventstore-azure-terraform

- Path: `ssh/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/RendleLabs/eventstore-azure-terraform/blob/3c1557544c94d32c4c5f75ed4a56c07a50b98904/ssh/id_rsa
- Repository URL: https://github.com/RendleLabs/eventstore-azure-terraform
- Assessment: unconfirmed; do not use or test any credentials.

### 219. P2_REVIEW — SalaTymoteusz/FotobudkaRaspberryPi

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/SalaTymoteusz/FotobudkaRaspberryPi/blob/3aed69da7ce605fcb94658bfc33ade251388fa27/id_rsa
- Repository URL: https://github.com/SalaTymoteusz/FotobudkaRaspberryPi
- Assessment: unconfirmed; do not use or test any credentials.

### 220. P2_REVIEW — SamuelGong/FLASHE

- Path: `utils/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/SamuelGong/FLASHE/blob/37a48b067c1439e0daa46630aa543d3f9e1b220f/utils/id_rsa
- Repository URL: https://github.com/SamuelGong/FLASHE
- Assessment: unconfirmed; do not use or test any credentials.

### 221. P2_REVIEW — SeaFlowIce/WA2

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/SeaFlowIce/WA2/blob/bb7383d5288281581f45823f4af355b56e58b91d/id_rsa
- Repository URL: https://github.com/SeaFlowIce/WA2
- Assessment: unconfirmed; do not use or test any credentials.

### 222. P2_REVIEW — Syncano/nodejs-codebox

- Path: `image/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/Syncano/nodejs-codebox/blob/08aee174ac5d582e77fd3dab4f75f5bf5cc9abe9/image/id_rsa
- Repository URL: https://github.com/Syncano/nodejs-codebox
- Assessment: unconfirmed; do not use or test any credentials.

### 223. P2_REVIEW — TUD-INF-IAI-MCI/agsbs_atom_package

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/TUD-INF-IAI-MCI/agsbs_atom_package/blob/86c308742fbca2511b91c5e73df47550922c32ba/id_rsa
- Repository URL: https://github.com/TUD-INF-IAI-MCI/agsbs_atom_package
- Assessment: unconfirmed; do not use or test any credentials.

### 224. P2_REVIEW — TraceNature/redissyncer-server

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/TraceNature/redissyncer-server/blob/c9927901478a809cf81ef3cf8ce4b7e669b36045/id_rsa
- Repository URL: https://github.com/TraceNature/redissyncer-server
- Assessment: unconfirmed; do not use or test any credentials.

### 225. P2_REVIEW — aepod/Magento-Vagrant-Puppet-Sandbox

- Path: `ssh/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/aepod/Magento-Vagrant-Puppet-Sandbox/blob/9140611e4e9a3307de29b0ea605f8797a8c8d3d6/ssh/id_rsa
- Repository URL: https://github.com/aepod/Magento-Vagrant-Puppet-Sandbox
- Assessment: unconfirmed; do not use or test any credentials.

### 226. P2_REVIEW — agaveplatform/jupyter-notebook

- Path: `ssh/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/agaveplatform/jupyter-notebook/blob/3e9af71744337817335ee39960ceb05b6e5f30e1/ssh/id_rsa
- Repository URL: https://github.com/agaveplatform/jupyter-notebook
- Assessment: unconfirmed; do not use or test any credentials.

### 227. P2_REVIEW — alay2003/Grocery-store

- Path: `terraform.tfstate.1729273912.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/alay2003/Grocery-store/blob/297cef6d70494ff0561d171ad734c67b0c09e82a/terraform.tfstate.1729273912.backup
- Repository URL: https://github.com/alay2003/Grocery-store
- Assessment: unconfirmed; do not use or test any credentials.

### 228. P2_REVIEW — alay2003/Grocery-store

- Path: `terraform.tfstate.1729273935.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/alay2003/Grocery-store/blob/297cef6d70494ff0561d171ad734c67b0c09e82a/terraform.tfstate.1729273935.backup
- Repository URL: https://github.com/alay2003/Grocery-store
- Assessment: unconfirmed; do not use or test any credentials.

### 229. P2_REVIEW — alay2003/Grocery-store

- Path: `terraform.tfstate.1729273936.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/alay2003/Grocery-store/blob/297cef6d70494ff0561d171ad734c67b0c09e82a/terraform.tfstate.1729273936.backup
- Repository URL: https://github.com/alay2003/Grocery-store
- Assessment: unconfirmed; do not use or test any credentials.

### 230. P2_REVIEW — amglogicalis/serverless-photo-gallery-aws-terraform

- Path: `terraform.tfstate.1779733964.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/amglogicalis/serverless-photo-gallery-aws-terraform/blob/6254fc3435a1287c26dc02043cbc19ac31460eb0/terraform.tfstate.1779733964.backup
- Repository URL: https://github.com/amglogicalis/serverless-photo-gallery-aws-terraform
- Assessment: unconfirmed; do not use or test any credentials.

### 231. P2_REVIEW — amglogicalis/serverless-photo-gallery-aws-terraform

- Path: `terraform.tfstate.1779734174.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/amglogicalis/serverless-photo-gallery-aws-terraform/blob/6254fc3435a1287c26dc02043cbc19ac31460eb0/terraform.tfstate.1779734174.backup
- Repository URL: https://github.com/amglogicalis/serverless-photo-gallery-aws-terraform
- Assessment: unconfirmed; do not use or test any credentials.

### 232. P2_REVIEW — andresmarinabad/github_mngm

- Path: `terraform.tfstate.1761205616.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/andresmarinabad/github_mngm/blob/0bd10b3b7162d98229a6f1b00f6ef65c8b699de9/terraform.tfstate.1761205616.backup
- Repository URL: https://github.com/andresmarinabad/github_mngm
- Assessment: unconfirmed; do not use or test any credentials.

### 233. P2_REVIEW — andresmarinabad/github_mngm

- Path: `terraform.tfstate.1761205635.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/andresmarinabad/github_mngm/blob/0bd10b3b7162d98229a6f1b00f6ef65c8b699de9/terraform.tfstate.1761205635.backup
- Repository URL: https://github.com/andresmarinabad/github_mngm
- Assessment: unconfirmed; do not use or test any credentials.

### 234. P2_REVIEW — andresmarinabad/github_mngm

- Path: `terraform.tfstate.1761205653.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/andresmarinabad/github_mngm/blob/0bd10b3b7162d98229a6f1b00f6ef65c8b699de9/terraform.tfstate.1761205653.backup
- Repository URL: https://github.com/andresmarinabad/github_mngm
- Assessment: unconfirmed; do not use or test any credentials.

### 235. P2_REVIEW — ansistrano/symfony-deploy-example

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/ansistrano/symfony-deploy-example/blob/ad90ccc34daef7d2638dbcea599d02007bfead5e/id_rsa
- Repository URL: https://github.com/ansistrano/symfony-deploy-example
- Assessment: unconfirmed; do not use or test any credentials.

### 236. P2_REVIEW — arosenmund/powersecops

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/arosenmund/powersecops/blob/44ceeb99fcc182092e6adb3ddf29fb62f3d11006/id_rsa
- Repository URL: https://github.com/arosenmund/powersecops
- Assessment: unconfirmed; do not use or test any credentials.

### 237. P2_REVIEW — balexx/foreman-vagrant

- Path: `ssh/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/balexx/foreman-vagrant/blob/d6e7a23eb05dccb3e7d2c41b088f65f21d9b83cf/ssh/id_rsa
- Repository URL: https://github.com/balexx/foreman-vagrant
- Assessment: unconfirmed; do not use or test any credentials.

### 238. P2_REVIEW — billy-yoyo/SoftMessage

- Path: `terraform.tfstate.locked`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/billy-yoyo/SoftMessage/blob/65b2cce7569c28b17c8b1c67d036b6b44f9312c9/terraform.tfstate.locked
- Repository URL: https://github.com/billy-yoyo/SoftMessage
- Assessment: unconfirmed; do not use or test any credentials.

### 239. P2_REVIEW — bk-rs/ssh-rs

- Path: `keys/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/bk-rs/ssh-rs/blob/3d05c309a4b6e88f0a77213fe606482528e1bb66/keys/id_rsa
- Repository URL: https://github.com/bk-rs/ssh-rs
- Assessment: unconfirmed; do not use or test any credentials.

### 240. P2_REVIEW — camelmasa/gemfile-monitor-heroku-app

- Path: `.ssh/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/camelmasa/gemfile-monitor-heroku-app/blob/31710e85fda5275fdf5907c8c9c8734dae33cd9d/.ssh/id_rsa
- Repository URL: https://github.com/camelmasa/gemfile-monitor-heroku-app
- Assessment: unconfirmed; do not use or test any credentials.

### 241. P2_REVIEW — catsecorg/CatSec-TryHackMe-WriteUps

- Path: `LFI/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/catsecorg/CatSec-TryHackMe-WriteUps/blob/81beda840352623e2071625cf2c95387e5633a1d/LFI/id_rsa
- Repository URL: https://github.com/catsecorg/CatSec-TryHackMe-WriteUps
- Assessment: unconfirmed; do not use or test any credentials.

### 242. P2_REVIEW — cbsd/reggae

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/cbsd/reggae/blob/61539178376f0715bcc36350839f629c4eabe184/id_rsa
- Repository URL: https://github.com/cbsd/reggae
- Assessment: unconfirmed; do not use or test any credentials.

### 243. P2_REVIEW — chacka0101/exploits

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/chacka0101/exploits/blob/f4adf61355c6941e6d8098965fea6ea6573f63f4/id_rsa
- Repository URL: https://github.com/chacka0101/exploits
- Assessment: unconfirmed; do not use or test any credentials.

### 244. P2_REVIEW — citypaul/mac-dev-machine-setup

- Path: `.ssh/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/citypaul/mac-dev-machine-setup/blob/26e8515cb32a1192cff1e8526a89dd47d67825f8/.ssh/id_rsa
- Repository URL: https://github.com/citypaul/mac-dev-machine-setup
- Assessment: unconfirmed; do not use or test any credentials.

### 245. P2_REVIEW — clan-lol/clan-infra

- Path: `terraform/terraform.tfstate.1765815698.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/clan-lol/clan-infra/blob/008b3ecbb16e586b18ce6c031192c0b701ab31a2/terraform/terraform.tfstate.1765815698.backup
- Repository URL: https://github.com/clan-lol/clan-infra
- Assessment: unconfirmed; do not use or test any credentials.

### 246. P2_REVIEW — clan-lol/clan-infra

- Path: `terraform/terraform.tfstate.1765816005.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/clan-lol/clan-infra/blob/008b3ecbb16e586b18ce6c031192c0b701ab31a2/terraform/terraform.tfstate.1765816005.backup
- Repository URL: https://github.com/clan-lol/clan-infra
- Assessment: unconfirmed; do not use or test any credentials.

### 247. P2_REVIEW — curiouslearning/productionImageInstaller

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/curiouslearning/productionImageInstaller/blob/13fdd767c2ecd0f80db61e51f128fd8c49c5ea6d/id_rsa
- Repository URL: https://github.com/curiouslearning/productionImageInstaller
- Assessment: unconfirmed; do not use or test any credentials.

### 248. P2_REVIEW — damiansoriano/barman-docker

- Path: `backup/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/damiansoriano/barman-docker/blob/ad7cbb08fcfa40860c0dfc995b96728ef7fb3be2/backup/id_rsa
- Repository URL: https://github.com/damiansoriano/barman-docker
- Assessment: unconfirmed; do not use or test any credentials.

### 249. P2_REVIEW — damiansoriano/barman-docker

- Path: `pg/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/damiansoriano/barman-docker/blob/ad7cbb08fcfa40860c0dfc995b96728ef7fb3be2/pg/id_rsa
- Repository URL: https://github.com/damiansoriano/barman-docker
- Assessment: unconfirmed; do not use or test any credentials.

### 250. P2_REVIEW — devbkhadka/UbuntuWithSSH-Docker

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/devbkhadka/UbuntuWithSSH-Docker/blob/35e7d3d40d74c6ef01ffd21736c6d7b93053e927/id_rsa
- Repository URL: https://github.com/devbkhadka/UbuntuWithSSH-Docker
- Assessment: unconfirmed; do not use or test any credentials.

### 251. P2_REVIEW — devel0/knowledge

- Path: `doc/id_rsa.md`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/devel0/knowledge/blob/bc4948957a64f6d6366d2c57259cec3d26656a1b/doc/id_rsa.md
- Repository URL: https://github.com/devel0/knowledge
- Assessment: unconfirmed; do not use or test any credentials.

### 252. P2_REVIEW — developing-today/code

- Path: `infra/dns/terraform.tfstate.enc`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/developing-today/code/blob/a03329d337bce21ba44e0204a8b591bd7a16b4ce/infra/dns/terraform.tfstate.enc
- Repository URL: https://github.com/developing-today/code
- Assessment: unconfirmed; do not use or test any credentials.

### 253. P2_REVIEW — dgruber/vagrantGridEngine

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/dgruber/vagrantGridEngine/blob/c3e9575874faf4a796fd7388f2e953462c4a9d81/id_rsa
- Repository URL: https://github.com/dgruber/vagrantGridEngine
- Assessment: unconfirmed; do not use or test any credentials.

### 254. P2_REVIEW — eiyaya/git-sshd

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/eiyaya/git-sshd/blob/27a283d4571343a29368017c083d6711836af33c/id_rsa
- Repository URL: https://github.com/eiyaya/git-sshd
- Assessment: unconfirmed; do not use or test any credentials.

### 255. P2_REVIEW — elijahu1/container-orch

- Path: `terraform/terraform.tfstate.1744303267.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/elijahu1/container-orch/blob/c0af58a0292a6cbe0182d140cfd8ddedf8a32b56/terraform/terraform.tfstate.1744303267.backup
- Repository URL: https://github.com/elijahu1/container-orch
- Assessment: unconfirmed; do not use or test any credentials.

### 256. P2_REVIEW — embox/emdocker

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/embox/emdocker/blob/b537bdef3d625442b4a574a0bde0bd7c1e568ac9/id_rsa
- Repository URL: https://github.com/embox/emdocker
- Assessment: unconfirmed; do not use or test any credentials.

### 257. P2_REVIEW — enkhalifapro/go-fast

- Path: `ssh/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/enkhalifapro/go-fast/blob/a61f15c81b9743fdd35b1b7c6b233620e6b4086c/ssh/id_rsa
- Repository URL: https://github.com/enkhalifapro/go-fast
- Assessment: unconfirmed; do not use or test any credentials.

### 258. P2_REVIEW — ewilde/terraform-aws-openfaas-fargate

- Path: `terraform.tfstate.1541875947.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/ewilde/terraform-aws-openfaas-fargate/blob/6268d896f3cdb20ef07015812814b2f3e023a38b/terraform.tfstate.1541875947.backup
- Repository URL: https://github.com/ewilde/terraform-aws-openfaas-fargate
- Assessment: unconfirmed; do not use or test any credentials.

### 259. P2_REVIEW — exu/go-playground

- Path: `ssh/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/exu/go-playground/blob/eee6795d5d7befe5837d2138f29a7db26c241b15/ssh/id_rsa
- Repository URL: https://github.com/exu/go-playground
- Assessment: unconfirmed; do not use or test any credentials.

### 260. P2_REVIEW — fanliang11/DMPSystem

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/fanliang11/DMPSystem/blob/a85a2a1cd95c00cdf4755dbd5630fe53e449c15d/id_rsa
- Repository URL: https://github.com/fanliang11/DMPSystem
- Assessment: unconfirmed; do not use or test any credentials.

### 261. P2_REVIEW — fingerecho/fingerecho.github.io

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/fingerecho/fingerecho.github.io/blob/4cee4e05212daa888f7e835145e8a0a91c23ccc2/id_rsa
- Repository URL: https://github.com/fingerecho/fingerecho.github.io
- Assessment: unconfirmed; do not use or test any credentials.

### 262. P2_REVIEW — frankNiessen/CAM2FIB

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/frankNiessen/CAM2FIB/blob/c673f2efdd8de3f0adf72ab9c2dabec88178e1b7/id_rsa
- Repository URL: https://github.com/frankNiessen/CAM2FIB
- Assessment: unconfirmed; do not use or test any credentials.

### 263. P2_REVIEW — fselius/qtcopter

- Path: `ssh/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/fselius/qtcopter/blob/1a16bacb5e49db59578c46f0fa14d64093e2504d/ssh/id_rsa
- Repository URL: https://github.com/fselius/qtcopter
- Assessment: unconfirmed; do not use or test any credentials.

### 264. P2_REVIEW — higgi13425/rmrwr-book

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/higgi13425/rmrwr-book/blob/8ec6c51e5d9364a5333425c7bdad5bc5184aab9f/id_rsa
- Repository URL: https://github.com/higgi13425/rmrwr-book
- Assessment: unconfirmed; do not use or test any credentials.

### 265. P2_REVIEW — icclab/vm-reliability-tester

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/icclab/vm-reliability-tester/blob/235e5862f488ded02559a6125177c611c934e2d7/id_rsa
- Repository URL: https://github.com/icclab/vm-reliability-tester
- Assessment: unconfirmed; do not use or test any credentials.

### 266. P2_REVIEW — ilya-lesikov/gke-demo

- Path: `id_rsa.enc`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/ilya-lesikov/gke-demo/blob/1e83901c670a6be505362bacafee87568521fc9c/id_rsa.enc
- Repository URL: https://github.com/ilya-lesikov/gke-demo
- Assessment: unconfirmed; do not use or test any credentials.

### 267. P2_REVIEW — inolabdev/rh-mgm

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/inolabdev/rh-mgm/blob/75c338ceb428cb2ea4d5994f0f0c5fc5d0038a90/id_rsa
- Repository URL: https://github.com/inolabdev/rh-mgm
- Assessment: unconfirmed; do not use or test any credentials.

### 268. P2_REVIEW — jagheterfredrik/wallbox-pwn

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/jagheterfredrik/wallbox-pwn/blob/b5b168579690c946edd104b6211aaa200bd70fc0/id_rsa
- Repository URL: https://github.com/jagheterfredrik/wallbox-pwn
- Assessment: unconfirmed; do not use or test any credentials.

### 269. P2_REVIEW — jdaniel006/CMAQv5.1

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/jdaniel006/CMAQv5.1/blob/761f57ebfb9ab9180db79c3b618e115d65f50d7a/id_rsa
- Repository URL: https://github.com/jdaniel006/CMAQv5.1
- Assessment: unconfirmed; do not use or test any credentials.

### 270. P2_REVIEW — jerico/terraform-proxmox-k3s

- Path: `ssh/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/jerico/terraform-proxmox-k3s/blob/e33776d050fff32ae3b25dddd770c30725b81550/ssh/id_rsa
- Repository URL: https://github.com/jerico/terraform-proxmox-k3s
- Assessment: unconfirmed; do not use or test any credentials.

### 271. P2_REVIEW — jeroenpeeters/docker-ssh

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/jeroenpeeters/docker-ssh/blob/fa4b2a6c275b540fd27031cf8fd85c2eea5ccf1a/id_rsa
- Repository URL: https://github.com/jeroenpeeters/docker-ssh
- Assessment: unconfirmed; do not use or test any credentials.

### 272. P2_REVIEW — jessefugitt/docker-autossh

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/jessefugitt/docker-autossh/blob/04fc0bb7c2b11858d4eaaa2ffdf350d99bd320a6/id_rsa
- Repository URL: https://github.com/jessefugitt/docker-autossh
- Assessment: unconfirmed; do not use or test any credentials.

### 273. P2_REVIEW — jpillora/go-and-ssh

- Path: `sshd/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/jpillora/go-and-ssh/blob/02cc3ee2900ec8ee98ad9c69d7e2be2fe2e19883/sshd/id_rsa
- Repository URL: https://github.com/jpillora/go-and-ssh
- Assessment: unconfirmed; do not use or test any credentials.

### 274. P2_REVIEW — js345/RadioHub

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/js345/RadioHub/blob/3ee374a7b606976dadbb1820aa1faaf6a66ae4d2/id_rsa
- Repository URL: https://github.com/js345/RadioHub
- Assessment: unconfirmed; do not use or test any credentials.

### 275. P2_REVIEW — k1031936721/binance-client

- Path: `.ssh/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/k1031936721/binance-client/blob/6403e980c3421d4f40a773c86b7479703b317d33/.ssh/id_rsa
- Repository URL: https://github.com/k1031936721/binance-client
- Assessment: unconfirmed; do not use or test any credentials.

### 276. P2_REVIEW — kangoo13/LightThemUp

- Path: `SSH/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/kangoo13/LightThemUp/blob/0e15d37a876c378ed8f831fa84d4c216d2872e8c/SSH/id_rsa
- Repository URL: https://github.com/kangoo13/LightThemUp
- Assessment: unconfirmed; do not use or test any credentials.

### 277. P2_REVIEW — kbaseattic/dev_container

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/kbaseattic/dev_container/blob/e7cd2833d4b7621b905a253792570caee9a7440a/id_rsa
- Repository URL: https://github.com/kbaseattic/dev_container
- Assessment: unconfirmed; do not use or test any credentials.

### 278. P2_REVIEW — kendou/lantern

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/kendou/lantern/blob/08f8d00fd0a1629919cd1c07cc635402cbab624c/id_rsa
- Repository URL: https://github.com/kendou/lantern
- Assessment: unconfirmed; do not use or test any credentials.

### 279. P2_REVIEW — khaledhawil/ITI-Project

- Path: `Terraform/terraform.tfstate.1750278318.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/khaledhawil/ITI-Project/blob/d117dc06f4f7e941719800ad2a3fba11f85e0600/Terraform/terraform.tfstate.1750278318.backup
- Repository URL: https://github.com/khaledhawil/ITI-Project
- Assessment: unconfirmed; do not use or test any credentials.

### 280. P2_REVIEW — khaledhawil/ITI-Project

- Path: `Terraform/terraform.tfstate.1750278336.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/khaledhawil/ITI-Project/blob/d117dc06f4f7e941719800ad2a3fba11f85e0600/Terraform/terraform.tfstate.1750278336.backup
- Repository URL: https://github.com/khaledhawil/ITI-Project
- Assessment: unconfirmed; do not use or test any credentials.

### 281. P2_REVIEW — khaledhawil/ITI-Project

- Path: `Terraform/terraform.tfstate.1750278346.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/khaledhawil/ITI-Project/blob/d117dc06f4f7e941719800ad2a3fba11f85e0600/Terraform/terraform.tfstate.1750278346.backup
- Repository URL: https://github.com/khaledhawil/ITI-Project
- Assessment: unconfirmed; do not use or test any credentials.

### 282. P2_REVIEW — khaledhawil/ITI-Project

- Path: `Terraform/terraform.tfstate.backup.1750307492`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/khaledhawil/ITI-Project/blob/d117dc06f4f7e941719800ad2a3fba11f85e0600/Terraform/terraform.tfstate.backup.1750307492
- Repository URL: https://github.com/khaledhawil/ITI-Project
- Assessment: unconfirmed; do not use or test any credentials.

### 283. P2_REVIEW — khaledhawil/ITI-Project

- Path: `Terraform/terraform.tfstate.backup.1750307617`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/khaledhawil/ITI-Project/blob/d117dc06f4f7e941719800ad2a3fba11f85e0600/Terraform/terraform.tfstate.backup.1750307617
- Repository URL: https://github.com/khaledhawil/ITI-Project
- Assessment: unconfirmed; do not use or test any credentials.

### 284. P2_REVIEW — lightcrest/kahu-api-demo

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/lightcrest/kahu-api-demo/blob/2331118cb3c68376c11dd3973d0ced591222db5f/id_rsa
- Repository URL: https://github.com/lightcrest/kahu-api-demo
- Assessment: unconfirmed; do not use or test any credentials.

### 285. P2_REVIEW — lucascebertin/ssh-game

- Path: `keys/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/lucascebertin/ssh-game/blob/053a7058a70b18268eaffb4e8a4da33a9e3cd896/keys/id_rsa
- Repository URL: https://github.com/lucascebertin/ssh-game
- Assessment: unconfirmed; do not use or test any credentials.

### 286. P2_REVIEW — marcosoliveirasilva/posweb20261_infra

- Path: `iac/terraform.tfstate.bak`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/marcosoliveirasilva/posweb20261_infra/blob/b10af7e09da471e2ce66913a0467be4d75672310/iac/terraform.tfstate.bak
- Repository URL: https://github.com/marcosoliveirasilva/posweb20261_infra
- Assessment: unconfirmed; do not use or test any credentials.

### 287. P2_REVIEW — masayukitooyama/Parme

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/masayukitooyama/Parme/blob/482775a2795bfeac1da11608c33b50c7fe1005b2/id_rsa
- Repository URL: https://github.com/masayukitooyama/Parme
- Assessment: unconfirmed; do not use or test any credentials.

### 288. P2_REVIEW — modouwifi/app-ssh-reverse

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/modouwifi/app-ssh-reverse/blob/83e2c70e098031ff00cf8986cca22392cbc7fa69/id_rsa
- Repository URL: https://github.com/modouwifi/app-ssh-reverse
- Assessment: unconfirmed; do not use or test any credentials.

### 289. P2_REVIEW — mojaloop/documentation

- Path: `infra/state/terraform.tfstate.backup_dep`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/mojaloop/documentation/blob/46a2ae63ece609c1855f5ed3cc2c0a44674b7489/infra/state/terraform.tfstate.backup_dep
- Repository URL: https://github.com/mojaloop/documentation
- Assessment: unconfirmed; do not use or test any credentials.

### 290. P2_REVIEW — neontribe/nagios

- Path: `ssh/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/neontribe/nagios/blob/d103f87a01e85c5fdc88ac5ddd6596d241804131/ssh/id_rsa
- Repository URL: https://github.com/neontribe/nagios
- Assessment: unconfirmed; do not use or test any credentials.

### 291. P2_REVIEW — nerdyman/dotfiles

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/nerdyman/dotfiles/blob/168d58e42c1bc0e804efbebda1e7286839cdde3d/id_rsa
- Repository URL: https://github.com/nerdyman/dotfiles
- Assessment: unconfirmed; do not use or test any credentials.

### 292. P2_REVIEW — njunth/Crawler

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/njunth/Crawler/blob/de0aa7321728d776915577827d719302f2cd1ed5/id_rsa
- Repository URL: https://github.com/njunth/Crawler
- Assessment: unconfirmed; do not use or test any credentials.

### 293. P2_REVIEW — nogibjj/BallersDash

- Path: `terraform/terraform.tfstate.1702260619.backup`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/nogibjj/BallersDash/blob/b801708a9fbccc25e10aff1f37fd21ed659aa7c4/terraform/terraform.tfstate.1702260619.backup
- Repository URL: https://github.com/nogibjj/BallersDash
- Assessment: unconfirmed; do not use or test any credentials.

### 294. P2_REVIEW — oVirt/ost-images

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/oVirt/ost-images/blob/cef120b66f4d418ece40db5f24dbc814e9027ff5/id_rsa
- Repository URL: https://github.com/oVirt/ost-images
- Assessment: unconfirmed; do not use or test any credentials.

### 295. P2_REVIEW — ofrendo/Swinglytics

- Path: `rpi/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/ofrendo/Swinglytics/blob/dfbe4a8282da5eb8ba9ada51fbbf0ba45449e6c0/rpi/id_rsa
- Repository URL: https://github.com/ofrendo/Swinglytics
- Assessment: unconfirmed; do not use or test any credentials.

### 296. P2_REVIEW — okigan/e7z

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/okigan/e7z/blob/ace8eb825e5905ea297cfebaedf69e95e3bd9822/id_rsa
- Repository URL: https://github.com/okigan/e7z
- Assessment: unconfirmed; do not use or test any credentials.

### 297. P2_REVIEW — opnfv/opnfv-ravello-demo

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/opnfv/opnfv-ravello-demo/blob/14b1f183b4f68cb1390ed5edc829f945e02c89b3/id_rsa
- Repository URL: https://github.com/opnfv/opnfv-ravello-demo
- Assessment: unconfirmed; do not use or test any credentials.

### 298. P2_REVIEW — ph0sgene/twitchinstalls

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/ph0sgene/twitchinstalls/blob/2039c0518842611ba8a49ab3205b36d7f8a42381/id_rsa
- Repository URL: https://github.com/ph0sgene/twitchinstalls
- Assessment: unconfirmed; do not use or test any credentials.

### 299. P2_REVIEW — procamora/fedora_pentesting

- Path: `ssh/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/procamora/fedora_pentesting/blob/9c2f5cf239281cd5e00d3f701a9f2593a41c391d/ssh/id_rsa
- Repository URL: https://github.com/procamora/fedora_pentesting
- Assessment: unconfirmed; do not use or test any credentials.

### 300. P2_REVIEW — puppetlabs/kreamlet

- Path: `ssh/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/puppetlabs/kreamlet/blob/1ae0b67342b6a93b638dc37be8e0f8672ffd5eef/ssh/id_rsa
- Repository URL: https://github.com/puppetlabs/kreamlet
- Assessment: unconfirmed; do not use or test any credentials.

### 301. P2_REVIEW — railsmachine/ceph-tutorial

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/railsmachine/ceph-tutorial/blob/d42a8430180a9643e38fbd4707323c57f2a69b5c/id_rsa
- Repository URL: https://github.com/railsmachine/ceph-tutorial
- Assessment: unconfirmed; do not use or test any credentials.

### 302. P2_REVIEW — rishi-organisation/Work-Terraform

- Path: `terraform.tfstate.backup123`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/rishi-organisation/Work-Terraform/blob/208e2152270f02122a816c157a0a647d074badc4/terraform.tfstate.backup123
- Repository URL: https://github.com/rishi-organisation/Work-Terraform
- Assessment: unconfirmed; do not use or test any credentials.

### 303. P2_REVIEW — rmin/flask-ansible

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/rmin/flask-ansible/blob/dd1de7e364a142d3bf62c6e1492ac7c7133314d7/id_rsa
- Repository URL: https://github.com/rmin/flask-ansible
- Assessment: unconfirmed; do not use or test any credentials.

### 304. P2_REVIEW — segee/ACG-USBIP-pi

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/segee/ACG-USBIP-pi/blob/c42d651066d6be0a7c6d45c8b187a0a1147d900f/id_rsa
- Repository URL: https://github.com/segee/ACG-USBIP-pi
- Assessment: unconfirmed; do not use or test any credentials.

### 305. P2_REVIEW — sergueik/selenium_vagrant

- Path: `id_rsa.txt`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/sergueik/selenium_vagrant/blob/b99792946617b9854a8578385b27cf6a71f26609/id_rsa.txt
- Repository URL: https://github.com/sergueik/selenium_vagrant
- Assessment: unconfirmed; do not use or test any credentials.

### 306. P2_REVIEW — shellwhale/ansible-docker-playground

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/shellwhale/ansible-docker-playground/blob/f62b1fcb1581ebd0c7b687d5b323726380a7a2ff/id_rsa
- Repository URL: https://github.com/shellwhale/ansible-docker-playground
- Assessment: unconfirmed; do not use or test any credentials.

### 307. P2_REVIEW — siedi/zabbix-autossh

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/siedi/zabbix-autossh/blob/5791f8935f831f1216a7969d352df487f2222b7a/id_rsa
- Repository URL: https://github.com/siedi/zabbix-autossh
- Assessment: unconfirmed; do not use or test any credentials.

### 308. P2_REVIEW — steled/homelab-terraform

- Path: `terraform.tfstate.old`
- Indicator: `terraform_state`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/steled/homelab-terraform/blob/b6710b48aa1fbdb7436a8923b051ed68cba4ba3f/terraform.tfstate.old
- Repository URL: https://github.com/steled/homelab-terraform
- Assessment: unconfirmed; do not use or test any credentials.

### 309. P2_REVIEW — swordqiu/kvmadmin

- Path: `etc/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/swordqiu/kvmadmin/blob/ba36298330f9048cac0bb4b596ce100bce3c1468/etc/id_rsa
- Repository URL: https://github.com/swordqiu/kvmadmin
- Assessment: unconfirmed; do not use or test any credentials.

### 310. P2_REVIEW — tehmaze-labs/lollipop

- Path: `etc/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/tehmaze-labs/lollipop/blob/1c68500324943b6fe6b659725ebec1eb550e3351/etc/id_rsa
- Repository URL: https://github.com/tehmaze-labs/lollipop
- Assessment: unconfirmed; do not use or test any credentials.

### 311. P2_REVIEW — telliott99/PyBioinformatics

- Path: `data/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/telliott99/PyBioinformatics/blob/d295b27e4057f369441ef5dabc97ae751420db3f/data/id_rsa
- Repository URL: https://github.com/telliott99/PyBioinformatics
- Assessment: unconfirmed; do not use or test any credentials.

### 312. P2_REVIEW — travis-perl/builder

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/travis-perl/builder/blob/4e0f86e2f198cfc8be7d0ec0f4aa0518e073941e/id_rsa
- Repository URL: https://github.com/travis-perl/builder
- Assessment: unconfirmed; do not use or test any credentials.

### 313. P2_REVIEW — ubc-systopia/inconcretes

- Path: `ae/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/ubc-systopia/inconcretes/blob/d5d67c6e9a365290d4a9564c213676356ae649fe/ae/id_rsa
- Repository URL: https://github.com/ubc-systopia/inconcretes
- Assessment: unconfirmed; do not use or test any credentials.

### 314. P2_REVIEW — underworld02/SecKill

- Path: `id_rsa.ppk`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/underworld02/SecKill/blob/f97de253482414adb61d0f2ee6dc5d85968efb59/id_rsa.ppk
- Repository URL: https://github.com/underworld02/SecKill
- Assessment: unconfirmed; do not use or test any credentials.

### 315. P2_REVIEW — unitedclassifiedsapps/gitlab-ci-android-fastlane

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/unitedclassifiedsapps/gitlab-ci-android-fastlane/blob/e82361f730c302f3cb38d937f814c2441c0194ac/id_rsa
- Repository URL: https://github.com/unitedclassifiedsapps/gitlab-ci-android-fastlane
- Assessment: unconfirmed; do not use or test any credentials.

### 316. P2_REVIEW — valeriangalliat/dotfiles

- Path: `ssh/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/valeriangalliat/dotfiles/blob/bec7a4a552a8001921121c1914f53e2c4eda283e/ssh/id_rsa
- Repository URL: https://github.com/valeriangalliat/dotfiles
- Assessment: unconfirmed; do not use or test any credentials.

### 317. P2_REVIEW — voicerepublic/vr-streambox

- Path: `id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/voicerepublic/vr-streambox/blob/028fa614038aa57d75c954b61ddf39ad9fcc9867/id_rsa
- Repository URL: https://github.com/voicerepublic/vr-streambox
- Assessment: unconfirmed; do not use or test any credentials.

### 318. P2_REVIEW — yaofeng-xu/samba

- Path: `.ssh/id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 3 (not severity)
- File URL: https://github.com/yaofeng-xu/samba/blob/baf5cb065b16098844a4e7d5d7516a810aa4bb19/.ssh/id_rsa
- Repository URL: https://github.com/yaofeng-xu/samba
- Assessment: unconfirmed; do not use or test any credentials.

### 319. P2_REVIEW — 0Itsuki0/google-api-rust-client

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/0Itsuki0/google-api-rust-client/blob/c1f343f52c88a207d2f690248afea1f7833f269f/README.md
- Repository URL: https://github.com/0Itsuki0/google-api-rust-client
- Assessment: unconfirmed; do not use or test any credentials.

### 320. P2_REVIEW — 1148118271/ssh-rs

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/1148118271/ssh-rs/blob/2699b3d75bf35ee6f33d5ed30f826e8ec2be979d/README.md
- Repository URL: https://github.com/1148118271/ssh-rs
- Assessment: unconfirmed; do not use or test any credentials.

### 321. P2_REVIEW — 1979139113/0day-today-exploits

- Path: `23477.txt`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/1979139113/0day-today-exploits/blob/8b2194688e3c722fe9369b045e37382e7f45e12b/23477.txt
- Repository URL: https://github.com/1979139113/0day-today-exploits
- Assessment: unconfirmed; do not use or test any credentials.

### 322. P2_REVIEW — 1979139113/0day-today-exploits

- Path: `27769.txt`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/1979139113/0day-today-exploits/blob/8b2194688e3c722fe9369b045e37382e7f45e12b/27769.txt
- Repository URL: https://github.com/1979139113/0day-today-exploits
- Assessment: unconfirmed; do not use or test any credentials.

### 323. P2_REVIEW — 1979139113/0day-today-exploits

- Path: `30148.txt`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/1979139113/0day-today-exploits/blob/8b2194688e3c722fe9369b045e37382e7f45e12b/30148.txt
- Repository URL: https://github.com/1979139113/0day-today-exploits
- Assessment: unconfirmed; do not use or test any credentials.

### 324. P2_REVIEW — 1979139113/0day-today-exploits

- Path: `30982.txt`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/1979139113/0day-today-exploits/blob/8b2194688e3c722fe9369b045e37382e7f45e12b/30982.txt
- Repository URL: https://github.com/1979139113/0day-today-exploits
- Assessment: unconfirmed; do not use or test any credentials.

### 325. P2_REVIEW — 1979139113/0day-today-exploits

- Path: `31215.txt`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/1979139113/0day-today-exploits/blob/8b2194688e3c722fe9369b045e37382e7f45e12b/31215.txt
- Repository URL: https://github.com/1979139113/0day-today-exploits
- Assessment: unconfirmed; do not use or test any credentials.

### 326. P2_REVIEW — 1979139113/0day-today-exploits

- Path: `8079.txt`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/1979139113/0day-today-exploits/blob/8b2194688e3c722fe9369b045e37382e7f45e12b/8079.txt
- Repository URL: https://github.com/1979139113/0day-today-exploits
- Assessment: unconfirmed; do not use or test any credentials.

### 327. P2_REVIEW — AAALearning/SetupProjectNextjs

- Path: `x.txt`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/AAALearning/SetupProjectNextjs/blob/652fee18096187647b9da2501ae52006e65f6038/x.txt
- Repository URL: https://github.com/AAALearning/SetupProjectNextjs
- Assessment: unconfirmed; do not use or test any credentials.

### 328. P2_REVIEW — Abbotton/alipay-sdk-php

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Abbotton/alipay-sdk-php/blob/a7a267be4743f5b884ee85e17f5fd16390c20f9e/README.md
- Repository URL: https://github.com/Abbotton/alipay-sdk-php
- Assessment: unconfirmed; do not use or test any credentials.

### 329. P2_REVIEW — AfedB/Nuke-My-City

- Path: `DB.md`
- Indicator: `database_url;db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/AfedB/Nuke-My-City/blob/8b00449a8a16187f0b498e2df4cdf9ef49a5db84/DB.md
- Repository URL: https://github.com/AfedB/Nuke-My-City
- Assessment: unconfirmed; do not use or test any credentials.

### 330. P2_REVIEW — AliGanji1/Pyrubi

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/AliGanji1/Pyrubi/blob/160e6f9845d3501a14a4efb02dc656f16e3d8f9e/README.md
- Repository URL: https://github.com/AliGanji1/Pyrubi
- Assessment: unconfirmed; do not use or test any credentials.

### 331. P2_REVIEW — AngeloTorano/shf-backend

- Path: `I.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/AngeloTorano/shf-backend/blob/d0c3b2d7f58a0399c02ada69f49333bead43d2d8/I.md
- Repository URL: https://github.com/AngeloTorano/shf-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 332. P2_REVIEW — ApurvaBr11/LearningManagementSystem

- Path: `h.txt`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/ApurvaBr11/LearningManagementSystem/blob/e1bc0f7c706a76ce397dafb187fc7407884a668d/h.txt
- Repository URL: https://github.com/ApurvaBr11/LearningManagementSystem
- Assessment: unconfirmed; do not use or test any credentials.

### 333. P2_REVIEW — ArianaProjects/prisma-nestjs-crud-generator

- Path: `r.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/ArianaProjects/prisma-nestjs-crud-generator/blob/6f7ed4ed62aaa5f271b6624b85ffe3ade3944c1f/r.md
- Repository URL: https://github.com/ArianaProjects/prisma-nestjs-crud-generator
- Assessment: unconfirmed; do not use or test any credentials.

### 334. P2_REVIEW — Atalanta/cucumber-chef

- Path: `WIKI.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Atalanta/cucumber-chef/blob/d2db3031527ae6b836accf07a6b4054c2d3eeb81/WIKI.md
- Repository URL: https://github.com/Atalanta/cucumber-chef
- Assessment: unconfirmed; do not use or test any credentials.

### 335. P2_REVIEW — Ayodya2007/Simple-MD

- Path: `EN.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Ayodya2007/Simple-MD/blob/b8045175d26c683f9ff80ebf70bc22ca17eb80a0/EN.md
- Repository URL: https://github.com/Ayodya2007/Simple-MD
- Assessment: unconfirmed; do not use or test any credentials.

### 336. P2_REVIEW — Ayodya2007/Simple-MD

- Path: `ID.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Ayodya2007/Simple-MD/blob/b8045175d26c683f9ff80ebf70bc22ca17eb80a0/ID.md
- Repository URL: https://github.com/Ayodya2007/Simple-MD
- Assessment: unconfirmed; do not use or test any credentials.

### 337. P2_REVIEW — Azure-Samples/app-templates-Liberty-on-aks

- Path: `env.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Azure-Samples/app-templates-Liberty-on-aks/blob/26faa4309f1ca78ce33107394d4ba0b90c63ee22/env.md
- Repository URL: https://github.com/Azure-Samples/app-templates-Liberty-on-aks
- Assessment: unconfirmed; do not use or test any credentials.

### 338. P2_REVIEW — Bakarseck/ProjetLaravel

- Path: `lamp.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Bakarseck/ProjetLaravel/blob/71ef13a9b64bb251317e44e2e66959dab2efef01/lamp.md
- Repository URL: https://github.com/Bakarseck/ProjetLaravel
- Assessment: unconfirmed; do not use or test any credentials.

### 339. P2_REVIEW — BalajSaleem/criterion

- Path: `MCP.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/BalajSaleem/criterion/blob/f08942ec2556dafe220f7b5cd52fbd77a769bd90/MCP.md
- Repository URL: https://github.com/BalajSaleem/criterion
- Assessment: unconfirmed; do not use or test any credentials.

### 340. P2_REVIEW — Balaji0707-R/BabyBuddy-AI

- Path: `..txt`
- Indicator: `database_url;api_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Balaji0707-R/BabyBuddy-AI/blob/6be9c9a98339adcf01ee4e9ed9d7e30ab6b0c1a8/..txt
- Repository URL: https://github.com/Balaji0707-R/BabyBuddy-AI
- Assessment: unconfirmed; do not use or test any credentials.

### 341. P2_REVIEW — BearKingF/blinko_ai

- Path: `DEV.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/BearKingF/blinko_ai/blob/f3c383b7bc0356cfca301b65302b6c84fa5a4b43/DEV.md
- Repository URL: https://github.com/BearKingF/blinko_ai
- Assessment: unconfirmed; do not use or test any credentials.

### 342. P2_REVIEW — BelgianBiodiversityPlatform/www.formicidae-atlas.be

- Path: `Run.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/BelgianBiodiversityPlatform/www.formicidae-atlas.be/blob/c62b04935e300ff549c2ab31eb1799a6e3977f6e/Run.md
- Repository URL: https://github.com/BelgianBiodiversityPlatform/www.formicidae-atlas.be
- Assessment: unconfirmed; do not use or test any credentials.

### 343. P2_REVIEW — Bozu1206/SeizureGuard

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Bozu1206/SeizureGuard/blob/faa31458b63a005c62ed03f08f0f56ff9eadd61b/README.md
- Repository URL: https://github.com/Bozu1206/SeizureGuard
- Assessment: unconfirmed; do not use or test any credentials.

### 344. P2_REVIEW — BrewedAlgorithms/Medical-Adherence-Monitoring-System

- Path: `FAQ.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/BrewedAlgorithms/Medical-Adherence-Monitoring-System/blob/0492c10a0206c56ee71e6c6fedbfecb2671eabd5/FAQ.md
- Repository URL: https://github.com/BrewedAlgorithms/Medical-Adherence-Monitoring-System
- Assessment: unconfirmed; do not use or test any credentials.

### 345. P2_REVIEW — CalvinHoover/cool-math-game

- Path: `DEV.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/CalvinHoover/cool-math-game/blob/fd312436096ee86cdf4a99ded849f04fef354102/DEV.md
- Repository URL: https://github.com/CalvinHoover/cool-math-game
- Assessment: unconfirmed; do not use or test any credentials.

### 346. P2_REVIEW — Capgemini/portable-k8s-demo

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Capgemini/portable-k8s-demo/blob/2284d9fc8a87eaa44b9d2f276eb3dfc2fa04cc94/README.md
- Repository URL: https://github.com/Capgemini/portable-k8s-demo
- Assessment: unconfirmed; do not use or test any credentials.

### 347. P2_REVIEW — Carrington-dev/dotzen

- Path: `PYPI.md`
- Indicator: `db_password_label;password_assignment`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Carrington-dev/dotzen/blob/4136432067537002f28dae7247a061e58e112da8/PYPI.md
- Repository URL: https://github.com/Carrington-dev/dotzen
- Assessment: unconfirmed; do not use or test any credentials.

### 348. P2_REVIEW — Catapush/catapush-ios-sdk-pod

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Catapush/catapush-ios-sdk-pod/blob/8ee51699f57972efbfcc43029840eb950fafda1f/README.md
- Repository URL: https://github.com/Catapush/catapush-ios-sdk-pod
- Assessment: unconfirmed; do not use or test any credentials.

### 349. P2_REVIEW — CharaChorder/DeviceManager

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/CharaChorder/DeviceManager/blob/33ce9b1ba725e44d0a878037ba397ad176e6a1d3/README.md
- Repository URL: https://github.com/CharaChorder/DeviceManager
- Assessment: unconfirmed; do not use or test any credentials.

### 350. P2_REVIEW — Clem-Fern/rtabby-web-api

- Path: `dev.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Clem-Fern/rtabby-web-api/blob/a2d034de631107bababb25261a7c855056eacdd4/dev.md
- Repository URL: https://github.com/Clem-Fern/rtabby-web-api
- Assessment: unconfirmed; do not use or test any credentials.

### 351. P2_REVIEW — CleverTap/apns-http2

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/CleverTap/apns-http2/blob/3fc3ccbf8fe57a0dbf8dee2a87f4d1775852105d/README.md
- Repository URL: https://github.com/CleverTap/apns-http2
- Assessment: unconfirmed; do not use or test any credentials.

### 352. P2_REVIEW — Covenant-Labs-AI/conduit

- Path: `ai.txt`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Covenant-Labs-AI/conduit/blob/87a6736c3905d151b8efd2c6a2653c2c04002298/ai.txt
- Repository URL: https://github.com/Covenant-Labs-AI/conduit
- Assessment: unconfirmed; do not use or test any credentials.

### 353. P2_REVIEW — CrossRef/reddit-dump-experiment

- Path: `AWS.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/CrossRef/reddit-dump-experiment/blob/d5a96cd6ecb503fe7d1c61055804c1bd16d7b3e7/AWS.md
- Repository URL: https://github.com/CrossRef/reddit-dump-experiment
- Assessment: unconfirmed; do not use or test any credentials.

### 354. P2_REVIEW — Cyberdad247/I-Creations

- Path: `env.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Cyberdad247/I-Creations/blob/ecb8cb25231061ba83c7cb66a145a3c80f12383a/env.md
- Repository URL: https://github.com/Cyberdad247/I-Creations
- Assessment: unconfirmed; do not use or test any credentials.

### 355. P2_REVIEW — DamageLabs/clahub

- Path: `PRD.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/DamageLabs/clahub/blob/9d1e666e1d30f271aea9640393229a7cbfbd1b62/PRD.md
- Repository URL: https://github.com/DamageLabs/clahub
- Assessment: unconfirmed; do not use or test any credentials.

### 356. P2_REVIEW — Dharaneesh20/Infra-Chat

- Path: `SETUP.md`
- Indicator: `aws_secret_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Dharaneesh20/Infra-Chat/blob/8547f057596739fc05aa182170b65f971193fdce/SETUP.md
- Repository URL: https://github.com/Dharaneesh20/Infra-Chat
- Assessment: unconfirmed; do not use or test any credentials.

### 357. P2_REVIEW — DharunKumar-G/mindvault-semanticlinking

- Path: `ENV.md`
- Indicator: `database_url;db_password_label;google_api_key_prefix`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/DharunKumar-G/mindvault-semanticlinking/blob/fb5777e51f019867513d08084fed824411da4587/ENV.md
- Repository URL: https://github.com/DharunKumar-G/mindvault-semanticlinking
- Assessment: unconfirmed; do not use or test any credentials.

### 358. P2_REVIEW — Digital-Defiance/the-complex-patient

- Path: `dev.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Digital-Defiance/the-complex-patient/blob/c515dfbe7935f01e9030a2476cb77de3fba32cd9/dev.md
- Repository URL: https://github.com/Digital-Defiance/the-complex-patient
- Assessment: unconfirmed; do not use or test any credentials.

### 359. P2_REVIEW — Don-Vicks/lens

- Path: `RUN.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Don-Vicks/lens/blob/2824b910eee32f1c755c8c2caecda2443044465c/RUN.md
- Repository URL: https://github.com/Don-Vicks/lens
- Assessment: unconfirmed; do not use or test any credentials.

### 360. P2_REVIEW — Draa3001/CELENG

- Path: `EN.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Draa3001/CELENG/blob/c86e43a13e85d080fa51bb3a19ee3eb992b52f63/EN.md
- Repository URL: https://github.com/Draa3001/CELENG
- Assessment: unconfirmed; do not use or test any credentials.

### 361. P2_REVIEW — Draa3001/CELENG

- Path: `ID.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Draa3001/CELENG/blob/c86e43a13e85d080fa51bb3a19ee3eb992b52f63/ID.md
- Repository URL: https://github.com/Draa3001/CELENG
- Assessment: unconfirmed; do not use or test any credentials.

### 362. P2_REVIEW — DuckHappy/quackly

- Path: `DB.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/DuckHappy/quackly/blob/610cdbe8d550c001d0296aa933b3c2848bee8961/DB.md
- Repository URL: https://github.com/DuckHappy/quackly
- Assessment: unconfirmed; do not use or test any credentials.

### 363. P2_REVIEW — DukeEmree/series-tracker-v2

- Path: `LEARN.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/DukeEmree/series-tracker-v2/blob/692226e12632b5f4ec06ba10d3dc37c924050039/LEARN.md
- Repository URL: https://github.com/DukeEmree/series-tracker-v2
- Assessment: unconfirmed; do not use or test any credentials.

### 364. P2_REVIEW — Dv-nn/Python--Cheat-Sheet

- Path: `API.md`
- Indicator: `client_secret_label;access_token_label;secret_assignment`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Dv-nn/Python--Cheat-Sheet/blob/2a0fb1d7b41776dd4ea12c81f35967161009d998/API.md
- Repository URL: https://github.com/Dv-nn/Python--Cheat-Sheet
- Assessment: unconfirmed; do not use or test any credentials.

### 365. P2_REVIEW — ESpaceMw/eCastBackend

- Path: `env.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/ESpaceMw/eCastBackend/blob/7479dd416e64ad38d549751d40992b6974ff2f4f/env.txt
- Repository URL: https://github.com/ESpaceMw/eCastBackend
- Assessment: unconfirmed; do not use or test any credentials.

### 366. P2_REVIEW — EkkoG/rtabby-web-api2

- Path: `dev.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/EkkoG/rtabby-web-api2/blob/a49ad592544e6db5c9b5ab020a640d5bf949cd59/dev.md
- Repository URL: https://github.com/EkkoG/rtabby-web-api2
- Assessment: unconfirmed; do not use or test any credentials.

### 367. P2_REVIEW — ElazzouziHassan/SGI-APP

- Path: `help.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/ElazzouziHassan/SGI-APP/blob/a3b2d49f83facc450798941497bf6768bf88e11b/help.md
- Repository URL: https://github.com/ElazzouziHassan/SGI-APP
- Assessment: unconfirmed; do not use or test any credentials.

### 368. P2_REVIEW — Elhussin/Learn

- Path: `env.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Elhussin/Learn/blob/f5b3f5c7acd496a411798ab37b78a3fbe3866cc5/env.md
- Repository URL: https://github.com/Elhussin/Learn
- Assessment: unconfirmed; do not use or test any credentials.

### 369. P2_REVIEW — EmesDev/AngularNginxDockerTemplate

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/EmesDev/AngularNginxDockerTemplate/blob/c2e74fed7dbfc6a118e0483b93a35d5ddc5c275a/README.md
- Repository URL: https://github.com/EmesDev/AngularNginxDockerTemplate
- Assessment: unconfirmed; do not use or test any credentials.

### 370. P2_REVIEW — EnigmaCurry/d.rymcg.tech

- Path: `AWS.md`
- Indicator: `aws_secret_key_label;client_secret_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/EnigmaCurry/d.rymcg.tech/blob/0d99a3245a8287421441006b60fe466345b68227/AWS.md
- Repository URL: https://github.com/EnigmaCurry/d.rymcg.tech
- Assessment: unconfirmed; do not use or test any credentials.

### 371. P2_REVIEW — FaaSTools/GoDeploy

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/FaaSTools/GoDeploy/blob/f0fa6b015313eef0425defd7849a1aa7b15e58e3/README.md
- Repository URL: https://github.com/FaaSTools/GoDeploy
- Assessment: unconfirmed; do not use or test any credentials.

### 372. P2_REVIEW — Frederick2313072/linuxdo

- Path: `api.md`
- Indicator: `client_secret_label;access_token_label;secret_assignment`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Frederick2313072/linuxdo/blob/84c9c1e4e29854f5edf220ea074000bfbe52d60e/api.md
- Repository URL: https://github.com/Frederick2313072/linuxdo
- Assessment: unconfirmed; do not use or test any credentials.

### 373. P2_REVIEW — G10rga/Litera

- Path: `OPS.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/G10rga/Litera/blob/86f6fb51cd3bf61ba24f851c3d18567e789c6a20/OPS.md
- Repository URL: https://github.com/G10rga/Litera
- Assessment: unconfirmed; do not use or test any credentials.

### 374. P2_REVIEW — GDSC-NIT-Calicut/nitc-connect-backend

- Path: `doc.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/GDSC-NIT-Calicut/nitc-connect-backend/blob/67fe41ea08da94c8f4c526b4fdb05db9b9589d9f/doc.md
- Repository URL: https://github.com/GDSC-NIT-Calicut/nitc-connect-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 375. P2_REVIEW — GSA/ansible-https-proxy

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/GSA/ansible-https-proxy/blob/920fc2e42aefd539a14a7915111a3a53b2b1f6c6/README.md
- Repository URL: https://github.com/GSA/ansible-https-proxy
- Assessment: unconfirmed; do not use or test any credentials.

### 376. P2_REVIEW — GSA/jenkins-deploy

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/GSA/jenkins-deploy/blob/af222abb4d0c97a1d7647cd36d92184382525f0b/README.md
- Repository URL: https://github.com/GSA/jenkins-deploy
- Assessment: unconfirmed; do not use or test any credentials.

### 377. P2_REVIEW — HIMEX/s3sftp-server

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/HIMEX/s3sftp-server/blob/d8e5ebf31881d1cf9ad8e61453737521f975e2a9/README.md
- Repository URL: https://github.com/HIMEX/s3sftp-server
- Assessment: unconfirmed; do not use or test any credentials.

### 378. P2_REVIEW — Het161/transitops-fleet-management

- Path: `RUN.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Het161/transitops-fleet-management/blob/1e8889ef3a8a121242ed3774a0d4db2723443819/RUN.md
- Repository URL: https://github.com/Het161/transitops-fleet-management
- Assessment: unconfirmed; do not use or test any credentials.

### 379. P2_REVIEW — HomeAssistant-Mods/home-assistant-miele

- Path: `info.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/HomeAssistant-Mods/home-assistant-miele/blob/38e06adc78f7d408883fdfa155288b071f55a683/info.md
- Repository URL: https://github.com/HomeAssistant-Mods/home-assistant-miele
- Assessment: unconfirmed; do not use or test any credentials.

### 380. P2_REVIEW — IBM-Security/verify-keycloak-integration

- Path: `hld.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/IBM-Security/verify-keycloak-integration/blob/1ab1b089c8b02ca5a79b30bc4fc781acb4da75e8/hld.md
- Repository URL: https://github.com/IBM-Security/verify-keycloak-integration
- Assessment: unconfirmed; do not use or test any credentials.

### 381. P2_REVIEW — InternalDeveloperPlatform/pe-course-labs

- Path: `cnoe.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/InternalDeveloperPlatform/pe-course-labs/blob/2527210398750b7fd68d7b0cee75cf9e30e5f899/cnoe.md
- Repository URL: https://github.com/InternalDeveloperPlatform/pe-course-labs
- Assessment: unconfirmed; do not use or test any credentials.

### 382. P2_REVIEW — Ishanoshada/GDorks

- Path: `dorks.txt`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Ishanoshada/GDorks/blob/796f20c5e64287a8ced2d59decd5e79aad5c39f8/dorks.txt
- Repository URL: https://github.com/Ishanoshada/GDorks
- Assessment: unconfirmed; do not use or test any credentials.

### 383. P2_REVIEW — JaydenTheCHiCPEA/pos-server

- Path: `,.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/JaydenTheCHiCPEA/pos-server/blob/7984afee374d11e1a104eb57f395d05165a99f74/,.md
- Repository URL: https://github.com/JaydenTheCHiCPEA/pos-server
- Assessment: unconfirmed; do not use or test any credentials.

### 384. P2_REVIEW — Jeangowhy/opendocs

- Path: `RSA.md`
- Indicator: `private_key_header;password_assignment`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Jeangowhy/opendocs/blob/25a77d63fd77ef03055191d6d83c30b26098a650/RSA.md
- Repository URL: https://github.com/Jeangowhy/opendocs
- Assessment: unconfirmed; do not use or test any credentials.

### 385. P2_REVIEW — Jeanmichel7/42_transcendence

- Path: `note.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Jeanmichel7/42_transcendence/blob/901f51aec892cd33ce5a5d99222fd045c4188044/note.md
- Repository URL: https://github.com/Jeanmichel7/42_transcendence
- Assessment: unconfirmed; do not use or test any credentials.

### 386. P2_REVIEW — JhendersonPHD/honeydew2026

- Path: `ENV.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/JhendersonPHD/honeydew2026/blob/5df82eee5389902348add208eda816c1a8b3cc31/ENV.md
- Repository URL: https://github.com/JhendersonPHD/honeydew2026
- Assessment: unconfirmed; do not use or test any credentials.

### 387. P2_REVIEW — Jonasinbar/teste

- Path: `a.txt`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Jonasinbar/teste/blob/a7d886c2a00da61efa20fa186c8658ec4be1482a/a.txt
- Repository URL: https://github.com/Jonasinbar/teste
- Assessment: unconfirmed; do not use or test any credentials.

### 388. P2_REVIEW — JulienDelavande/SoccerBetMLOptimizer

- Path: `DEV.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/JulienDelavande/SoccerBetMLOptimizer/blob/2cec18ef1ff40b6ce3539e0658be2e9799c459f3/DEV.md
- Repository URL: https://github.com/JulienDelavande/SoccerBetMLOptimizer
- Assessment: unconfirmed; do not use or test any credentials.

### 389. P2_REVIEW — Juniper/ansible-junos-stdlib

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Juniper/ansible-junos-stdlib/blob/a81752df20c2142cac5fba4aa2f5ed269371bb39/README.md
- Repository URL: https://github.com/Juniper/ansible-junos-stdlib
- Assessment: unconfirmed; do not use or test any credentials.

### 390. P2_REVIEW — KelvinKamchen/ProjetoPHPgrupo3

- Path: `env.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/KelvinKamchen/ProjetoPHPgrupo3/blob/122f20c1f4adbc755b26c1fd0fa206a3317b745f/env.md
- Repository URL: https://github.com/KelvinKamchen/ProjetoPHPgrupo3
- Assessment: unconfirmed; do not use or test any credentials.

### 391. P2_REVIEW — KhuongNguyen27/findwork

- Path: `env.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/KhuongNguyen27/findwork/blob/3b1530706979f20d860b6b1e611b2d926270250a/env.md
- Repository URL: https://github.com/KhuongNguyen27/findwork
- Assessment: unconfirmed; do not use or test any credentials.

### 392. P2_REVIEW — KleeUT/Auth0-rules-cicd-example-2020

- Path: `blog.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/KleeUT/Auth0-rules-cicd-example-2020/blob/682cd9678bbda3fbc206557802a942fd020dba48/blog.md
- Repository URL: https://github.com/KleeUT/Auth0-rules-cicd-example-2020
- Assessment: unconfirmed; do not use or test any credentials.

### 393. P2_REVIEW — Krakow2016/wolontariusze

- Path: `API.md`
- Indicator: `client_secret_label;access_token_label;bearer_auth_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Krakow2016/wolontariusze/blob/e457b0bbc280185b50f713b77fc5b2d255ca3674/API.md
- Repository URL: https://github.com/Krakow2016/wolontariusze
- Assessment: unconfirmed; do not use or test any credentials.

### 394. P2_REVIEW — KristianOellegaard/django-saml-service-provider

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/KristianOellegaard/django-saml-service-provider/blob/5de8e24c5c411708782450200442b6ab7991f3a9/README.md
- Repository URL: https://github.com/KristianOellegaard/django-saml-service-provider
- Assessment: unconfirmed; do not use or test any credentials.

### 395. P2_REVIEW — Kushal25Gupta/opensource-job-portal

- Path: `ENV.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Kushal25Gupta/opensource-job-portal/blob/2a12e3b3a120c4631f1355af84660893b43a71de/ENV.md
- Repository URL: https://github.com/Kushal25Gupta/opensource-job-portal
- Assessment: unconfirmed; do not use or test any credentials.

### 396. P2_REVIEW — LaravelRUS/docs

- Path: `mail.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/LaravelRUS/docs/blob/e65d703e3ea694a565eb6c240d4243280723e5c2/mail.md
- Repository URL: https://github.com/LaravelRUS/docs
- Assessment: unconfirmed; do not use or test any credentials.

### 397. P2_REVIEW — LaravelRUS/docs

- Path: `sail.md`
- Indicator: `aws_secret_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/LaravelRUS/docs/blob/e65d703e3ea694a565eb6c240d4243280723e5c2/sail.md
- Repository URL: https://github.com/LaravelRUS/docs
- Assessment: unconfirmed; do not use or test any credentials.

### 398. P2_REVIEW — LikithR-AI/voting-system

- Path: `RUN.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/LikithR-AI/voting-system/blob/ec55501a4fb93981203ca0bc4461b4473845d391/RUN.md
- Repository URL: https://github.com/LikithR-AI/voting-system
- Assessment: unconfirmed; do not use or test any credentials.

### 399. P2_REVIEW — LoganRickert/HarborFM

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/LoganRickert/HarborFM/blob/aca17ec4f264ffbe3f113f63b3da9c0b8d9b7b25/README.md
- Repository URL: https://github.com/LoganRickert/HarborFM
- Assessment: unconfirmed; do not use or test any credentials.

### 400. P2_REVIEW — LondheShubham153/strands-agents-workshop

- Path: `SETUP.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/LondheShubham153/strands-agents-workshop/blob/f9ccf122c1649c2879b6252d7638c8ab7eabf5a2/SETUP.md
- Repository URL: https://github.com/LondheShubham153/strands-agents-workshop
- Assessment: unconfirmed; do not use or test any credentials.

### 401. P2_REVIEW — LucianoArmas/Antojos

- Path: `xd.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/LucianoArmas/Antojos/blob/0826c6069308f982851aae571e64979a81bf5573/xd.txt
- Repository URL: https://github.com/LucianoArmas/Antojos
- Assessment: unconfirmed; do not use or test any credentials.

### 402. P2_REVIEW — M0okz/Homybudget

- Path: `api.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/M0okz/Homybudget/blob/297cbb5fcabb1dece9bad5ed1c947db6d9325df2/api.md
- Repository URL: https://github.com/M0okz/Homybudget
- Assessment: unconfirmed; do not use or test any credentials.

### 403. P2_REVIEW — MacTynow/drone-s3cache

- Path: `DOCS.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/MacTynow/drone-s3cache/blob/00dcb2abed8be758a84c812c3145f4e215e584c2/DOCS.md
- Repository URL: https://github.com/MacTynow/drone-s3cache
- Assessment: unconfirmed; do not use or test any credentials.

### 404. P2_REVIEW — MarkEdmondson1234/googleAuthR

- Path: `NEWS.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/MarkEdmondson1234/googleAuthR/blob/4e00724150b958c38dfa1fabcc7ebc0e4e837443/NEWS.md
- Repository URL: https://github.com/MarkEdmondson1234/googleAuthR
- Assessment: unconfirmed; do not use or test any credentials.

### 405. P2_REVIEW — Math-Vov13/Mistral-X_FastAPI

- Path: `BDD.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Math-Vov13/Mistral-X_FastAPI/blob/f5a60839f0f71bfdec2d1c25a82e874e6224ab87/BDD.md
- Repository URL: https://github.com/Math-Vov13/Mistral-X_FastAPI
- Assessment: unconfirmed; do not use or test any credentials.

### 406. P2_REVIEW — Matrixxboy/QueryCrafter

- Path: `npm.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Matrixxboy/QueryCrafter/blob/a714b41501c5c0989414257ffc7d8c27a59b08b8/npm.md
- Repository URL: https://github.com/Matrixxboy/QueryCrafter
- Assessment: unconfirmed; do not use or test any credentials.

### 407. P2_REVIEW — MatteoIorio11/ghapp-deployer-aws

- Path: `setup.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/MatteoIorio11/ghapp-deployer-aws/blob/a103a7c0a6e082a0cfff7947733151eca49d327c/setup.md
- Repository URL: https://github.com/MatteoIorio11/ghapp-deployer-aws
- Assessment: unconfirmed; do not use or test any credentials.

### 408. P2_REVIEW — MaxxtonGroup/transip-backup

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/MaxxtonGroup/transip-backup/blob/719b5c052c28ac7f6d3ce022d44e3590220ff6a8/README.md
- Repository URL: https://github.com/MaxxtonGroup/transip-backup
- Assessment: unconfirmed; do not use or test any credentials.

### 409. P2_REVIEW — Mews/spotify-lyrics

- Path: `FAQ.md`
- Indicator: `client_secret_label;secret_assignment`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Mews/spotify-lyrics/blob/6cb4297c457d90d9669c021fdd5698083442e90b/FAQ.md
- Repository URL: https://github.com/Mews/spotify-lyrics
- Assessment: unconfirmed; do not use or test any credentials.

### 410. P2_REVIEW — MirotechTeam/rasedi-flutter-sdk

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/MirotechTeam/rasedi-flutter-sdk/blob/44162a821c7a6f57b309015e34f8b984f50a43d6/README.md
- Repository URL: https://github.com/MirotechTeam/rasedi-flutter-sdk
- Assessment: unconfirmed; do not use or test any credentials.

### 411. P2_REVIEW — Mirzamurod/chatogram

- Path: `env.txt`
- Indicator: `client_secret_label;secret_assignment`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Mirzamurod/chatogram/blob/013587f1b411b440d69e3c82a5b2aabfec78cd59/env.txt
- Repository URL: https://github.com/Mirzamurod/chatogram
- Assessment: unconfirmed; do not use or test any credentials.

### 412. P2_REVIEW — Mohammad-Ghouse-virtuoso/cookie-gallery_

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Mohammad-Ghouse-virtuoso/cookie-gallery_/blob/fa04f869f9243d47e1040187b7b4b776328a333d/README.md
- Repository URL: https://github.com/Mohammad-Ghouse-virtuoso/cookie-gallery_
- Assessment: unconfirmed; do not use or test any credentials.

### 413. P2_REVIEW — MohitGoyal09/BlinkAI

- Path: `AWS.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/MohitGoyal09/BlinkAI/blob/fdf6daf13d8a2e15b93baba77e72b610aae8ffac/AWS.md
- Repository URL: https://github.com/MohitGoyal09/BlinkAI
- Assessment: unconfirmed; do not use or test any credentials.

### 414. P2_REVIEW — Motopp-Bottle-CRM/Django-CRM

- Path: `ENV.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Motopp-Bottle-CRM/Django-CRM/blob/f282b21f409839a5469f64394e7622b8f925e7f2/ENV.md
- Repository URL: https://github.com/Motopp-Bottle-CRM/Django-CRM
- Assessment: unconfirmed; do not use or test any credentials.

### 415. P2_REVIEW — MrReza69/jakal

- Path: `t.txt`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/MrReza69/jakal/blob/b1d15abc284361db7252fa7b3d11cc1c6b9fac6a/t.txt
- Repository URL: https://github.com/MrReza69/jakal
- Assessment: unconfirmed; do not use or test any credentials.

### 416. P2_REVIEW — Nateliason/sondex-oss

- Path: `PRD.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Nateliason/sondex-oss/blob/092d0b75c2d09140045585019d02e94516480e9c/PRD.md
- Repository URL: https://github.com/Nateliason/sondex-oss
- Assessment: unconfirmed; do not use or test any credentials.

### 417. P2_REVIEW — NexusQuantum/NQRust-MicroVM

- Path: `env.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/NexusQuantum/NQRust-MicroVM/blob/c5ee792e188c62f7e3c15620a6d2a65d444b393d/env.md
- Repository URL: https://github.com/NexusQuantum/NQRust-MicroVM
- Assessment: unconfirmed; do not use or test any credentials.

### 418. P2_REVIEW — Nickwenniyxiao-art/nordhjem-medusa-backend

- Path: `ENV.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Nickwenniyxiao-art/nordhjem-medusa-backend/blob/da011d1fe73c95cb5b00a04faa1680deae86f359/ENV.md
- Repository URL: https://github.com/Nickwenniyxiao-art/nordhjem-medusa-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 419. P2_REVIEW — No-Instructions/relay-server-template

- Path: `S3.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/No-Instructions/relay-server-template/blob/b1dc2a55a586df03876af3162be2f9c3a270dc27/S3.md
- Repository URL: https://github.com/No-Instructions/relay-server-template
- Assessment: unconfirmed; do not use or test any credentials.

### 420. P2_REVIEW — OmarSharaf/ecommerce-bi-pipeline

- Path: `env.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/OmarSharaf/ecommerce-bi-pipeline/blob/bdb9062f1c2e35419b01a5094fe4ff4097e17358/env.txt
- Repository URL: https://github.com/OmarSharaf/ecommerce-bi-pipeline
- Assessment: unconfirmed; do not use or test any credentials.

### 421. P2_REVIEW — OmkarY6978/FinTrust-ML-Powered-Lending-Revolution

- Path: `RUN.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/OmkarY6978/FinTrust-ML-Powered-Lending-Revolution/blob/58a63334b068c4607e4eb907c53d9cddbf0ce1c5/RUN.md
- Repository URL: https://github.com/OmkarY6978/FinTrust-ML-Powered-Lending-Revolution
- Assessment: unconfirmed; do not use or test any credentials.

### 422. P2_REVIEW — One-Man-App-Studio/rails-ai-playbook

- Path: `auth.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/One-Man-App-Studio/rails-ai-playbook/blob/e25445ecc4ae2d797276c9201b516ba4793804d9/auth.md
- Repository URL: https://github.com/One-Man-App-Studio/rails-ai-playbook
- Assessment: unconfirmed; do not use or test any credentials.

### 423. P2_REVIEW — OrewaHanz/HanzV5

- Path: `EN.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/OrewaHanz/HanzV5/blob/11c2366bbe58b391327b69149528134dcc9a5ed3/EN.md
- Repository URL: https://github.com/OrewaHanz/HanzV5
- Assessment: unconfirmed; do not use or test any credentials.

### 424. P2_REVIEW — OrewaHanz/HanzV5

- Path: `ID.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/OrewaHanz/HanzV5/blob/11c2366bbe58b391327b69149528134dcc9a5ed3/ID.md
- Repository URL: https://github.com/OrewaHanz/HanzV5
- Assessment: unconfirmed; do not use or test any credentials.

### 425. P2_REVIEW — Parallelia/criptocracia

- Path: `CLAUDE.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Parallelia/criptocracia/blob/6350aba9b2708976e8bc85adab9db04f8ba89924/CLAUDE.md
- Repository URL: https://github.com/Parallelia/criptocracia
- Assessment: unconfirmed; do not use or test any credentials.

### 426. P2_REVIEW — Path-Check/vds-sdk.js

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Path-Check/vds-sdk.js/blob/90997a7403487ac775275917da5dae9161d435e9/README.md
- Repository URL: https://github.com/Path-Check/vds-sdk.js
- Assessment: unconfirmed; do not use or test any credentials.

### 427. P2_REVIEW — PingPlusPlus/pingpp-php

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/PingPlusPlus/pingpp-php/blob/16677d4eaf6dc94289326e0f7446c6ad1c235668/README.md
- Repository URL: https://github.com/PingPlusPlus/pingpp-php
- Assessment: unconfirmed; do not use or test any credentials.

### 428. P2_REVIEW — Pingflow/ssl-file

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Pingflow/ssl-file/blob/3074c8cae0bda6eb5ec20bacc868a76234d4e387/README.md
- Repository URL: https://github.com/Pingflow/ssl-file
- Assessment: unconfirmed; do not use or test any credentials.

### 429. P2_REVIEW — Pinta365/oura_api

- Path: `MCP.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Pinta365/oura_api/blob/23de6e9c8371affa2bf4a5f9f30e64c07ce0c966/MCP.md
- Repository URL: https://github.com/Pinta365/oura_api
- Assessment: unconfirmed; do not use or test any credentials.

### 430. P2_REVIEW — Pisano/summer-camp-2016

- Path: `SW305.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Pisano/summer-camp-2016/blob/9104f02c634b6d761259f9c94f73b0fc5bd11ce5/SW305.md
- Repository URL: https://github.com/Pisano/summer-camp-2016
- Assessment: unconfirmed; do not use or test any credentials.

### 431. P2_REVIEW — PlatformOfTrust/connector-signspace-with-tests

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/PlatformOfTrust/connector-signspace-with-tests/blob/6a7f4c3b58b75689e5611b3ee428507ee5ef59bf/README.md
- Repository URL: https://github.com/PlatformOfTrust/connector-signspace-with-tests
- Assessment: unconfirmed; do not use or test any credentials.

### 432. P2_REVIEW — Police-Data-Accessibility-Project/data-sources-app

- Path: `ENV.md`
- Indicator: `database_url;client_secret_label;access_token_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Police-Data-Accessibility-Project/data-sources-app/blob/67725b1856d96e5e60f9bbb314f74b404e9853f6/ENV.md
- Repository URL: https://github.com/Police-Data-Accessibility-Project/data-sources-app
- Assessment: unconfirmed; do not use or test any credentials.

### 433. P2_REVIEW — Prathameshv07/AquaSense_AI

- Path: `env.txt`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Prathameshv07/AquaSense_AI/blob/0b8ba4d31001afa6b4803598d83badf368c33d36/env.txt
- Repository URL: https://github.com/Prathameshv07/AquaSense_AI
- Assessment: unconfirmed; do not use or test any credentials.

### 434. P2_REVIEW — PremShinde-2013/Brainwave.ai-final

- Path: `DEV.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/PremShinde-2013/Brainwave.ai-final/blob/abd33e3f2970df816aa36b89fb7fc94af246a69d/DEV.md
- Repository URL: https://github.com/PremShinde-2013/Brainwave.ai-final
- Assessment: unconfirmed; do not use or test any credentials.

### 435. P2_REVIEW — RAMKUMARMN/hub_notify

- Path: `setup.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/RAMKUMARMN/hub_notify/blob/8f61159ce814575e038b52feb08eb7103b0a209a/setup.md
- Repository URL: https://github.com/RAMKUMARMN/hub_notify
- Assessment: unconfirmed; do not use or test any credentials.

### 436. P2_REVIEW — REANNZ/etcbd-public

- Path: `Lab.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/REANNZ/etcbd-public/blob/8ef983397ce1255311a02791d9d24de7a235bd20/Lab.md
- Repository URL: https://github.com/REANNZ/etcbd-public
- Assessment: unconfirmed; do not use or test any credentials.

### 437. P2_REVIEW — REFUZIION/riot-php-rso-example

- Path: `DOCS.md`
- Indicator: `client_secret_label;secret_assignment`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/REFUZIION/riot-php-rso-example/blob/0e2810304e4155ea665b43adb370cee34e89fae3/DOCS.md
- Repository URL: https://github.com/REFUZIION/riot-php-rso-example
- Assessment: unconfirmed; do not use or test any credentials.

### 438. P2_REVIEW — RLesur/sspcloud-demo

- Path: `s3.Rmd`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/RLesur/sspcloud-demo/blob/9c555e36ac954a1db111e54fe1adf526ef5b8f94/s3.Rmd
- Repository URL: https://github.com/RLesur/sspcloud-demo
- Assessment: unconfirmed; do not use or test any credentials.

### 439. P2_REVIEW — RaimundoDiaz/google-wallet-passes

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/RaimundoDiaz/google-wallet-passes/blob/83c0ba3cd34fd1d24c1fc416b5763102b3f1d2d8/README.md
- Repository URL: https://github.com/RaimundoDiaz/google-wallet-passes
- Assessment: unconfirmed; do not use or test any credentials.

### 440. P2_REVIEW — RamonPage/ex_azure_key_vault

- Path: `DOCS.md`
- Indicator: `private_key_header;client_secret_label;private_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/RamonPage/ex_azure_key_vault/blob/d9ca26a824d3199ed24b061e86eb5033977968e9/DOCS.md
- Repository URL: https://github.com/RamonPage/ex_azure_key_vault
- Assessment: unconfirmed; do not use or test any credentials.

### 441. P2_REVIEW — Ranaaa17/Job-portal

- Path: `ENV.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Ranaaa17/Job-portal/blob/7f20ea5710f46f7bfc5c628061c687ae3b9da501/ENV.md
- Repository URL: https://github.com/Ranaaa17/Job-portal
- Assessment: unconfirmed; do not use or test any credentials.

### 442. P2_REVIEW — Raxon24/Nextcloud

- Path: `db.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Raxon24/Nextcloud/blob/825f69b6908460dc24f70db13396f21b5064276a/db.md
- Repository URL: https://github.com/Raxon24/Nextcloud
- Assessment: unconfirmed; do not use or test any credentials.

### 443. P2_REVIEW — Redth/AppStoreConnectNet

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Redth/AppStoreConnectNet/blob/5400c3dfa00e3c11f4d87ee9dd651ea5ba3151ac/README.md
- Repository URL: https://github.com/Redth/AppStoreConnectNet
- Assessment: unconfirmed; do not use or test any credentials.

### 444. P2_REVIEW — RemonAhammad/Issue-Solving-Way-And-Guides

- Path: `fcm.md`
- Indicator: `private_key_header;private_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/RemonAhammad/Issue-Solving-Way-And-Guides/blob/3f4dfdaa1ab0b08aff9f5078f45cdb2e5f81d56d/fcm.md
- Repository URL: https://github.com/RemonAhammad/Issue-Solving-Way-And-Guides
- Assessment: unconfirmed; do not use or test any credentials.

### 445. P2_REVIEW — ReversecLabs/awspx

- Path: `INSTALL`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/ReversecLabs/awspx/blob/b5eec7448930e042aeb61723d37cd2f38d7483db/INSTALL
- Repository URL: https://github.com/ReversecLabs/awspx
- Assessment: unconfirmed; do not use or test any credentials.

### 446. P2_REVIEW — Richard-Zhang-AI/MIND-V

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Richard-Zhang-AI/MIND-V/blob/55f00d5cfec94eac10292d9a95456cacdac96a37/README.md
- Repository URL: https://github.com/Richard-Zhang-AI/MIND-V
- Assessment: unconfirmed; do not use or test any credentials.

### 447. P2_REVIEW — RobSchilderr/nextjs-native-starter

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/RobSchilderr/nextjs-native-starter/blob/1c905d553751bafd0c817b25d418cdaadecca748/README.md
- Repository URL: https://github.com/RobSchilderr/nextjs-native-starter
- Assessment: unconfirmed; do not use or test any credentials.

### 448. P2_REVIEW — RushikeshChamle/app_cunsole

- Path: `d.txt`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/RushikeshChamle/app_cunsole/blob/2ff41697aff786cf12e430512c0969a02928e347/d.txt
- Repository URL: https://github.com/RushikeshChamle/app_cunsole
- Assessment: unconfirmed; do not use or test any credentials.

### 449. P2_REVIEW — Salaar-Saaiem/Hybrid-Decentralized-Voting-System-using-Blockchain

- Path: `RUN.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Salaar-Saaiem/Hybrid-Decentralized-Voting-System-using-Blockchain/blob/f3bb4c5457e3cb5fc4af96bae8a13a572d25cffb/RUN.md
- Repository URL: https://github.com/Salaar-Saaiem/Hybrid-Decentralized-Voting-System-using-Blockchain
- Assessment: unconfirmed; do not use or test any credentials.

### 450. P2_REVIEW — SamipPoudel58/nodejs-ts-google-oauth

- Path: `blog.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/SamipPoudel58/nodejs-ts-google-oauth/blob/bcd470a362a622e4911b133195ea04c82d9a206b/blog.md
- Repository URL: https://github.com/SamipPoudel58/nodejs-ts-google-oauth
- Assessment: unconfirmed; do not use or test any credentials.

### 451. P2_REVIEW — SamirNaggara/chilliz

- Path: `ENV.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/SamirNaggara/chilliz/blob/02c990ef3e1c26ac949e86a9e180a6be27bc1b17/ENV.md
- Repository URL: https://github.com/SamirNaggara/chilliz
- Assessment: unconfirmed; do not use or test any credentials.

### 452. P2_REVIEW — SarahHindawi/PatientExperienceTracker

- Path: `env.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/SarahHindawi/PatientExperienceTracker/blob/6fa2273b66a913b1bd4d19c2ba3f393fb4bad95e/env.txt
- Repository URL: https://github.com/SarahHindawi/PatientExperienceTracker
- Assessment: unconfirmed; do not use or test any credentials.

### 453. P2_REVIEW — Sardorbekmaxmud/maxway

- Path: `env.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Sardorbekmaxmud/maxway/blob/bb05ac0020470cb5a8585793c4d08ef0ed936338/env.txt
- Repository URL: https://github.com/Sardorbekmaxmud/maxway
- Assessment: unconfirmed; do not use or test any credentials.

### 454. P2_REVIEW — Sarthak-G0yal/bastionvault

- Path: `plan.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Sarthak-G0yal/bastionvault/blob/bf1213ccac1fb4f7ec5ff50d4179b3dbe653f0fe/plan.md
- Repository URL: https://github.com/Sarthak-G0yal/bastionvault
- Assessment: unconfirmed; do not use or test any credentials.

### 455. P2_REVIEW — SatangThevalue/dst

- Path: `env.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/SatangThevalue/dst/blob/287632bc7ca301c35555c66c55f76774ff2811ae/env.txt
- Repository URL: https://github.com/SatangThevalue/dst
- Assessment: unconfirmed; do not use or test any credentials.

### 456. P2_REVIEW — SciStarter/Circuit

- Path: `Mac.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/SciStarter/Circuit/blob/513d03a33f0aa0f2ad346d3df8309f742b262f8d/Mac.md
- Repository URL: https://github.com/SciStarter/Circuit
- Assessment: unconfirmed; do not use or test any credentials.

### 457. P2_REVIEW — SeraphimSerapis/HA_VSS

- Path: `info.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/SeraphimSerapis/HA_VSS/blob/9b7e265af2e0373b74537140d642fe73a2b9bc68/info.md
- Repository URL: https://github.com/SeraphimSerapis/HA_VSS
- Assessment: unconfirmed; do not use or test any credentials.

### 458. P2_REVIEW — SethukumarJ/Events_Radar_Developement

- Path: `cmd.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/SethukumarJ/Events_Radar_Developement/blob/9260414065ef622e9b4a7b773de308af1b722472/cmd.txt
- Repository URL: https://github.com/SethukumarJ/Events_Radar_Developement
- Assessment: unconfirmed; do not use or test any credentials.

### 459. P2_REVIEW — ShawInnes/SshKeyGenerator

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/ShawInnes/SshKeyGenerator/blob/993f943800f3e4886f5b95f4ebd63cb6e4c665d2/README.md
- Repository URL: https://github.com/ShawInnes/SshKeyGenerator
- Assessment: unconfirmed; do not use or test any credentials.

### 460. P2_REVIEW — SiriusA015/produgieBackend

- Path: `1.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/SiriusA015/produgieBackend/blob/db6b90a2a7221789cfc7751e0dab1a02d961fc56/1.txt
- Repository URL: https://github.com/SiriusA015/produgieBackend
- Assessment: unconfirmed; do not use or test any credentials.

### 461. P2_REVIEW — Sitecore/marketplace-google-analytics

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Sitecore/marketplace-google-analytics/blob/c0c9acc831532d89ed001d850775de417d424924/README.md
- Repository URL: https://github.com/Sitecore/marketplace-google-analytics
- Assessment: unconfirmed; do not use or test any credentials.

### 462. P2_REVIEW — SoteriaInitiative/flstandards

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/SoteriaInitiative/flstandards/blob/f86fb4c489484b896318e472ed82a1207fb04a4e/README.md
- Repository URL: https://github.com/SoteriaInitiative/flstandards
- Assessment: unconfirmed; do not use or test any credentials.

### 463. P2_REVIEW — SpatioCore/STAC-Atlas

- Path: `bid.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/SpatioCore/STAC-Atlas/blob/6cefcd27f1859ce568a888168a3b9fb65fa2b112/bid.md
- Repository URL: https://github.com/SpatioCore/STAC-Atlas
- Assessment: unconfirmed; do not use or test any credentials.

### 464. P2_REVIEW — Strategienavigator/Strategienavigator-backend

- Path: `ENV.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Strategienavigator/Strategienavigator-backend/blob/3f38eb3e0adb6f13525c10851a76b92d0a50de01/ENV.md
- Repository URL: https://github.com/Strategienavigator/Strategienavigator-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 465. P2_REVIEW — Strategienavigator/Strategienavigator-frontend

- Path: `ENV.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Strategienavigator/Strategienavigator-frontend/blob/0e87810cb9b72202e0a93cd78372a94ac19d72f8/ENV.md
- Repository URL: https://github.com/Strategienavigator/Strategienavigator-frontend
- Assessment: unconfirmed; do not use or test any credentials.

### 466. P2_REVIEW — Sysvale/board

- Path: `API.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Sysvale/board/blob/8cad9124064683250de0dcc312a1a296d29e8cdc/API.md
- Repository URL: https://github.com/Sysvale/board
- Assessment: unconfirmed; do not use or test any credentials.

### 467. P2_REVIEW — The-Running-Dev/Docs-Template

- Path: `PRD.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/The-Running-Dev/Docs-Template/blob/cb9e2a580061469f441a16facbf003452d512e92/PRD.md
- Repository URL: https://github.com/The-Running-Dev/Docs-Template
- Assessment: unconfirmed; do not use or test any credentials.

### 468. P2_REVIEW — TheExplainthis/ChatGPT-AI-English-Tutor

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/TheExplainthis/ChatGPT-AI-English-Tutor/blob/dd2366b5cec4a9efce4111fd927b2738c8897243/README.md
- Repository URL: https://github.com/TheExplainthis/ChatGPT-AI-English-Tutor
- Assessment: unconfirmed; do not use or test any credentials.

### 469. P2_REVIEW — TheGabeMan/HealthSync

- Path: `env.md`
- Indicator: `client_secret_label;api_key_label;secret_assignment`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/TheGabeMan/HealthSync/blob/1e779e0ce47a9f0f646793252e8d276703d7c65c/env.md
- Repository URL: https://github.com/TheGabeMan/HealthSync
- Assessment: unconfirmed; do not use or test any credentials.

### 470. P2_REVIEW — TouchInstinct/Backend-common

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/TouchInstinct/Backend-common/blob/c8ed908656dc5d28b77961131188ef5b65a98e0d/README.md
- Repository URL: https://github.com/TouchInstinct/Backend-common
- Assessment: unconfirmed; do not use or test any credentials.

### 471. P2_REVIEW — TrainWithShubham/python-for-devops

- Path: `SETUP.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/TrainWithShubham/python-for-devops/blob/eaa921a093225d8a5b0ceddf4d3579f03f92b59b/SETUP.md
- Repository URL: https://github.com/TrainWithShubham/python-for-devops
- Assessment: unconfirmed; do not use or test any credentials.

### 472. P2_REVIEW — UFO0001/WX_RSA

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/UFO0001/WX_RSA/blob/96073389a4fcbecb6b4a17ed0c7a41029342ec3f/README.md
- Repository URL: https://github.com/UFO0001/WX_RSA
- Assessment: unconfirmed; do not use or test any credentials.

### 473. P2_REVIEW — VSK-777/AIAlgoCoach

- Path: `HELP.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/VSK-777/AIAlgoCoach/blob/8a9d9f11e3c2e6f18d0a1142bf2d1f5deed21c96/HELP.md
- Repository URL: https://github.com/VSK-777/AIAlgoCoach
- Assessment: unconfirmed; do not use or test any credentials.

### 474. P2_REVIEW — ValentinFunk/firebase-steam-login

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/ValentinFunk/firebase-steam-login/blob/4c3a424436e2cb96728387c1deb6d035f5c00169/README.md
- Repository URL: https://github.com/ValentinFunk/firebase-steam-login
- Assessment: unconfirmed; do not use or test any credentials.

### 475. P2_REVIEW — Venafi/vault-pki-backend-venafi

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Venafi/vault-pki-backend-venafi/blob/226ffb74845cc2edbc667c4e8188ca2dbf4be530/README.md
- Repository URL: https://github.com/Venafi/vault-pki-backend-venafi
- Assessment: unconfirmed; do not use or test any credentials.

### 476. P2_REVIEW — Welbert-Soares/study-bank

- Path: `doc.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Welbert-Soares/study-bank/blob/760badd66042da9d8f6c9e306921103b71794499/doc.md
- Repository URL: https://github.com/Welbert-Soares/study-bank
- Assessment: unconfirmed; do not use or test any credentials.

### 477. P2_REVIEW — XenitAB/azure-devops-templates

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/XenitAB/azure-devops-templates/blob/78633cb0cb2a9c32fede9deed5406d28cd69da1c/README.md
- Repository URL: https://github.com/XenitAB/azure-devops-templates
- Assessment: unconfirmed; do not use or test any credentials.

### 478. P2_REVIEW — YUGESHKARAN/Tech-Community-App

- Path: `SETUP.md`
- Indicator: `aws_secret_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/YUGESHKARAN/Tech-Community-App/blob/fbcb78280279e01b28c9e97d81bbdbb2627c14de/SETUP.md
- Repository URL: https://github.com/YUGESHKARAN/Tech-Community-App
- Assessment: unconfirmed; do not use or test any credentials.

### 479. P2_REVIEW — YashBaraii/Digital_Attendance_System

- Path: `env.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/YashBaraii/Digital_Attendance_System/blob/562fa557705572329fa6c4409a7cb9cefcfb2adb/env.txt
- Repository URL: https://github.com/YashBaraii/Digital_Attendance_System
- Assessment: unconfirmed; do not use or test any credentials.

### 480. P2_REVIEW — YashBaraii/Healthcare_Backend

- Path: `env.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/YashBaraii/Healthcare_Backend/blob/02444c3398e94bbef6c53152e1cfae156d4ba412/env.txt
- Repository URL: https://github.com/YashBaraii/Healthcare_Backend
- Assessment: unconfirmed; do not use or test any credentials.

### 481. P2_REVIEW — YmerFlow/Ymerflow

- Path: `CLI.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/YmerFlow/Ymerflow/blob/8df43e57817ea3e5d5285f77b14685bc32eb8cc9/CLI.md
- Repository URL: https://github.com/YmerFlow/Ymerflow
- Assessment: unconfirmed; do not use or test any credentials.

### 482. P2_REVIEW — Zargarmomin/Placement-Management-System

- Path: `env.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/Zargarmomin/Placement-Management-System/blob/8b4af2590dec107d0bbd842ab983ded1a27ce26a/env.txt
- Repository URL: https://github.com/Zargarmomin/Placement-Management-System
- Assessment: unconfirmed; do not use or test any credentials.

### 483. P2_REVIEW — aadarshjaiswal640/Job-Scheduler

- Path: `re.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/aadarshjaiswal640/Job-Scheduler/blob/366be43a898c20a94cbca4f302b8c62bfa9946bc/re.md
- Repository URL: https://github.com/aadarshjaiswal640/Job-Scheduler
- Assessment: unconfirmed; do not use or test any credentials.

### 484. P2_REVIEW — aaravarr/grok-api

- Path: `MCP.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/aaravarr/grok-api/blob/2b389a6453995e85a9c9f62d12d74d34507321d4/MCP.md
- Repository URL: https://github.com/aaravarr/grok-api
- Assessment: unconfirmed; do not use or test any credentials.

### 485. P2_REVIEW — aayush31bhatt-dev/MLModelsITrained

- Path: `V01.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/aayush31bhatt-dev/MLModelsITrained/blob/027406eb4ab2339884eb6d4fd464e71f76e3d7a0/V01.md
- Repository URL: https://github.com/aayush31bhatt-dev/MLModelsITrained
- Assessment: unconfirmed; do not use or test any credentials.

### 486. P2_REVIEW — abhra92/lets-code

- Path: `db.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/abhra92/lets-code/blob/be5d1a52b0003bc7ec0ced8e44a2b924e76ed062/db.md
- Repository URL: https://github.com/abhra92/lets-code
- Assessment: unconfirmed; do not use or test any credentials.

### 487. P2_REVIEW — adobe/aio-lib-ims

- Path: `api.md`
- Indicator: `client_secret_label;access_token_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/adobe/aio-lib-ims/blob/799f891bd154750abd3c15ef6665a36227b00a9c/api.md
- Repository URL: https://github.com/adobe/aio-lib-ims
- Assessment: unconfirmed; do not use or test any credentials.

### 488. P2_REVIEW — adobe/asset-compute-events-client

- Path: `usage.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/adobe/asset-compute-events-client/blob/5ac7115188cae02733ae42531bd6eb1cf09b0929/usage.md
- Repository URL: https://github.com/adobe/asset-compute-events-client
- Assessment: unconfirmed; do not use or test any credentials.

### 489. P2_REVIEW — adobe/helix-deploy

- Path: `AWS.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/adobe/helix-deploy/blob/b6206592c20e8ad818b3062408181f0390f36455/AWS.md
- Repository URL: https://github.com/adobe/helix-deploy
- Assessment: unconfirmed; do not use or test any credentials.

### 490. P2_REVIEW — aequitas/terraform-provider-transip

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/aequitas/terraform-provider-transip/blob/8333b53bcb0f50908e49201c203f9926f95d8aef/README.md
- Repository URL: https://github.com/aequitas/terraform-provider-transip
- Assessment: unconfirmed; do not use or test any credentials.

### 491. P2_REVIEW — albirrkarim/mozilla-hubs-installation-detailed

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/albirrkarim/mozilla-hubs-installation-detailed/blob/c78baae5e826c1543cb1319fcc11cda2c47d811b/README.md
- Repository URL: https://github.com/albirrkarim/mozilla-hubs-installation-detailed
- Assessment: unconfirmed; do not use or test any credentials.

### 492. P2_REVIEW — albonidrizi/event-management

- Path: `MCP.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/albonidrizi/event-management/blob/85a5d2762d97aa2b63c744c67ce2d34885c66a69/MCP.md
- Repository URL: https://github.com/albonidrizi/event-management
- Assessment: unconfirmed; do not use or test any credentials.

### 493. P2_REVIEW — alex/letsencrypt-aws

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/alex/letsencrypt-aws/blob/c7008fe6681071d798223c4478a407a1bbcf1b1e/README.md
- Repository URL: https://github.com/alex/letsencrypt-aws
- Assessment: unconfirmed; do not use or test any credentials.

### 494. P2_REVIEW — alextanhongpin/cheat-sheet

- Path: `aws.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/alextanhongpin/cheat-sheet/blob/e6ec6a8fc7ae51229eabd7c199914684af7f964b/aws.md
- Repository URL: https://github.com/alextanhongpin/cheat-sheet
- Assessment: unconfirmed; do not use or test any credentials.

### 495. P2_REVIEW — alextanhongpin/cheat-sheet

- Path: `php.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/alextanhongpin/cheat-sheet/blob/e6ec6a8fc7ae51229eabd7c199914684af7f964b/php.md
- Repository URL: https://github.com/alextanhongpin/cheat-sheet
- Assessment: unconfirmed; do not use or test any credentials.

### 496. P2_REVIEW — alextanhongpin/go-learn

- Path: `s3.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/alextanhongpin/go-learn/blob/544d5b97cf8975a93f5ab0d4bebc8d3fe71a511f/s3.md
- Repository URL: https://github.com/alextanhongpin/go-learn
- Assessment: unconfirmed; do not use or test any credentials.

### 497. P2_REVIEW — aliengiraffe/spotdb

- Path: `DOCS.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/aliengiraffe/spotdb/blob/cfbbef27f89d18939149790a0fa9ce1ee2c5eac5/DOCS.md
- Repository URL: https://github.com/aliengiraffe/spotdb
- Assessment: unconfirmed; do not use or test any credentials.

### 498. P2_REVIEW — amarkes/codeigniter-restfull-swagger

- Path: `12.md`
- Indicator: `client_secret_label;access_token_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/amarkes/codeigniter-restfull-swagger/blob/28a47596a68feb5608b006b4d998a09eb363879b/12.md
- Repository URL: https://github.com/amarkes/codeigniter-restfull-swagger
- Assessment: unconfirmed; do not use or test any credentials.

### 499. P2_REVIEW — anchapin/portkit

- Path: `RAG.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/anchapin/portkit/blob/5dc92e0d4d1e4d300b4207376a9719f0b6fc5558/RAG.md
- Repository URL: https://github.com/anchapin/portkit
- Assessment: unconfirmed; do not use or test any credentials.

### 500. P2_REVIEW — andersundsehr/mail_logger

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/andersundsehr/mail_logger/blob/4d7a56035e6e9b5c04a6e561cb7ff88515606b3a/README.md
- Repository URL: https://github.com/andersundsehr/mail_logger
- Assessment: unconfirmed; do not use or test any credentials.

### 501. P2_REVIEW — anjrlee/webProject

- Path: `env.txt`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/anjrlee/webProject/blob/af183781b2bee14c0458f4c772ff6f4eef85c5fb/env.txt
- Repository URL: https://github.com/anjrlee/webProject
- Assessment: unconfirmed; do not use or test any credentials.

### 502. P2_REVIEW — antoinersx/clawhost

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/antoinersx/clawhost/blob/83adb0ba3ba5797020efce06b01ee6f3a5ede138/README.md
- Repository URL: https://github.com/antoinersx/clawhost
- Assessment: unconfirmed; do not use or test any credentials.

### 503. P2_REVIEW — antonscheffer/as_crypto

- Path: `jwt.md`
- Indicator: `private_key_header;private_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/antonscheffer/as_crypto/blob/a32ec8233babb51641f46e1d82b5814199ac42d9/jwt.md
- Repository URL: https://github.com/antonscheffer/as_crypto
- Assessment: unconfirmed; do not use or test any credentials.

### 504. P2_REVIEW — apidae-tourisme/ApidaeBundle

- Path: `SSO.md`
- Indicator: `client_secret_label;access_token_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/apidae-tourisme/ApidaeBundle/blob/ec8a4862e98df6ca8a92c061b07ed294533db793/SSO.md
- Repository URL: https://github.com/apidae-tourisme/ApidaeBundle
- Assessment: unconfirmed; do not use or test any credentials.

### 505. P2_REVIEW — apoorv-chandra/adlaunch

- Path: `RUN.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/apoorv-chandra/adlaunch/blob/c461305b1dd1f222d71bfbe7c5e5b8690db064f4/RUN.md
- Repository URL: https://github.com/apoorv-chandra/adlaunch
- Assessment: unconfirmed; do not use or test any credentials.

### 506. P2_REVIEW — arcVaishali/stellar-vision

- Path: `text.txt`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/arcVaishali/stellar-vision/blob/e2fe89994aa0a5589ca14cfd93db8dd16ae97d6d/text.txt
- Repository URL: https://github.com/arcVaishali/stellar-vision
- Assessment: unconfirmed; do not use or test any credentials.

### 507. P2_REVIEW — ashiklom/shiklomanov-lab-resources

- Path: `aws.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/ashiklom/shiklomanov-lab-resources/blob/d55ed750e555059d59f955f65b96f3a4e005dce3/aws.md
- Repository URL: https://github.com/ashiklom/shiklomanov-lab-resources
- Assessment: unconfirmed; do not use or test any credentials.

### 508. P2_REVIEW — atinsood/watson-studio-lab

- Path: `cli.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/atinsood/watson-studio-lab/blob/ea2d092a8ca92ab74fe000354be6f40fdc7e38dc/cli.md
- Repository URL: https://github.com/atinsood/watson-studio-lab
- Assessment: unconfirmed; do not use or test any credentials.

### 509. P2_REVIEW — atssj/env-twin

- Path: `llm.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/atssj/env-twin/blob/408292360ea76aeff5435bc7438549e4ad714e23/llm.txt
- Repository URL: https://github.com/atssj/env-twin
- Assessment: unconfirmed; do not use or test any credentials.

### 510. P2_REVIEW — attome-ai/Comfyui_Attome_S3

- Path: `env.txt`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/attome-ai/Comfyui_Attome_S3/blob/01f817b5f73f944bcb17e30276de2121579a2cc7/env.txt
- Repository URL: https://github.com/attome-ai/Comfyui_Attome_S3
- Assessment: unconfirmed; do not use or test any credentials.

### 511. P2_REVIEW — atulkamble/Invi-Grid

- Path: `k8s.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/atulkamble/Invi-Grid/blob/863972b9d242c0a39a0dbb922e1146369b626d8d/k8s.md
- Repository URL: https://github.com/atulkamble/Invi-Grid
- Assessment: unconfirmed; do not use or test any credentials.

### 512. P2_REVIEW — auriza/komdat-lab

- Path: `p01.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/auriza/komdat-lab/blob/57926d97233f37ae4feb2ae5e2e2d6f16503cca4/p01.md
- Repository URL: https://github.com/auriza/komdat-lab
- Assessment: unconfirmed; do not use or test any credentials.

### 513. P2_REVIEW — avborup/fireplace

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/avborup/fireplace/blob/b2937079a37b73479efdbffe6c30793e95d94ce5/README.md
- Repository URL: https://github.com/avborup/fireplace
- Assessment: unconfirmed; do not use or test any credentials.

### 514. P2_REVIEW — aws-samples/amazon-kinesis-video-streams-producer-embedded-c

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/aws-samples/amazon-kinesis-video-streams-producer-embedded-c/blob/86e561d257e860536840ae79b594d8d98a8af567/README.md
- Repository URL: https://github.com/aws-samples/amazon-kinesis-video-streams-producer-embedded-c
- Assessment: unconfirmed; do not use or test any credentials.

### 515. P2_REVIEW — aws-samples/eks-gitops-crossplane-flux

- Path: `flux.md`
- Indicator: `aws_secret_key_label;secret_access_key_label;github_token_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/aws-samples/eks-gitops-crossplane-flux/blob/bb822b2fb9e6c088937d7bdfebb064ed4412bf30/flux.md
- Repository URL: https://github.com/aws-samples/eks-gitops-crossplane-flux
- Assessment: unconfirmed; do not use or test any credentials.

### 516. P2_REVIEW — aws-samples/sample-technical-validation-automation-agent

- Path: `POWER.md`
- Indicator: `aws_secret_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/aws-samples/sample-technical-validation-automation-agent/blob/bcb199a2d4a206e99a8210ce5a621f13306faeb1/POWER.md
- Repository URL: https://github.com/aws-samples/sample-technical-validation-automation-agent
- Assessment: unconfirmed; do not use or test any credentials.

### 517. P2_REVIEW — awskaizen02/Doc-commands

- Path: `db.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/awskaizen02/Doc-commands/blob/9dae691ec0a3978aae187a158ec3fd4711e68043/db.md
- Repository URL: https://github.com/awskaizen02/Doc-commands
- Assessment: unconfirmed; do not use or test any credentials.

### 518. P2_REVIEW — awslabs/tecli

- Path: `TIPS.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/awslabs/tecli/blob/eafed26c0beabf326440dce40867b9ee40cb84d5/TIPS.md
- Repository URL: https://github.com/awslabs/tecli
- Assessment: unconfirmed; do not use or test any credentials.

### 519. P2_REVIEW — azat-co/node-in-production

- Path: `02.md`
- Indicator: `database_url;api_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/azat-co/node-in-production/blob/ee990a958a7e391da25a050ee098eca829131cbc/02.md
- Repository URL: https://github.com/azat-co/node-in-production
- Assessment: unconfirmed; do not use or test any credentials.

### 520. P2_REVIEW — azilber/walletserver

- Path: `roles.md`
- Indicator: `aws_secret_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/azilber/walletserver/blob/728a73b578f6e5cf0b3d2d65c142feb53b14727b/roles.md
- Repository URL: https://github.com/azilber/walletserver
- Assessment: unconfirmed; do not use or test any credentials.

### 521. P2_REVIEW — azophy/sshifu

- Path: `PRD.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/azophy/sshifu/blob/d7662b980da8542a2d3293f0d714e70a61de0f8e/PRD.md
- Repository URL: https://github.com/azophy/sshifu
- Assessment: unconfirmed; do not use or test any credentials.

### 522. P2_REVIEW — bdwong-mirrors/mrbs

- Path: `INSTALL`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/bdwong-mirrors/mrbs/blob/03c1b451ed803d5633d6d193923b88f3c15d8f05/INSTALL
- Repository URL: https://github.com/bdwong-mirrors/mrbs
- Assessment: unconfirmed; do not use or test any credentials.

### 523. P2_REVIEW — bdwong-mirrors/mrbs

- Path: `NEWS`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/bdwong-mirrors/mrbs/blob/03c1b451ed803d5633d6d193923b88f3c15d8f05/NEWS
- Repository URL: https://github.com/bdwong-mirrors/mrbs
- Assessment: unconfirmed; do not use or test any credentials.

### 524. P2_REVIEW — benrwoodard/adobeanalyticsr

- Path: `NEWS.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/benrwoodard/adobeanalyticsr/blob/af719d7db9a747e221eca72276f0bfdd87f3321f/NEWS.md
- Repository URL: https://github.com/benrwoodard/adobeanalyticsr
- Assessment: unconfirmed; do not use or test any credentials.

### 525. P2_REVIEW — bf4/Notes

- Path: `db.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/bf4/Notes/blob/d790c4c19e784c42f697ff9bb6e97d3c45bbbbd0/db.txt
- Repository URL: https://github.com/bf4/Notes
- Assessment: unconfirmed; do not use or test any credentials.

### 526. P2_REVIEW — bhargavjoshi1237/medtest

- Path: `en.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/bhargavjoshi1237/medtest/blob/99d554274905b3a5795753d135f9074e91533a44/en.md
- Repository URL: https://github.com/bhargavjoshi1237/medtest
- Assessment: unconfirmed; do not use or test any credentials.

### 527. P2_REVIEW — bigmoby/scrum-training-app

- Path: `DOC.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/bigmoby/scrum-training-app/blob/11d5f798d6b5e294c9371a23abdbe281adb66317/DOC.md
- Repository URL: https://github.com/bigmoby/scrum-training-app
- Assessment: unconfirmed; do not use or test any credentials.

### 528. P2_REVIEW — biocodellc/bcid

- Path: `api.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/biocodellc/bcid/blob/6b0650b9d8076d645f0bb0d64269fab5b0e2b06c/api.md
- Repository URL: https://github.com/biocodellc/bcid
- Assessment: unconfirmed; do not use or test any credentials.

### 529. P2_REVIEW — bjompen/PSSecretScanner

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/bjompen/PSSecretScanner/blob/16b11ce42801d737d1bc8c397f50230c4a5454b7/README.md
- Repository URL: https://github.com/bjompen/PSSecretScanner
- Assessment: unconfirmed; do not use or test any credentials.

### 530. P2_REVIEW — bloom-solutions/docker-stellar-core

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/bloom-solutions/docker-stellar-core/blob/329e409d4478c01402f77be3acd8c0d2f411d515/README.md
- Repository URL: https://github.com/bloom-solutions/docker-stellar-core
- Assessment: unconfirmed; do not use or test any credentials.

### 531. P2_REVIEW — bluehalo/graphql-fhir

- Path: `FAQ.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/bluehalo/graphql-fhir/blob/4408d7849130c125f53b1914aa6807424a1413fe/FAQ.md
- Repository URL: https://github.com/bluehalo/graphql-fhir
- Assessment: unconfirmed; do not use or test any credentials.

### 532. P2_REVIEW — bokwoon95/sq

- Path: `sq.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/bokwoon95/sq/blob/eae3b0c03361f5b98ac6d0701c6aa71c94d4e4c2/sq.md
- Repository URL: https://github.com/bokwoon95/sq
- Assessment: unconfirmed; do not use or test any credentials.

### 533. P2_REVIEW — boronine/h2tunnel

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/boronine/h2tunnel/blob/8d2cc8a66eb9e73c8b567118a67c5d4aa2451518/README.md
- Repository URL: https://github.com/boronine/h2tunnel
- Assessment: unconfirmed; do not use or test any credentials.

### 534. P2_REVIEW — brasizza/signac_sat-package-dart

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/brasizza/signac_sat-package-dart/blob/78c0542c96ba48cf0aecde12540295d4e6fea0ac/README.md
- Repository URL: https://github.com/brasizza/signac_sat-package-dart
- Assessment: unconfirmed; do not use or test any credentials.

### 535. P2_REVIEW — brettinhere/Codong

- Path: `SPEC.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/brettinhere/Codong/blob/90cbbfc0f43d86dd68756e3bb9624a2d722ba521/SPEC.md
- Repository URL: https://github.com/brettinhere/Codong
- Assessment: unconfirmed; do not use or test any credentials.

### 536. P2_REVIEW — bsm/drone-s3-cache

- Path: `DOCS.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/bsm/drone-s3-cache/blob/1d27f0f6686348deb2d92c0f76e0c10e3b98d311/DOCS.md
- Repository URL: https://github.com/bsm/drone-s3-cache
- Assessment: unconfirmed; do not use or test any credentials.

### 537. P2_REVIEW — bytebuff/JSpider

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/bytebuff/JSpider/blob/e8e7f6bf18d6d8fdf7d7efc2c2b151cf3042ddc4/README.md
- Repository URL: https://github.com/bytebuff/JSpider
- Assessment: unconfirmed; do not use or test any credentials.

### 538. P2_REVIEW — c0mm4nd/dart-elliptic

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/c0mm4nd/dart-elliptic/blob/03cab5ba5f28d34652f23533864ce88fd5a5d05c/README.md
- Repository URL: https://github.com/c0mm4nd/dart-elliptic
- Assessment: unconfirmed; do not use or test any credentials.

### 539. P2_REVIEW — camiloAndres11/Plumb

- Path: `MCP.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/camiloAndres11/Plumb/blob/a9317fe2a15acde714f66db7c5f8c50c507b5a90/MCP.md
- Repository URL: https://github.com/camiloAndres11/Plumb
- Assessment: unconfirmed; do not use or test any credentials.

### 540. P2_REVIEW — camunda-community-hub/camunda-8-connector-openweather-api

- Path: `env.txt`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/camunda-community-hub/camunda-8-connector-openweather-api/blob/380748eb1c965db13fcd8eb70646b40ddc6c8512/env.txt
- Repository URL: https://github.com/camunda-community-hub/camunda-8-connector-openweather-api
- Assessment: unconfirmed; do not use or test any credentials.

### 541. P2_REVIEW — canonical/identity-platform-admin-ui

- Path: `API.md`
- Indicator: `client_secret_label;private_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/canonical/identity-platform-admin-ui/blob/898be088543ff45af1ee210bc3692f9aca88d43a/API.md
- Repository URL: https://github.com/canonical/identity-platform-admin-ui
- Assessment: unconfirmed; do not use or test any credentials.

### 542. P2_REVIEW — caroSeminario23/RECLA_servicio_compraventa

- Path: `env.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/caroSeminario23/RECLA_servicio_compraventa/blob/141dcc63452e983eb1913a1b7c23e6cc5b5d345c/env.txt
- Repository URL: https://github.com/caroSeminario23/RECLA_servicio_compraventa
- Assessment: unconfirmed; do not use or test any credentials.

### 543. P2_REVIEW — caroSeminario23/RECLA_servicio_gamificacion

- Path: `env.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/caroSeminario23/RECLA_servicio_gamificacion/blob/74d87d3b24ae8f79797ff796ff5abb2ac5ec0dc2/env.txt
- Repository URL: https://github.com/caroSeminario23/RECLA_servicio_gamificacion
- Assessment: unconfirmed; do not use or test any credentials.

### 544. P2_REVIEW — caroSeminario23/RECLA_servicio_usuarios

- Path: `env.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/caroSeminario23/RECLA_servicio_usuarios/blob/e16cbb1d725f968094da5d9727ba7ba091ba202e/env.txt
- Repository URL: https://github.com/caroSeminario23/RECLA_servicio_usuarios
- Assessment: unconfirmed; do not use or test any credentials.

### 545. P2_REVIEW — castagna/tdbloader4

- Path: `TODO.txt`
- Indicator: `aws_secret_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/castagna/tdbloader4/blob/f5363fa49d16a04a362898c1a5084ade620ee81b/TODO.txt
- Repository URL: https://github.com/castagna/tdbloader4
- Assessment: unconfirmed; do not use or test any credentials.

### 546. P2_REVIEW — cdklabs/cdk-pipelines-github

- Path: `API.md`
- Indicator: `aws_secret_key_label;secret_access_key_label;github_token_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/cdklabs/cdk-pipelines-github/blob/b971f8fa7a92deaf548d433337432e21159eb714/API.md
- Repository URL: https://github.com/cdklabs/cdk-pipelines-github
- Assessment: unconfirmed; do not use or test any credentials.

### 547. P2_REVIEW — cheikh2shift/godex

- Path: `MCP.md`
- Indicator: `database_url;github_token_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/cheikh2shift/godex/blob/59ae2f7f9b9226b5025d322499177a63e595df2c/MCP.md
- Repository URL: https://github.com/cheikh2shift/godex
- Assessment: unconfirmed; do not use or test any credentials.

### 548. P2_REVIEW — chicago-tool-library/circulate

- Path: `NIX.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/chicago-tool-library/circulate/blob/f6f95b89caddf8f2556430209aee9dc40f03046a/NIX.md
- Repository URL: https://github.com/chicago-tool-library/circulate
- Assessment: unconfirmed; do not use or test any credentials.

### 549. P2_REVIEW — chloerei/alipay

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/chloerei/alipay/blob/c99f75f568efe23d0af309e98601b31cb85e6295/README.md
- Repository URL: https://github.com/chloerei/alipay
- Assessment: unconfirmed; do not use or test any credentials.

### 550. P2_REVIEW — cloudfoundry-community/bitbucket-boshrelease

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/cloudfoundry-community/bitbucket-boshrelease/blob/5b23d0a3719170e56845f338c87f5856106f1951/README.md
- Repository URL: https://github.com/cloudfoundry-community/bitbucket-boshrelease
- Assessment: unconfirmed; do not use or test any credentials.

### 551. P2_REVIEW — cloudfoundry-community/nginx-release

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/cloudfoundry-community/nginx-release/blob/587cbd5f8c0dd7f655bfded41c5b48ab7c8d4591/README.md
- Repository URL: https://github.com/cloudfoundry-community/nginx-release
- Assessment: unconfirmed; do not use or test any credentials.

### 552. P2_REVIEW — cloudnative-pg/postgres-keycloak-oauth-validator

- Path: `demo.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/cloudnative-pg/postgres-keycloak-oauth-validator/blob/06e4c01c592d0231ee3520db03fcbc5829f2eefe/demo.md
- Repository URL: https://github.com/cloudnative-pg/postgres-keycloak-oauth-validator
- Assessment: unconfirmed; do not use or test any credentials.

### 553. P2_REVIEW — code4romania/theater-hub-api

- Path: `CI.md`
- Indicator: `aws_secret_key_label;secret_access_key_label;access_token_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/code4romania/theater-hub-api/blob/9dbefe676483b65ef8c80fec77be6df218398034/CI.md
- Repository URL: https://github.com/code4romania/theater-hub-api
- Assessment: unconfirmed; do not use or test any credentials.

### 554. P2_REVIEW — codelibs/fess-ds-gsuite

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/codelibs/fess-ds-gsuite/blob/0b67a966c57696e6c81ef5f35f0b102ebeffc8fe/README.md
- Repository URL: https://github.com/codelibs/fess-ds-gsuite
- Assessment: unconfirmed; do not use or test any credentials.

### 555. P2_REVIEW — concourse/docker-image-resource

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/concourse/docker-image-resource/blob/8b7b4426ef5a820bf95fd0c45615639d3fbe0c6e/README.md
- Repository URL: https://github.com/concourse/docker-image-resource
- Assessment: unconfirmed; do not use or test any credentials.

### 556. P2_REVIEW — confluentinc/mongodb-cflt-gcp-genai-quickstart

- Path: `FAQ.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/confluentinc/mongodb-cflt-gcp-genai-quickstart/blob/4292365369714cd6a2d98f55b3b65fbb26db6257/FAQ.md
- Repository URL: https://github.com/confluentinc/mongodb-cflt-gcp-genai-quickstart
- Assessment: unconfirmed; do not use or test any credentials.

### 557. P2_REVIEW — confluentinc/mongodb-cflt-genai-quickstart

- Path: `FAQ.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/confluentinc/mongodb-cflt-genai-quickstart/blob/f0df63b5deca955a54dfe0daaf4a585585ed0ab6/FAQ.md
- Repository URL: https://github.com/confluentinc/mongodb-cflt-genai-quickstart
- Assessment: unconfirmed; do not use or test any credentials.

### 558. P2_REVIEW — connectamey/husky-ai

- Path: `ss.txt`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/connectamey/husky-ai/blob/4edf9074ce514011715ce5f6d28b4f88906a754b/ss.txt
- Repository URL: https://github.com/connectamey/husky-ai
- Assessment: unconfirmed; do not use or test any credentials.

### 559. P2_REVIEW — cookiegg/nof

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/cookiegg/nof/blob/084a93ec4c8b04d38f1f94b387cb6a1d093ba681/README.md
- Repository URL: https://github.com/cookiegg/nof
- Assessment: unconfirmed; do not use or test any credentials.

### 560. P2_REVIEW — crawfordb2026/private-fly

- Path: `tips.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/crawfordb2026/private-fly/blob/356ccc07683c783965843e02c0ee75b22b53486a/tips.md
- Repository URL: https://github.com/crawfordb2026/private-fly
- Assessment: unconfirmed; do not use or test any credentials.

### 561. P2_REVIEW — cryptoparty/handbook

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/cryptoparty/handbook/blob/02c33625fe28760048862078ba4871912900f8a5/README.md
- Repository URL: https://github.com/cryptoparty/handbook
- Assessment: unconfirmed; do not use or test any credentials.

### 562. P2_REVIEW — cunnie/docs

- Path: `aws.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/cunnie/docs/blob/b07b1dd2d43abeaf174bc5da49baef085237a76b/aws.md
- Repository URL: https://github.com/cunnie/docs
- Assessment: unconfirmed; do not use or test any credentials.

### 563. P2_REVIEW — cycloidio/docker-cycloid-toolkit

- Path: `TIPS.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/cycloidio/docker-cycloid-toolkit/blob/b6e5abe3067a071a8dc49ebcec25d998fe480f1b/TIPS.md
- Repository URL: https://github.com/cycloidio/docker-cycloid-toolkit
- Assessment: unconfirmed; do not use or test any credentials.

### 564. P2_REVIEW — danielpmichalski/anki-cloud

- Path: `TODO.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/danielpmichalski/anki-cloud/blob/60fae73709cd3f1d38d93b0c3b251fbf5ed863ba/TODO.md
- Repository URL: https://github.com/danielpmichalski/anki-cloud
- Assessment: unconfirmed; do not use or test any credentials.

### 565. P2_REVIEW — darcys22/noterepo

- Path: `r.md`
- Indicator: `db_password_label;password_assignment`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/darcys22/noterepo/blob/3874da01839687cf1c00903d3fa1d101a429dd07/r.md
- Repository URL: https://github.com/darcys22/noterepo
- Assessment: unconfirmed; do not use or test any credentials.

### 566. P2_REVIEW — dazzy11/NextStep-dep

- Path: `t.txt`
- Indicator: `database_url;api_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/dazzy11/NextStep-dep/blob/4c84ef0921c7c9797768299d557a798693380940/t.txt
- Repository URL: https://github.com/dazzy11/NextStep-dep
- Assessment: unconfirmed; do not use or test any credentials.

### 567. P2_REVIEW — dblock/discord-strava

- Path: `DEV.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/dblock/discord-strava/blob/995a12d03bfdc9f2d94ab8bcb9e33f26ddf42f93/DEV.md
- Repository URL: https://github.com/dblock/discord-strava
- Assessment: unconfirmed; do not use or test any credentials.

### 568. P2_REVIEW — dblock/slack-arena

- Path: `DEV.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/dblock/slack-arena/blob/c8bfab69589a1b42e34af135ab16110d5592d982/DEV.md
- Repository URL: https://github.com/dblock/slack-arena
- Assessment: unconfirmed; do not use or test any credentials.

### 569. P2_REVIEW — dblock/slack-gamebot

- Path: `DEV.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/dblock/slack-gamebot/blob/92065d050817892f3ce69464e4648068dc4cc08e/DEV.md
- Repository URL: https://github.com/dblock/slack-gamebot
- Assessment: unconfirmed; do not use or test any credentials.

### 570. P2_REVIEW — dblock/slack-market

- Path: `DEV.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/dblock/slack-market/blob/0f31cc0076b28f0bbba7204dec075a40dc0d971c/DEV.md
- Repository URL: https://github.com/dblock/slack-market
- Assessment: unconfirmed; do not use or test any credentials.

### 571. P2_REVIEW — dblock/slack-sup

- Path: `DEV.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/dblock/slack-sup/blob/5f127dcb57eb626bd6326ef59798c3351c9ca281/DEV.md
- Repository URL: https://github.com/dblock/slack-sup
- Assessment: unconfirmed; do not use or test any credentials.

### 572. P2_REVIEW — deductive-ai/aws-setup

- Path: `FAQ.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/deductive-ai/aws-setup/blob/1bd1970be6ee763062334391cf1a1f70bc357313/FAQ.md
- Repository URL: https://github.com/deductive-ai/aws-setup
- Assessment: unconfirmed; do not use or test any credentials.

### 573. P2_REVIEW — deltaprojects/foreman_discovery_image_installer

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/deltaprojects/foreman_discovery_image_installer/blob/d3fa1613314a71fae95b4696a01085fa391bf856/README.md
- Repository URL: https://github.com/deltaprojects/foreman_discovery_image_installer
- Assessment: unconfirmed; do not use or test any credentials.

### 574. P2_REVIEW — demoiselle/framework-documentation

- Path: `jwt.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/demoiselle/framework-documentation/blob/4d78b9261bdc49f9c1ac3f592b4c2461cda4d668/jwt.md
- Repository URL: https://github.com/demoiselle/framework-documentation
- Assessment: unconfirmed; do not use or test any credentials.

### 575. P2_REVIEW — demopark/sequelize-docs-Zh-CN

- Path: `cli.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/demopark/sequelize-docs-Zh-CN/blob/1ea7803202f46786b6b2bfbd4973b9ee1a41af1d/cli.md
- Repository URL: https://github.com/demopark/sequelize-docs-Zh-CN
- Assessment: unconfirmed; do not use or test any credentials.

### 576. P2_REVIEW — denizalti/openreplica

- Path: `README`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/denizalti/openreplica/blob/5a51ba2b475f44da221304ea7f0b9118f2e8511a/README
- Repository URL: https://github.com/denizalti/openreplica
- Assessment: unconfirmed; do not use or test any credentials.

### 577. P2_REVIEW — denoland/ronly

- Path: `spec.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/denoland/ronly/blob/fc49a71bc269e7f3da08b223c3d16115fa1057f8/spec.md
- Repository URL: https://github.com/denoland/ronly
- Assessment: unconfirmed; do not use or test any credentials.

### 578. P2_REVIEW — devmasterbob/automated-joomla-master

- Path: `DEV.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/devmasterbob/automated-joomla-master/blob/359967951f8aaa26f719aa13919984c4d95481c7/DEV.txt
- Repository URL: https://github.com/devmasterbob/automated-joomla-master
- Assessment: unconfirmed; do not use or test any credentials.

### 579. P2_REVIEW — devops-dynamics/devops-dynamics-website

- Path: `INS.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/devops-dynamics/devops-dynamics-website/blob/662bcf9834023d9317862788cac30b3358654e31/INS.md
- Repository URL: https://github.com/devops-dynamics/devops-dynamics-website
- Assessment: unconfirmed; do not use or test any credentials.

### 580. P2_REVIEW — dianhua1560/bhgh

- Path: `DEV.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/dianhua1560/bhgh/blob/a64cb38453376df68d142270709aa7377c721e71/DEV.md
- Repository URL: https://github.com/dianhua1560/bhgh
- Assessment: unconfirmed; do not use or test any credentials.

### 581. P2_REVIEW — dotbitHQ/das-register

- Path: `API.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/dotbitHQ/das-register/blob/e2f29b08c38c6cedb7c48655f97cc107e48af3e0/API.md
- Repository URL: https://github.com/dotbitHQ/das-register
- Assessment: unconfirmed; do not use or test any credentials.

### 582. P2_REVIEW — dotbitHQ/unipay

- Path: `API.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/dotbitHQ/unipay/blob/5846c206ce0676655e50c4950a9fbe98e6ec3ac9/API.md
- Repository URL: https://github.com/dotbitHQ/unipay
- Assessment: unconfirmed; do not use or test any credentials.

### 583. P2_REVIEW — dotcypress/tilde-token

- Path: `readme.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/dotcypress/tilde-token/blob/5b46fd582285ac0f2639020e40821ab6959d5a24/readme.md
- Repository URL: https://github.com/dotcypress/tilde-token
- Assessment: unconfirmed; do not use or test any credentials.

### 584. P2_REVIEW — dragouf/AppStoreServerApi

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/dragouf/AppStoreServerApi/blob/77d95806d8dcfd60b03323a99cdc82d75eee819c/README.md
- Repository URL: https://github.com/dragouf/AppStoreServerApi
- Assessment: unconfirmed; do not use or test any credentials.

### 585. P2_REVIEW — drbarzaga/react-dojo

- Path: `PLAN.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/drbarzaga/react-dojo/blob/8007d7b15864ae74f85dee1c69f4df22de5d6695/PLAN.md
- Repository URL: https://github.com/drbarzaga/react-dojo
- Assessment: unconfirmed; do not use or test any credentials.

### 586. P2_REVIEW — dream-horizon-org/checkmate

- Path: `HLD.md`
- Indicator: `database_url;client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/dream-horizon-org/checkmate/blob/bba5937c08bedb13e5fc7f0e9b87bf00fcba03e3/HLD.md
- Repository URL: https://github.com/dream-horizon-org/checkmate
- Assessment: unconfirmed; do not use or test any credentials.

### 587. P2_REVIEW — drxpofficial/Leaderboard

- Path: `2.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/drxpofficial/Leaderboard/blob/a6127e8836cc4c0089b406d606bfd7392ab19729/2.md
- Repository URL: https://github.com/drxpofficial/Leaderboard
- Assessment: unconfirmed; do not use or test any credentials.

### 588. P2_REVIEW — dwyl/imgup

- Path: `api.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/dwyl/imgup/blob/353e14b223e41bae5c58813235c6a14032e4230c/api.md
- Repository URL: https://github.com/dwyl/imgup
- Assessment: unconfirmed; do not use or test any credentials.

### 589. P2_REVIEW — dwyschka/localkit

- Path: `s3.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/dwyschka/localkit/blob/7fe872e9a1449bf12e0c21c17082c911f8ba76be/s3.md
- Repository URL: https://github.com/dwyschka/localkit
- Assessment: unconfirmed; do not use or test any credentials.

### 590. P2_REVIEW — earth-app/doc2lora

- Path: `USAGE.md`
- Indicator: `aws_secret_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/earth-app/doc2lora/blob/3a0c33eb79908f62fd32c52f095ef32b85998ae5/USAGE.md
- Repository URL: https://github.com/earth-app/doc2lora
- Assessment: unconfirmed; do not use or test any credentials.

### 591. P2_REVIEW — egen/service-fabric-boshrelease

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/egen/service-fabric-boshrelease/blob/94254d585c45692297a46f27ee9084cd0ec7939b/README.md
- Repository URL: https://github.com/egen/service-fabric-boshrelease
- Assessment: unconfirmed; do not use or test any credentials.

### 592. P2_REVIEW — einaros/heartbleed-tools

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/einaros/heartbleed-tools/blob/7ecb1e35f4b30ff6e6c2ecf72b6be32c9e63b91e/README.md
- Repository URL: https://github.com/einaros/heartbleed-tools
- Assessment: unconfirmed; do not use or test any credentials.

### 593. P2_REVIEW — emac-utd/git-syllabus

- Path: `todo.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/emac-utd/git-syllabus/blob/b7809a247d506a729dfdf46af43d60f15ff1bf3b/todo.md
- Repository URL: https://github.com/emac-utd/git-syllabus
- Assessment: unconfirmed; do not use or test any credentials.

### 594. P2_REVIEW — embulk/embulk-output-bigquery

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/embulk/embulk-output-bigquery/blob/e4cc3fcbb6a481a71874c357a947b298ceb2bc23/README.md
- Repository URL: https://github.com/embulk/embulk-output-bigquery
- Assessment: unconfirmed; do not use or test any credentials.

### 595. P2_REVIEW — embulk/embulk-output-gcs

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/embulk/embulk-output-gcs/blob/427f9fdc677885a7467606393f6a343ceda2c4c9/README.md
- Repository URL: https://github.com/embulk/embulk-output-gcs
- Assessment: unconfirmed; do not use or test any credentials.

### 596. P2_REVIEW — embulk/embulk-output-sftp

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/embulk/embulk-output-sftp/blob/6cf442dd45d9fa50c1edbff194dce35209487c0f/README.md
- Repository URL: https://github.com/embulk/embulk-output-sftp
- Assessment: unconfirmed; do not use or test any credentials.

### 597. P2_REVIEW — enginterzi/amazon-seller-mcp

- Path: `API.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/enginterzi/amazon-seller-mcp/blob/c58550f9d1b245af1773755fbe15f500b51f9a73/API.md
- Repository URL: https://github.com/enginterzi/amazon-seller-mcp
- Assessment: unconfirmed; do not use or test any credentials.

### 598. P2_REVIEW — eooce/sbx-native

- Path: `NODE.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/eooce/sbx-native/blob/7e66ff47ca09a47e4ab2c975dababdb04765026a/NODE.md
- Repository URL: https://github.com/eooce/sbx-native
- Assessment: unconfirmed; do not use or test any credentials.

### 599. P2_REVIEW — epfl-sdf/openid_cli_hello_world

- Path: `DOC.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/epfl-sdf/openid_cli_hello_world/blob/e67b83f04bbcf350b927c664796cf0f18ed66ffb/DOC.md
- Repository URL: https://github.com/epfl-sdf/openid_cli_hello_world
- Assessment: unconfirmed; do not use or test any credentials.

### 600. P2_REVIEW — ercole-io/tico

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/ercole-io/tico/blob/2ca8d133c0760204a6af18e9979c71e82c7eae64/README.md
- Repository URL: https://github.com/ercole-io/tico
- Assessment: unconfirmed; do not use or test any credentials.

### 601. P2_REVIEW — evanshortiss/env-var

- Path: `API.md`
- Indicator: `db_password_label;secret_assignment`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/evanshortiss/env-var/blob/56fe6cb47e1e79e0a4ec5474daab9dc3cae73947/API.md
- Repository URL: https://github.com/evanshortiss/env-var
- Assessment: unconfirmed; do not use or test any credentials.

### 602. P2_REVIEW — featbit/featbit-terraform-aws

- Path: `memo.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/featbit/featbit-terraform-aws/blob/912ac47ab8af2f3f39b3f8783c971fbafc7fca7c/memo.md
- Repository URL: https://github.com/featbit/featbit-terraform-aws
- Assessment: unconfirmed; do not use or test any credentials.

### 603. P2_REVIEW — fedora-infra/python-fedora

- Path: `NEWS`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/fedora-infra/python-fedora/blob/54b015371c944f23a4c49f30ef914fd658ff0c94/NEWS
- Repository URL: https://github.com/fedora-infra/python-fedora
- Assessment: unconfirmed; do not use or test any credentials.

### 604. P2_REVIEW — filipedeschamps/parse-google-docs-json

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/filipedeschamps/parse-google-docs-json/blob/d95dd1213125d927aa48271f87daadf8ae0b89a1/README.md
- Repository URL: https://github.com/filipedeschamps/parse-google-docs-json
- Assessment: unconfirmed; do not use or test any credentials.

### 605. P2_REVIEW — finsweet/fireworkers

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/finsweet/fireworkers/blob/a3872aff61cf8990ba0c1d234e433a68738b91d1/README.md
- Repository URL: https://github.com/finsweet/fireworkers
- Assessment: unconfirmed; do not use or test any credentials.

### 606. P2_REVIEW — fog/fog-google

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/fog/fog-google/blob/f5b660c86002a50c91d1854979619939d2f8d8a8/README.md
- Repository URL: https://github.com/fog/fog-google
- Assessment: unconfirmed; do not use or test any credentials.

### 607. P2_REVIEW — founderlab/founderlabinterns.com

- Path: `wtf.txt`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/founderlab/founderlabinterns.com/blob/0413f4174de19cbcd5480112c0f78ff36bdd5ffe/wtf.txt
- Repository URL: https://github.com/founderlab/founderlabinterns.com
- Assessment: unconfirmed; do not use or test any credentials.

### 608. P2_REVIEW — fredjean/middleman-s3_sync

- Path: `WARP.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/fredjean/middleman-s3_sync/blob/92c767571941e7515830e090ac47584e0257e658/WARP.md
- Repository URL: https://github.com/fredjean/middleman-s3_sync
- Assessment: unconfirmed; do not use or test any credentials.

### 609. P2_REVIEW — fredrikburmester/streamystats

- Path: `AIO.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/fredrikburmester/streamystats/blob/1a154af6e59b5f6a5407f1e18704cc6bd5ac15bf/AIO.md
- Repository URL: https://github.com/fredrikburmester/streamystats
- Assessment: unconfirmed; do not use or test any credentials.

### 610. P2_REVIEW — fxckcode/envy

- Path: `PRD.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/fxckcode/envy/blob/414ba3b756981de3d3f42af8c441c4c249769022/PRD.md
- Repository URL: https://github.com/fxckcode/envy
- Assessment: unconfirmed; do not use or test any credentials.

### 611. P2_REVIEW — gameenginedude/spotifinder-backend

- Path: `env.txt`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/gameenginedude/spotifinder-backend/blob/70d7f97a9ba9b0fdb3ac5a7a8803e95323e8b68c/env.txt
- Repository URL: https://github.com/gameenginedude/spotifinder-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 612. P2_REVIEW — garystafford/content-clustering-ollama

- Path: `env.txt`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/garystafford/content-clustering-ollama/blob/fc6bb06c2120f45c291034ce16cf80cfb56c45a2/env.txt
- Repository URL: https://github.com/garystafford/content-clustering-ollama
- Assessment: unconfirmed; do not use or test any credentials.

### 613. P2_REVIEW — garystafford/nova-mm-embedding-model-demo

- Path: `env.txt`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/garystafford/nova-mm-embedding-model-demo/blob/afee0c086775be3ddd452dbe58c6437935c3b193/env.txt
- Repository URL: https://github.com/garystafford/nova-mm-embedding-model-demo
- Assessment: unconfirmed; do not use or test any credentials.

### 614. P2_REVIEW — garystafford/twelve-labs-bedrock-opensearch-demo

- Path: `env.txt`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/garystafford/twelve-labs-bedrock-opensearch-demo/blob/66eb5221a2513c308989067a087977aec185a70c/env.txt
- Repository URL: https://github.com/garystafford/twelve-labs-bedrock-opensearch-demo
- Assessment: unconfirmed; do not use or test any credentials.

### 615. P2_REVIEW — garystafford/twelve-labs-opensearch-demo

- Path: `env.txt`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/garystafford/twelve-labs-opensearch-demo/blob/256f76bcd84e64ff8d421a02c97bbb39dd5b1bee/env.txt
- Repository URL: https://github.com/garystafford/twelve-labs-opensearch-demo
- Assessment: unconfirmed; do not use or test any credentials.

### 616. P2_REVIEW — gbaptista/gemini-ai

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/gbaptista/gemini-ai/blob/2c52a849fb80e1a3dc13eda3635eef170e754be3/README.md
- Repository URL: https://github.com/gbaptista/gemini-ai
- Assessment: unconfirmed; do not use or test any credentials.

### 617. P2_REVIEW — gemini-cli-extensions/security

- Path: `GEMINI.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/gemini-cli-extensions/security/blob/2227f3cf7150972baac695b8233abc2186408538/GEMINI.md
- Repository URL: https://github.com/gemini-cli-extensions/security
- Assessment: unconfirmed; do not use or test any credentials.

### 618. P2_REVIEW — gerlacdt/quarkus-playground

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/gerlacdt/quarkus-playground/blob/d40e96bf374e99f0ec4d265bb41bad5576a63641/README.md
- Repository URL: https://github.com/gerlacdt/quarkus-playground
- Assessment: unconfirmed; do not use or test any credentials.

### 619. P2_REVIEW — geteduroam/letswifi-portal

- Path: `API.md`
- Indicator: `client_secret_label;access_token_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/geteduroam/letswifi-portal/blob/ebd652baf8aab87e8c22e63cd2f82d8ec293894a/API.md
- Repository URL: https://github.com/geteduroam/letswifi-portal
- Assessment: unconfirmed; do not use or test any credentials.

### 620. P2_REVIEW — gizmax/Sandcastle

- Path: `SPEC.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/gizmax/Sandcastle/blob/b6f38ed7cb0615aa5c23e7e469f579b577662ae5/SPEC.md
- Repository URL: https://github.com/gizmax/Sandcastle
- Assessment: unconfirmed; do not use or test any credentials.

### 621. P2_REVIEW — go-vela/vela-s3-cache

- Path: `DOCS.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/go-vela/vela-s3-cache/blob/9520de12ea76e9ecef26c41291e868d27351f1c3/DOCS.md
- Repository URL: https://github.com/go-vela/vela-s3-cache
- Assessment: unconfirmed; do not use or test any credentials.

### 622. P2_REVIEW — godBuddha/tomua-map-travel

- Path: `ENV.md`
- Indicator: `database_url;db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/godBuddha/tomua-map-travel/blob/db3341e4a18d66dbfe0083a93bff4945de278da8/ENV.md
- Repository URL: https://github.com/godBuddha/tomua-map-travel
- Assessment: unconfirmed; do not use or test any credentials.

### 623. P2_REVIEW — gojek/kingsly

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/gojek/kingsly/blob/116e447e730026b642caedd874b82e48930e9252/README.md
- Repository URL: https://github.com/gojek/kingsly
- Assessment: unconfirmed; do not use or test any credentials.

### 624. P2_REVIEW — gonelist/gonelist-doc

- Path: `bt.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/gonelist/gonelist-doc/blob/0882be8e97f23d81e697c8b09d914295710edfda/bt.md
- Repository URL: https://github.com/gonelist/gonelist-doc
- Assessment: unconfirmed; do not use or test any credentials.

### 625. P2_REVIEW — grahamhelton/dredge

- Path: `net.txt`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/grahamhelton/dredge/blob/bcb6ea916b6ecdd68592da90fa7894cabf75a62a/net.txt
- Repository URL: https://github.com/grahamhelton/dredge
- Assessment: unconfirmed; do not use or test any credentials.

### 626. P2_REVIEW — grasp-labs/ds-stoa

- Path: `PyPI.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/grasp-labs/ds-stoa/blob/9e6a730bc9ad2d802ab306ce05a6a410c37c0ea5/PyPI.md
- Repository URL: https://github.com/grasp-labs/ds-stoa
- Assessment: unconfirmed; do not use or test any credentials.

### 627. P2_REVIEW — gtaylor44/FirebaseAuth

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/gtaylor44/FirebaseAuth/blob/374ca37987c8b9235df64663fec43cc4cca885e5/README.md
- Repository URL: https://github.com/gtaylor44/FirebaseAuth
- Assessment: unconfirmed; do not use or test any credentials.

### 628. P2_REVIEW — gtg7784/dr-manhattan-rust

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/gtg7784/dr-manhattan-rust/blob/c1eba5e383c93a5cbef735a92e7f40ad2f4f83fa/README.md
- Repository URL: https://github.com/gtg7784/dr-manhattan-rust
- Assessment: unconfirmed; do not use or test any credentials.

### 629. P2_REVIEW — guild-is/guild.is

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/guild-is/guild.is/blob/8fa409f7c51155f44373704f9fa1305315110879/README.md
- Repository URL: https://github.com/guild-is/guild.is
- Assessment: unconfirmed; do not use or test any credentials.

### 630. P2_REVIEW — h33tlit/secret-regex-list

- Path: `README.md`
- Indicator: `rsa_private_key_header;stripe_live_prefix`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/h33tlit/secret-regex-list/blob/2af20050e2eff21abb52ec2e4485df0e8ed4abcf/README.md
- Repository URL: https://github.com/h33tlit/secret-regex-list
- Assessment: unconfirmed; do not use or test any credentials.

### 631. P2_REVIEW — hackclub/lapse

- Path: `API.md`
- Indicator: `client_secret_label;access_token_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/hackclub/lapse/blob/4d97d316db5a49f4365cb2eae494d5a414d12e0f/API.md
- Repository URL: https://github.com/hackclub/lapse
- Assessment: unconfirmed; do not use or test any credentials.

### 632. P2_REVIEW — hanzoai/erp

- Path: `LLM.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/hanzoai/erp/blob/37f92888b8f5ea34715706456d5bc2109f295d7b/LLM.md
- Repository URL: https://github.com/hanzoai/erp
- Assessment: unconfirmed; do not use or test any credentials.

### 633. P2_REVIEW — harbourrocks/harbour

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/harbourrocks/harbour/blob/cb90f3590321e3dcf3cb33399c176d1f1806c9b4/README.md
- Repository URL: https://github.com/harbourrocks/harbour
- Assessment: unconfirmed; do not use or test any credentials.

### 634. P2_REVIEW — harsheetkd/SAFEST-Route-Planner

- Path: `env.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/harsheetkd/SAFEST-Route-Planner/blob/abe4bc7f4b9be5b0faf746edbafaa81060cc067c/env.txt
- Repository URL: https://github.com/harsheetkd/SAFEST-Route-Planner
- Assessment: unconfirmed; do not use or test any credentials.

### 635. P2_REVIEW — hemantkamalakar/google_fit_hass

- Path: `info.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/hemantkamalakar/google_fit_hass/blob/235f31b95de1517286c8375f812a50dccb553c6d/info.md
- Repository URL: https://github.com/hemantkamalakar/google_fit_hass
- Assessment: unconfirmed; do not use or test any credentials.

### 636. P2_REVIEW — henilcalagiya/google-sheets-mcp

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/henilcalagiya/google-sheets-mcp/blob/fa4bc1fb940fcbeba9d73f86b232ba02b50f8a8a/README.md
- Repository URL: https://github.com/henilcalagiya/google-sheets-mcp
- Assessment: unconfirmed; do not use or test any credentials.

### 637. P2_REVIEW — hglabplh-tech/HGPExamWorkFlowAndChat

- Path: `run.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/hglabplh-tech/HGPExamWorkFlowAndChat/blob/2bb0df5b7a8a17432821a924a043eb6e49c58433/run.md
- Repository URL: https://github.com/hglabplh-tech/HGPExamWorkFlowAndChat
- Assessment: unconfirmed; do not use or test any credentials.

### 638. P2_REVIEW — hideakitai/MQTTPubSubClient

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/hideakitai/MQTTPubSubClient/blob/43771e8104899f86ad92a22266427608d7a2d262/README.md
- Repository URL: https://github.com/hideakitai/MQTTPubSubClient
- Assessment: unconfirmed; do not use or test any credentials.

### 639. P2_REVIEW — hkparker/proxyd

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/hkparker/proxyd/blob/a0b5167382878cb290bb59da888f703b517d2d99/README.md
- Repository URL: https://github.com/hkparker/proxyd
- Assessment: unconfirmed; do not use or test any credentials.

### 640. P2_REVIEW — hoangsonww/WealthWise-Finance-Tracker

- Path: `PLAN.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/hoangsonww/WealthWise-Finance-Tracker/blob/8abd4ea065e461233584a63e65b70252604f67f9/PLAN.md
- Repository URL: https://github.com/hoangsonww/WealthWise-Finance-Tracker
- Assessment: unconfirmed; do not use or test any credentials.

### 641. P2_REVIEW — holaSpirit/holaspirit-docs

- Path: `api.md`
- Indicator: `client_secret_label;access_token_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/holaSpirit/holaspirit-docs/blob/d6c23060daba443e87a9be3ddf31bdccd969994c/api.md
- Repository URL: https://github.com/holaSpirit/holaspirit-docs
- Assessment: unconfirmed; do not use or test any credentials.

### 642. P2_REVIEW — hsmade/certbot-dns-transip

- Path: `USAGE.rst`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/hsmade/certbot-dns-transip/blob/bedca68b173f33d4815570b91f46596fe33b5bc5/USAGE.rst
- Repository URL: https://github.com/hsmade/certbot-dns-transip
- Assessment: unconfirmed; do not use or test any credentials.

### 643. P2_REVIEW — iTranslateX/odoo-cookbook

- Path: `1.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/iTranslateX/odoo-cookbook/blob/66da4e88051db26d632f21872625e80b83a86db3/1.md
- Repository URL: https://github.com/iTranslateX/odoo-cookbook
- Assessment: unconfirmed; do not use or test any credentials.

### 644. P2_REVIEW — iambstha/next-auth-implementation

- Path: `env.txt`
- Indicator: `client_secret_label;secret_assignment`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/iambstha/next-auth-implementation/blob/de34eddcaa3def9f0bf0f1a023f353da37e411e1/env.txt
- Repository URL: https://github.com/iambstha/next-auth-implementation
- Assessment: unconfirmed; do not use or test any credentials.

### 645. P2_REVIEW — ibm-cloud-docs/cloud-object-storage

- Path: `go.md`
- Indicator: `aws_secret_key_label;secret_access_key_label;api_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/ibm-cloud-docs/cloud-object-storage/blob/58112f68d3675230c87793e2c3226a7d86328d31/go.md
- Repository URL: https://github.com/ibm-cloud-docs/cloud-object-storage
- Assessment: unconfirmed; do not use or test any credentials.

### 646. P2_REVIEW — ibm-cloud-docs/cloud-object-storage

- Path: `java.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/ibm-cloud-docs/cloud-object-storage/blob/58112f68d3675230c87793e2c3226a7d86328d31/java.md
- Repository URL: https://github.com/ibm-cloud-docs/cloud-object-storage
- Assessment: unconfirmed; do not use or test any credentials.

### 647. P2_REVIEW — ibm-cloud-docs/cloud-object-storage

- Path: `node.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/ibm-cloud-docs/cloud-object-storage/blob/58112f68d3675230c87793e2c3226a7d86328d31/node.md
- Repository URL: https://github.com/ibm-cloud-docs/cloud-object-storage
- Assessment: unconfirmed; do not use or test any credentials.

### 648. P2_REVIEW — icekidtech/UniVerify

- Path: `db.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/icekidtech/UniVerify/blob/fc4d7ebfc564a23a2920fe0e6e8110871f4199f7/db.md
- Repository URL: https://github.com/icekidtech/UniVerify
- Assessment: unconfirmed; do not use or test any credentials.

### 649. P2_REVIEW — idcrook/kubernetes-homespun

- Path: `RUN.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/idcrook/kubernetes-homespun/blob/5e4c73ce7c6657449c45fe6528ab6b15af9088e7/RUN.md
- Repository URL: https://github.com/idcrook/kubernetes-homespun
- Assessment: unconfirmed; do not use or test any credentials.

### 650. P2_REVIEW — ideawu/Objective-C-RSA

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/ideawu/Objective-C-RSA/blob/12bff24634cb341f029a64d486734adde1843257/README.md
- Repository URL: https://github.com/ideawu/Objective-C-RSA
- Assessment: unconfirmed; do not use or test any credentials.

### 651. P2_REVIEW — ihrishikesh0896/vulnreach

- Path: `CI.md`
- Indicator: `database_url;github_token_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/ihrishikesh0896/vulnreach/blob/1ffdc233030a3a78e23134fba0eaf3a784cb3468/CI.md
- Repository URL: https://github.com/ihrishikesh0896/vulnreach
- Assessment: unconfirmed; do not use or test any credentials.

### 652. P2_REVIEW — imurpalvicky/testnodejsApp

- Path: `db.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/imurpalvicky/testnodejsApp/blob/f1124157dc886ae6d3c5d3da06bc3e04dea2a9db/db.txt
- Repository URL: https://github.com/imurpalvicky/testnodejsApp
- Assessment: unconfirmed; do not use or test any credentials.

### 653. P2_REVIEW — indygreg/apple-code-sign-action

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/indygreg/apple-code-sign-action/blob/5e7a4a01fe4dffe948ef3bcf1f4538d963cb0c72/README.md
- Repository URL: https://github.com/indygreg/apple-code-sign-action
- Assessment: unconfirmed; do not use or test any credentials.

### 654. P2_REVIEW — inspec/inspec-gcp

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/inspec/inspec-gcp/blob/36f22c34f68c2a4eb678a7582dd648a84855e019/README.md
- Repository URL: https://github.com/inspec/inspec-gcp
- Assessment: unconfirmed; do not use or test any credentials.

### 655. P2_REVIEW — intelie/python-openidconnect

- Path: `TODO.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/intelie/python-openidconnect/blob/f3d733aa45f6e7bff02fe9b8aa1ea6abf5f9ca53/TODO.md
- Repository URL: https://github.com/intelie/python-openidconnect
- Assessment: unconfirmed; do not use or test any credentials.

### 656. P2_REVIEW — ipedrazas/drone-helm

- Path: `DOCS.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/ipedrazas/drone-helm/blob/c110459ad9aff373cb25e3fb3a6650d31209dde7/DOCS.md
- Repository URL: https://github.com/ipedrazas/drone-helm
- Assessment: unconfirmed; do not use or test any credentials.

### 657. P2_REVIEW — iserlatam/api-miurafx

- Path: `p.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/iserlatam/api-miurafx/blob/ed613f44169653030cb4a5157d2d3700e208caee/p.txt
- Repository URL: https://github.com/iserlatam/api-miurafx
- Assessment: unconfirmed; do not use or test any credentials.

### 658. P2_REVIEW — jasonfriedland/httpie-asap-auth

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/jasonfriedland/httpie-asap-auth/blob/b6ab83af87cb1c75858551caeb54675edcef34f0/README.md
- Repository URL: https://github.com/jasonfriedland/httpie-asap-auth
- Assessment: unconfirmed; do not use or test any credentials.

### 659. P2_REVIEW — jcberquist/jwt-cfml

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/jcberquist/jwt-cfml/blob/243b2bacfbc94cb836ba1ff6d9e406b7f080b795/README.md
- Repository URL: https://github.com/jcberquist/jwt-cfml
- Assessment: unconfirmed; do not use or test any credentials.

### 660. P2_REVIEW — jcesarstef/ghhdb-Github-Hacking-Database

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/jcesarstef/ghhdb-Github-Hacking-Database/blob/149ec9486546d10d7e2a41ce277826bbd39d15d3/README.md
- Repository URL: https://github.com/jcesarstef/ghhdb-Github-Hacking-Database
- Assessment: unconfirmed; do not use or test any credentials.

### 661. P2_REVIEW — jenkinsci/digitalocean-plugin

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/jenkinsci/digitalocean-plugin/blob/b2c7dde5e4b442a7c35dbaf279b7fe76e108cf16/README.md
- Repository URL: https://github.com/jenkinsci/digitalocean-plugin
- Assessment: unconfirmed; do not use or test any credentials.

### 662. P2_REVIEW — jenkinsci/ec2-plugin

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/jenkinsci/ec2-plugin/blob/79de4fd2d03bad4f4d3b3baa9f45c181444ca9f0/README.md
- Repository URL: https://github.com/jenkinsci/ec2-plugin
- Assessment: unconfirmed; do not use or test any credentials.

### 663. P2_REVIEW — jeremyarancio/invoice-reader-app

- Path: `NOTES.md`
- Indicator: `aws_secret_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/jeremyarancio/invoice-reader-app/blob/4ae88ef8b75743f85aa7d376688b2c76005b92f0/NOTES.md
- Repository URL: https://github.com/jeremyarancio/invoice-reader-app
- Assessment: unconfirmed; do not use or test any credentials.

### 664. P2_REVIEW — jesusgavancho/TryHackMe_and_HackTheBox

- Path: `0day.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/jesusgavancho/TryHackMe_and_HackTheBox/blob/79a1966038832fba66dd39cfa0d8a08622530192/0day.md
- Repository URL: https://github.com/jesusgavancho/TryHackMe_and_HackTheBox
- Assessment: unconfirmed; do not use or test any credentials.

### 665. P2_REVIEW — jesusgavancho/TryHackMe_and_HackTheBox

- Path: `Jack.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/jesusgavancho/TryHackMe_and_HackTheBox/blob/79a1966038832fba66dd39cfa0d8a08622530192/Jack.md
- Repository URL: https://github.com/jesusgavancho/TryHackMe_and_HackTheBox
- Assessment: unconfirmed; do not use or test any credentials.

### 666. P2_REVIEW — jesusgavancho/TryHackMe_and_HackTheBox

- Path: `Ra 2.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/jesusgavancho/TryHackMe_and_HackTheBox/blob/79a1966038832fba66dd39cfa0d8a08622530192/Ra 2.md
- Repository URL: https://github.com/jesusgavancho/TryHackMe_and_HackTheBox
- Assessment: unconfirmed; do not use or test any credentials.

### 667. P2_REVIEW — jesusgavancho/TryHackMe_and_HackTheBox

- Path: `Willow.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/jesusgavancho/TryHackMe_and_HackTheBox/blob/79a1966038832fba66dd39cfa0d8a08622530192/Willow.md
- Repository URL: https://github.com/jesusgavancho/TryHackMe_and_HackTheBox
- Assessment: unconfirmed; do not use or test any credentials.

### 668. P2_REVIEW — jesusmira/BiblioLorcana

- Path: `ENV.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/jesusmira/BiblioLorcana/blob/8ec9f6b917236daa3d1d6c651d1f46349a5d9809/ENV.md
- Repository URL: https://github.com/jesusmira/BiblioLorcana
- Assessment: unconfirmed; do not use or test any credentials.

### 669. P2_REVIEW — jfrog/Evidence-Examples

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/jfrog/Evidence-Examples/blob/f61d951e78475f7f2021e1c56cded1e720b5e90d/README.md
- Repository URL: https://github.com/jfrog/Evidence-Examples
- Assessment: unconfirmed; do not use or test any credentials.

### 670. P2_REVIEW — jgazzin/tp-tienda-codo

- Path: `sql.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/jgazzin/tp-tienda-codo/blob/a97ea517a0f1061ee0205e31c2600eb03126c30c/sql.txt
- Repository URL: https://github.com/jgazzin/tp-tienda-codo
- Assessment: unconfirmed; do not use or test any credentials.

### 671. P2_REVIEW — jheidebrink-ma/m7prog_opdrachtensite

- Path: `faq.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/jheidebrink-ma/m7prog_opdrachtensite/blob/bfa49690f9db481c89fcf580a0d9d7b72a1e622d/faq.md
- Repository URL: https://github.com/jheidebrink-ma/m7prog_opdrachtensite
- Assessment: unconfirmed; do not use or test any credentials.

### 672. P2_REVIEW — jiramo/jiramo

- Path: `DOCS.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/jiramo/jiramo/blob/3a7815cc0b6fe3f891959be10291506cc7c5b793/DOCS.md
- Repository URL: https://github.com/jiramo/jiramo
- Assessment: unconfirmed; do not use or test any credentials.

### 673. P2_REVIEW — josephgoksu/prime-nestjs

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/josephgoksu/prime-nestjs/blob/705c24587be369d98a1717840aa697b3ae636ef8/README.md
- Repository URL: https://github.com/josephgoksu/prime-nestjs
- Assessment: unconfirmed; do not use or test any credentials.

### 674. P2_REVIEW — jpwesselink/dotsec-rs

- Path: `QA.md`
- Indicator: `database_url;api_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/jpwesselink/dotsec-rs/blob/d1fdd30e9d01a760df99f8f86e3bc16c6251f558/QA.md
- Repository URL: https://github.com/jpwesselink/dotsec-rs
- Assessment: unconfirmed; do not use or test any credentials.

### 675. P2_REVIEW — jrd/django-oauth2-authcodeflow

- Path: `OP.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/jrd/django-oauth2-authcodeflow/blob/f9eca34829c55843843071c99b4454c927f4fe63/OP.md
- Repository URL: https://github.com/jrd/django-oauth2-authcodeflow
- Assessment: unconfirmed; do not use or test any credentials.

### 676. P2_REVIEW — julian-richter/AccountChecker

- Path: `DB.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/julian-richter/AccountChecker/blob/2274cdc75031e10eb8a47d4f561ba8a90c7389c0/DB.md
- Repository URL: https://github.com/julian-richter/AccountChecker
- Assessment: unconfirmed; do not use or test any credentials.

### 677. P2_REVIEW — junchil/eks-cluster

- Path: `SETUP.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/junchil/eks-cluster/blob/f1a6950402777980f57c97337989ee4749f86ccd/SETUP.md
- Repository URL: https://github.com/junchil/eks-cluster
- Assessment: unconfirmed; do not use or test any credentials.

### 678. P2_REVIEW — kalviumcommunity/S74_capstone_yogesh_guessync

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/kalviumcommunity/S74_capstone_yogesh_guessync/blob/de0df52e77e32ce69730bef87a16c671000b6bbe/README.md
- Repository URL: https://github.com/kalviumcommunity/S74_capstone_yogesh_guessync
- Assessment: unconfirmed; do not use or test any credentials.

### 679. P2_REVIEW — kaonone/nucypher-hackaton

- Path: `NOTE.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/kaonone/nucypher-hackaton/blob/270073cf1d283c5869f21ab60a0c37101d4cbb2b/NOTE.md
- Repository URL: https://github.com/kaonone/nucypher-hackaton
- Assessment: unconfirmed; do not use or test any credentials.

### 680. P2_REVIEW — kelompokpia/inkayat_kost

- Path: `env.txt`
- Indicator: `aws_secret_key_label;db_password_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/kelompokpia/inkayat_kost/blob/465dfe7ae1b7e3a6dc4656ab80cb1e7b5aa388c2/env.txt
- Repository URL: https://github.com/kelompokpia/inkayat_kost
- Assessment: unconfirmed; do not use or test any credentials.

### 681. P2_REVIEW — kexue-z/nonebot-plugin-heweather

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/kexue-z/nonebot-plugin-heweather/blob/1975abc2d10eae22c9a5fc397ed06079670d5f58/README.md
- Repository URL: https://github.com/kexue-z/nonebot-plugin-heweather
- Assessment: unconfirmed; do not use or test any credentials.

### 682. P2_REVIEW — keycloak/keycloak-github-bot

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/keycloak/keycloak-github-bot/blob/f2c44f665899d7500d013539832866295c595907/README.md
- Repository URL: https://github.com/keycloak/keycloak-github-bot
- Assessment: unconfirmed; do not use or test any credentials.

### 683. P2_REVIEW — khushal-winner/neighbr

- Path: `ENV.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/khushal-winner/neighbr/blob/57ab6e6f4fc310b834c8a40eb9e00c637d0fd461/ENV.md
- Repository URL: https://github.com/khushal-winner/neighbr
- Assessment: unconfirmed; do not use or test any credentials.

### 684. P2_REVIEW — kidino/KLM-NOV2024

- Path: `env.txt`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/kidino/KLM-NOV2024/blob/69f052b8c6c6eca144028eabad7c1bc5fdd88127/env.txt
- Repository URL: https://github.com/kidino/KLM-NOV2024
- Assessment: unconfirmed; do not use or test any credentials.

### 685. P2_REVIEW — kiegroup/kiebot

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/kiegroup/kiebot/blob/27b013d84ea728c6f77cc03a83375346e0bb59ce/README.md
- Repository URL: https://github.com/kiegroup/kiebot
- Assessment: unconfirmed; do not use or test any credentials.

### 686. P2_REVIEW — knowusuboaky/chatLLM

- Path: `NEWS.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/knowusuboaky/chatLLM/blob/d2b7d8b2f525875f764106e7014de024102996cb/NEWS.md
- Repository URL: https://github.com/knowusuboaky/chatLLM
- Assessment: unconfirmed; do not use or test any credentials.

### 687. P2_REVIEW — knpuniversity/oauth2-client-bundle

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/knpuniversity/oauth2-client-bundle/blob/c8780787350adc752af20e445eb0d5a4728a1a1c/README.md
- Repository URL: https://github.com/knpuniversity/oauth2-client-bundle
- Assessment: unconfirmed; do not use or test any credentials.

### 688. P2_REVIEW — ko6lvm/cordis

- Path: `ENV.md`
- Indicator: `database_url;secret_access_key_label;access_token_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/ko6lvm/cordis/blob/a5e2f6a61776738e0b0051fc77df0079992bbc77/ENV.md
- Repository URL: https://github.com/ko6lvm/cordis
- Assessment: unconfirmed; do not use or test any credentials.

### 689. P2_REVIEW — koolkishan/nextjs-cryptomus-ecommerce

- Path: `env.md`
- Indicator: `database_url;client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/koolkishan/nextjs-cryptomus-ecommerce/blob/cf88c5b451520f9d4599696c9c37e8886a1b448b/env.md
- Repository URL: https://github.com/koolkishan/nextjs-cryptomus-ecommerce
- Assessment: unconfirmed; do not use or test any credentials.

### 690. P2_REVIEW — kortirso/railschessserver

- Path: `API.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/kortirso/railschessserver/blob/442330982c06339306c15d9d5d249d5e641a3302/API.md
- Repository URL: https://github.com/kortirso/railschessserver
- Assessment: unconfirmed; do not use or test any credentials.

### 691. P2_REVIEW — kousen/spring-and-spring-boot

- Path: `labs.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/kousen/spring-and-spring-boot/blob/1013d27a14a86163e8b3dc0a565363ea13620ca5/labs.md
- Repository URL: https://github.com/kousen/spring-and-spring-boot
- Assessment: unconfirmed; do not use or test any credentials.

### 692. P2_REVIEW — laincloud/sso

- Path: `api.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/laincloud/sso/blob/01681b26d00d974d6821abfb7e9fb55b76dd0a73/api.md
- Repository URL: https://github.com/laincloud/sso
- Assessment: unconfirmed; do not use or test any credentials.

### 693. P2_REVIEW — lak7/devildev

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/lak7/devildev/blob/c4f8a63e68e7ce325a4a161bf095ea877440329c/README.md
- Repository URL: https://github.com/lak7/devildev
- Assessment: unconfirmed; do not use or test any credentials.

### 694. P2_REVIEW — lambci/git-lambda-layer

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/lambci/git-lambda-layer/blob/3b4d3592afb537be4c1e291e8cf3b6a3f75d23d5/README.md
- Repository URL: https://github.com/lambci/git-lambda-layer
- Assessment: unconfirmed; do not use or test any credentials.

### 695. P2_REVIEW — lamw/vmware-pks-automated-lab-deployment

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/lamw/vmware-pks-automated-lab-deployment/blob/2bf03335d0231191e2e57f5ff5a1c329f22cbd99/README.md
- Repository URL: https://github.com/lamw/vmware-pks-automated-lab-deployment
- Assessment: unconfirmed; do not use or test any credentials.

### 696. P2_REVIEW — laoqiren/yohe

- Path: `CN.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/laoqiren/yohe/blob/a66220aab4bf17184608d92c36bca18b3e7e43c9/CN.md
- Repository URL: https://github.com/laoqiren/yohe
- Assessment: unconfirmed; do not use or test any credentials.

### 697. P2_REVIEW — latchset/custodia

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/latchset/custodia/blob/56babdf1229c17a82bae639675d25057808b7ae2/README.md
- Repository URL: https://github.com/latchset/custodia
- Assessment: unconfirmed; do not use or test any credentials.

### 698. P2_REVIEW — left4craft/left4bot

- Path: `env.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/left4craft/left4bot/blob/b8693a1161703d3ceefbe50e05d0fbffeec54a9c/env.txt
- Repository URL: https://github.com/left4craft/left4bot
- Assessment: unconfirmed; do not use or test any credentials.

### 699. P2_REVIEW — legacy-use/legacy-use

- Path: `plan.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/legacy-use/legacy-use/blob/28c650c9b1da04635c40c128bf4353d7ac5c7afc/plan.md
- Repository URL: https://github.com/legacy-use/legacy-use
- Assessment: unconfirmed; do not use or test any credentials.

### 700. P2_REVIEW — lewagon/data-engineering-setup

- Path: `LINUX.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/lewagon/data-engineering-setup/blob/60df3685ead9b3c23b883cc01dc19d81937c6d20/LINUX.md
- Repository URL: https://github.com/lewagon/data-engineering-setup
- Assessment: unconfirmed; do not use or test any credentials.

### 701. P2_REVIEW — lewagon/data-engineering-setup

- Path: `macOS.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/lewagon/data-engineering-setup/blob/60df3685ead9b3c23b883cc01dc19d81937c6d20/macOS.md
- Repository URL: https://github.com/lewagon/data-engineering-setup
- Assessment: unconfirmed; do not use or test any credentials.

### 702. P2_REVIEW — liangzibao/opensdk-java

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/liangzibao/opensdk-java/blob/78099582ae8e60a1e1ea9de4668fb8924b4bd357/README.md
- Repository URL: https://github.com/liangzibao/opensdk-java
- Assessment: unconfirmed; do not use or test any credentials.

### 703. P2_REVIEW — linagora/lemonldap-ng-plugins

- Path: `OIDC.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/linagora/lemonldap-ng-plugins/blob/1c90e40078b70b798296a57738c6b64807410fd0/OIDC.md
- Repository URL: https://github.com/linagora/lemonldap-ng-plugins
- Assessment: unconfirmed; do not use or test any credentials.

### 704. P2_REVIEW — linuxfoundation/easycla

- Path: `dev.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/linuxfoundation/easycla/blob/3cefb6013ca7f39b6ac26db0ad89d50a5a9c34e0/dev.md
- Repository URL: https://github.com/linuxfoundation/easycla
- Assessment: unconfirmed; do not use or test any credentials.

### 705. P2_REVIEW — little-xin/wxpay-applet-back

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/little-xin/wxpay-applet-back/blob/0a5ddc6acb18d6cfe82fbada336bcc7e9a541b07/README.md
- Repository URL: https://github.com/little-xin/wxpay-applet-back
- Assessment: unconfirmed; do not use or test any credentials.

### 706. P2_REVIEW — lrqdo/developer

- Path: `api.md`
- Indicator: `client_secret_label;access_token_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/lrqdo/developer/blob/6fa72025c3bb711b2cf0176c6a8e20b7d64d5568/api.md
- Repository URL: https://github.com/lrqdo/developer
- Assessment: unconfirmed; do not use or test any credentials.

### 707. P2_REVIEW — lucidworks/fusion-search-solarium

- Path: `HOW.md`
- Indicator: `client_secret_label;access_token_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/lucidworks/fusion-search-solarium/blob/e4712a61ff28d89c6c904668a3cb627db0383d7f/HOW.md
- Repository URL: https://github.com/lucidworks/fusion-search-solarium
- Assessment: unconfirmed; do not use or test any credentials.

### 708. P2_REVIEW — lucified/lucify-component-builder

- Path: `API.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/lucified/lucify-component-builder/blob/6ca1a011858f9bfb116bd8c3d079b56015ccaad5/API.md
- Repository URL: https://github.com/lucified/lucify-component-builder
- Assessment: unconfirmed; do not use or test any credentials.

### 709. P2_REVIEW — luckygametools/gui

- Path: `readme.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/luckygametools/gui/blob/04cc14f1689bc44de5fd09da5e16d7d8c6d8f586/readme.md
- Repository URL: https://github.com/luckygametools/gui
- Assessment: unconfirmed; do not use or test any credentials.

### 710. P2_REVIEW — lukasz-antoniak/neo4j-operator

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/lukasz-antoniak/neo4j-operator/blob/f4472b524f14ba4b0f8b88f358772758848b5912/README.md
- Repository URL: https://github.com/lukasz-antoniak/neo4j-operator
- Assessment: unconfirmed; do not use or test any credentials.

### 711. P2_REVIEW — lxrite/azure-http-proxy

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/lxrite/azure-http-proxy/blob/c90005d35cab605e99ae210f889236dd23440aa7/README.md
- Repository URL: https://github.com/lxrite/azure-http-proxy
- Assessment: unconfirmed; do not use or test any credentials.

### 712. P2_REVIEW — madetech/stem-cell

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/madetech/stem-cell/blob/93b2cec8e4e2d88ab8aa76741c596e4d957dd524/README.md
- Repository URL: https://github.com/madetech/stem-cell
- Assessment: unconfirmed; do not use or test any credentials.

### 713. P2_REVIEW — majidalaeinia/uncommon-env-keys-finder

- Path: `env.txt`
- Indicator: `aws_secret_key_label;db_password_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/majidalaeinia/uncommon-env-keys-finder/blob/5c04933dac806355d2730f8ad77aeecaf47f3d19/env.txt
- Repository URL: https://github.com/majidalaeinia/uncommon-env-keys-finder
- Assessment: unconfirmed; do not use or test any credentials.

### 714. P2_REVIEW — malaporte/pippin

- Path: `AWS.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/malaporte/pippin/blob/b9e2c8a45831a04c355aaf685d8fd61fbfa1949c/AWS.md
- Repository URL: https://github.com/malaporte/pippin
- Assessment: unconfirmed; do not use or test any credentials.

### 715. P2_REVIEW — mapattacker/cheatsheets

- Path: `dvc.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/mapattacker/cheatsheets/blob/f7b519632679ade31a6def2cc9e6c270ec0b0d2b/dvc.md
- Repository URL: https://github.com/mapattacker/cheatsheets
- Assessment: unconfirmed; do not use or test any credentials.

### 716. P2_REVIEW — marcelorodrigo/aws-certified-developer-associate-exam

- Path: `cli.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/marcelorodrigo/aws-certified-developer-associate-exam/blob/7453df3461c16f2923c969795e86062e39eaf168/cli.md
- Repository URL: https://github.com/marcelorodrigo/aws-certified-developer-associate-exam
- Assessment: unconfirmed; do not use or test any credentials.

### 717. P2_REVIEW — marco-acm-asi/Minimarket

- Path: `FAQ.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/marco-acm-asi/Minimarket/blob/a28c4bb1b9824415e5496ffd8855b1d3d3bfcb4d/FAQ.md
- Repository URL: https://github.com/marco-acm-asi/Minimarket
- Assessment: unconfirmed; do not use or test any credentials.

### 718. P2_REVIEW — matPK/rsa-example

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/matPK/rsa-example/blob/ee07b0ef20f928679795dc6041b117239a83eb83/README.md
- Repository URL: https://github.com/matPK/rsa-example
- Assessment: unconfirmed; do not use or test any credentials.

### 719. P2_REVIEW — matrimony-portal/matrimony-backend

- Path: `HELP.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/matrimony-portal/matrimony-backend/blob/f75b096481d69f6594953b949da63094099e6ad2/HELP.md
- Repository URL: https://github.com/matrimony-portal/matrimony-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 720. P2_REVIEW — matteobaccan/owner

- Path: `CRYPTO.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/matteobaccan/owner/blob/474b0b7daf92af5cef5cb56519f4534dee25bfea/CRYPTO.md
- Repository URL: https://github.com/matteobaccan/owner
- Assessment: unconfirmed; do not use or test any credentials.

### 721. P2_REVIEW — maulanashalihin/laju

- Path: `QWEN.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/maulanashalihin/laju/blob/a55e91111dfa968ef21745c1d3a15e79b005e240/QWEN.md
- Repository URL: https://github.com/maulanashalihin/laju
- Assessment: unconfirmed; do not use or test any credentials.

### 722. P2_REVIEW — mauritslamers/orion-db

- Path: `INSTALL`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/mauritslamers/orion-db/blob/ddda15c4ba360bd614c4f45474338af4b12ac88e/INSTALL
- Repository URL: https://github.com/mauritslamers/orion-db
- Assessment: unconfirmed; do not use or test any credentials.

### 723. P2_REVIEW — memo33/sc4pac-tools

- Path: `api.md`
- Indicator: `client_secret_label;access_token_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/memo33/sc4pac-tools/blob/13d553a9037602d7ea9811f6fe56f62030d093e5/api.md
- Repository URL: https://github.com/memo33/sc4pac-tools
- Assessment: unconfirmed; do not use or test any credentials.

### 724. P2_REVIEW — memo33/sc4pac-tools

- Path: `cli.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/memo33/sc4pac-tools/blob/13d553a9037602d7ea9811f6fe56f62030d093e5/cli.md
- Repository URL: https://github.com/memo33/sc4pac-tools
- Assessment: unconfirmed; do not use or test any credentials.

### 725. P2_REVIEW — mernstack-developer/docker-Moodle-LMS-with-Maria-db-

- Path: `d.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/mernstack-developer/docker-Moodle-LMS-with-Maria-db-/blob/101522e6b5004c8e97b1090e1139c6e3c933b35f/d.txt
- Repository URL: https://github.com/mernstack-developer/docker-Moodle-LMS-with-Maria-db-
- Assessment: unconfirmed; do not use or test any credentials.

### 726. P2_REVIEW — mhaidarhanif/leader-workshop

- Path: `RFC.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/mhaidarhanif/leader-workshop/blob/6d9808821cb65ee1a4f492f2ab1d829db9fd1b2a/RFC.md
- Repository URL: https://github.com/mhaidarhanif/leader-workshop
- Assessment: unconfirmed; do not use or test any credentials.

### 727. P2_REVIEW — microsoft/dev-tunnels-ssh

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/microsoft/dev-tunnels-ssh/blob/e65278de0bf73b7730d82a9469714677f5fc496a/README.md
- Repository URL: https://github.com/microsoft/dev-tunnels-ssh
- Assessment: unconfirmed; do not use or test any credentials.

### 728. P2_REVIEW — mighty840/orca

- Path: `OPS.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/mighty840/orca/blob/7a7f882b375969b615a7809e10d949ca81b02551/OPS.md
- Repository URL: https://github.com/mighty840/orca
- Assessment: unconfirmed; do not use or test any credentials.

### 729. P2_REVIEW — miit-daga/env-guard

- Path: `CLI.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/miit-daga/env-guard/blob/2caeebf46c166c9ee0a364caf330281c58961aaa/CLI.md
- Repository URL: https://github.com/miit-daga/env-guard
- Assessment: unconfirmed; do not use or test any credentials.

### 730. P2_REVIEW — mikemainguy/diaquest

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/mikemainguy/diaquest/blob/7d257a206b6e1363d398b65ea123b204c19c95d7/README.md
- Repository URL: https://github.com/mikemainguy/diaquest
- Assessment: unconfirmed; do not use or test any credentials.

### 731. P2_REVIEW — mirumee/ariadne-graphql-proxy

- Path: `GUIDE.md`
- Indicator: `aws_secret_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/mirumee/ariadne-graphql-proxy/blob/4cb2ae4e9a8f7c010ba1b0a4759532ecd5f28db3/GUIDE.md
- Repository URL: https://github.com/mirumee/ariadne-graphql-proxy
- Assessment: unconfirmed; do not use or test any credentials.

### 732. P2_REVIEW — miyataka/fcmpush

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/miyataka/fcmpush/blob/531c0b093988b74b22dadc8c69138d01a9d5b785/README.md
- Repository URL: https://github.com/miyataka/fcmpush
- Assessment: unconfirmed; do not use or test any credentials.

### 733. P2_REVIEW — mkaag/docker-haproxy-confd

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/mkaag/docker-haproxy-confd/blob/607ccf198b508e3943670b311f88d2d912d4284b/README.md
- Repository URL: https://github.com/mkaag/docker-haproxy-confd
- Assessment: unconfirmed; do not use or test any credentials.

### 734. P2_REVIEW — mmcquillan/lawsg

- Path: `HELP.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/mmcquillan/lawsg/blob/bcd82c24dd12c9fc431f183bfde2fa27f749783c/HELP.md
- Repository URL: https://github.com/mmcquillan/lawsg
- Assessment: unconfirmed; do not use or test any credentials.

### 735. P2_REVIEW — mobizt/ESP-Google-Sheet-Client

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/mobizt/ESP-Google-Sheet-Client/blob/05a247c53b64f7e82aeae848578eeb4acc73da83/README.md
- Repository URL: https://github.com/mobizt/ESP-Google-Sheet-Client
- Assessment: unconfirmed; do not use or test any credentials.

### 736. P2_REVIEW — mohan-chinnappan-n/cli-dx

- Path: `aws.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/mohan-chinnappan-n/cli-dx/blob/84d2f83ef08b43eb13a26106894fd40054d93ee3/aws.md
- Repository URL: https://github.com/mohan-chinnappan-n/cli-dx
- Assessment: unconfirmed; do not use or test any credentials.

### 737. P2_REVIEW — monkeylite/lua-codec

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/monkeylite/lua-codec/blob/bc91846055a1f3c8fc7a6073e45dece258a01cba/README.md
- Repository URL: https://github.com/monkeylite/lua-codec
- Assessment: unconfirmed; do not use or test any credentials.

### 738. P2_REVIEW — mophos/mmis-contract-backend

- Path: `env.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/mophos/mmis-contract-backend/blob/47de57e2ee445202476ba14a93b820649a77a346/env.txt
- Repository URL: https://github.com/mophos/mmis-contract-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 739. P2_REVIEW — mophos/mmis-documents-management

- Path: `env.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/mophos/mmis-documents-management/blob/3875d50cea94f93a98afdc2608acfe320d4c7132/env.txt
- Repository URL: https://github.com/mophos/mmis-documents-management
- Assessment: unconfirmed; do not use or test any credentials.

### 740. P2_REVIEW — mophos/mmis-inventory-backend

- Path: `env.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/mophos/mmis-inventory-backend/blob/f34b18bb522cff428ba42fda7f1c352fc93cd85c/env.txt
- Repository URL: https://github.com/mophos/mmis-inventory-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 741. P2_REVIEW — mophos/mmis-management-backend

- Path: `env.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/mophos/mmis-management-backend/blob/69a211db06023734eb8d8d5ebc523bfbde4ea1d3/env.txt
- Repository URL: https://github.com/mophos/mmis-management-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 742. P2_REVIEW — mophos/mmis-material-backend

- Path: `env.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/mophos/mmis-material-backend/blob/57eb53355b7990da908e16820a512a60b26d23a6/env.txt
- Repository URL: https://github.com/mophos/mmis-material-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 743. P2_REVIEW — mophos/mmis-portal-backend

- Path: `env.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/mophos/mmis-portal-backend/blob/92cbd197b216e9e22defb3d12665263015791a1e/env.txt
- Repository URL: https://github.com/mophos/mmis-portal-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 744. P2_REVIEW — mophos/mmis-purchase-backend

- Path: `env.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/mophos/mmis-purchase-backend/blob/ce00d24723d07a221d975ff11d8ad52e95bfedb5/env.txt
- Repository URL: https://github.com/mophos/mmis-purchase-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 745. P2_REVIEW — mtzluisalfredo/urbitts-backend

- Path: `env.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/mtzluisalfredo/urbitts-backend/blob/fcca7427ad84533dcfa58c16c457f7ab09b8d277/env.txt
- Repository URL: https://github.com/mtzluisalfredo/urbitts-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 746. P2_REVIEW — mustafaaljadery/disperse

- Path: `env.md`
- Indicator: `database_url;client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/mustafaaljadery/disperse/blob/6c647c2a1965a5e2337a17b6f1eb10034abd6ac8/env.md
- Repository URL: https://github.com/mustafaaljadery/disperse
- Assessment: unconfirmed; do not use or test any credentials.

### 747. P2_REVIEW — mvmaasakkers/certificates

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/mvmaasakkers/certificates/blob/dd7ff0f3ed4dfc099984cb5b6c4b2855e606036b/README.md
- Repository URL: https://github.com/mvmaasakkers/certificates
- Assessment: unconfirmed; do not use or test any credentials.

### 748. P2_REVIEW — nean-and-i/matrix-stack

- Path: `TODO.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/nean-and-i/matrix-stack/blob/add852e9992f689593d31af01536fcef6b3ab0b4/TODO.md
- Repository URL: https://github.com/nean-and-i/matrix-stack
- Assessment: unconfirmed; do not use or test any credentials.

### 749. P2_REVIEW — neohan666/wxmp-rsa

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/neohan666/wxmp-rsa/blob/b15dfb581c2513271fe9404619a67460f55c51b3/README.md
- Repository URL: https://github.com/neohan666/wxmp-rsa
- Assessment: unconfirmed; do not use or test any credentials.

### 750. P2_REVIEW — neoxr/wbot

- Path: `ID.md`
- Indicator: `database_url;api_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/neoxr/wbot/blob/ab1477f8307c489c72824a2478fa4cd35dfdb869/ID.md
- Repository URL: https://github.com/neoxr/wbot
- Assessment: unconfirmed; do not use or test any credentials.

### 751. P2_REVIEW — newrelic/rusty-hog

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/newrelic/rusty-hog/blob/9da595ad204f017cff576ffac5bce7f2bed1be2f/README.md
- Repository URL: https://github.com/newrelic/rusty-hog
- Assessment: unconfirmed; do not use or test any credentials.

### 752. P2_REVIEW — nick-prater/kronekeeper

- Path: `INSTALL`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/nick-prater/kronekeeper/blob/9114d54586430b8ec6eafd263a56edebee7b26e1/INSTALL
- Repository URL: https://github.com/nick-prater/kronekeeper
- Assessment: unconfirmed; do not use or test any credentials.

### 753. P2_REVIEW — nicoribeiro/java_efactura_uy

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/nicoribeiro/java_efactura_uy/blob/44e40750d3628bb5ebe1f82be60902d792af9c43/README.md
- Repository URL: https://github.com/nicoribeiro/java_efactura_uy
- Assessment: unconfirmed; do not use or test any credentials.

### 754. P2_REVIEW — niktayv/tasks-api

- Path: `CI.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/niktayv/tasks-api/blob/5f37e477ba9f63b3f5496e51e5fc88ba4a0b1ead/CI.md
- Repository URL: https://github.com/niktayv/tasks-api
- Assessment: unconfirmed; do not use or test any credentials.

### 755. P2_REVIEW — nikyoudale/CocoaCryptoMac

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/nikyoudale/CocoaCryptoMac/blob/5204f2d5c8dccd63402fe5c4609caba7b5d6d036/README.md
- Repository URL: https://github.com/nikyoudale/CocoaCryptoMac
- Assessment: unconfirmed; do not use or test any credentials.

### 756. P2_REVIEW — ninja-dart/ninja

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/ninja-dart/ninja/blob/36fabf7374981b162fc9cd2c65dba3e4251be669/README.md
- Repository URL: https://github.com/ninja-dart/ninja
- Assessment: unconfirmed; do not use or test any credentials.

### 757. P2_REVIEW — nleiva/ansible-web-server

- Path: `aws.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/nleiva/ansible-web-server/blob/ae97c97b0c57854a57e6d380a2d5a4152bdb5676/aws.md
- Repository URL: https://github.com/nleiva/ansible-web-server
- Assessment: unconfirmed; do not use or test any credentials.

### 758. P2_REVIEW — nokitakaze/AmneziaVPNDockerServer

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/nokitakaze/AmneziaVPNDockerServer/blob/c8a277fdc5f4c5c11f2998c58c01802b366aaf7d/README.md
- Repository URL: https://github.com/nokitakaze/AmneziaVPNDockerServer
- Assessment: unconfirmed; do not use or test any credentials.

### 759. P2_REVIEW — nomankhokhar/Car-Keeper-AutoZone-Hub

- Path: `ME.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/nomankhokhar/Car-Keeper-AutoZone-Hub/blob/4b51e8e823dd6bd90f7c51daaf15fa8bbda6bccb/ME.md
- Repository URL: https://github.com/nomankhokhar/Car-Keeper-AutoZone-Hub
- Assessment: unconfirmed; do not use or test any credentials.

### 760. P2_REVIEW — nov/json-jwt

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/nov/json-jwt/blob/fa5ef904013bb96da5f6fa78c0fe02dfaee862e2/README.md
- Repository URL: https://github.com/nov/json-jwt
- Assessment: unconfirmed; do not use or test any credentials.

### 761. P2_REVIEW — nrvana/macOS-triage

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/nrvana/macOS-triage/blob/8efd3ca1d31d74aad00f0e6bb67f8f39d01ddc60/README.md
- Repository URL: https://github.com/nrvana/macOS-triage
- Assessment: unconfirmed; do not use or test any credentials.

### 762. P2_REVIEW — numToStr/zenv

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/numToStr/zenv/blob/3997807dc5e593c6ea9f18fabfc3117fca2a8415/README.md
- Repository URL: https://github.com/numToStr/zenv
- Assessment: unconfirmed; do not use or test any credentials.

### 763. P2_REVIEW — nyzhanggy/RSADemo

- Path: `README.md`
- Indicator: `private_key_header;rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/nyzhanggy/RSADemo/blob/e1a0447d0f716d46d6e80b18446a9db42fe377db/README.md
- Repository URL: https://github.com/nyzhanggy/RSADemo
- Assessment: unconfirmed; do not use or test any credentials.

### 764. P2_REVIEW — object-Object/HexBug

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/object-Object/HexBug/blob/3d1fa0d572615484dbc77faa6bda6f8a47693e90/README.md
- Repository URL: https://github.com/object-Object/HexBug
- Assessment: unconfirmed; do not use or test any credentials.

### 765. P2_REVIEW — oleksiyk/kafka

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/oleksiyk/kafka/blob/c36bdeb22d09c47ece7e73c9ea147ee1f3c4064c/README.md
- Repository URL: https://github.com/oleksiyk/kafka
- Assessment: unconfirmed; do not use or test any credentials.

### 766. P2_REVIEW — omelhus/ha-listonic

- Path: `API.md`
- Indicator: `client_secret_label;access_token_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/omelhus/ha-listonic/blob/aaf9794c1b109b6d27d769300bde9828964f9ad1/API.md
- Repository URL: https://github.com/omelhus/ha-listonic
- Assessment: unconfirmed; do not use or test any credentials.

### 767. P2_REVIEW — ondrejvysek/HomeAssistant-EGD-PowerData

- Path: `info.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/ondrejvysek/HomeAssistant-EGD-PowerData/blob/14abdc5fcc2554a62bbfba997a6acb0a83278e49/info.md
- Repository URL: https://github.com/ondrejvysek/HomeAssistant-EGD-PowerData
- Assessment: unconfirmed; do not use or test any credentials.

### 768. P2_REVIEW — opszero/terraform-aws-kubespot

- Path: `usage.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/opszero/terraform-aws-kubespot/blob/6ff7bdd25d8cfdeb999b52eb4eb9d8f323d2af4e/usage.md
- Repository URL: https://github.com/opszero/terraform-aws-kubespot
- Assessment: unconfirmed; do not use or test any credentials.

### 769. P2_REVIEW — optimusexe/Briefly

- Path: `ENV.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/optimusexe/Briefly/blob/8d1c67fd5edf37db71a586509c4cd4d4df9975f0/ENV.md
- Repository URL: https://github.com/optimusexe/Briefly
- Assessment: unconfirmed; do not use or test any credentials.

### 770. P2_REVIEW — osmlab/to-fix-backend

- Path: `API.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/osmlab/to-fix-backend/blob/d43d819ed0f40f8b4b2696ad4dfe691cf8427d56/API.md
- Repository URL: https://github.com/osmlab/to-fix-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 771. P2_REVIEW — oubingbing/wechatAlliance

- Path: `bt.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/oubingbing/wechatAlliance/blob/ae296d3cb5395e2573de2d6ef6c0590ab46c4021/bt.md
- Repository URL: https://github.com/oubingbing/wechatAlliance
- Assessment: unconfirmed; do not use or test any credentials.

### 772. P2_REVIEW — p3rcha/repair-shop

- Path: `AWS.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/p3rcha/repair-shop/blob/b6672e6a2ab07b677a75d691f6dd8ed9535d65ab/AWS.md
- Repository URL: https://github.com/p3rcha/repair-shop
- Assessment: unconfirmed; do not use or test any credentials.

### 773. P2_REVIEW — pain2hustle/AMH-Cloudflare-Ops-MCP-by-WT

- Path: `MCP.md`
- Indicator: `client_secret_label;bearer_auth_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/pain2hustle/AMH-Cloudflare-Ops-MCP-by-WT/blob/8ae2ac651c49e7533d4115476a70c3bf7776d58e/MCP.md
- Repository URL: https://github.com/pain2hustle/AMH-Cloudflare-Ops-MCP-by-WT
- Assessment: unconfirmed; do not use or test any credentials.

### 774. P2_REVIEW — paphuc/pap-shop

- Path: `HELP.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/paphuc/pap-shop/blob/add02864ba1f892775e48cde7e5cba6f0039f269/HELP.md
- Repository URL: https://github.com/paphuc/pap-shop
- Assessment: unconfirmed; do not use or test any credentials.

### 775. P2_REVIEW — paulczar/omgwtfssl

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/paulczar/omgwtfssl/blob/952e20514bad9e72bbc90057fa49f415859de891/README.md
- Repository URL: https://github.com/paulczar/omgwtfssl
- Assessment: unconfirmed; do not use or test any credentials.

### 776. P2_REVIEW — pavlovic-ivan/ghrunner-app

- Path: `setup.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/pavlovic-ivan/ghrunner-app/blob/e5797ef321f5eea0669d8c754210f206cf509353/setup.md
- Repository URL: https://github.com/pavlovic-ivan/ghrunner-app
- Assessment: unconfirmed; do not use or test any credentials.

### 777. P2_REVIEW — perry-mitchell/aws-get-credentials

- Path: `API.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/perry-mitchell/aws-get-credentials/blob/c90420711401981913bca41b9a300a6425ea6eef/API.md
- Repository URL: https://github.com/perry-mitchell/aws-get-credentials
- Assessment: unconfirmed; do not use or test any credentials.

### 778. P2_REVIEW — perseids-project/perseids_docs

- Path: `api.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/perseids-project/perseids_docs/blob/20d3898d01ac73eca6a1c09620b0e6c5d98aa5bb/api.md
- Repository URL: https://github.com/perseids-project/perseids_docs
- Assessment: unconfirmed; do not use or test any credentials.

### 779. P2_REVIEW — pexip/os-rust-pem

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/pexip/os-rust-pem/blob/c5c44ebcd3e39c458e43af2bfbe4f6c6ae6e237a/README.md
- Repository URL: https://github.com/pexip/os-rust-pem
- Assessment: unconfirmed; do not use or test any credentials.

### 780. P2_REVIEW — pgpool/pgpooladmin

- Path: `NEWS`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/pgpool/pgpooladmin/blob/9229f82dc864c57974e80b2c83791d94d5da2d57/NEWS
- Repository URL: https://github.com/pgpool/pgpooladmin
- Assessment: unconfirmed; do not use or test any credentials.

### 781. P2_REVIEW — planningcenter/signature

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/planningcenter/signature/blob/0f1efb8af3cd1ee96ca75e36083adc4698c5d4fb/README.md
- Repository URL: https://github.com/planningcenter/signature
- Assessment: unconfirmed; do not use or test any credentials.

### 782. P2_REVIEW — podverse/podverse-api

- Path: `ENV.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/podverse/podverse-api/blob/6fed938be3e29d23feab46c313469b61217abf81/ENV.md
- Repository URL: https://github.com/podverse/podverse-api
- Assessment: unconfirmed; do not use or test any credentials.

### 783. P2_REVIEW — postalsys/pending-dns

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/postalsys/pending-dns/blob/54a02e5c5752bc8784b4e086ea589485ddf11787/README.md
- Repository URL: https://github.com/postalsys/pending-dns
- Assessment: unconfirmed; do not use or test any credentials.

### 784. P2_REVIEW — pozgo/web-cli

- Path: `API.md`
- Indicator: `database_url;private_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/pozgo/web-cli/blob/e9c35abd17b1bb30baa575be24271f6cac752580/API.md
- Repository URL: https://github.com/pozgo/web-cli
- Assessment: unconfirmed; do not use or test any credentials.

### 785. P2_REVIEW — pprasoon1/ML-miniProject

- Path: `mm.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/pprasoon1/ML-miniProject/blob/cac21ca53ed5de0252c04e11da2941d1535c820e/mm.txt
- Repository URL: https://github.com/pprasoon1/ML-miniProject
- Assessment: unconfirmed; do not use or test any credentials.

### 786. P2_REVIEW — pump-io/pump.io

- Path: `API.md`
- Indicator: `client_secret_label;access_token_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/pump-io/pump.io/blob/ba6b392c0720404a9e689d334e9436ce71b814c3/API.md
- Repository URL: https://github.com/pump-io/pump.io
- Assessment: unconfirmed; do not use or test any credentials.

### 787. P2_REVIEW — puretears/SwiftRSA

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/puretears/SwiftRSA/blob/01b126e96c091772a48dd836c2fd3eef2655d274/README.md
- Repository URL: https://github.com/puretears/SwiftRSA
- Assessment: unconfirmed; do not use or test any credentials.

### 788. P2_REVIEW — qrdate/qrdate

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/qrdate/qrdate/blob/551666edab9a2988f9d6749c99f543cb735ea5e8/README.md
- Repository URL: https://github.com/qrdate/qrdate
- Assessment: unconfirmed; do not use or test any credentials.

### 789. P2_REVIEW — qvantel/kafka-explorer

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/qvantel/kafka-explorer/blob/446932cf12dee7016ef12e77dd52f536f59254d9/README.md
- Repository URL: https://github.com/qvantel/kafka-explorer
- Assessment: unconfirmed; do not use or test any credentials.

### 790. P2_REVIEW — r-lidar/lidRbook

- Path: `io.qmd`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/r-lidar/lidRbook/blob/56d6702bff0e13182c4f986e9694da0d07bde3b4/io.qmd
- Repository URL: https://github.com/r-lidar/lidRbook
- Assessment: unconfirmed; do not use or test any credentials.

### 791. P2_REVIEW — r-spark/the-r-in-spark

- Path: `data.Rmd`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/r-spark/the-r-in-spark/blob/68b42f8c2b8f78ed9ce68bded4ae6549d2a423d5/data.Rmd
- Repository URL: https://github.com/r-spark/the-r-in-spark
- Assessment: unconfirmed; do not use or test any credentials.

### 792. P2_REVIEW — rashidwassan/CNCF-Certification-Notes

- Path: `CKAD.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/rashidwassan/CNCF-Certification-Notes/blob/a6ab399b07a554594a636457c379bc120d984c5c/CKAD.md
- Repository URL: https://github.com/rashidwassan/CNCF-Certification-Notes
- Assessment: unconfirmed; do not use or test any credentials.

### 793. P2_REVIEW — rdio/pgpool2

- Path: `NEWS`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/rdio/pgpool2/blob/707a5edf9419896f744edf1ae7afdcabdb8700b1/NEWS
- Repository URL: https://github.com/rdio/pgpool2
- Assessment: unconfirmed; do not use or test any credentials.

### 794. P2_REVIEW — relevance/relevance_rails

- Path: `USAGE.md`
- Indicator: `aws_secret_key_label;rsa_private_key_header;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/relevance/relevance_rails/blob/35ddcaa6062df5686bb2c73cf23cbddfaf611799/USAGE.md
- Repository URL: https://github.com/relevance/relevance_rails
- Assessment: unconfirmed; do not use or test any credentials.

### 795. P2_REVIEW — rennokki/laravel-aws-eb

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/rennokki/laravel-aws-eb/blob/4d28a4516ee290e636ac6586f65dd9978237429a/README.md
- Repository URL: https://github.com/rennokki/laravel-aws-eb
- Assessment: unconfirmed; do not use or test any credentials.

### 796. P2_REVIEW — revisium/revisium

- Path: `ENV.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/revisium/revisium/blob/0ffe37975a3dad78094cbe462a64a17ecddd3221/ENV.md
- Repository URL: https://github.com/revisium/revisium
- Assessment: unconfirmed; do not use or test any credentials.

### 797. P2_REVIEW — rfaita/iot-infra

- Path: `HELP.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/rfaita/iot-infra/blob/f9dc8e6268c0afa98a89a6b7bf66752c209fff97/HELP.md
- Repository URL: https://github.com/rfaita/iot-infra
- Assessment: unconfirmed; do not use or test any credentials.

### 798. P2_REVIEW — rhthsa/openshift-demo

- Path: `loki.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/rhthsa/openshift-demo/blob/d5c717225ea3a28f9222d3f01501ab062c0d9af0/loki.md
- Repository URL: https://github.com/rhthsa/openshift-demo
- Assessment: unconfirmed; do not use or test any credentials.

### 799. P2_REVIEW — rickbutterfield/BlockPreview

- Path: `MCP.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/rickbutterfield/BlockPreview/blob/c8989cde5019e1755758d50cae2684d4e58ec299/MCP.md
- Repository URL: https://github.com/rickbutterfield/BlockPreview
- Assessment: unconfirmed; do not use or test any credentials.

### 800. P2_REVIEW — rikulo/xml-crypto

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/rikulo/xml-crypto/blob/5beec885d073d6fca819240e3f58f490862b01c4/README.md
- Repository URL: https://github.com/rikulo/xml-crypto
- Assessment: unconfirmed; do not use or test any credentials.

### 801. P2_REVIEW — rivkode/wanted-pre-onboarding-backend

- Path: `a.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/rivkode/wanted-pre-onboarding-backend/blob/f95b763d921902a4a28e42d67fceb3286aa126b3/a.md
- Repository URL: https://github.com/rivkode/wanted-pre-onboarding-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 802. P2_REVIEW — robmarkcole/HASS-amazon-rekognition

- Path: `info.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/robmarkcole/HASS-amazon-rekognition/blob/5c1849d63d6a0b539678d66deb2dd303e5fecd7d/info.md
- Repository URL: https://github.com/robmarkcole/HASS-amazon-rekognition
- Assessment: unconfirmed; do not use or test any credentials.

### 803. P2_REVIEW — robototes/robototes-website

- Path: `CI.md`
- Indicator: `aws_secret_key_label;client_secret_label;secret_access_key_label;api_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/robototes/robototes-website/blob/ca66cebc462c9e0f3a9cdccf5636b7ee00232cd5/CI.md
- Repository URL: https://github.com/robototes/robototes-website
- Assessment: unconfirmed; do not use or test any credentials.

### 804. P2_REVIEW — rodartecode/catering-event-manager

- Path: `ENV.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/rodartecode/catering-event-manager/blob/f30fc7b77914d0b314ff065733be3cfe2bc89d23/ENV.md
- Repository URL: https://github.com/rodartecode/catering-event-manager
- Assessment: unconfirmed; do not use or test any credentials.

### 805. P2_REVIEW — rootstrap/apple_auth

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/rootstrap/apple_auth/blob/c64ffad3f1d455c90f4d91b5e5d44e4eb6034190/README.md
- Repository URL: https://github.com/rootstrap/apple_auth
- Assessment: unconfirmed; do not use or test any credentials.

### 806. P2_REVIEW — rootzilopochtli/coatlicue

- Path: `polr.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/rootzilopochtli/coatlicue/blob/099ea9a6beb3460079e3de96cf229e6364b4dcdd/polr.md
- Repository URL: https://github.com/rootzilopochtli/coatlicue
- Assessment: unconfirmed; do not use or test any credentials.

### 807. P2_REVIEW — sakibtamim/Jasper

- Path: `ENV.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/sakibtamim/Jasper/blob/3d10e0e89e607d3d7c1ea105f87c082c325b8dbd/ENV.md
- Repository URL: https://github.com/sakibtamim/Jasper
- Assessment: unconfirmed; do not use or test any credentials.

### 808. P2_REVIEW — salaboy/from-monolith-to-k8s

- Path: `sso.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/salaboy/from-monolith-to-k8s/blob/19a8b0156afae764c0d88369d43a988d86576d84/sso.md
- Repository URL: https://github.com/salaboy/from-monolith-to-k8s
- Assessment: unconfirmed; do not use or test any credentials.

### 809. P2_REVIEW — saml-idp/saml_idp

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/saml-idp/saml_idp/blob/4dde1a3cb9b740c48d5c17154df3e58e3b43de5b/README.md
- Repository URL: https://github.com/saml-idp/saml_idp
- Assessment: unconfirmed; do not use or test any credentials.

### 810. P2_REVIEW — scaleway/python-dkim

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/scaleway/python-dkim/blob/55403408038a5347ac3469adc9bbdc7de36c6076/README.md
- Repository URL: https://github.com/scaleway/python-dkim
- Assessment: unconfirmed; do not use or test any credentials.

### 811. P2_REVIEW — scylladb/scylla-machine-image

- Path: `SETUP.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/scylladb/scylla-machine-image/blob/d0a74e4ec04640095dbf9f5910337fed6417bc38/SETUP.md
- Repository URL: https://github.com/scylladb/scylla-machine-image
- Assessment: unconfirmed; do not use or test any credentials.

### 812. P2_REVIEW — securestart/sstart

- Path: `SSO.md`
- Indicator: `client_secret_label;access_token_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/securestart/sstart/blob/f81e29a7a1a31a7807b95881dd400ee1d407df19/SSO.md
- Repository URL: https://github.com/securestart/sstart
- Assessment: unconfirmed; do not use or test any credentials.

### 813. P2_REVIEW — shadowabi/S-BlastingDictionary

- Path: `JNDI.txt`
- Indicator: `aws_secret_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/shadowabi/S-BlastingDictionary/blob/f8927e54af048f245d1af06dfd5bc988b580a398/JNDI.txt
- Repository URL: https://github.com/shadowabi/S-BlastingDictionary
- Assessment: unconfirmed; do not use or test any credentials.

### 814. P2_REVIEW — shahbaztariq/dotfiles

- Path: `op.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/shahbaztariq/dotfiles/blob/a630ed0343b36c7bb52d3a5be83e5012dd1dc2c1/op.txt
- Repository URL: https://github.com/shahbaztariq/dotfiles
- Assessment: unconfirmed; do not use or test any credentials.

### 815. P2_REVIEW — shkumagai/ansible-doc-ja

- Path: `api.rst`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/shkumagai/ansible-doc-ja/blob/62220af40af184bac899247ac9eeea4cefc6d713/api.rst
- Repository URL: https://github.com/shkumagai/ansible-doc-ja
- Assessment: unconfirmed; do not use or test any credentials.

### 816. P2_REVIEW — silentsignal/sslproxy

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/silentsignal/sslproxy/blob/9ce8af9825049f3ff36b9ea5386c82b1e1e57dc0/README.md
- Repository URL: https://github.com/silentsignal/sslproxy
- Assessment: unconfirmed; do not use or test any credentials.

### 817. P2_REVIEW — simonroedig/ChordSync

- Path: `env.txt`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/simonroedig/ChordSync/blob/1724460a2a6a4812819723aded19d4856b91c488/env.txt
- Repository URL: https://github.com/simonroedig/ChordSync
- Assessment: unconfirmed; do not use or test any credentials.

### 818. P2_REVIEW — simonroedig/SongTreasure

- Path: `env.txt`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/simonroedig/SongTreasure/blob/1df2d197ec1e55e96d677f0b2b1846bef8443085/env.txt
- Repository URL: https://github.com/simonroedig/SongTreasure
- Assessment: unconfirmed; do not use or test any credentials.

### 819. P2_REVIEW — slub/ddev-dfgviewer-dist

- Path: `dfg.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/slub/ddev-dfgviewer-dist/blob/e20eaf77b468e1a43ce4d799d559a7b39b5c8df9/dfg.md
- Repository URL: https://github.com/slub/ddev-dfgviewer-dist
- Assessment: unconfirmed; do not use or test any credentials.

### 820. P2_REVIEW — smartcontractkit/functions-google-bigquery

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/smartcontractkit/functions-google-bigquery/blob/9a620d6a014af2c4b3b4f0780ff4948fc98b9ba0/README.md
- Repository URL: https://github.com/smartcontractkit/functions-google-bigquery
- Assessment: unconfirmed; do not use or test any credentials.

### 821. P2_REVIEW — snehagoyal25/backend-journey

- Path: `a.txt`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/snehagoyal25/backend-journey/blob/f729e24eb8390945ea988fa022e443a8a8c2fd53/a.txt
- Repository URL: https://github.com/snehagoyal25/backend-journey
- Assessment: unconfirmed; do not use or test any credentials.

### 822. P2_REVIEW — solomongetnet/tiktok-award-voting-web-app

- Path: `env.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/solomongetnet/tiktok-award-voting-web-app/blob/1c8ff9f3680fdb94ab26f8bae2dc52deed909025/env.md
- Repository URL: https://github.com/solomongetnet/tiktok-award-voting-web-app
- Assessment: unconfirmed; do not use or test any credentials.

### 823. P2_REVIEW — sourcekris/goRsaTool

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/sourcekris/goRsaTool/blob/0f75502d2d76c026ab5c1155f6b03d6f305f6307/README.md
- Repository URL: https://github.com/sourcekris/goRsaTool
- Assessment: unconfirmed; do not use or test any credentials.

### 824. P2_REVIEW — soy-rafa/claude-mcp-sentinel

- Path: `SKILL.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/soy-rafa/claude-mcp-sentinel/blob/02884f325cdd1cf05dac872f96b4c8ff3e9362b6/SKILL.md
- Repository URL: https://github.com/soy-rafa/claude-mcp-sentinel
- Assessment: unconfirmed; do not use or test any credentials.

### 825. P2_REVIEW — spesmilo/electrum-docs

- Path: `ssl.rst`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/spesmilo/electrum-docs/blob/824a848c9092a6ed7ed063e37af47637e0d2cda2/ssl.rst
- Repository URL: https://github.com/spesmilo/electrum-docs
- Assessment: unconfirmed; do not use or test any credentials.

### 826. P2_REVIEW — ssh-vault/ssh-vault

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/ssh-vault/ssh-vault/blob/94ccccb00d32affa4304500052ac1efec75c87e2/README.md
- Repository URL: https://github.com/ssh-vault/ssh-vault
- Assessment: unconfirmed; do not use or test any credentials.

### 827. P2_REVIEW — sssn1/w18-project-66

- Path: `1.txt`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/sssn1/w18-project-66/blob/e2a4cc4aaf90f2e3f4638c8e7928897e0c0d053b/1.txt
- Repository URL: https://github.com/sssn1/w18-project-66
- Assessment: unconfirmed; do not use or test any credentials.

### 828. P2_REVIEW — stepanowon/openapi-script

- Path: `08.txt`
- Indicator: `client_secret_label;access_token_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/stepanowon/openapi-script/blob/21446077d5e915dfd70a69f32de4b808cbdced39/08.txt
- Repository URL: https://github.com/stepanowon/openapi-script
- Assessment: unconfirmed; do not use or test any credentials.

### 829. P2_REVIEW — streamlit/gsheets-connection

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/streamlit/gsheets-connection/blob/0d3a6d13b2ad3c8cf5a78957f71173911d57a560/README.md
- Repository URL: https://github.com/streamlit/gsheets-connection
- Assessment: unconfirmed; do not use or test any credentials.

### 830. P2_REVIEW — stylessh/diffkit

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/stylessh/diffkit/blob/dc5d34d05937527aa606c858199eaf7df2828b68/README.md
- Repository URL: https://github.com/stylessh/diffkit
- Assessment: unconfirmed; do not use or test any credentials.

### 831. P2_REVIEW — sundayayandele/SundayPlatformEngineer.github.io

- Path: `cert.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/sundayayandele/SundayPlatformEngineer.github.io/blob/a4f79b16f5ccdd22f8fc47f6d8e978b5375d76e4/cert.md
- Repository URL: https://github.com/sundayayandele/SundayPlatformEngineer.github.io
- Assessment: unconfirmed; do not use or test any credentials.

### 832. P2_REVIEW — super-easy-forms/super-easy-forms

- Path: `docs.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/super-easy-forms/super-easy-forms/blob/ed3387c9d53b1461bc97537cfa31f5972401acea/docs.md
- Repository URL: https://github.com/super-easy-forms/super-easy-forms
- Assessment: unconfirmed; do not use or test any credentials.

### 833. P2_REVIEW — superdevops233/Django-CRM

- Path: `ENV.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/superdevops233/Django-CRM/blob/2de2fa9e2930ff1f99a5c3dedf9e0a433a1a1756/ENV.md
- Repository URL: https://github.com/superdevops233/Django-CRM
- Assessment: unconfirmed; do not use or test any credentials.

### 834. P2_REVIEW — superior57/reporting

- Path: `env.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/superior57/reporting/blob/d4b18d7a4b9baa4b464e222d76010a7741e3ed18/env.txt
- Repository URL: https://github.com/superior57/reporting
- Assessment: unconfirmed; do not use or test any credentials.

### 835. P2_REVIEW — swyxio/netlify-google-spreadsheet-demo

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/swyxio/netlify-google-spreadsheet-demo/blob/13cd4a199152d3fd25382f6a3e3d8bc604ce53c2/README.md
- Repository URL: https://github.com/swyxio/netlify-google-spreadsheet-demo
- Assessment: unconfirmed; do not use or test any credentials.

### 836. P2_REVIEW — tadasant/mcp-server-stability-ai

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/tadasant/mcp-server-stability-ai/blob/d2f0a57adbbd8e080a99729cb062a3bcde6fee7a/README.md
- Repository URL: https://github.com/tadasant/mcp-server-stability-ai
- Assessment: unconfirmed; do not use or test any credentials.

### 837. P2_REVIEW — taifAlrubeaan/2024-GP_4

- Path: `c.txt`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/taifAlrubeaan/2024-GP_4/blob/01c9df62eb9c90656463afedd73b77ceaf1e8bd9/c.txt
- Repository URL: https://github.com/taifAlrubeaan/2024-GP_4
- Assessment: unconfirmed; do not use or test any credentials.

### 838. P2_REVIEW — tatsuya6502/docker-x2go

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/tatsuya6502/docker-x2go/blob/a855df05f1fcb1c5e34ab746b8a4b16f29112eea/README.md
- Repository URL: https://github.com/tatsuya6502/docker-x2go
- Assessment: unconfirmed; do not use or test any credentials.

### 839. P2_REVIEW — tbarn/guys-bot

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/tbarn/guys-bot/blob/548c610e94d1c09655e0536a13c4a6faadaf04cf/README.md
- Repository URL: https://github.com/tbarn/guys-bot
- Assessment: unconfirmed; do not use or test any credentials.

### 840. P2_REVIEW — theabdullahraja/database-intrusion-detection-system

- Path: `DEMO.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/theabdullahraja/database-intrusion-detection-system/blob/2b534d61cd159f5f724925a11d9b6636110b7f0a/DEMO.md
- Repository URL: https://github.com/theabdullahraja/database-intrusion-detection-system
- Assessment: unconfirmed; do not use or test any credentials.

### 841. P2_REVIEW — thesubtlety/go-decrypt-jenkins

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/thesubtlety/go-decrypt-jenkins/blob/4f4ac4b75250c23a6861ccb74e34886bf02c873f/README.md
- Repository URL: https://github.com/thesubtlety/go-decrypt-jenkins
- Assessment: unconfirmed; do not use or test any credentials.

### 842. P2_REVIEW — tierratelematics/cfsign

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/tierratelematics/cfsign/blob/e6192da829087dc63e29a39f65000dbfee3a8010/README.md
- Repository URL: https://github.com/tierratelematics/cfsign
- Assessment: unconfirmed; do not use or test any credentials.

### 843. P2_REVIEW — tinkink-net/tinkses

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/tinkink-net/tinkses/blob/b10b9bd282052f0697e21fc19fb7701fc63ac1ee/README.md
- Repository URL: https://github.com/tinkink-net/tinkses
- Assessment: unconfirmed; do not use or test any credentials.

### 844. P2_REVIEW — toast-ninja/github-analytics-starter

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/toast-ninja/github-analytics-starter/blob/623545b54dc858d0feb05c3565466b1dce759d1e/README.md
- Repository URL: https://github.com/toast-ninja/github-analytics-starter
- Assessment: unconfirmed; do not use or test any credentials.

### 845. P2_REVIEW — tom-hightower/talli

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/tom-hightower/talli/blob/297ddce880376fc5218986f51d80a06c584492c5/README.md
- Repository URL: https://github.com/tom-hightower/talli
- Assessment: unconfirmed; do not use or test any credentials.

### 846. P2_REVIEW — tompi/mrbs

- Path: `NEWS`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/tompi/mrbs/blob/1ce953ab7410cc01e7c599ad26ddd849f795d072/NEWS
- Repository URL: https://github.com/tompi/mrbs
- Assessment: unconfirmed; do not use or test any credentials.

### 847. P2_REVIEW — tomwhite/genomics-analytics

- Path: `adam.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/tomwhite/genomics-analytics/blob/8dc0f53b553120a1b64d1223996d6cfcc81c3465/adam.md
- Repository URL: https://github.com/tomwhite/genomics-analytics
- Assessment: unconfirmed; do not use or test any credentials.

### 848. P2_REVIEW — transistorsoft/background-geolocation-console

- Path: `README.md`
- Indicator: `private_key_header;rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/transistorsoft/background-geolocation-console/blob/5aa8518390dee634a5307ee1ad6ac46b910f2054/README.md
- Repository URL: https://github.com/transistorsoft/background-geolocation-console
- Assessment: unconfirmed; do not use or test any credentials.

### 849. P2_REVIEW — traviscrawford/spark-dynamodb

- Path: `DEV.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/traviscrawford/spark-dynamodb/blob/74d44c15d3e20d7d1e2722b46cfbe8ea9590c59f/DEV.md
- Repository URL: https://github.com/traviscrawford/spark-dynamodb
- Assessment: unconfirmed; do not use or test any credentials.

### 850. P2_REVIEW — travist/jsencrypt

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/travist/jsencrypt/blob/a0ae319f4011d90ec7dc15192c0f7be1f3946ee0/README.md
- Repository URL: https://github.com/travist/jsencrypt
- Assessment: unconfirmed; do not use or test any credentials.

### 851. P2_REVIEW — travist/jsencrypt

- Path: `index.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/travist/jsencrypt/blob/a0ae319f4011d90ec7dc15192c0f7be1f3946ee0/index.md
- Repository URL: https://github.com/travist/jsencrypt
- Assessment: unconfirmed; do not use or test any credentials.

### 852. P2_REVIEW — truster-dev/truster

- Path: `DEV.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/truster-dev/truster/blob/10e49ebe65e339d426b7b1e20fa283cf96ebc813/DEV.md
- Repository URL: https://github.com/truster-dev/truster
- Assessment: unconfirmed; do not use or test any credentials.

### 853. P2_REVIEW — ttab/ttab.github.io

- Path: `api.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/ttab/ttab.github.io/blob/2be6b3201aae100ad5f946f5d8d42cc6103ae1d0/api.md
- Repository URL: https://github.com/ttab/ttab.github.io
- Assessment: unconfirmed; do not use or test any credentials.

### 854. P2_REVIEW — tuana9a/docs

- Path: `aws.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/tuana9a/docs/blob/1bace9ac45edb49955b7c74cd01ff6b125aa43b0/aws.md
- Repository URL: https://github.com/tuana9a/docs
- Assessment: unconfirmed; do not use or test any credentials.

### 855. P2_REVIEW — tuanvu0202/TOT1-Media

- Path: `env.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/tuanvu0202/TOT1-Media/blob/4cf46aba12e8121c865c7ef3cd3ffef7d3511e83/env.txt
- Repository URL: https://github.com/tuanvu0202/TOT1-Media
- Assessment: unconfirmed; do not use or test any credentials.

### 856. P2_REVIEW — tumblr/docs

- Path: `api.md`
- Indicator: `client_secret_label;access_token_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/tumblr/docs/blob/708be10978b23e29eb4bc97109dd11f30be3e12b/api.md
- Repository URL: https://github.com/tumblr/docs
- Assessment: unconfirmed; do not use or test any credentials.

### 857. P2_REVIEW — twitchyliquid64/nexus

- Path: `docs.MD`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/twitchyliquid64/nexus/blob/47b669a7eeeecea55cbddfcb6732e03e50eb6d7d/docs.MD
- Repository URL: https://github.com/twitchyliquid64/nexus
- Assessment: unconfirmed; do not use or test any credentials.

### 858. P2_REVIEW — vanha0910/udacity_eks

- Path: `cmd.txt`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/vanha0910/udacity_eks/blob/fd49ad3cf7d18b7264fd9f0eeb652cb4849eb5e1/cmd.txt
- Repository URL: https://github.com/vanha0910/udacity_eks
- Assessment: unconfirmed; do not use or test any credentials.

### 859. P2_REVIEW — ventz/easy-llms

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/ventz/easy-llms/blob/934b63327681eaaf55f91e138cc6046b43b159ec/README.md
- Repository URL: https://github.com/ventz/easy-llms
- Assessment: unconfirmed; do not use or test any credentials.

### 860. P2_REVIEW — vestris/slack-invite

- Path: `DEV.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/vestris/slack-invite/blob/e565caf5d49519e03319c4da2478d9f2ac987e6c/DEV.md
- Repository URL: https://github.com/vestris/slack-invite
- Assessment: unconfirmed; do not use or test any credentials.

### 861. P2_REVIEW — vielang/vieshare-axum

- Path: `Dev.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/vielang/vieshare-axum/blob/c544f0ef25a966d7104c6e5b1d881022641f5370/Dev.md
- Repository URL: https://github.com/vielang/vieshare-axum
- Assessment: unconfirmed; do not use or test any credentials.

### 862. P2_REVIEW — vietduongd/cdcsink

- Path: `ENV.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/vietduongd/cdcsink/blob/dd9151b7a9a07269a412046d6f657de898edb2d3/ENV.md
- Repository URL: https://github.com/vietduongd/cdcsink
- Assessment: unconfirmed; do not use or test any credentials.

### 863. P2_REVIEW — vignesh-cloud-prog/QP

- Path: `env.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/vignesh-cloud-prog/QP/blob/5f09d7ab544f38a05f9d868e8fe5130fd3f67602/env.md
- Repository URL: https://github.com/vignesh-cloud-prog/QP
- Assessment: unconfirmed; do not use or test any credentials.

### 864. P2_REVIEW — vikingmute/better-wechatpay

- Path: `llms.txt`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/vikingmute/better-wechatpay/blob/2253184804467d7078a30da89bed965bc78c7187/llms.txt
- Repository URL: https://github.com/vikingmute/better-wechatpay
- Assessment: unconfirmed; do not use or test any credentials.

### 865. P2_REVIEW — vlucas/pikirasa

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/vlucas/pikirasa/blob/13037864da08933eb716537cfac055d3735d1c16/README.md
- Repository URL: https://github.com/vlucas/pikirasa
- Assessment: unconfirmed; do not use or test any credentials.

### 866. P2_REVIEW — voxpupuli/beaker-aws

- Path: `aws.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/voxpupuli/beaker-aws/blob/d8b01976ad888ec81b42cbc86ed4bf217f764bbc/aws.md
- Repository URL: https://github.com/voxpupuli/beaker-aws
- Assessment: unconfirmed; do not use or test any credentials.

### 867. P2_REVIEW — voxpupuli/beaker-aws

- Path: `ec2.md`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/voxpupuli/beaker-aws/blob/d8b01976ad888ec81b42cbc86ed4bf217f764bbc/ec2.md
- Repository URL: https://github.com/voxpupuli/beaker-aws
- Assessment: unconfirmed; do not use or test any credentials.

### 868. P2_REVIEW — wadewegner/deploy-to-sfdx

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/wadewegner/deploy-to-sfdx/blob/2501db3c1592c24b3cbc5b42617f46d94c15f5ba/README.md
- Repository URL: https://github.com/wadewegner/deploy-to-sfdx
- Assessment: unconfirmed; do not use or test any credentials.

### 869. P2_REVIEW — webiness/webiness_inventory

- Path: `INSTALL`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/webiness/webiness_inventory/blob/863f2d10c64386c461281af8aeda2a868d1a549b/INSTALL
- Repository URL: https://github.com/webiness/webiness_inventory
- Assessment: unconfirmed; do not use or test any credentials.

### 870. P2_REVIEW — widdix/aws-cf-templates-cli

- Path: `cli.txt`
- Indicator: `aws_secret_key_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/widdix/aws-cf-templates-cli/blob/98a3b7e7935fd178c248034ad83efcf7e3c793ba/cli.txt
- Repository URL: https://github.com/widdix/aws-cf-templates-cli
- Assessment: unconfirmed; do not use or test any credentials.

### 871. P2_REVIEW — win4r/mytest

- Path: `qm.md`
- Indicator: `database_url;client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/win4r/mytest/blob/fc16e29b0d11253254ac98b51f551099cf9c9de3/qm.md
- Repository URL: https://github.com/win4r/mytest
- Assessment: unconfirmed; do not use or test any credentials.

### 872. P2_REVIEW — wiseman-umanah/polymarket-bot

- Path: `BOT.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/wiseman-umanah/polymarket-bot/blob/c2aa19092932e3d06a72c437190d1757b749ec82/BOT.md
- Repository URL: https://github.com/wiseman-umanah/polymarket-bot
- Assessment: unconfirmed; do not use or test any credentials.

### 873. P2_REVIEW — wmhello/laravel_template_with_vue

- Path: `back.md`
- Indicator: `db_password_label;client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/wmhello/laravel_template_with_vue/blob/523f035cc95563316f0410c3bb4089654627a0f9/back.md
- Repository URL: https://github.com/wmhello/laravel_template_with_vue
- Assessment: unconfirmed; do not use or test any credentials.

### 874. P2_REVIEW — woohgit/woocommerce-otpbank-payment-gateway

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/woohgit/woocommerce-otpbank-payment-gateway/blob/e8271248238fe2c3181a8fd46a93e548c4031b60/README.md
- Repository URL: https://github.com/woohgit/woocommerce-otpbank-payment-gateway
- Assessment: unconfirmed; do not use or test any credentials.

### 875. P2_REVIEW — wtcctw/dianping-lion

- Path: `LION.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/wtcctw/dianping-lion/blob/1abdcfe172332a68eb76ba62fe608327c7d24f1b/LION.md
- Repository URL: https://github.com/wtcctw/dianping-lion
- Assessment: unconfirmed; do not use or test any credentials.

### 876. P2_REVIEW — wunderwuzzi23/scratch

- Path: `creds.md`
- Indicator: `aws_secret_key_label;private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/wunderwuzzi23/scratch/blob/70dac02a549f68aefe2dc6c1ae08e9c9b7e2b22a/creds.md
- Repository URL: https://github.com/wunderwuzzi23/scratch
- Assessment: unconfirmed; do not use or test any credentials.

### 877. P2_REVIEW — wyu31/TECHIN-510-FinalProject

- Path: `db.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/wyu31/TECHIN-510-FinalProject/blob/9973cde53aebf0c4cb94ff71a23d6cee5844ffce/db.md
- Repository URL: https://github.com/wyu31/TECHIN-510-FinalProject
- Assessment: unconfirmed; do not use or test any credentials.

### 878. P2_REVIEW — xcodeme21/tb-delima

- Path: `env.txt`
- Indicator: `aws_secret_key_label;db_password_label;secret_access_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/xcodeme21/tb-delima/blob/03efb8848abd5118e60e10053f1e464ad2058544/env.txt
- Repository URL: https://github.com/xcodeme21/tb-delima
- Assessment: unconfirmed; do not use or test any credentials.

### 879. P2_REVIEW — xthxr/piik.me

- Path: `FAQ.md`
- Indicator: `private_key_header;private_key_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/xthxr/piik.me/blob/37a64a275a434e6b3de40a87bc1834859fed83b0/FAQ.md
- Repository URL: https://github.com/xthxr/piik.me
- Assessment: unconfirmed; do not use or test any credentials.

### 880. P2_REVIEW — yangtao121/HomeSystem

- Path: `FAQ.md`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/yangtao121/HomeSystem/blob/3fb3d4631e8952ee439f9dd809d9f105340f7ee7/FAQ.md
- Repository URL: https://github.com/yangtao121/HomeSystem
- Assessment: unconfirmed; do not use or test any credentials.

### 881. P2_REVIEW — yaoshanliang/ucenter-open

- Path: `api.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/yaoshanliang/ucenter-open/blob/4bf7cf1f04f4df039773fa212c49862afb42332c/api.md
- Repository URL: https://github.com/yaoshanliang/ucenter-open
- Assessment: unconfirmed; do not use or test any credentials.

### 882. P2_REVIEW — yetu/oauth2-provider

- Path: `API.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/yetu/oauth2-provider/blob/57710199079b7e65035c756b99c1bd0f241cc906/API.md
- Repository URL: https://github.com/yetu/oauth2-provider
- Assessment: unconfirmed; do not use or test any credentials.

### 883. P2_REVIEW — yolosec/zeman-parser

- Path: `fb.md`
- Indicator: `client_secret_label;access_token_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/yolosec/zeman-parser/blob/40bb31efdde0409f5851200f116e721f77ffc5ba/fb.md
- Repository URL: https://github.com/yolosec/zeman-parser
- Assessment: unconfirmed; do not use or test any credentials.

### 884. P2_REVIEW — yorkulibraries/mrbs

- Path: `NEWS`
- Indicator: `db_password_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/yorkulibraries/mrbs/blob/c72b5af084ed9ec88e4dc2e70797dd29d06746b8/NEWS
- Repository URL: https://github.com/yorkulibraries/mrbs
- Assessment: unconfirmed; do not use or test any credentials.

### 885. P2_REVIEW — yueyoum/social-oauth

- Path: `doc.md`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/yueyoum/social-oauth/blob/80600ea737355b20931c8a0b5223f5b68175d930/doc.md
- Repository URL: https://github.com/yueyoum/social-oauth
- Assessment: unconfirmed; do not use or test any credentials.

### 886. P2_REVIEW — yyoshiki41/go-siwa

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/yyoshiki41/go-siwa/blob/e408b43ddd989040c12c69ee922d9dc33d3947ca/README.md
- Repository URL: https://github.com/yyoshiki41/go-siwa
- Assessment: unconfirmed; do not use or test any credentials.

### 887. P2_REVIEW — zanechua/comment-worker

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/zanechua/comment-worker/blob/8e1a63acd0145e9fea515fe94e056a254d972e62/README.md
- Repository URL: https://github.com/zanechua/comment-worker
- Assessment: unconfirmed; do not use or test any credentials.

### 888. P2_REVIEW — zhangzhaopds/WeixinApp_RSA_Signature

- Path: `README.md`
- Indicator: `rsa_private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/zhangzhaopds/WeixinApp_RSA_Signature/blob/295ed2acb6231fd66d2a15f003b2a36b2e98db63/README.md
- Repository URL: https://github.com/zhangzhaopds/WeixinApp_RSA_Signature
- Assessment: unconfirmed; do not use or test any credentials.

### 889. P2_REVIEW — zmanda/amanda

- Path: `NEWS`
- Indicator: `client_secret_label`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/zmanda/amanda/blob/a7c8c3e7d4726ed7bccb6dbd5a3b274e73e1655e/NEWS
- Repository URL: https://github.com/zmanda/amanda
- Assessment: unconfirmed; do not use or test any credentials.

### 890. P2_REVIEW — zuohuadong/refine-sqlx

- Path: `CLI.md`
- Indicator: `database_url`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/zuohuadong/refine-sqlx/blob/67aface8939fcf84a8f4bf00b5a661d0449be842/CLI.md
- Repository URL: https://github.com/zuohuadong/refine-sqlx
- Assessment: unconfirmed; do not use or test any credentials.

### 891. P2_REVIEW — zvakanaka/sheets-db

- Path: `README.md`
- Indicator: `private_key_header`
- Heuristic score: 2 (not severity)
- File URL: https://github.com/zvakanaka/sheets-db/blob/4b348aef640cd8693f106b87976083e16449c40a/README.md
- Repository URL: https://github.com/zvakanaka/sheets-db
- Assessment: unconfirmed; do not use or test any credentials.

### 892. P3_LOW_SIGNAL — ANLAB-KAIST/Knapp

- Path: `config.json.bak`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/ANLAB-KAIST/Knapp/blob/783ba9248ac48ab2246ef84dfd7e2efd79dcc23e/config.json.bak
- Repository URL: https://github.com/ANLAB-KAIST/Knapp
- Assessment: unconfirmed; do not use or test any credentials.

### 893. P3_LOW_SIGNAL — Ardenhong/fb-crawler

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/Ardenhong/fb-crawler/blob/fa675a7064263f57ff91f1d0b106a59310a77845/config.json.dist
- Repository URL: https://github.com/Ardenhong/fb-crawler
- Assessment: unconfirmed; do not use or test any credentials.

### 894. P3_LOW_SIGNAL — Arunvijay28/Mentoring-system

- Path: `credentials1.txt`
- Indicator: `config_credentials`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/Arunvijay28/Mentoring-system/blob/edfbab1cb3fc5930cf08f5578dd7d860b658686b/credentials1.txt
- Repository URL: https://github.com/Arunvijay28/Mentoring-system
- Assessment: unconfirmed; do not use or test any credentials.

### 895. P3_LOW_SIGNAL — Batrium/WatchMonUdpListener

- Path: `config.json_dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/Batrium/WatchMonUdpListener/blob/8ed316f5a21bd6a3ee80718f06bbcb053628cbad/config.json_dist
- Repository URL: https://github.com/Batrium/WatchMonUdpListener
- Assessment: unconfirmed; do not use or test any credentials.

### 896. P3_LOW_SIGNAL — Bookshlf-in/Website

- Path: `Demo.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/Bookshlf-in/Website/blob/5089517320feaa2fcdb649286eebcaf16065ccb3/Demo.env.txt
- Repository URL: https://github.com/Bookshlf-in/Website
- Assessment: unconfirmed; do not use or test any credentials.

### 897. P3_LOW_SIGNAL — Cognigy/Cognigy-CLI

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/Cognigy/Cognigy-CLI/blob/e8e383e4d7c2a5f74195880d1400ce4e7ca02b44/config.json.dist
- Repository URL: https://github.com/Cognigy/Cognigy-CLI
- Assessment: unconfirmed; do not use or test any credentials.

### 898. P3_LOW_SIGNAL — DeaglePC/CordCloud-Check-in

- Path: `config.json.bak`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/DeaglePC/CordCloud-Check-in/blob/8d93097f7f8b88c400e31beb7332e4ef3b331017/config.json.bak
- Repository URL: https://github.com/DeaglePC/CordCloud-Check-in
- Assessment: unconfirmed; do not use or test any credentials.

### 899. P3_LOW_SIGNAL — Deneir/deneir

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/Deneir/deneir/blob/cc939a5ef9dfb03b68a123513ae3615d558b880f/config.json.dist
- Repository URL: https://github.com/Deneir/deneir
- Assessment: unconfirmed; do not use or test any credentials.

### 900. P3_LOW_SIGNAL — GoPlugin/plugin-deployment

- Path: `apicredentials.txt`
- Indicator: `config_credentials`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/GoPlugin/plugin-deployment/blob/fe727c43f76aef26ff2be7c40840ffc4b800ade1/apicredentials.txt
- Repository URL: https://github.com/GoPlugin/plugin-deployment
- Assessment: unconfirmed; do not use or test any credentials.

### 901. P3_LOW_SIGNAL — Greenjiao/Game-Map-Tracker

- Path: `config.json.bak`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/Greenjiao/Game-Map-Tracker/blob/ed3fb2abb4bde95d589e3ba3323e05f2473a5fb4/config.json.bak
- Repository URL: https://github.com/Greenjiao/Game-Map-Tracker
- Assessment: unconfirmed; do not use or test any credentials.

### 902. P3_LOW_SIGNAL — HellRok/Taylor

- Path: `taylor-config.json.md`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/HellRok/Taylor/blob/11f1d1e4808543cc2c09b6d9ac531876d471dc6e/taylor-config.json.md
- Repository URL: https://github.com/HellRok/Taylor
- Assessment: unconfirmed; do not use or test any credentials.

### 903. P3_LOW_SIGNAL — HouzuoGuo/laitos

- Path: `sample-config.json.txt`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/HouzuoGuo/laitos/blob/b4583f26964502c117ee783e055dc9150e16a2bf/sample-config.json.txt
- Repository URL: https://github.com/HouzuoGuo/laitos
- Assessment: unconfirmed; do not use or test any credentials.

### 904. P3_LOW_SIGNAL — Janusec/janusec

- Path: `config.json.bak`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/Janusec/janusec/blob/17a265c7f5afb72c5ec9caa48bf37adb1ec3c7b8/config.json.bak
- Repository URL: https://github.com/Janusec/janusec
- Assessment: unconfirmed; do not use or test any credentials.

### 905. P3_LOW_SIGNAL — Kilix/packer-docker

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/Kilix/packer-docker/blob/96e14cca474cfeb9332bcf00eda8eedbc0c86053/config.json.dist
- Repository URL: https://github.com/Kilix/packer-docker
- Assessment: unconfirmed; do not use or test any credentials.

### 906. P3_LOW_SIGNAL — KoFish/pallium

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/KoFish/pallium/blob/1cbd5f88c815c1c46ad47cf0649fb94dccc581c4/config.json.dist
- Repository URL: https://github.com/KoFish/pallium
- Assessment: unconfirmed; do not use or test any credentials.

### 907. P3_LOW_SIGNAL — Kopano-dev/meet

- Path: `config.json.in`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/Kopano-dev/meet/blob/fc2d0096598f6ecfcf621adfc0a0c553c437d37b/config.json.in
- Repository URL: https://github.com/Kopano-dev/meet
- Assessment: unconfirmed; do not use or test any credentials.

### 908. P3_LOW_SIGNAL — Kualarz/bridge

- Path: `SECRETS-SCAN.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/Kualarz/bridge/blob/96510e184af7c014bb26a1416aaf665009a0dde3/SECRETS-SCAN.md
- Repository URL: https://github.com/Kualarz/bridge
- Assessment: unconfirmed; do not use or test any credentials.

### 909. P3_LOW_SIGNAL — Lerrylore/Gen-AI-In-Metaverse

- Path: `Example.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/Lerrylore/Gen-AI-In-Metaverse/blob/53ac3e4605d01b48de283e054b5e1444d41bf91f/Example.env.txt
- Repository URL: https://github.com/Lerrylore/Gen-AI-In-Metaverse
- Assessment: unconfirmed; do not use or test any credentials.

### 910. P3_LOW_SIGNAL — LiamKarlMitchell/InfiniteSky

- Path: `config.json-dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/LiamKarlMitchell/InfiniteSky/blob/b0b8f74faeaf63f270bee0191462a0b8394c9a4d/config.json-dist
- Repository URL: https://github.com/LiamKarlMitchell/InfiniteSky
- Assessment: unconfirmed; do not use or test any credentials.

### 911. P3_LOW_SIGNAL — MartinChen1973/lllm

- Path: `.env_`
- Indicator: `credentials_file`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/MartinChen1973/lllm/blob/fcabc18903c3c3a13cd112c738d406d330163422/.env_
- Repository URL: https://github.com/MartinChen1973/lllm
- Assessment: unconfirmed; do not use or test any credentials.

### 912. P3_LOW_SIGNAL — OraOpenSource/plsql-md-doc

- Path: `docs/config.json.md`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/OraOpenSource/plsql-md-doc/blob/5a33f999154ef5e1d4fce63889bda97f88a60bd7/docs/config.json.md
- Repository URL: https://github.com/OraOpenSource/plsql-md-doc
- Assessment: unconfirmed; do not use or test any credentials.

### 913. P3_LOW_SIGNAL — PixelChainDapp/PixelChain-GoLang-Decoder

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/PixelChainDapp/PixelChain-GoLang-Decoder/blob/de9cd174a3947fb2ce6a0f30ba24dfd6d35929a3/config.json.dist
- Repository URL: https://github.com/PixelChainDapp/PixelChain-GoLang-Decoder
- Assessment: unconfirmed; do not use or test any credentials.

### 914. P3_LOW_SIGNAL — RayFernando1337/ray-fernando-actions-templates

- Path: `docs/secrets.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/RayFernando1337/ray-fernando-actions-templates/blob/9d4382cfbfe92d97a10bf51d6121697504ee2ac4/docs/secrets.md
- Repository URL: https://github.com/RayFernando1337/ray-fernando-actions-templates
- Assessment: unconfirmed; do not use or test any credentials.

### 915. P3_LOW_SIGNAL — RepoReapers/reaper

- Path: `config.json.skel`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/RepoReapers/reaper/blob/d6e591cdb0783aa4245fc7ec3a0c982e6bf28713/config.json.skel
- Repository URL: https://github.com/RepoReapers/reaper
- Assessment: unconfirmed; do not use or test any credentials.

### 916. P3_LOW_SIGNAL — Shad02w/Youtube-Chat-in-Fullscreen

- Path: `tsconfig.json.bck`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/Shad02w/Youtube-Chat-in-Fullscreen/blob/c062bc9ce27a6379feb6917b00e25aa5872269cc/tsconfig.json.bck
- Repository URL: https://github.com/Shad02w/Youtube-Chat-in-Fullscreen
- Assessment: unconfirmed; do not use or test any credentials.

### 917. P3_LOW_SIGNAL — Sn0wCrack/ExHen-Archive

- Path: `config.json.linux`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/Sn0wCrack/ExHen-Archive/blob/ded46525e953f8f1053edd743a9207ad1ea4b189/config.json.linux
- Repository URL: https://github.com/Sn0wCrack/ExHen-Archive
- Assessment: unconfirmed; do not use or test any credentials.

### 918. P3_LOW_SIGNAL — TritonDataCenter/sdc-fwapi

- Path: `config.json.sample`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/TritonDataCenter/sdc-fwapi/blob/f6888f779a31eba6b544007c7f571c1101d73fda/config.json.sample
- Repository URL: https://github.com/TritonDataCenter/sdc-fwapi
- Assessment: unconfirmed; do not use or test any credentials.

### 919. P3_LOW_SIGNAL — ViacomInc/roku_builder

- Path: `config.json.min`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/ViacomInc/roku_builder/blob/9eef624178c10181e18a588b2a23d61b18359cf0/config.json.min
- Repository URL: https://github.com/ViacomInc/roku_builder
- Assessment: unconfirmed; do not use or test any credentials.

### 920. P3_LOW_SIGNAL — abhishekjnvk/telegram-channel-downloader

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/abhishekjnvk/telegram-channel-downloader/blob/0aed5a52e5eb9d88a8360eddff8a11bb76548188/config.json.dist
- Repository URL: https://github.com/abhishekjnvk/telegram-channel-downloader
- Assessment: unconfirmed; do not use or test any credentials.

### 921. P3_LOW_SIGNAL — abustany/s3proxy

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/abustany/s3proxy/blob/80edfcfcae5f37d5067ee86214bd013180233653/config.json.dist
- Repository URL: https://github.com/abustany/s3proxy
- Assessment: unconfirmed; do not use or test any credentials.

### 922. P3_LOW_SIGNAL — adamy/RedactWire

- Path: `docs/rules/secrets.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/adamy/RedactWire/blob/8fa2568c1d1297f8f3284399f36694c9884f680c/docs/rules/secrets.md
- Repository URL: https://github.com/adamy/RedactWire
- Assessment: unconfirmed; do not use or test any credentials.

### 923. P3_LOW_SIGNAL — adasq/dropbox-v2-api

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/adasq/dropbox-v2-api/blob/5ec1033632903103287cc0686ad9d9e2b96d52cd/config.json.dist
- Repository URL: https://github.com/adasq/dropbox-v2-api
- Assessment: unconfirmed; do not use or test any credentials.

### 924. P3_LOW_SIGNAL — adasq/google-alerts-api

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/adasq/google-alerts-api/blob/75f538bb2fc2a65ef4fd772b4a4c2395b528938b/config.json.dist
- Repository URL: https://github.com/adasq/google-alerts-api
- Assessment: unconfirmed; do not use or test any credentials.

### 925. P3_LOW_SIGNAL — adasq/youtube-studio

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/adasq/youtube-studio/blob/05c6a2652ce4a2db0c243cc1a0aa5742c57f960c/config.json.dist
- Repository URL: https://github.com/adasq/youtube-studio
- Assessment: unconfirmed; do not use or test any credentials.

### 926. P3_LOW_SIGNAL — bioothod/backrunner

- Path: `config.json.local`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/bioothod/backrunner/blob/0e46f2334888069e71c2af754f8f0e2bc8576d98/config.json.local
- Repository URL: https://github.com/bioothod/backrunner
- Assessment: unconfirmed; do not use or test any credentials.

### 927. P3_LOW_SIGNAL — bsn-si/IPEHR-gateway

- Path: `config.json.fevm`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/bsn-si/IPEHR-gateway/blob/4eea6972ecf4d1ed118290acddb126f1e3ab5688/config.json.fevm
- Repository URL: https://github.com/bsn-si/IPEHR-gateway
- Assessment: unconfirmed; do not use or test any credentials.

### 928. P3_LOW_SIGNAL — christear/APAIQ_release

- Path: `apaiq.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/christear/APAIQ_release/blob/dfe917b265890f3724d66b9840575d9672c22854/apaiq.env.txt
- Repository URL: https://github.com/christear/APAIQ_release
- Assessment: unconfirmed; do not use or test any credentials.

### 929. P3_LOW_SIGNAL — ctsit/redcap_deployment

- Path: `example.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/ctsit/redcap_deployment/blob/1f7013e0a6d656179c8b6c6c0d5fb55c506a31a9/example.env.txt
- Repository URL: https://github.com/ctsit/redcap_deployment
- Assessment: unconfirmed; do not use or test any credentials.

### 930. P3_LOW_SIGNAL — datagrove/test-sales-page

- Path: `sample.env.md`
- Indicator: `credentials_file`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/datagrove/test-sales-page/blob/59a939a233cf9e63ed78f20c1341e8cfcabea364/sample.env.md
- Repository URL: https://github.com/datagrove/test-sales-page
- Assessment: unconfirmed; do not use or test any credentials.

### 931. P3_LOW_SIGNAL — devture/matrix-corporal

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/devture/matrix-corporal/blob/09d33d1f4c813049e79306cf4808c98408ed017c/config.json.dist
- Repository URL: https://github.com/devture/matrix-corporal
- Assessment: unconfirmed; do not use or test any credentials.

### 932. P3_LOW_SIGNAL — dflydev/dflydev-git-subsplit-github-webhook

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/dflydev/dflydev-git-subsplit-github-webhook/blob/48a97144b24ad7424b78f4949ad186d140562fec/config.json.dist
- Repository URL: https://github.com/dflydev/dflydev-git-subsplit-github-webhook
- Assessment: unconfirmed; do not use or test any credentials.

### 933. P3_LOW_SIGNAL — dmuth/evernote-to-obsidian

- Path: `config.json.in`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/dmuth/evernote-to-obsidian/blob/0030469d6229ab28e14d4f2d5f641f2534adbbf5/config.json.in
- Repository URL: https://github.com/dmuth/evernote-to-obsidian
- Assessment: unconfirmed; do not use or test any credentials.

### 934. P3_LOW_SIGNAL — eastlondoner/vibe-tools

- Path: `CONFIGURATION.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/eastlondoner/vibe-tools/blob/4a1d17cf501db3a719a9c2bf0ee0d288282a63a7/CONFIGURATION.md
- Repository URL: https://github.com/eastlondoner/vibe-tools
- Assessment: unconfirmed; do not use or test any credentials.

### 935. P3_LOW_SIGNAL — edi-design/kd-go

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/edi-design/kd-go/blob/1dd6e069743011426cdc8358db9ae0947aff6e9b/config.json.dist
- Repository URL: https://github.com/edi-design/kd-go
- Assessment: unconfirmed; do not use or test any credentials.

### 936. P3_LOW_SIGNAL — edoardottt/secfiles

- Path: `regex/secrets.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/edoardottt/secfiles/blob/c3db4eb5974bcd955b34182e1057bec8cd1ec030/regex/secrets.md
- Repository URL: https://github.com/edoardottt/secfiles
- Assessment: unconfirmed; do not use or test any credentials.

### 937. P3_LOW_SIGNAL — ericmagnuson/rmcontrol

- Path: `config.json.sample`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/ericmagnuson/rmcontrol/blob/4cc679e7ebe9f74826e523d3c08a0ba84141086c/config.json.sample
- Repository URL: https://github.com/ericmagnuson/rmcontrol
- Assessment: unconfirmed; do not use or test any credentials.

### 938. P3_LOW_SIGNAL — everstu/Koolcenter_alist

- Path: `config.json.js`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/everstu/Koolcenter_alist/blob/548b258899ee09df9dd7039f141764613a7c7934/config.json.js
- Repository URL: https://github.com/everstu/Koolcenter_alist
- Assessment: unconfirmed; do not use or test any credentials.

### 939. P3_LOW_SIGNAL — everstu/Koolcenter_rustdesk

- Path: `config.json.js`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/everstu/Koolcenter_rustdesk/blob/ed1f5739e1b7a99b71f9495c5c5dc197a9d0c2f8/config.json.js
- Repository URL: https://github.com/everstu/Koolcenter_rustdesk
- Assessment: unconfirmed; do not use or test any credentials.

### 940. P3_LOW_SIGNAL — fossasia/fossasia-nodemailer

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/fossasia/fossasia-nodemailer/blob/b825d098643fa3cb42ba5774b2100322c8006cd2/config.json.dist
- Repository URL: https://github.com/fossasia/fossasia-nodemailer
- Assessment: unconfirmed; do not use or test any credentials.

### 941. P3_LOW_SIGNAL — gnd/archive_downloader

- Path: `config.json.orig`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/gnd/archive_downloader/blob/6c74d42c6345a39754d22c06d1fad5cfbb37eeba/config.json.orig
- Repository URL: https://github.com/gnd/archive_downloader
- Assessment: unconfirmed; do not use or test any credentials.

### 942. P3_LOW_SIGNAL — gooddaytoday/TypeScript-Handbook-RU

- Path: `pages/tsconfig.json.md`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/gooddaytoday/TypeScript-Handbook-RU/blob/753b2e3c8aaf644a9933faf24a0a9f86dc3f2733/pages/tsconfig.json.md
- Repository URL: https://github.com/gooddaytoday/TypeScript-Handbook-RU
- Assessment: unconfirmed; do not use or test any credentials.

### 943. P3_LOW_SIGNAL — gregzaal/HDR-Merge-Master

- Path: `config.json.bak`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/gregzaal/HDR-Merge-Master/blob/7dd44b7725aed9c2a9373acb6031188164467892/config.json.bak
- Repository URL: https://github.com/gregzaal/HDR-Merge-Master
- Assessment: unconfirmed; do not use or test any credentials.

### 944. P3_LOW_SIGNAL — h4rvey-g/bioinfo-for-dummies

- Path: `2.env_tool.qmd`
- Indicator: `credentials_file`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/h4rvey-g/bioinfo-for-dummies/blob/f1ba574eaa7862e8fe9187924192b2fb60e39b3e/2.env_tool.qmd
- Repository URL: https://github.com/h4rvey-g/bioinfo-for-dummies
- Assessment: unconfirmed; do not use or test any credentials.

### 945. P3_LOW_SIGNAL — hhru/ab-reminder-bot

- Path: `config.json.ex`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/hhru/ab-reminder-bot/blob/14a99fb6e12e407ac10377214a80dea8689d60ba/config.json.ex
- Repository URL: https://github.com/hhru/ab-reminder-bot
- Assessment: unconfirmed; do not use or test any credentials.

### 946. P3_LOW_SIGNAL — houzi-/Koolshare-Clash-hack

- Path: `config.json.js`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/houzi-/Koolshare-Clash-hack/blob/5f925ac3e9471a701898da5b5ce29e01fe863eec/config.json.js
- Repository URL: https://github.com/houzi-/Koolshare-Clash-hack
- Assessment: unconfirmed; do not use or test any credentials.

### 947. P3_LOW_SIGNAL — htmlburger/wpemerge-plugin

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/htmlburger/wpemerge-plugin/blob/27e2dd7e65f82551eb340f36835e3d14e1083c83/config.json.dist
- Repository URL: https://github.com/htmlburger/wpemerge-plugin
- Assessment: unconfirmed; do not use or test any credentials.

### 948. P3_LOW_SIGNAL — jaykdoe/infranodus

- Path: `config.json.sample`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/jaykdoe/infranodus/blob/1a91e545ea91e3e54c1666a5ebd207b64d7c4a88/config.json.sample
- Repository URL: https://github.com/jaykdoe/infranodus
- Assessment: unconfirmed; do not use or test any credentials.

### 949. P3_LOW_SIGNAL — jimwmg/JiM-Blog

- Path: `typeScript/tsconfig.json.md`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/jimwmg/JiM-Blog/blob/11adb268258e10b8ea6a0897cfd56d4ee83a71e9/typeScript/tsconfig.json.md
- Repository URL: https://github.com/jimwmg/JiM-Blog
- Assessment: unconfirmed; do not use or test any credentials.

### 950. P3_LOW_SIGNAL — juks/HomeMeter

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/juks/HomeMeter/blob/550f46aa2c91eb6cc1213064281680f74d07826e/config.json.dist
- Repository URL: https://github.com/juks/HomeMeter
- Assessment: unconfirmed; do not use or test any credentials.

### 951. P3_LOW_SIGNAL — kavicastelo/advanced-cache-design

- Path: `tsconfig.json~`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/kavicastelo/advanced-cache-design/blob/525d4dedd41f4175d0b91d1a1b303f321e653db4/tsconfig.json~
- Repository URL: https://github.com/kavicastelo/advanced-cache-design
- Assessment: unconfirmed; do not use or test any credentials.

### 952. P3_LOW_SIGNAL — kinfey/dotNETMauiHOL

- Path: `cn/00.Env.md`
- Indicator: `credentials_file`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/kinfey/dotNETMauiHOL/blob/9e02e5342b368e20d530a455327843d51fd032cd/cn/00.Env.md
- Repository URL: https://github.com/kinfey/dotNETMauiHOL
- Assessment: unconfirmed; do not use or test any credentials.

### 953. P3_LOW_SIGNAL — koolproxy/merlin-koolproxy

- Path: `config.json.js`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/koolproxy/merlin-koolproxy/blob/75c68a9b63eb5b97b3c897cbf2c3e53509ded7ec/config.json.js
- Repository URL: https://github.com/koolproxy/merlin-koolproxy
- Assessment: unconfirmed; do not use or test any credentials.

### 954. P3_LOW_SIGNAL — koolshare/armsoft

- Path: `kms/config.json.js`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/koolshare/armsoft/blob/06d3d3234224d34d75d17b3f700a5c3ed8d33840/kms/config.json.js
- Repository URL: https://github.com/koolshare/armsoft
- Assessment: unconfirmed; do not use or test any credentials.

### 955. P3_LOW_SIGNAL — koolshare/merlin-aliddns

- Path: `config.json.js`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/koolshare/merlin-aliddns/blob/3f957eaad2565b718d5d164b08f19e4cb8e9073f/config.json.js
- Repository URL: https://github.com/koolshare/merlin-aliddns
- Assessment: unconfirmed; do not use or test any credentials.

### 956. P3_LOW_SIGNAL — koolshare/merlin-aria2

- Path: `config.json.js`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/koolshare/merlin-aria2/blob/80fff62903f1d816e42ec9cc4e84695fbcc3b5a8/config.json.js
- Repository URL: https://github.com/koolshare/merlin-aria2
- Assessment: unconfirmed; do not use or test any credentials.

### 957. P3_LOW_SIGNAL — koolshare/merlin-ssserver

- Path: `config.json.js`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/koolshare/merlin-ssserver/blob/ade35cf2bd55787bac2bcb70d473761dfb428be4/config.json.js
- Repository URL: https://github.com/koolshare/merlin-ssserver
- Assessment: unconfirmed; do not use or test any credentials.

### 958. P3_LOW_SIGNAL — koolshare/merlin_frpc

- Path: `config.json.js`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/koolshare/merlin_frpc/blob/11a8f6cd9e7e932c9727479416a277563bae070b/config.json.js
- Repository URL: https://github.com/koolshare/merlin_frpc
- Assessment: unconfirmed; do not use or test any credentials.

### 959. P3_LOW_SIGNAL — koolshare/merlin_frps

- Path: `config.json.js`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/koolshare/merlin_frps/blob/4a9c4daf407cf677cf638c52175066029e242d6d/config.json.js
- Repository URL: https://github.com/koolshare/merlin_frps
- Assessment: unconfirmed; do not use or test any credentials.

### 960. P3_LOW_SIGNAL — koolshare/merlin_serverChan

- Path: `config.json.js`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/koolshare/merlin_serverChan/blob/afee6d686b021d8bb3f58d1576629edafdfbfcdd/config.json.js
- Repository URL: https://github.com/koolshare/merlin_serverChan
- Assessment: unconfirmed; do not use or test any credentials.

### 961. P3_LOW_SIGNAL — koolshare/signdog_hnd

- Path: `config.json.js`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/koolshare/signdog_hnd/blob/799e5316784e4bca97872b3b7c17bc35cc5f9e35/config.json.js
- Repository URL: https://github.com/koolshare/signdog_hnd
- Assessment: unconfirmed; do not use or test any credentials.

### 962. P3_LOW_SIGNAL — koolshare/softgear

- Path: `ss/config.json.js`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/koolshare/softgear/blob/a0688e56f76fb34d00491ebbc0f2a49c0eb35c0b/ss/config.json.js
- Repository URL: https://github.com/koolshare/softgear
- Assessment: unconfirmed; do not use or test any credentials.

### 963. P3_LOW_SIGNAL — ksred/go-stock-notifier

- Path: `config.json.sample`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/ksred/go-stock-notifier/blob/b6d4325b6999984fd2f3a18ee724e2385b28e02f/config.json.sample
- Repository URL: https://github.com/ksred/go-stock-notifier
- Assessment: unconfirmed; do not use or test any credentials.

### 964. P3_LOW_SIGNAL — kudelskisecurity/cdf

- Path: `config.json.enc`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/kudelskisecurity/cdf/blob/29a75421d9edf8a5fd10a4564879e315e4ea20af/config.json.enc
- Repository URL: https://github.com/kudelskisecurity/cdf
- Assessment: unconfirmed; do not use or test any credentials.

### 965. P3_LOW_SIGNAL — kudelskisecurity/cdf

- Path: `config.json.oaep`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/kudelskisecurity/cdf/blob/29a75421d9edf8a5fd10a4564879e315e4ea20af/config.json.oaep
- Repository URL: https://github.com/kudelskisecurity/cdf
- Assessment: unconfirmed; do not use or test any credentials.

### 966. P3_LOW_SIGNAL — kudelskisecurity/cdf

- Path: `config.json.prf`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/kudelskisecurity/cdf/blob/29a75421d9edf8a5fd10a4564879e315e4ea20af/config.json.prf
- Repository URL: https://github.com/kudelskisecurity/cdf
- Assessment: unconfirmed; do not use or test any credentials.

### 967. P3_LOW_SIGNAL — lelledev/upaygo

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/lelledev/upaygo/blob/526ee16849172d748017a8de65c2082cbb1b9ea4/config.json.dist
- Repository URL: https://github.com/lelledev/upaygo
- Assessment: unconfirmed; do not use or test any credentials.

### 968. P3_LOW_SIGNAL — loco/loco-php-sdk

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/loco/loco-php-sdk/blob/b646e5adfc731cb6715da8e25f5805e753e738bb/config.json.dist
- Repository URL: https://github.com/loco/loco-php-sdk
- Assessment: unconfirmed; do not use or test any credentials.

### 969. P3_LOW_SIGNAL — loopbackio/loopback.io

- Path: `pages/en/lb3/config.json.md`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/loopbackio/loopback.io/blob/43b96786c9e9ff6985ed084a9a22ced8a8aaa8db/pages/en/lb3/config.json.md
- Repository URL: https://github.com/loopbackio/loopback.io
- Assessment: unconfirmed; do not use or test any credentials.

### 970. P3_LOW_SIGNAL — loopbackio/loopback.io

- Path: `pages/ja/lb3/config.json.md`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/loopbackio/loopback.io/blob/43b96786c9e9ff6985ed084a9a22ced8a8aaa8db/pages/ja/lb3/config.json.md
- Repository URL: https://github.com/loopbackio/loopback.io
- Assessment: unconfirmed; do not use or test any credentials.

### 971. P3_LOW_SIGNAL — lxylxy123456/shierquan

- Path: `s.env.txt`
- Indicator: `credentials_file`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/lxylxy123456/shierquan/blob/d7c9d28d3af8edc8aa35cdf70333a5dba415dc89/s.env.txt
- Repository URL: https://github.com/lxylxy123456/shierquan
- Assessment: unconfirmed; do not use or test any credentials.

### 972. P3_LOW_SIGNAL — mgechev/real-world-bazel

- Path: `tsconfig.json.bak`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/mgechev/real-world-bazel/blob/b6e446519dd18fce12291cf4e1c5663c41023a59/tsconfig.json.bak
- Repository URL: https://github.com/mgechev/real-world-bazel
- Assessment: unconfirmed; do not use or test any credentials.

### 973. P3_LOW_SIGNAL — mhdawson/AlexaMqttBridge

- Path: `config.json.sample`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/mhdawson/AlexaMqttBridge/blob/fdcd939325e14c753c92f9af7dfaa3927cc9d59f/config.json.sample
- Repository URL: https://github.com/mhdawson/AlexaMqttBridge
- Assessment: unconfirmed; do not use or test any credentials.

### 974. P3_LOW_SIGNAL — michaelnisi/podest

- Path: `config.json.in`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/michaelnisi/podest/blob/6930ea94092f00db48e6bc7d359ab37a320413d4/config.json.in
- Repository URL: https://github.com/michaelnisi/podest
- Assessment: unconfirmed; do not use or test any credentials.

### 975. P3_LOW_SIGNAL — microsoft/TypeScript-wiki

- Path: `tsconfig.json.md`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/microsoft/TypeScript-wiki/blob/66ff1e4cb40a8749dfaf07d6b22dc0c0da3771dd/tsconfig.json.md
- Repository URL: https://github.com/microsoft/TypeScript-wiki
- Assessment: unconfirmed; do not use or test any credentials.

### 976. P3_LOW_SIGNAL — moeyy01/gh-proxy-go

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/moeyy01/gh-proxy-go/blob/280177e2d047512efb61dc83932248e446a37b22/config.json.dist
- Repository URL: https://github.com/moeyy01/gh-proxy-go
- Assessment: unconfirmed; do not use or test any credentials.

### 977. P3_LOW_SIGNAL — monsur/sonos-now-playing

- Path: `src/config.json.txt`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/monsur/sonos-now-playing/blob/53cbf1fecf67b5f8d2cea555d8d56cf751bfba46/src/config.json.txt
- Repository URL: https://github.com/monsur/sonos-now-playing
- Assessment: unconfirmed; do not use or test any credentials.

### 978. P3_LOW_SIGNAL — mybuilder/kongfig

- Path: `config.json.sample`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/mybuilder/kongfig/blob/62daeb670ee1c909ba2a46c93e63d9ad05e3ca61/config.json.sample
- Repository URL: https://github.com/mybuilder/kongfig
- Assessment: unconfirmed; do not use or test any credentials.

### 979. P3_LOW_SIGNAL — nagcloudlab/hsbc-java

- Path: `docs/2.Envi.md`
- Indicator: `credentials_file`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/nagcloudlab/hsbc-java/blob/61c1a61589b834637e95a82f23ad3bc87602a50c/docs/2.Envi.md
- Repository URL: https://github.com/nagcloudlab/hsbc-java
- Assessment: unconfirmed; do not use or test any credentials.

### 980. P3_LOW_SIGNAL — nice-winter/fancyss_arm

- Path: `config.json.js`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/nice-winter/fancyss_arm/blob/03a9b49a0f6604ef35626ae9fbfca46fc2cee5a0/config.json.js
- Repository URL: https://github.com/nice-winter/fancyss_arm
- Assessment: unconfirmed; do not use or test any credentials.

### 981. P3_LOW_SIGNAL — openfresque/trouver-une-fresque-scraper

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/openfresque/trouver-une-fresque-scraper/blob/919411e3e7e07f9f5c6bc6797b459863f50e626b/config.json.dist
- Repository URL: https://github.com/openfresque/trouver-une-fresque-scraper
- Assessment: unconfirmed; do not use or test any credentials.

### 982. P3_LOW_SIGNAL — otland/mapeditor

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/otland/mapeditor/blob/2410cf216b6ba455200f473f029fe8398a5b0c12/config.json.dist
- Repository URL: https://github.com/otland/mapeditor
- Assessment: unconfirmed; do not use or test any credentials.

### 983. P3_LOW_SIGNAL — piojanu/World-Models

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/piojanu/World-Models/blob/6af5acc61002c273dac1dfd40b2149ce2a8bf13d/config.json.dist
- Repository URL: https://github.com/piojanu/World-Models
- Assessment: unconfirmed; do not use or test any credentials.

### 984. P3_LOW_SIGNAL — pushchain/push-notifications-dapp

- Path: `jsconfig.json.old`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/pushchain/push-notifications-dapp/blob/96dd5db0e814dd942125d1c1604b3d6c651744dd/jsconfig.json.old
- Repository URL: https://github.com/pushchain/push-notifications-dapp
- Assessment: unconfirmed; do not use or test any credentials.

### 985. P3_LOW_SIGNAL — rakshixh/FakeAuthentication-API

- Path: `.env .txt`
- Indicator: `credentials_file`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/rakshixh/FakeAuthentication-API/blob/694e2e82eca88f301fa3cd2874d38434591accbe/.env .txt
- Repository URL: https://github.com/rakshixh/FakeAuthentication-API
- Assessment: unconfirmed; do not use or test any credentials.

### 986. P3_LOW_SIGNAL — ringcaptcha/widget

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/ringcaptcha/widget/blob/2dfe45ea9e2c274706e9d679c122fb3a7ada69fc/config.json.dist
- Repository URL: https://github.com/ringcaptcha/widget
- Assessment: unconfirmed; do not use or test any credentials.

### 987. P3_LOW_SIGNAL — sadoneli/merlin380-qiandao

- Path: `config.json.js`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/sadoneli/merlin380-qiandao/blob/176871209f3b41804041123194c865568dc9af48/config.json.js
- Repository URL: https://github.com/sadoneli/merlin380-qiandao
- Assessment: unconfirmed; do not use or test any credentials.

### 988. P3_LOW_SIGNAL — sandroneterpone/ye-meme-trader

- Path: `.env2.txt`
- Indicator: `credentials_file`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/sandroneterpone/ye-meme-trader/blob/0cf98ffad988794862d01b9c26419b09c5e3f09e/.env2.txt
- Repository URL: https://github.com/sandroneterpone/ye-meme-trader
- Assessment: unconfirmed; do not use or test any credentials.

### 989. P3_LOW_SIGNAL — scumdestroy/warlusts

- Path: `secrets.md`
- Indicator: `github_oauth_prefix;github_refresh_prefix`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/scumdestroy/warlusts/blob/06f6e94fb0006e1af3f5b6901d856725cfbaed5d/secrets.md
- Repository URL: https://github.com/scumdestroy/warlusts
- Assessment: unconfirmed; do not use or test any credentials.

### 990. P3_LOW_SIGNAL — snowdd1/homebridge-knx

- Path: `knx_config.json.md`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/snowdd1/homebridge-knx/blob/e0371999582c98fcd966b2a7792c70732c7dea3c/knx_config.json.md
- Repository URL: https://github.com/snowdd1/homebridge-knx
- Assessment: unconfirmed; do not use or test any credentials.

### 991. P3_LOW_SIGNAL — survivorzik/chatbot-langchain-flask

- Path: `.envsample.txt`
- Indicator: `credentials_file`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/survivorzik/chatbot-langchain-flask/blob/7d650721e6219c41efffb7ff856fd4cdf41a4af9/.envsample.txt
- Repository URL: https://github.com/survivorzik/chatbot-langchain-flask
- Assessment: unconfirmed; do not use or test any credentials.

### 992. P3_LOW_SIGNAL — tchapi/mlmmj-simple-web-interface

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/tchapi/mlmmj-simple-web-interface/blob/c9abfaa4b1859b1860fa7a3e01224dc53e55edb7/config.json.dist
- Repository URL: https://github.com/tchapi/mlmmj-simple-web-interface
- Assessment: unconfirmed; do not use or test any credentials.

### 993. P3_LOW_SIGNAL — terrestris/masterportal-addons

- Path: `exporter/doc/config.json.md`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/terrestris/masterportal-addons/blob/a39f340335f0aaaf995859d73384b2f534c2e64f/exporter/doc/config.json.md
- Repository URL: https://github.com/terrestris/masterportal-addons
- Assessment: unconfirmed; do not use or test any credentials.

### 994. P3_LOW_SIGNAL — textlint/textlint-plugin-latex2e

- Path: `tsconfig.json`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/textlint/textlint-plugin-latex2e/blob/5c5e376b5760751c3cebb13ab828375eac84632a/tsconfig.json
- Repository URL: https://github.com/textlint/textlint-plugin-latex2e
- Assessment: unconfirmed; do not use or test any credentials.

### 995. P3_LOW_SIGNAL — timvideos/streaming-system

- Path: `config.json`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/timvideos/streaming-system/blob/af5b8e81bddbec5d09eb2e674faa3a9e6030c049/config.json
- Repository URL: https://github.com/timvideos/streaming-system
- Assessment: unconfirmed; do not use or test any credentials.

### 996. P3_LOW_SIGNAL — tobinbradley/pg-vector-tile-server

- Path: `config.json.txt`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/tobinbradley/pg-vector-tile-server/blob/0e271f544b286532a63b3f5b4cd478460aa4dc8b/config.json.txt
- Repository URL: https://github.com/tobinbradley/pg-vector-tile-server
- Assessment: unconfirmed; do not use or test any credentials.

### 997. P3_LOW_SIGNAL — tp4a/teleport

- Path: `config.json.in`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/tp4a/teleport/blob/49d79ce8c6b4efb3c1547e4f4bed6dff4d83bc51/config.json.in
- Repository URL: https://github.com/tp4a/teleport
- Assessment: unconfirmed; do not use or test any credentials.

### 998. P3_LOW_SIGNAL — twansolo/kraven

- Path: `setup-token.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/twansolo/kraven/blob/2d1c407963865a9ab6c7352c418e1d008ee7c555/setup-token.md
- Repository URL: https://github.com/twansolo/kraven
- Assessment: unconfirmed; do not use or test any credentials.

### 999. P3_LOW_SIGNAL — typescript-kr/typescript-kr.github.io

- Path: `pages/tsconfig.json.md`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/typescript-kr/typescript-kr.github.io/blob/3fad5f8dab80e88a9190aae8c3256ce0b9bc7869/pages/tsconfig.json.md
- Repository URL: https://github.com/typescript-kr/typescript-kr.github.io
- Assessment: unconfirmed; do not use or test any credentials.

### 1000. P3_LOW_SIGNAL — usubalang/usuba

- Path: `config.json.help`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/usubalang/usuba/blob/4553c25c3d8abd8bcbb2edf75740a3c6d0ca1222/config.json.help
- Repository URL: https://github.com/usubalang/usuba
- Assessment: unconfirmed; do not use or test any credentials.

### 1001. P3_LOW_SIGNAL — vj23456/LookCat

- Path: `config.json.js`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/vj23456/LookCat/blob/7a10e88825214d4b53211278ca2d6338b27ed4e0/config.json.js
- Repository URL: https://github.com/vj23456/LookCat
- Assessment: unconfirmed; do not use or test any credentials.

### 1002. P3_LOW_SIGNAL — vj23456/MerlinLucky

- Path: `config.json.js`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/vj23456/MerlinLucky/blob/7ba928b7b45daa442578d5562cdcbc54ca7837ae/config.json.js
- Repository URL: https://github.com/vj23456/MerlinLucky
- Assessment: unconfirmed; do not use or test any credentials.

### 1003. P3_LOW_SIGNAL — w3c/cg-monitor

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/w3c/cg-monitor/blob/6c195fdd9824dc389d7313e6077d128addee9205/config.json.dist
- Repository URL: https://github.com/w3c/cg-monitor
- Assessment: unconfirmed; do not use or test any credentials.

### 1004. P3_LOW_SIGNAL — w3c/spec-dashboard

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/w3c/spec-dashboard/blob/f6bdc53a8de893945797d333017ca22761c68f10/config.json.dist
- Repository URL: https://github.com/w3c/spec-dashboard
- Assessment: unconfirmed; do not use or test any credentials.

### 1005. P3_LOW_SIGNAL — w3c/strudy

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/w3c/strudy/blob/18e1b101d1bfd60bb55a2edecaad235c609e1857/config.json.dist
- Repository URL: https://github.com/w3c/strudy
- Assessment: unconfirmed; do not use or test any credentials.

### 1006. P3_LOW_SIGNAL — wangdoc/typescript-tutorial

- Path: `docs/tsconfig.json.md`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/wangdoc/typescript-tutorial/blob/af3943a18219875aaef9af6b10ca756f2ab09841/docs/tsconfig.json.md
- Repository URL: https://github.com/wangdoc/typescript-tutorial
- Assessment: unconfirmed; do not use or test any credentials.

### 1007. P3_LOW_SIGNAL — weiwei2012holy/short_url

- Path: `config.json.tmp`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/weiwei2012holy/short_url/blob/ec9bffc90fb39199239c8068c5b4d9706de553f5/config.json.tmp
- Repository URL: https://github.com/weiwei2012holy/short_url
- Assessment: unconfirmed; do not use or test any credentials.

### 1008. P3_LOW_SIGNAL — wirenboard/wb-mqtt-gpio

- Path: `config.json.wb60`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/wirenboard/wb-mqtt-gpio/blob/7a00adb9ccbaad39a13dcb3ae7be3f2c18e607fa/config.json.wb60
- Repository URL: https://github.com/wirenboard/wb-mqtt-gpio
- Assessment: unconfirmed; do not use or test any credentials.

### 1009. P3_LOW_SIGNAL — wirenboard/wb-mqtt-gpio

- Path: `config.json.wb61`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/wirenboard/wb-mqtt-gpio/blob/7a00adb9ccbaad39a13dcb3ae7be3f2c18e607fa/config.json.wb61
- Repository URL: https://github.com/wirenboard/wb-mqtt-gpio
- Assessment: unconfirmed; do not use or test any credentials.

### 1010. P3_LOW_SIGNAL — xn030523/arcee

- Path: `config.json.ex`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/xn030523/arcee/blob/fbc2eba067628d913f5a8999f0815fd108c6a3d2/config.json.ex
- Repository URL: https://github.com/xn030523/arcee
- Assessment: unconfirmed; do not use or test any credentials.

### 1011. P3_LOW_SIGNAL — yannh/openbsd_immutable_router

- Path: `config.json.dist`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/yannh/openbsd_immutable_router/blob/2c2cfc26b4efe6c419cbc5f991ceecee29edf630/config.json.dist
- Repository URL: https://github.com/yannh/openbsd_immutable_router
- Assessment: unconfirmed; do not use or test any credentials.

### 1012. P3_LOW_SIGNAL — yaxitech/nix-install-pkgs-action

- Path: `tsconfig.json`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/yaxitech/nix-install-pkgs-action/blob/4a16f394a349f8936635b60259b1705cdec89cb5/tsconfig.json
- Repository URL: https://github.com/yaxitech/nix-install-pkgs-action
- Assessment: unconfirmed; do not use or test any credentials.

### 1013. P3_LOW_SIGNAL — you21979/node-zaif

- Path: `example/config.json.org`
- Indicator: `docker_config`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/you21979/node-zaif/blob/2ea036615f58a9f0f84bf9f02b7cfb3c0407229d/example/config.json.org
- Repository URL: https://github.com/you21979/node-zaif
- Assessment: unconfirmed; do not use or test any credentials.

### 1014. P3_LOW_SIGNAL — zebbern/secfiles

- Path: `regex/secrets.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 1 (not severity)
- File URL: https://github.com/zebbern/secfiles/blob/b9822bd929dfe9313596ed3314cab17c4c064101/regex/secrets.md
- Repository URL: https://github.com/zebbern/secfiles
- Assessment: unconfirmed; do not use or test any credentials.

### 1015. P3_LOW_SIGNAL — 01esya/module

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/01esya/module/blob/ca74feab6818d69caf094671a77a218497de21b9/API.md
- Repository URL: https://github.com/01esya/module
- Assessment: unconfirmed; do not use or test any credentials.

### 1016. P3_LOW_SIGNAL — 0dillon/Glassbox

- Path: `JOIN.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/0dillon/Glassbox/blob/05a52394682ab7b2714c54d7b285242a206670f1/JOIN.md
- Repository URL: https://github.com/0dillon/Glassbox
- Assessment: unconfirmed; do not use or test any credentials.

### 1017. P3_LOW_SIGNAL — 0gfoundation/0g-storage-client

- Path: `cli.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/0gfoundation/0g-storage-client/blob/bb5675461a96b654d3015c5522666ee8101cf810/cli.md
- Repository URL: https://github.com/0gfoundation/0g-storage-client
- Assessment: unconfirmed; do not use or test any credentials.

### 1018. P3_LOW_SIGNAL — 0gfoundation/0g-storage-client

- Path: `sdk.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/0gfoundation/0g-storage-client/blob/bb5675461a96b654d3015c5522666ee8101cf810/sdk.md
- Repository URL: https://github.com/0gfoundation/0g-storage-client
- Assessment: unconfirmed; do not use or test any credentials.

### 1019. P3_LOW_SIGNAL — 0xArx/claude-managed-agents-skill

- Path: `SKILL.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/0xArx/claude-managed-agents-skill/blob/be102cd3457f39d9333403669620e2d41130a28e/SKILL.md
- Repository URL: https://github.com/0xArx/claude-managed-agents-skill
- Assessment: unconfirmed; do not use or test any credentials.

### 1020. P3_LOW_SIGNAL — 0xAwali/WebSocketChecker

- Path: `README.md`
- Indicator: `github_oauth_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/0xAwali/WebSocketChecker/blob/310a7b1a02a69a0a6bb7bf0fb6f5f77f5cdc5d1a/README.md
- Repository URL: https://github.com/0xAwali/WebSocketChecker
- Assessment: unconfirmed; do not use or test any credentials.

### 1021. P3_LOW_SIGNAL — 0xCryptoZen/x-sdks

- Path: `X.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/0xCryptoZen/x-sdks/blob/fa3a15f1b44fe9da827d633b014db5d79b04b572/X.md
- Repository URL: https://github.com/0xCryptoZen/x-sdks
- Assessment: unconfirmed; do not use or test any credentials.

### 1022. P3_LOW_SIGNAL — 0xEAB/blacksea

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/0xEAB/blacksea/blob/e94184977e4ff86247201f90b96e01d04ec6ab71/README.md
- Repository URL: https://github.com/0xEAB/blacksea
- Assessment: unconfirmed; do not use or test any credentials.

### 1023. P3_LOW_SIGNAL — 0xHoneyJar/loa-finn

- Path: `SECURITY.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/0xHoneyJar/loa-finn/blob/71d5a2b23734bb64cef29ce62e473b36231dc34f/SECURITY.md
- Repository URL: https://github.com/0xHoneyJar/loa-finn
- Assessment: unconfirmed; do not use or test any credentials.

### 1024. P3_LOW_SIGNAL — 0xchsh/portfolio

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/0xchsh/portfolio/blob/ea87d8e0cf3b45360f588b612f84f71ab51f0deb/README.md
- Repository URL: https://github.com/0xchsh/portfolio
- Assessment: unconfirmed; do not use or test any credentials.

### 1025. P3_LOW_SIGNAL — 0xfrq/trackit

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/0xfrq/trackit/blob/ef064596ddecd4bf5c6e506d32d5fb59cdcbb46f/README.md
- Repository URL: https://github.com/0xfrq/trackit
- Assessment: unconfirmed; do not use or test any credentials.

### 1026. P3_LOW_SIGNAL — 0xlipon/payloads

- Path: `pem.txt`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/0xlipon/payloads/blob/9f740b320481ef18b663eb56206e700e9b2bc8a4/pem.txt
- Repository URL: https://github.com/0xlipon/payloads
- Assessment: unconfirmed; do not use or test any credentials.

### 1027. P3_LOW_SIGNAL — 0xmhha/claude-knowledge-vault

- Path: `PLAN.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/0xmhha/claude-knowledge-vault/blob/da1d960233dca50a9e05a17637764034d9943dc8/PLAN.md
- Repository URL: https://github.com/0xmhha/claude-knowledge-vault
- Assessment: unconfirmed; do not use or test any credentials.

### 1028. P3_LOW_SIGNAL — 0xmoei/sonic-tx

- Path: `env.txt`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/0xmoei/sonic-tx/blob/f3de1d80756dafacfeaf7014d54d8166742cb420/env.txt
- Repository URL: https://github.com/0xmoei/sonic-tx
- Assessment: unconfirmed; do not use or test any credentials.

### 1029. P3_LOW_SIGNAL — 0xtanmayx0/Key-Scraper

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/0xtanmayx0/Key-Scraper/blob/e5998b945913d647830eb522fdc4f31a1a19401e/README.md
- Repository URL: https://github.com/0xtanmayx0/Key-Scraper
- Assessment: unconfirmed; do not use or test any credentials.

### 1030. P3_LOW_SIGNAL — 1979139113/0day-today-exploits

- Path: `30.txt`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/1979139113/0day-today-exploits/blob/8b2194688e3c722fe9369b045e37382e7f45e12b/30.txt
- Repository URL: https://github.com/1979139113/0day-today-exploits
- Assessment: unconfirmed; do not use or test any credentials.

### 1031. P3_LOW_SIGNAL — 1979139113/0day-today-exploits

- Path: `319.txt`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/1979139113/0day-today-exploits/blob/8b2194688e3c722fe9369b045e37382e7f45e12b/319.txt
- Repository URL: https://github.com/1979139113/0day-today-exploits
- Assessment: unconfirmed; do not use or test any credentials.

### 1032. P3_LOW_SIGNAL — 1979139113/0day-today-exploits

- Path: `321.txt`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/1979139113/0day-today-exploits/blob/8b2194688e3c722fe9369b045e37382e7f45e12b/321.txt
- Repository URL: https://github.com/1979139113/0day-today-exploits
- Assessment: unconfirmed; do not use or test any credentials.

### 1033. P3_LOW_SIGNAL — 1979139113/0day-today-exploits

- Path: `381.txt`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/1979139113/0day-today-exploits/blob/8b2194688e3c722fe9369b045e37382e7f45e12b/381.txt
- Repository URL: https://github.com/1979139113/0day-today-exploits
- Assessment: unconfirmed; do not use or test any credentials.

### 1034. P3_LOW_SIGNAL — 1979139113/0day-today-exploits

- Path: `60.txt`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/1979139113/0day-today-exploits/blob/8b2194688e3c722fe9369b045e37382e7f45e12b/60.txt
- Repository URL: https://github.com/1979139113/0day-today-exploits
- Assessment: unconfirmed; do not use or test any credentials.

### 1035. P3_LOW_SIGNAL — 1979139113/0day-today-exploits

- Path: `852.txt`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/1979139113/0day-today-exploits/blob/8b2194688e3c722fe9369b045e37382e7f45e12b/852.txt
- Repository URL: https://github.com/1979139113/0day-today-exploits
- Assessment: unconfirmed; do not use or test any credentials.

### 1036. P3_LOW_SIGNAL — 1979139113/0day-today-exploits

- Path: `95.txt`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/1979139113/0day-today-exploits/blob/8b2194688e3c722fe9369b045e37382e7f45e12b/95.txt
- Repository URL: https://github.com/1979139113/0day-today-exploits
- Assessment: unconfirmed; do not use or test any credentials.

### 1037. P3_LOW_SIGNAL — 1a57danc3/gfvvlist

- Path: `pac.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/1a57danc3/gfvvlist/blob/a9df5889786c4eb129d963e5f8289be601d67c67/pac.txt
- Repository URL: https://github.com/1a57danc3/gfvvlist
- Assessment: unconfirmed; do not use or test any credentials.

### 1038. P3_LOW_SIGNAL — 23/DeveloperDocumentation

- Path: `oauth.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/23/DeveloperDocumentation/blob/2991a1af6e272512d199851dbca6f8516e8f6ff8/oauth.md
- Repository URL: https://github.com/23/DeveloperDocumentation
- Assessment: unconfirmed; do not use or test any credentials.

### 1039. P3_LOW_SIGNAL — 3kpro/paralegal-agent-crew

- Path: `info.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/3kpro/paralegal-agent-crew/blob/9e0c9755acfb20924a60f2a6bcade1550177556a/info.md
- Repository URL: https://github.com/3kpro/paralegal-agent-crew
- Assessment: unconfirmed; do not use or test any credentials.

### 1040. P3_LOW_SIGNAL — 3liz/lizmap-documentation

- Path: `DEV.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/3liz/lizmap-documentation/blob/e17a2dabd8916eb73b34b39a5d834547f7685db7/DEV.md
- Repository URL: https://github.com/3liz/lizmap-documentation
- Assessment: unconfirmed; do not use or test any credentials.

### 1041. P3_LOW_SIGNAL — 99designs/aws-vault

- Path: `USAGE.md`
- Indicator: `aws_access_key;aws_secret_key_label;secret_access_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/99designs/aws-vault/blob/74e2f7ac256f4da1efbc8a48a4c0c364e454acd4/USAGE.md
- Repository URL: https://github.com/99designs/aws-vault
- Assessment: unconfirmed; do not use or test any credentials.

### 1042. P3_LOW_SIGNAL — A2B78/gitbrowser

- Path: `API.md`
- Indicator: `bearer_auth_label;github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/A2B78/gitbrowser/blob/7491b59997965f7a43a3ff61541d0ad3d6f6d151/API.md
- Repository URL: https://github.com/A2B78/gitbrowser
- Assessment: unconfirmed; do not use or test any credentials.

### 1043. P3_LOW_SIGNAL — ABHISHEK-DBZ/friendly-fishstick

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ABHISHEK-DBZ/friendly-fishstick/blob/3885b5d718ed02c570f172cd57dad9eb856ca839/SETUP.md
- Repository URL: https://github.com/ABHISHEK-DBZ/friendly-fishstick
- Assessment: unconfirmed; do not use or test any credentials.

### 1044. P3_LOW_SIGNAL — ACHolding/Claude45.22.25Jailbreka-

- Path: `0.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ACHolding/Claude45.22.25Jailbreka-/blob/59fa33943fcfc0e69ee93d03814d22dfac0df5ce/0.md
- Repository URL: https://github.com/ACHolding/Claude45.22.25Jailbreka-
- Assessment: unconfirmed; do not use or test any credentials.

### 1045. P3_LOW_SIGNAL — ACHolding/HALTMANNINFDEV1.0.719.25GROK4PROMPT

- Path: `1.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ACHolding/HALTMANNINFDEV1.0.719.25GROK4PROMPT/blob/62cf14c9145f1bf30b2f5e7de44249a752cd9df2/1.md
- Repository URL: https://github.com/ACHolding/HALTMANNINFDEV1.0.719.25GROK4PROMPT
- Assessment: unconfirmed; do not use or test any credentials.

### 1046. P3_LOW_SIGNAL — ALEXSANDER2002/restaurant

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ALEXSANDER2002/restaurant/blob/1c16f4f7d91031bc88470edadb9574b392712810/API.md
- Repository URL: https://github.com/ALEXSANDER2002/restaurant
- Assessment: unconfirmed; do not use or test any credentials.

### 1047. P3_LOW_SIGNAL — ATOM00blue/envlint

- Path: `PLAN.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ATOM00blue/envlint/blob/e25efa85a22de6f23805d3170e7b1f9957d7d0cf/PLAN.md
- Repository URL: https://github.com/ATOM00blue/envlint
- Assessment: unconfirmed; do not use or test any credentials.

### 1048. P3_LOW_SIGNAL — ATOMGAMERAGA/atom-bilgi

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ATOMGAMERAGA/atom-bilgi/blob/411345fd4bfc36d7dd92190c8abc02946c30bf00/README.md
- Repository URL: https://github.com/ATOMGAMERAGA/atom-bilgi
- Assessment: unconfirmed; do not use or test any credentials.

### 1049. P3_LOW_SIGNAL — Aaks-hatH/clean-slop

- Path: `DOCS.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Aaks-hatH/clean-slop/blob/d2b47661cf183c2165cd1aebcffaeb9f1871a97c/DOCS.md
- Repository URL: https://github.com/Aaks-hatH/clean-slop
- Assessment: unconfirmed; do not use or test any credentials.

### 1050. P3_LOW_SIGNAL — AaronFriel/google-cloud-sql-instance-412-bug

- Path: `create/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/AaronFriel/google-cloud-sql-instance-412-bug/blob/c5df5acdea69a0845e011b09e90523352343f3d7/create/.terraform.tfstate.lock.info
- Repository URL: https://github.com/AaronFriel/google-cloud-sql-instance-412-bug
- Assessment: unconfirmed; do not use or test any credentials.

### 1051. P3_LOW_SIGNAL — Aayush-Joshi-01/Cognity-AI

- Path: `API.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Aayush-Joshi-01/Cognity-AI/blob/8e623e2e151de9a8bc42f1f625f2c88fdc2513c4/API.md
- Repository URL: https://github.com/Aayush-Joshi-01/Cognity-AI
- Assessment: unconfirmed; do not use or test any credentials.

### 1052. P3_LOW_SIGNAL — Abaidullah889/chatapp

- Path: `terraform/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Abaidullah889/chatapp/blob/fced7e5017856cb7ca85759c87353974945338cc/terraform/.terraform.tfstate.lock.info
- Repository URL: https://github.com/Abaidullah889/chatapp
- Assessment: unconfirmed; do not use or test any credentials.

### 1053. P3_LOW_SIGNAL — AbdullahYaqoob07/NexAgent

- Path: `todo.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/AbdullahYaqoob07/NexAgent/blob/385a20ed5e727e347c4cdeb7e479107be19b03a9/todo.md
- Repository URL: https://github.com/AbdullahYaqoob07/NexAgent
- Assessment: unconfirmed; do not use or test any credentials.

### 1054. P3_LOW_SIGNAL — AdrianTIonut/airseekers-tron-ha

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/AdrianTIonut/airseekers-tron-ha/blob/b5b4e2f8355af246c280a5c93072a5945730bc6a/API.md
- Repository URL: https://github.com/AdrianTIonut/airseekers-tron-ha
- Assessment: unconfirmed; do not use or test any credentials.

### 1055. P3_LOW_SIGNAL — AgentPhone-AI/skills

- Path: `SKILL.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/AgentPhone-AI/skills/blob/f3efa13866e890692b0154e8b7009a413085bb21/SKILL.md
- Repository URL: https://github.com/AgentPhone-AI/skills
- Assessment: unconfirmed; do not use or test any credentials.

### 1056. P3_LOW_SIGNAL — AgenticAdvertising/adside-mcp

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/AgenticAdvertising/adside-mcp/blob/2e337dbb239157315ea602f096fe02e310ecc6f2/README.md
- Repository URL: https://github.com/AgenticAdvertising/adside-mcp
- Assessment: unconfirmed; do not use or test any credentials.

### 1057. P3_LOW_SIGNAL — Agustrihanton/teach-tube

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Agustrihanton/teach-tube/blob/9c8ccc792bdc547e68efce7e5995b78d2a117a90/API.md
- Repository URL: https://github.com/Agustrihanton/teach-tube
- Assessment: unconfirmed; do not use or test any credentials.

### 1058. P3_LOW_SIGNAL — AhaSend/ahasend-go

- Path: `ENV.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/AhaSend/ahasend-go/blob/2e6daa1f45b784a4da4f25c52f669f037e0fce7f/ENV.md
- Repository URL: https://github.com/AhaSend/ahasend-go
- Assessment: unconfirmed; do not use or test any credentials.

### 1059. P3_LOW_SIGNAL — Aitherium/awdk

- Path: `llms.txt`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Aitherium/awdk/blob/7e922bad20afba32c45fca9b299bd2e9bf7172b3/llms.txt
- Repository URL: https://github.com/Aitherium/awdk
- Assessment: unconfirmed; do not use or test any credentials.

### 1060. P3_LOW_SIGNAL — Albert-Weasker/niubi_guard

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Albert-Weasker/niubi_guard/blob/e8a85931a0c23b04d2ef33d642fb8f549660ae63/README.md
- Repository URL: https://github.com/Albert-Weasker/niubi_guard
- Assessment: unconfirmed; do not use or test any credentials.

### 1061. P3_LOW_SIGNAL — AleksandrZhukov/slack-stickers

- Path: `DEPLOY.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/AleksandrZhukov/slack-stickers/blob/f6f84231b055b34ae3a49ccf7f21e4ebef9c164a/DEPLOY.md
- Repository URL: https://github.com/AleksandrZhukov/slack-stickers
- Assessment: unconfirmed; do not use or test any credentials.

### 1062. P3_LOW_SIGNAL — Aletech-Solutions/Open-Atlas-Node

- Path: `API.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Aletech-Solutions/Open-Atlas-Node/blob/49e9203f07198c4a867df2f4aedbe735d3365e49/API.md
- Repository URL: https://github.com/Aletech-Solutions/Open-Atlas-Node
- Assessment: unconfirmed; do not use or test any credentials.

### 1063. P3_LOW_SIGNAL — AlexChesser/ail

- Path: `API.md`
- Indicator: `api_key_label;bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/AlexChesser/ail/blob/29e5bd252d1ff10569b7d0e8a72154a28dec773a/API.md
- Repository URL: https://github.com/AlexChesser/ail
- Assessment: unconfirmed; do not use or test any credentials.

### 1064. P3_LOW_SIGNAL — Alexbeav/devops-phonebook-demo

- Path: `TODO.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Alexbeav/devops-phonebook-demo/blob/772e3301d97221718f53f2df05cf87706289d0f8/TODO.md
- Repository URL: https://github.com/Alexbeav/devops-phonebook-demo
- Assessment: unconfirmed; do not use or test any credentials.

### 1065. P3_LOW_SIGNAL — AllahuRodrigues/naia-design

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/AllahuRodrigues/naia-design/blob/bdce41cd11a6efe7bce6e66443f5ea3f92355d64/README.md
- Repository URL: https://github.com/AllahuRodrigues/naia-design
- Assessment: unconfirmed; do not use or test any credentials.

### 1066. P3_LOW_SIGNAL — Allow2/Allow2WP

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Allow2/Allow2WP/blob/4844f95f7440e618ca7b06a678fc0f5e7552096b/API.md
- Repository URL: https://github.com/Allow2/Allow2WP
- Assessment: unconfirmed; do not use or test any credentials.

### 1067. P3_LOW_SIGNAL — Amaankaa/AlgoMentor

- Path: `DEPLOY.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Amaankaa/AlgoMentor/blob/ecefe8f22dbc0a4a9bdf71a6d27b3ed235bcb48e/DEPLOY.md
- Repository URL: https://github.com/Amaankaa/AlgoMentor
- Assessment: unconfirmed; do not use or test any credentials.

### 1068. P3_LOW_SIGNAL — Amman30/rag_hallucination

- Path: `RUN.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Amman30/rag_hallucination/blob/be6138a6e700ae208721af385f0fb08eaa933dc5/RUN.md
- Repository URL: https://github.com/Amman30/rag_hallucination
- Assessment: unconfirmed; do not use or test any credentials.

### 1069. P3_LOW_SIGNAL — Amrisingh/ClientProof

- Path: `CLERK.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Amrisingh/ClientProof/blob/ca02b7bb3e588185cc5a752d0aa4c86afe848dcf/CLERK.md
- Repository URL: https://github.com/Amrisingh/ClientProof
- Assessment: unconfirmed; do not use or test any credentials.

### 1070. P3_LOW_SIGNAL — AndersDJohnson/use-yarn

- Path: `index.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/AndersDJohnson/use-yarn/blob/afc194946e480d65510c722a1f94079cc1b21e28/index.md
- Repository URL: https://github.com/AndersDJohnson/use-yarn
- Assessment: unconfirmed; do not use or test any credentials.

### 1071. P3_LOW_SIGNAL — AndreaGriffiths11/machine-mcp

- Path: `AGENTS.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/AndreaGriffiths11/machine-mcp/blob/ca0778ff546793b6f355bfd89e437e97b3a6b862/AGENTS.md
- Repository URL: https://github.com/AndreaGriffiths11/machine-mcp
- Assessment: unconfirmed; do not use or test any credentials.

### 1072. P3_LOW_SIGNAL — Andy-Aranda/pr-reviewer

- Path: `README.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Andy-Aranda/pr-reviewer/blob/b7abae0eed08848ca4e102f08b1daef930cb802b/README.md
- Repository URL: https://github.com/Andy-Aranda/pr-reviewer
- Assessment: unconfirmed; do not use or test any credentials.

### 1073. P3_LOW_SIGNAL — Andy-K-Sparklight/PluginDiary

- Path: `2-1.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Andy-K-Sparklight/PluginDiary/blob/554c33c477e24974f77cf4cfa44d9bdaf5eb62a0/2-1.md
- Repository URL: https://github.com/Andy-K-Sparklight/PluginDiary
- Assessment: unconfirmed; do not use or test any credentials.

### 1074. P3_LOW_SIGNAL — Andy-K-Sparklight/PluginDiary

- Path: `4-3.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Andy-K-Sparklight/PluginDiary/blob/554c33c477e24974f77cf4cfa44d9bdaf5eb62a0/4-3.md
- Repository URL: https://github.com/Andy-K-Sparklight/PluginDiary
- Assessment: unconfirmed; do not use or test any credentials.

### 1075. P3_LOW_SIGNAL — Ankumeah/SourceFlameBackend

- Path: `doc.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Ankumeah/SourceFlameBackend/blob/f3e235bf8b4d1cf70c395b89bb8717dd189e9f1e/doc.md
- Repository URL: https://github.com/Ankumeah/SourceFlameBackend
- Assessment: unconfirmed; do not use or test any credentials.

### 1076. P3_LOW_SIGNAL — Ankushryuga/Github-MCP-PR-Reviewer

- Path: `FAQ.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Ankushryuga/Github-MCP-PR-Reviewer/blob/699b7c2f6dc81cfb9333ed2d7a48a566704575e6/FAQ.md
- Repository URL: https://github.com/Ankushryuga/Github-MCP-PR-Reviewer
- Assessment: unconfirmed; do not use or test any credentials.

### 1077. P3_LOW_SIGNAL — Ansygroup/ebook-store

- Path: `SETUP.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Ansygroup/ebook-store/blob/c99deaaab4f2f52cd3c8c17e1c95db50870d3eb7/SETUP.md
- Repository URL: https://github.com/Ansygroup/ebook-store
- Assessment: unconfirmed; do not use or test any credentials.

### 1078. P3_LOW_SIGNAL — AnupBhat30/github-leaked-keys-scanner

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/AnupBhat30/github-leaked-keys-scanner/blob/c92d8e7efcc62c0331d2e31e71f1b5797ff0f240/README.md
- Repository URL: https://github.com/AnupBhat30/github-leaked-keys-scanner
- Assessment: unconfirmed; do not use or test any credentials.

### 1079. P3_LOW_SIGNAL — ArchiveBox/abx-dl

- Path: `TODOs.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ArchiveBox/abx-dl/blob/d9d1fba72109e2abab67595c831243789d4f0a48/TODOs.md
- Repository URL: https://github.com/ArchiveBox/abx-dl
- Assessment: unconfirmed; do not use or test any credentials.

### 1080. P3_LOW_SIGNAL — Arseno25/actionlens

- Path: `docs/SECURITY.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Arseno25/actionlens/blob/f5a45ff68e554fcfbbfba7cfa7742a3159ed6e36/docs/SECURITY.md
- Repository URL: https://github.com/Arseno25/actionlens
- Assessment: unconfirmed; do not use or test any credentials.

### 1081. P3_LOW_SIGNAL — ArthurDS-tech/Emotify-Spotify

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ArthurDS-tech/Emotify-Spotify/blob/8924e3d3e586e7f0f3fbc8dfaff51e9237a6da71/API.md
- Repository URL: https://github.com/ArthurDS-tech/Emotify-Spotify
- Assessment: unconfirmed; do not use or test any credentials.

### 1082. P3_LOW_SIGNAL — Aryan-20-04/ElixAI

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Aryan-20-04/ElixAI/blob/65f3a0243cf15060d001c8038355a76a9253b455/README.md
- Repository URL: https://github.com/Aryan-20-04/ElixAI
- Assessment: unconfirmed; do not use or test any credentials.

### 1083. P3_LOW_SIGNAL — Aryan-Rishi/alcatraz

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Aryan-Rishi/alcatraz/blob/8f38c1c518eb7651a37ee6aec55f5da0aeb7cd69/README.md
- Repository URL: https://github.com/Aryan-Rishi/alcatraz
- Assessment: unconfirmed; do not use or test any credentials.

### 1084. P3_LOW_SIGNAL — Askenter/claude-journal-tools

- Path: `CHANGELOG.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Askenter/claude-journal-tools/blob/c73385dd2e50754a1e2da9e0ada0ecc0f5b13231/CHANGELOG.md
- Repository URL: https://github.com/Askenter/claude-journal-tools
- Assessment: unconfirmed; do not use or test any credentials.

### 1085. P3_LOW_SIGNAL — Askenter/claude-journal-tools

- Path: `SECURITY.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Askenter/claude-journal-tools/blob/c73385dd2e50754a1e2da9e0ada0ecc0f5b13231/SECURITY.md
- Repository URL: https://github.com/Askenter/claude-journal-tools
- Assessment: unconfirmed; do not use or test any credentials.

### 1086. P3_LOW_SIGNAL — Astoriel/GrowthOS

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Astoriel/GrowthOS/blob/d17702b0661b77073da9a80d6de28f7a7d21a5ba/README.md
- Repository URL: https://github.com/Astoriel/GrowthOS
- Assessment: unconfirmed; do not use or test any credentials.

### 1087. P3_LOW_SIGNAL — Atoast/nobodyprox

- Path: `spec.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Atoast/nobodyprox/blob/3b27d31ea9bfac15cab722aa3df2b0e6aacc6ad2/spec.md
- Repository URL: https://github.com/Atoast/nobodyprox
- Assessment: unconfirmed; do not use or test any credentials.

### 1088. P3_LOW_SIGNAL — AuthenTrend/piv-cli-tool

- Path: `NEWS`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/AuthenTrend/piv-cli-tool/blob/478497c19bd10cce3a2c54e60c98b5772185a785/NEWS
- Repository URL: https://github.com/AuthenTrend/piv-cli-tool
- Assessment: unconfirmed; do not use or test any credentials.

### 1089. P3_LOW_SIGNAL — Avanderheyde/levelsio-vps-setup-skill

- Path: `SKILL.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Avanderheyde/levelsio-vps-setup-skill/blob/eb0a9c5904d0ec8cc2ac1bb89583c52a3e046f29/SKILL.md
- Repository URL: https://github.com/Avanderheyde/levelsio-vps-setup-skill
- Assessment: unconfirmed; do not use or test any credentials.

### 1090. P3_LOW_SIGNAL — Ayushmore1214/CloudCore

- Path: `terraform/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Ayushmore1214/CloudCore/blob/fbcb0988c7c15de001cc5bb252700b00fc031ed6/terraform/.terraform.tfstate.lock.info
- Repository URL: https://github.com/Ayushmore1214/CloudCore
- Assessment: unconfirmed; do not use or test any credentials.

### 1091. P3_LOW_SIGNAL — Azure/az-prototype

- Path: `MODELS.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Azure/az-prototype/blob/afb8821da0bb88cfa433dbe3e475b8e4910403ea/MODELS.md
- Repository URL: https://github.com/Azure/az-prototype
- Assessment: unconfirmed; do not use or test any credentials.

### 1092. P3_LOW_SIGNAL — BatiOli9/MalarIA

- Path: `.rest`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/BatiOli9/MalarIA/blob/35507aa447be1cc461d2b7e05dcd4cec9cc2c1e2/.rest
- Repository URL: https://github.com/BatiOli9/MalarIA
- Assessment: unconfirmed; do not use or test any credentials.

### 1093. P3_LOW_SIGNAL — Bhai4You/bhai4you

- Path: `.4.txt`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Bhai4You/bhai4you/blob/82a1c2ff1d70605aa66b7a6d2055a951fe53cd18/.4.txt
- Repository URL: https://github.com/Bhai4You/bhai4you
- Assessment: unconfirmed; do not use or test any credentials.

### 1094. P3_LOW_SIGNAL — Bhavishya-code/Pixro

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Bhavishya-code/Pixro/blob/77c5eb742fec0521cbbdbacff16be0c92d0e1089/README.md
- Repository URL: https://github.com/Bhavishya-code/Pixro
- Assessment: unconfirmed; do not use or test any credentials.

### 1095. P3_LOW_SIGNAL — BioDataScience-Course/BioDataScience

- Path: `NEWS.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/BioDataScience-Course/BioDataScience/blob/2d737d1d724ea3462d101a22249382cb259157e5/NEWS.md
- Repository URL: https://github.com/BioDataScience-Course/BioDataScience
- Assessment: unconfirmed; do not use or test any credentials.

### 1096. P3_LOW_SIGNAL — BjornMelin/codex-prompt-refinery

- Path: `PRD.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/BjornMelin/codex-prompt-refinery/blob/2b6f5bcaf4f5e48cd694c96f6adb68af903e60b0/PRD.md
- Repository URL: https://github.com/BjornMelin/codex-prompt-refinery
- Assessment: unconfirmed; do not use or test any credentials.

### 1097. P3_LOW_SIGNAL — Blockchair/Blockchair.Support

- Path: `API.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Blockchair/Blockchair.Support/blob/c11daec8c263cc10ea61143f010d0986e827d4d4/API.md
- Repository URL: https://github.com/Blockchair/Blockchair.Support
- Assessment: unconfirmed; do not use or test any credentials.

### 1098. P3_LOW_SIGNAL — Borni1507/WANSINN

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Borni1507/WANSINN/blob/3fbbb14c0ea03bd0a9154b0d5d7981b4a0c4ecfd/API.md
- Repository URL: https://github.com/Borni1507/WANSINN
- Assessment: unconfirmed; do not use or test any credentials.

### 1099. P3_LOW_SIGNAL — Brettm12345/go-slack-pokerbot

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Brettm12345/go-slack-pokerbot/blob/b482ab118cd0afed7ef6e71715f5cbfbed3bc666/README.md
- Repository URL: https://github.com/Brettm12345/go-slack-pokerbot
- Assessment: unconfirmed; do not use or test any credentials.

### 1100. P3_LOW_SIGNAL — C0A0A/Wiki-Woof

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/C0A0A/Wiki-Woof/blob/6f7a475a664753d7b4d0072d65d462c951e20636/README.md
- Repository URL: https://github.com/C0A0A/Wiki-Woof
- Assessment: unconfirmed; do not use or test any credentials.

### 1101. P3_LOW_SIGNAL — C0dwiz/Configurator

- Path: `API.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/C0dwiz/Configurator/blob/038b4327df293ff441f3886c3ea8469767285d7d/API.md
- Repository URL: https://github.com/C0dwiz/Configurator
- Assessment: unconfirmed; do not use or test any credentials.

### 1102. P3_LOW_SIGNAL — CWALabs/AspNetCore.Identity.CosmosDb

- Path: `log.txt`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/CWALabs/AspNetCore.Identity.CosmosDb/blob/bc12e79d473deffa8a1b083203ae03306ebc7bb4/log.txt
- Repository URL: https://github.com/CWALabs/AspNetCore.Identity.CosmosDb
- Assessment: unconfirmed; do not use or test any credentials.

### 1103. P3_LOW_SIGNAL — Cadarn/PyData-Prefect-Workshop

- Path: `notes.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Cadarn/PyData-Prefect-Workshop/blob/dd8374cbacc541f7db48356e9d020917db58ad3b/notes.md
- Repository URL: https://github.com/Cadarn/PyData-Prefect-Workshop
- Assessment: unconfirmed; do not use or test any credentials.

### 1104. P3_LOW_SIGNAL — CartoDB/carto-python

- Path: `NEWS`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/CartoDB/carto-python/blob/8122c5510f8f93fb30f1917187452b5469f8fb3c/NEWS
- Repository URL: https://github.com/CartoDB/carto-python
- Assessment: unconfirmed; do not use or test any credentials.

### 1105. P3_LOW_SIGNAL — CatChen/token-who-am-i-action

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/CatChen/token-who-am-i-action/blob/e1915b68f5754f1e3ef39a8c61a3f9797ad42b64/README.md
- Repository URL: https://github.com/CatChen/token-who-am-i-action
- Assessment: unconfirmed; do not use or test any credentials.

### 1106. P3_LOW_SIGNAL — CavinHuang/claude-code-switch

- Path: `PRD.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/CavinHuang/claude-code-switch/blob/ec452a38efd5915be949e53862f0dc53f3348fd7/PRD.md
- Repository URL: https://github.com/CavinHuang/claude-code-switch
- Assessment: unconfirmed; do not use or test any credentials.

### 1107. P3_LOW_SIGNAL — CharlesCNorton/omnia

- Path: `toadd.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/CharlesCNorton/omnia/blob/d7f7c5205c86b1d0c63046e310cb2afce45e7b89/toadd.md
- Repository URL: https://github.com/CharlesCNorton/omnia
- Assessment: unconfirmed; do not use or test any credentials.

### 1108. P3_LOW_SIGNAL — ChasManRors/yasnippets-for-rinari

- Path: `c..1`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ChasManRors/yasnippets-for-rinari/blob/88e411dec1b3daa06978d3af6b5385a8df794d09/c..1
- Repository URL: https://github.com/ChasManRors/yasnippets-for-rinari
- Assessment: unconfirmed; do not use or test any credentials.

### 1109. P3_LOW_SIGNAL — ChnMig/art-design-pro-edge

- Path: `api.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ChnMig/art-design-pro-edge/blob/ce3775b949448d0a9c76a07384bae6d6b06fc484/api.md
- Repository URL: https://github.com/ChnMig/art-design-pro-edge
- Assessment: unconfirmed; do not use or test any credentials.

### 1110. P3_LOW_SIGNAL — Cocabadger/saferun-guard

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Cocabadger/saferun-guard/blob/83fb04ba4ad819589f1301ab0302fe81043fc305/README.md
- Repository URL: https://github.com/Cocabadger/saferun-guard
- Assessment: unconfirmed; do not use or test any credentials.

### 1111. P3_LOW_SIGNAL — CodeChain-io/codechain-sdk-js

- Path: `API.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/CodeChain-io/codechain-sdk-js/blob/8a59083ecb8037fa76ea4ecdbd0c0c64dec49d0c/API.md
- Repository URL: https://github.com/CodeChain-io/codechain-sdk-js
- Assessment: unconfirmed; do not use or test any credentials.

### 1112. P3_LOW_SIGNAL — Codenuclei/video-image-search-indexer-quality

- Path: `PR.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Codenuclei/video-image-search-indexer-quality/blob/18f65207f0431d31ca3f561a04ccfb6d8df37c1a/PR.md
- Repository URL: https://github.com/Codenuclei/video-image-search-indexer-quality
- Assessment: unconfirmed; do not use or test any credentials.

### 1113. P3_LOW_SIGNAL — CodySwannGT/lisa

- Path: `PLAN.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/CodySwannGT/lisa/blob/08ee71200b5e384f43d4daa01f71d3cc75dc5944/PLAN.md
- Repository URL: https://github.com/CodySwannGT/lisa
- Assessment: unconfirmed; do not use or test any credentials.

### 1114. P3_LOW_SIGNAL — Collectorscanyon/Poly-edge

- Path: `env.txt`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Collectorscanyon/Poly-edge/blob/41096608cb6e7e09153318129eff2d57bcfd2e0c/env.txt
- Repository URL: https://github.com/Collectorscanyon/Poly-edge
- Assessment: unconfirmed; do not use or test any credentials.

### 1115. P3_LOW_SIGNAL — Colorful-glassblock/Dont-Be-Stupid-Leaker

- Path: `README.md`
- Indicator: `github_pat_prefix;stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Colorful-glassblock/Dont-Be-Stupid-Leaker/blob/794f2ed55a04aee49b541d035c2b07c194d71b54/README.md
- Repository URL: https://github.com/Colorful-glassblock/Dont-Be-Stupid-Leaker
- Assessment: unconfirmed; do not use or test any credentials.

### 1116. P3_LOW_SIGNAL — ComPDFKit/compdfkit-pdf-sdk-react-native

- Path: `API.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ComPDFKit/compdfkit-pdf-sdk-react-native/blob/9362ddcc0adb8b71d96aad5ac8fee9c7a1c3f562/API.md
- Repository URL: https://github.com/ComPDFKit/compdfkit-pdf-sdk-react-native
- Assessment: unconfirmed; do not use or test any credentials.

### 1117. P3_LOW_SIGNAL — CommandOSSLabs/dotmask

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/CommandOSSLabs/dotmask/blob/a59a56cc9a37c93acec69d66c9e71e23765d2062/README.md
- Repository URL: https://github.com/CommandOSSLabs/dotmask
- Assessment: unconfirmed; do not use or test any credentials.

### 1118. P3_LOW_SIGNAL — ConnectForLife/openmrs-module-callflows

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ConnectForLife/openmrs-module-callflows/blob/edf22188d7dab995c163922058860c9416f340d3/README.md
- Repository URL: https://github.com/ConnectForLife/openmrs-module-callflows
- Assessment: unconfirmed; do not use or test any credentials.

### 1119. P3_LOW_SIGNAL — CortexPrism/cortex-plugin-secret-rotation

- Path: `README.md`
- Indicator: `github_pat_prefix;github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/CortexPrism/cortex-plugin-secret-rotation/blob/e81293fc6d7dc6e5e20186254972d90d7a5714f5/README.md
- Repository URL: https://github.com/CortexPrism/cortex-plugin-secret-rotation
- Assessment: unconfirmed; do not use or test any credentials.

### 1120. P3_LOW_SIGNAL — CrayfishGo/authenticator-rs

- Path: `README.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/CrayfishGo/authenticator-rs/blob/dc7d3a875773e9a72d413e932357ac7243e12685/README.md
- Repository URL: https://github.com/CrayfishGo/authenticator-rs
- Assessment: unconfirmed; do not use or test any credentials.

### 1121. P3_LOW_SIGNAL — Createya-ai/createya-docs

- Path: `index.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Createya-ai/createya-docs/blob/bb4e3c1263ee69d8c914fad4cb1a740bb99945d3/index.md
- Repository URL: https://github.com/Createya-ai/createya-docs
- Assessment: unconfirmed; do not use or test any credentials.

### 1122. P3_LOW_SIGNAL — CyberSource/cybersource-rest-client-dotnet

- Path: `MLE.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/CyberSource/cybersource-rest-client-dotnet/blob/b23d03d4eff7e61ba571f69d5350c6d1f7405e2e/MLE.md
- Repository URL: https://github.com/CyberSource/cybersource-rest-client-dotnet
- Assessment: unconfirmed; do not use or test any credentials.

### 1123. P3_LOW_SIGNAL — CyberSource/cybersource-rest-client-node

- Path: `MLE.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/CyberSource/cybersource-rest-client-node/blob/6323f844e94b111c415baae4080f514cd8e7c460/MLE.md
- Repository URL: https://github.com/CyberSource/cybersource-rest-client-node
- Assessment: unconfirmed; do not use or test any credentials.

### 1124. P3_LOW_SIGNAL — CyberSource/cybersource-rest-client-php

- Path: `MLE.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/CyberSource/cybersource-rest-client-php/blob/ae4c4fd0b974f197340121114f63c74d762c0aab/MLE.md
- Repository URL: https://github.com/CyberSource/cybersource-rest-client-php
- Assessment: unconfirmed; do not use or test any credentials.

### 1125. P3_LOW_SIGNAL — CyberSource/cybersource-rest-client-python

- Path: `MLE.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/CyberSource/cybersource-rest-client-python/blob/7349130612f998e58ec0f08ff36bdd9efacee7cd/MLE.md
- Repository URL: https://github.com/CyberSource/cybersource-rest-client-python
- Assessment: unconfirmed; do not use or test any credentials.

### 1126. P3_LOW_SIGNAL — CyberSource/cybersource-rest-client-ruby

- Path: `MLE.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/CyberSource/cybersource-rest-client-ruby/blob/72efe433adb7e2ab33e62050bae949764b8350bb/MLE.md
- Repository URL: https://github.com/CyberSource/cybersource-rest-client-ruby
- Assessment: unconfirmed; do not use or test any credentials.

### 1127. P3_LOW_SIGNAL — CygnusNetworks/slack_asterisk

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/CygnusNetworks/slack_asterisk/blob/db28b6b0f7f364d7cac0add69405d07efd743239/README.md
- Repository URL: https://github.com/CygnusNetworks/slack_asterisk
- Assessment: unconfirmed; do not use or test any credentials.

### 1128. P3_LOW_SIGNAL — D8-X/d8x-liquidator

- Path: `DEV.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/D8-X/d8x-liquidator/blob/cc0370275b2c67a8e6394316d9a6170a65887806/DEV.md
- Repository URL: https://github.com/D8-X/d8x-liquidator
- Assessment: unconfirmed; do not use or test any credentials.

### 1129. P3_LOW_SIGNAL — DaInfLoop/beat-time-slack

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/DaInfLoop/beat-time-slack/blob/6c4cb30b6258d66aac95d4b7ac4664d919b88744/README.md
- Repository URL: https://github.com/DaInfLoop/beat-time-slack
- Assessment: unconfirmed; do not use or test any credentials.

### 1130. P3_LOW_SIGNAL — DaInfLoop/slack-osu-bot

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/DaInfLoop/slack-osu-bot/blob/a83c58cf2f2d1ad068bb3722c1bbfc1c72b440d5/README.md
- Repository URL: https://github.com/DaInfLoop/slack-osu-bot
- Assessment: unconfirmed; do not use or test any credentials.

### 1131. P3_LOW_SIGNAL — Damon-Li/openapi

- Path: `DOC.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Damon-Li/openapi/blob/807d0f3a5a882b2f0f67fa80e6c5da301f6c36bd/DOC.md
- Repository URL: https://github.com/Damon-Li/openapi
- Assessment: unconfirmed; do not use or test any credentials.

### 1132. P3_LOW_SIGNAL — DaoCloud/php-apache-mysql-sample

- Path: `CI.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/DaoCloud/php-apache-mysql-sample/blob/7aa6c7a6d206e71651f05cd4d8799a4b34ebaba1/CI.md
- Repository URL: https://github.com/DaoCloud/php-apache-mysql-sample
- Assessment: unconfirmed; do not use or test any credentials.

### 1133. P3_LOW_SIGNAL — Darkwolf007/detour_infrared_hackathon

- Path: `TODO.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Darkwolf007/detour_infrared_hackathon/blob/0337455cbd0c48947d58acfd2fd162a1bbc9289e/TODO.md
- Repository URL: https://github.com/Darkwolf007/detour_infrared_hackathon
- Assessment: unconfirmed; do not use or test any credentials.

### 1134. P3_LOW_SIGNAL — Dash2701/terraform-ecs-fargate

- Path: `.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Dash2701/terraform-ecs-fargate/blob/547773686cd6273ebbd43b2df2ef0c6cd7555e15/.terraform.tfstate.lock.info
- Repository URL: https://github.com/Dash2701/terraform-ecs-fargate
- Assessment: unconfirmed; do not use or test any credentials.

### 1135. P3_LOW_SIGNAL — Dash2701/terraform-makefile

- Path: `.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Dash2701/terraform-makefile/blob/e6b87c1e67c8fc6c0c7ae97722a576a7c4f071bb/.terraform.tfstate.lock.info
- Repository URL: https://github.com/Dash2701/terraform-makefile
- Assessment: unconfirmed; do not use or test any credentials.

### 1136. P3_LOW_SIGNAL — DataDog/shopist-code-security-demo

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/DataDog/shopist-code-security-demo/blob/050578c46c8698b52ab314e7453c46c95999968f/README.md
- Repository URL: https://github.com/DataDog/shopist-code-security-demo
- Assessment: unconfirmed; do not use or test any credentials.

### 1137. P3_LOW_SIGNAL — DatanoiseTV/aigateway

- Path: `SPEC.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/DatanoiseTV/aigateway/blob/2e192f174e97523b725d402fe7110273b95ef46d/SPEC.md
- Repository URL: https://github.com/DatanoiseTV/aigateway
- Assessment: unconfirmed; do not use or test any credentials.

### 1138. P3_LOW_SIGNAL — DecentralizedAmateurPagingNetwork/DAPNETAPRS

- Path: `INSTALL`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/DecentralizedAmateurPagingNetwork/DAPNETAPRS/blob/242cd19f3bbd9c693105e27928cd769831512dde/INSTALL
- Repository URL: https://github.com/DecentralizedAmateurPagingNetwork/DAPNETAPRS
- Assessment: unconfirmed; do not use or test any credentials.

### 1139. P3_LOW_SIGNAL — DefectDojo-Inc/notify-pr-reviewers-action

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/DefectDojo-Inc/notify-pr-reviewers-action/blob/be473e4aaee0fba5a38d94ba092f90033e945544/README.md
- Repository URL: https://github.com/DefectDojo-Inc/notify-pr-reviewers-action
- Assessment: unconfirmed; do not use or test any credentials.

### 1140. P3_LOW_SIGNAL — DerProfi/devlog

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/DerProfi/devlog/blob/20319dce487b26df0c7a021dd7d38f43ca161144/SETUP.md
- Repository URL: https://github.com/DerProfi/devlog
- Assessment: unconfirmed; do not use or test any credentials.

### 1141. P3_LOW_SIGNAL — DevSolaUS/Solana-Memecoin-Generator-and-Pump

- Path: `env.txt`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/DevSolaUS/Solana-Memecoin-Generator-and-Pump/blob/43ffbde82a16b1be5d0303d2d4b880af230388c3/env.txt
- Repository URL: https://github.com/DevSolaUS/Solana-Memecoin-Generator-and-Pump
- Assessment: unconfirmed; do not use or test any credentials.

### 1142. P3_LOW_SIGNAL — DharmikJagodana/github-starts

- Path: `readme.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/DharmikJagodana/github-starts/blob/88ae5afe648d327a66f1b28c64d2a91086ebe5d4/readme.md
- Repository URL: https://github.com/DharmikJagodana/github-starts
- Assessment: unconfirmed; do not use or test any credentials.

### 1143. P3_LOW_SIGNAL — Divyanshu-kumar14/is-my-repo-compromised

- Path: `PRD.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Divyanshu-kumar14/is-my-repo-compromised/blob/e3bab1b293796f10cc94be631738367a5a2fe62e/PRD.md
- Repository URL: https://github.com/Divyanshu-kumar14/is-my-repo-compromised
- Assessment: unconfirmed; do not use or test any credentials.

### 1144. P3_LOW_SIGNAL — DmitryBMsk/llm-council-plus

- Path: `RUN.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/DmitryBMsk/llm-council-plus/blob/60730751e236258b74b4034cc8a53598ea134314/RUN.md
- Repository URL: https://github.com/DmitryBMsk/llm-council-plus
- Assessment: unconfirmed; do not use or test any credentials.

### 1145. P3_LOW_SIGNAL — DonArtkins/rockbridge-backend-api

- Path: `SETUP.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/DonArtkins/rockbridge-backend-api/blob/b25a5b647e109894c233d238214d92499da61f3a/SETUP.md
- Repository URL: https://github.com/DonArtkins/rockbridge-backend-api
- Assessment: unconfirmed; do not use or test any credentials.

### 1146. P3_LOW_SIGNAL — DotBion/iSummarize

- Path: `plan.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/DotBion/iSummarize/blob/454fc06d4ebb8ddd88c035d9a8a08262c0093f00/plan.md
- Repository URL: https://github.com/DotBion/iSummarize
- Assessment: unconfirmed; do not use or test any credentials.

### 1147. P3_LOW_SIGNAL — DrJuChunKoO/TransPal-transcriber

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/DrJuChunKoO/TransPal-transcriber/blob/ff3a3d13779f8058fd2efe9489b5607df39ac7a7/README.md
- Repository URL: https://github.com/DrJuChunKoO/TransPal-transcriber
- Assessment: unconfirmed; do not use or test any credentials.

### 1148. P3_LOW_SIGNAL — DryFernandez/AutoDry

- Path: `SETUP.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/DryFernandez/AutoDry/blob/1c1607d36a7e365c908f64c22dfdb6fc3cbd28f3/SETUP.md
- Repository URL: https://github.com/DryFernandez/AutoDry
- Assessment: unconfirmed; do not use or test any credentials.

### 1149. P3_LOW_SIGNAL — Dubcodes/Kairix-Opsbook

- Path: `README.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Dubcodes/Kairix-Opsbook/blob/db398a6e9a3f59282208b35d9c2ae36569e88dcc/README.md
- Repository URL: https://github.com/Dubcodes/Kairix-Opsbook
- Assessment: unconfirmed; do not use or test any credentials.

### 1150. P3_LOW_SIGNAL — DusanCar-sudo/enables

- Path: `AURA.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/DusanCar-sudo/enables/blob/77e1143a4a3cf09e703b5a17b795d5178b8479e4/AURA.md
- Repository URL: https://github.com/DusanCar-sudo/enables
- Assessment: unconfirmed; do not use or test any credentials.

### 1151. P3_LOW_SIGNAL — DynoGator/SERIES-2-MHD-GEN-4

- Path: `AGENTS.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/DynoGator/SERIES-2-MHD-GEN-4/blob/361d55f502199caf1470d2e27ff54de31b45f73f/AGENTS.md
- Repository URL: https://github.com/DynoGator/SERIES-2-MHD-GEN-4
- Assessment: unconfirmed; do not use or test any credentials.

### 1152. P3_LOW_SIGNAL — ENJOuYang/campus-wall

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ENJOuYang/campus-wall/blob/ba446ac18eb2d76980dd1626d6dc95168e3f6d8a/API.md
- Repository URL: https://github.com/ENJOuYang/campus-wall
- Assessment: unconfirmed; do not use or test any credentials.

### 1153. P3_LOW_SIGNAL — ENZO7700/seo4websk

- Path: `vps.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ENZO7700/seo4websk/blob/4ecddfcc4e4426dd888a2eb0fe8118c4ca8cf416/vps.md
- Repository URL: https://github.com/ENZO7700/seo4websk
- Assessment: unconfirmed; do not use or test any credentials.

### 1154. P3_LOW_SIGNAL — Eason-Ni/niyisen-homepage

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Eason-Ni/niyisen-homepage/blob/0b926dc912b9f9fada58d2462c7c0d12ea649ead/README.md
- Repository URL: https://github.com/Eason-Ni/niyisen-homepage
- Assessment: unconfirmed; do not use or test any credentials.

### 1155. P3_LOW_SIGNAL — Ecook14/gocrewwai

- Path: `API.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Ecook14/gocrewwai/blob/4e64e103990cc060e3b07a7ce0df0b30b3c72985/API.md
- Repository URL: https://github.com/Ecook14/gocrewwai
- Assessment: unconfirmed; do not use or test any credentials.

### 1156. P3_LOW_SIGNAL — Edison-Watch/hackbot-main

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Edison-Watch/hackbot-main/blob/5d8c6b614edf8141708155b3d55541592329ca7d/README.md
- Repository URL: https://github.com/Edison-Watch/hackbot-main
- Assessment: unconfirmed; do not use or test any credentials.

### 1157. P3_LOW_SIGNAL — EfeDurmaz16/sardis

- Path: `llms.txt`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/EfeDurmaz16/sardis/blob/3843b90ebccdfc42eafad5cdf97e997ec9e6ea05/llms.txt
- Repository URL: https://github.com/EfeDurmaz16/sardis
- Assessment: unconfirmed; do not use or test any credentials.

### 1158. P3_LOW_SIGNAL — Elsa-Health/bayesian-logistic-regressor

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Elsa-Health/bayesian-logistic-regressor/blob/b5397bf9a4e35f1437b60088aa9c4fc87fa59ff8/README.md
- Repository URL: https://github.com/Elsa-Health/bayesian-logistic-regressor
- Assessment: unconfirmed; do not use or test any credentials.

### 1159. P3_LOW_SIGNAL — Elxan450/Unistore

- Path: `env.txt`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Elxan450/Unistore/blob/d3e7bcebb4da49ad2dc06e622fb1f100e48ed531/env.txt
- Repository URL: https://github.com/Elxan450/Unistore
- Assessment: unconfirmed; do not use or test any credentials.

### 1160. P3_LOW_SIGNAL — Emasoft/apias

- Path: `API.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Emasoft/apias/blob/37a1b95dad27c0aa097ca97ec138ddaa0a3078de/API.md
- Repository URL: https://github.com/Emasoft/apias
- Assessment: unconfirmed; do not use or test any credentials.

### 1161. P3_LOW_SIGNAL — Entropy-Increase-Team/endfield-plugin

- Path: `API.md`
- Indicator: `api_key_label;access_token_label;bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Entropy-Increase-Team/endfield-plugin/blob/32167dfd5dbefa0a5ccaeae20ed7f153d59a75f5/API.md
- Repository URL: https://github.com/Entropy-Increase-Team/endfield-plugin
- Assessment: unconfirmed; do not use or test any credentials.

### 1162. P3_LOW_SIGNAL — Erikvdv/realworlddotnet

- Path: `pfx.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Erikvdv/realworlddotnet/blob/2fb40e9744d4a05962b8fbd37d4d137a47706559/pfx.md
- Repository URL: https://github.com/Erikvdv/realworlddotnet
- Assessment: unconfirmed; do not use or test any credentials.

### 1163. P3_LOW_SIGNAL — FMFigueroa/superheroes

- Path: `env.txt`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/FMFigueroa/superheroes/blob/d49105da23b4829729c50a527ac6918c3c434c3d/env.txt
- Repository URL: https://github.com/FMFigueroa/superheroes
- Assessment: unconfirmed; do not use or test any credentials.

### 1164. P3_LOW_SIGNAL — Fabian-Castro-C/adk-translate

- Path: `USAGE.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Fabian-Castro-C/adk-translate/blob/cde664f7a07db19af6b4231d63abe87c7dd8dffc/USAGE.md
- Repository URL: https://github.com/Fabian-Castro-C/adk-translate
- Assessment: unconfirmed; do not use or test any credentials.

### 1165. P3_LOW_SIGNAL — Faizaniqbal52/ai-investment-research-agent

- Path: `TODO.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Faizaniqbal52/ai-investment-research-agent/blob/c835c9c7506fd7f30398eed3fc93f6abd36a560b/TODO.md
- Repository URL: https://github.com/Faizaniqbal52/ai-investment-research-agent
- Assessment: unconfirmed; do not use or test any credentials.

### 1166. P3_LOW_SIGNAL — FanLu1994/axiss-nav

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/FanLu1994/axiss-nav/blob/695223749b1a056cd56007644bbe766eea22f9af/README.md
- Repository URL: https://github.com/FanLu1994/axiss-nav
- Assessment: unconfirmed; do not use or test any credentials.

### 1167. P3_LOW_SIGNAL — FaultMaven/fm-auth-service

- Path: `CI_CD.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/FaultMaven/fm-auth-service/blob/e96e9a3259fba4ab88b42f8375a52b18211ab0d7/CI_CD.md
- Repository URL: https://github.com/FaultMaven/fm-auth-service
- Assessment: unconfirmed; do not use or test any credentials.

### 1168. P3_LOW_SIGNAL — FedTax/simplesalestax

- Path: `v3.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/FedTax/simplesalestax/blob/89410e7c68d38c3b963e698da0661213d0164bb1/v3.md
- Repository URL: https://github.com/FedTax/simplesalestax
- Assessment: unconfirmed; do not use or test any credentials.

### 1169. P3_LOW_SIGNAL — Fendix-app/Fendix

- Path: `plan.md`
- Indicator: `github_app_token_prefix;github_refresh_prefix;npm_token_prefix;google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Fendix-app/Fendix/blob/bddfeac0d2451d10a1f0475216f5e1ad79fa25d3/plan.md
- Repository URL: https://github.com/Fendix-app/Fendix
- Assessment: unconfirmed; do not use or test any credentials.

### 1170. P3_LOW_SIGNAL — FinLens/Facebook-ai-agents-public

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/FinLens/Facebook-ai-agents-public/blob/1cd0e78b3fdd244e7fc7376c1b5fecc6983b9028/README.md
- Repository URL: https://github.com/FinLens/Facebook-ai-agents-public
- Assessment: unconfirmed; do not use or test any credentials.

### 1171. P3_LOW_SIGNAL — Finch-API/finch-api-python

- Path: `api.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Finch-API/finch-api-python/blob/f45bb91f88c88a9368cd62e3e5a715767f0a6e1b/api.md
- Repository URL: https://github.com/Finch-API/finch-api-python
- Assessment: unconfirmed; do not use or test any credentials.

### 1172. P3_LOW_SIGNAL — FinnishNationalGallery/mediahillo_ng

- Path: `env.txt`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/FinnishNationalGallery/mediahillo_ng/blob/0696cb875ee92bbc50fda7862ed508dbfbfe855b/env.txt
- Repository URL: https://github.com/FinnishNationalGallery/mediahillo_ng
- Assessment: unconfirmed; do not use or test any credentials.

### 1173. P3_LOW_SIGNAL — FlashingChen/dsh-desktop-hub

- Path: `PRD.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/FlashingChen/dsh-desktop-hub/blob/d81fb810ee1e2cfa7694ef0ebec8ad03c8873276/PRD.md
- Repository URL: https://github.com/FlashingChen/dsh-desktop-hub
- Assessment: unconfirmed; do not use or test any credentials.

### 1174. P3_LOW_SIGNAL — FracktalWorks/agent-3dprinter-expert

- Path: `TODO.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/FracktalWorks/agent-3dprinter-expert/blob/24fa19ec591bef5f24b505aae6fc7bc6868829c8/TODO.md
- Repository URL: https://github.com/FracktalWorks/agent-3dprinter-expert
- Assessment: unconfirmed; do not use or test any credentials.

### 1175. P3_LOW_SIGNAL — GNOME/gnome-builder

- Path: `po/ml.po`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/GNOME/gnome-builder/blob/0d438050a2e195f9a0bd1584da325617c7189f41/po/ml.po
- Repository URL: https://github.com/GNOME/gnome-builder
- Assessment: unconfirmed; do not use or test any credentials.

### 1176. P3_LOW_SIGNAL — GNOME/gnome-builder

- Path: `po/ms.po`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/GNOME/gnome-builder/blob/0d438050a2e195f9a0bd1584da325617c7189f41/po/ms.po
- Repository URL: https://github.com/GNOME/gnome-builder
- Assessment: unconfirmed; do not use or test any credentials.

### 1177. P3_LOW_SIGNAL — GNOME/gnome-builder

- Path: `po/pl.po`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/GNOME/gnome-builder/blob/0d438050a2e195f9a0bd1584da325617c7189f41/po/pl.po
- Repository URL: https://github.com/GNOME/gnome-builder
- Assessment: unconfirmed; do not use or test any credentials.

### 1178. P3_LOW_SIGNAL — GSonofNun/GitSmarter

- Path: `src/CLAUDE.md`
- Indicator: `github_oauth_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/GSonofNun/GitSmarter/blob/3c723b0512d9bed4cc13692d6160dbb6154fadb4/src/CLAUDE.md
- Repository URL: https://github.com/GSonofNun/GitSmarter
- Assessment: unconfirmed; do not use or test any credentials.

### 1179. P3_LOW_SIGNAL — GXDEVS/grouter

- Path: `API.md`
- Indicator: `api_key_label;bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/GXDEVS/grouter/blob/e50893a5e44b7c1bbd6d185c50c6d6cf1db8f0e6/API.md
- Repository URL: https://github.com/GXDEVS/grouter
- Assessment: unconfirmed; do not use or test any credentials.

### 1180. P3_LOW_SIGNAL — Gamesight/slack-workflow-status

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Gamesight/slack-workflow-status/blob/2e709ce51fd47f02b7221db8547e6e6f49f81f1d/README.md
- Repository URL: https://github.com/Gamesight/slack-workflow-status
- Assessment: unconfirmed; do not use or test any credentials.

### 1181. P3_LOW_SIGNAL — Gastremo/PMSG

- Path: `API.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Gastremo/PMSG/blob/b61791863c17c15ada426eaa9fda8a16cbc6e83a/API.md
- Repository URL: https://github.com/Gastremo/PMSG
- Assessment: unconfirmed; do not use or test any credentials.

### 1182. P3_LOW_SIGNAL — GeoAziz/nova-ai-offline-assistant

- Path: `DEV.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/GeoAziz/nova-ai-offline-assistant/blob/170022c7b81a8cf03e4e3921b8efc537d1ede51d/DEV.md
- Repository URL: https://github.com/GeoAziz/nova-ai-offline-assistant
- Assessment: unconfirmed; do not use or test any credentials.

### 1183. P3_LOW_SIGNAL — Ghenghis/AI-Project-Synthesizer

- Path: `SECURITY.md`
- Indicator: `github_app_token_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Ghenghis/AI-Project-Synthesizer/blob/482c7d23e45d2c832ff68e4e9ba377ccef364e91/SECURITY.md
- Repository URL: https://github.com/Ghenghis/AI-Project-Synthesizer
- Assessment: unconfirmed; do not use or test any credentials.

### 1184. P3_LOW_SIGNAL — Ghenghis/AI-Project-Synthesizer

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Ghenghis/AI-Project-Synthesizer/blob/482c7d23e45d2c832ff68e4e9ba377ccef364e91/SETUP.md
- Repository URL: https://github.com/Ghenghis/AI-Project-Synthesizer
- Assessment: unconfirmed; do not use or test any credentials.

### 1185. P3_LOW_SIGNAL — GizzZmo/NAW

- Path: `API.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/GizzZmo/NAW/blob/0c8fabaf4435900f0dd2043c4509e13ea8c1a474/API.md
- Repository URL: https://github.com/GizzZmo/NAW
- Assessment: unconfirmed; do not use or test any credentials.

### 1186. P3_LOW_SIGNAL — GoogleCloudPlatform/solutions-floating-ip-patterns-terraform

- Path: `1-ilb-active-active/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/GoogleCloudPlatform/solutions-floating-ip-patterns-terraform/blob/fdd0b039b0006cfb8b7ad53ea5539d2afc3b2b45/1-ilb-active-active/.terraform.tfstate.lock.info
- Repository URL: https://github.com/GoogleCloudPlatform/solutions-floating-ip-patterns-terraform
- Assessment: unconfirmed; do not use or test any credentials.

### 1187. P3_LOW_SIGNAL — GreyRaphael/QuantNotes

- Path: `llm.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/GreyRaphael/QuantNotes/blob/a43912cefaa487491f87b988dd9c0712f20946bd/llm.md
- Repository URL: https://github.com/GreyRaphael/QuantNotes
- Assessment: unconfirmed; do not use or test any credentials.

### 1188. P3_LOW_SIGNAL — GuiZeroUm/GuiZeroUm

- Path: `FARM.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/GuiZeroUm/GuiZeroUm/blob/77d04b51ed883d9e65306f4f5370f513ddca90f5/FARM.md
- Repository URL: https://github.com/GuiZeroUm/GuiZeroUm
- Assessment: unconfirmed; do not use or test any credentials.

### 1189. P3_LOW_SIGNAL — GuillaumePressiat/pmeasyr

- Path: `NEWS.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/GuillaumePressiat/pmeasyr/blob/ed9e25b1e5d9297b91bfc18ef3f0478547ce11f3/NEWS.md
- Repository URL: https://github.com/GuillaumePressiat/pmeasyr
- Assessment: unconfirmed; do not use or test any credentials.

### 1190. P3_LOW_SIGNAL — Gurupatil0003/01_Flask_Tutorial

- Path: `que.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Gurupatil0003/01_Flask_Tutorial/blob/da67856acd9b4f4d35266cf7ec0dda7d0001456e/que.md
- Repository URL: https://github.com/Gurupatil0003/01_Flask_Tutorial
- Assessment: unconfirmed; do not use or test any credentials.

### 1191. P3_LOW_SIGNAL — Gymnott1/baby_ai

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Gymnott1/baby_ai/blob/74fe74b8669328bd093bcb4750128fdb09ea1ee8/README.md
- Repository URL: https://github.com/Gymnott1/baby_ai
- Assessment: unconfirmed; do not use or test any credentials.

### 1192. P3_LOW_SIGNAL — H4CK3RT3CH/awesome-devsecops

- Path: `readme.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/H4CK3RT3CH/awesome-devsecops/blob/0affc21e1f16fd90ceff839f9ce1c7dd497a1ff0/readme.md
- Repository URL: https://github.com/H4CK3RT3CH/awesome-devsecops
- Assessment: unconfirmed; do not use or test any credentials.

### 1193. P3_LOW_SIGNAL — HPSoftware/co-hubot

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/HPSoftware/co-hubot/blob/64e136ec1bff7b426f64af3b3ce398094608fdf5/README.md
- Repository URL: https://github.com/HPSoftware/co-hubot
- Assessment: unconfirmed; do not use or test any credentials.

### 1194. P3_LOW_SIGNAL — HQU-gxy/vue-laser-backend

- Path: `node.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/HQU-gxy/vue-laser-backend/blob/baeabbf192625feba18aa39a2d0ff9f6fa0fdafb/node.md
- Repository URL: https://github.com/HQU-gxy/vue-laser-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 1195. P3_LOW_SIGNAL — Hackerzspace/FramePhase

- Path: `SETUP.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Hackerzspace/FramePhase/blob/ae1e4cf1597559dc68f99a26395b49dc01e42211/SETUP.md
- Repository URL: https://github.com/Hackerzspace/FramePhase
- Assessment: unconfirmed; do not use or test any credentials.

### 1196. P3_LOW_SIGNAL — Hans-Rafael/PI-countries

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Hans-Rafael/PI-countries/blob/d30c9dba6511a8ab74f02d31fb87b0e6d727efd1/README.md
- Repository URL: https://github.com/Hans-Rafael/PI-countries
- Assessment: unconfirmed; do not use or test any credentials.

### 1197. P3_LOW_SIGNAL — HarryAlvarado28/Shortly

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/HarryAlvarado28/Shortly/blob/91d06c337dd96d5e42400fd9e45ce5a974c7482d/API.md
- Repository URL: https://github.com/HarryAlvarado28/Shortly
- Assessment: unconfirmed; do not use or test any credentials.

### 1198. P3_LOW_SIGNAL — HarryEMartland/terraform-provider-appdynamics

- Path: `README.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/HarryEMartland/terraform-provider-appdynamics/blob/3e8afdb8a4f0ab66d0567bcc06b1d1158a9af044/README.md
- Repository URL: https://github.com/HarryEMartland/terraform-provider-appdynamics
- Assessment: unconfirmed; do not use or test any credentials.

### 1199. P3_LOW_SIGNAL — HarshKapadia2/networking

- Path: `ssh.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/HarshKapadia2/networking/blob/1800f82ef2273bc3900ec65c28205622d7d70039/ssh.md
- Repository URL: https://github.com/HarshKapadia2/networking
- Assessment: unconfirmed; do not use or test any credentials.

### 1200. P3_LOW_SIGNAL — HasanJahidul/terminal-history-mcp

- Path: `CHANGELOG.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/HasanJahidul/terminal-history-mcp/blob/8ec2c71129186162cd3099bddd17c3fc31464f65/CHANGELOG.md
- Repository URL: https://github.com/HasanJahidul/terminal-history-mcp
- Assessment: unconfirmed; do not use or test any credentials.

### 1201. P3_LOW_SIGNAL — HasanJahidul/terminal-history-mcp

- Path: `README.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/HasanJahidul/terminal-history-mcp/blob/8ec2c71129186162cd3099bddd17c3fc31464f65/README.md
- Repository URL: https://github.com/HasanJahidul/terminal-history-mcp
- Assessment: unconfirmed; do not use or test any credentials.

### 1202. P3_LOW_SIGNAL — Hassanmahmood4/CodeMind

- Path: `RUN.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Hassanmahmood4/CodeMind/blob/2f0e6e9f6a39afc3abc9b703a3846e5901b80ada/RUN.md
- Repository URL: https://github.com/Hassanmahmood4/CodeMind
- Assessment: unconfirmed; do not use or test any credentials.

### 1203. P3_LOW_SIGNAL — HectorPulido/pequeroku

- Path: `AI.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/HectorPulido/pequeroku/blob/a1b4b96b296cd87774e49bf130439cbec3fa7e13/AI.md
- Repository URL: https://github.com/HectorPulido/pequeroku
- Assessment: unconfirmed; do not use or test any credentials.

### 1204. P3_LOW_SIGNAL — Hefezopf/hopf-it.de

- Path: `todo.txt`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Hefezopf/hopf-it.de/blob/30adb5103061aafe972c6e2a337d4fe12d38d1c1/todo.txt
- Repository URL: https://github.com/Hefezopf/hopf-it.de
- Assessment: unconfirmed; do not use or test any credentials.

### 1205. P3_LOW_SIGNAL — Herdeny/dsh-qc

- Path: `SPEC.md`
- Indicator: `aws_access_key;google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Herdeny/dsh-qc/blob/63db674254814479c67c3c812a3262d191061d11/SPEC.md
- Repository URL: https://github.com/Herdeny/dsh-qc
- Assessment: unconfirmed; do not use or test any credentials.

### 1206. P3_LOW_SIGNAL — HerronTech/soajs.installer

- Path: `INSTALL`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/HerronTech/soajs.installer/blob/b2a76042419436f72e3bcbcbbc8cf9c0fe94b361/INSTALL
- Repository URL: https://github.com/HerronTech/soajs.installer
- Assessment: unconfirmed; do not use or test any credentials.

### 1207. P3_LOW_SIGNAL — Hierosoft/repo-organizer

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Hierosoft/repo-organizer/blob/7448456cead0194b3fb63b3f5ca9a4d40f68969d/README.md
- Repository URL: https://github.com/Hierosoft/repo-organizer
- Assessment: unconfirmed; do not use or test any credentials.

### 1208. P3_LOW_SIGNAL — HiteshGorana/agent-brain

- Path: `usage.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/HiteshGorana/agent-brain/blob/4c1d2bd7c35fe557bb36db5b81f527bd16467639/usage.md
- Repository URL: https://github.com/HiteshGorana/agent-brain
- Assessment: unconfirmed; do not use or test any credentials.

### 1209. P3_LOW_SIGNAL — HuakunShen/git-skyline

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/HuakunShen/git-skyline/blob/7364b8ecde784a17280f99a6fa1c3d80f3fd4de9/README.md
- Repository URL: https://github.com/HuakunShen/git-skyline
- Assessment: unconfirmed; do not use or test any credentials.

### 1210. P3_LOW_SIGNAL — IRussianGamerI/ITMO-AI-Security-Seminar4

- Path: `TODO.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/IRussianGamerI/ITMO-AI-Security-Seminar4/blob/55393f68a601b8d6e903064980898a8a666eb53e/TODO.md
- Repository URL: https://github.com/IRussianGamerI/ITMO-AI-Security-Seminar4
- Assessment: unconfirmed; do not use or test any credentials.

### 1211. P3_LOW_SIGNAL — IS908/claude-lark-plugin

- Path: `CHANGELOG.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/IS908/claude-lark-plugin/blob/f8566b2247670795cf73bec812feae97886ef21e/CHANGELOG.md
- Repository URL: https://github.com/IS908/claude-lark-plugin
- Assessment: unconfirmed; do not use or test any credentials.

### 1212. P3_LOW_SIGNAL — IYair/fc-sdk-node

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/IYair/fc-sdk-node/blob/2b631139aeadc6821e96671299a5510fd9e7f177/README.md
- Repository URL: https://github.com/IYair/fc-sdk-node
- Assessment: unconfirmed; do not use or test any credentials.

### 1213. P3_LOW_SIGNAL — IceBearAI/LLM-And-More

- Path: `api.md`
- Indicator: `api_key_label;bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/IceBearAI/LLM-And-More/blob/95ca1d266c213f22d1f35e17e96407d353625010/api.md
- Repository URL: https://github.com/IceBearAI/LLM-And-More
- Assessment: unconfirmed; do not use or test any credentials.

### 1214. P3_LOW_SIGNAL — Inayat-0007/jobharness

- Path: `SETUP.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Inayat-0007/jobharness/blob/5da0beaf491f157aa3907d3d3766ece52c73c373/SETUP.md
- Repository URL: https://github.com/Inayat-0007/jobharness
- Assessment: unconfirmed; do not use or test any credentials.

### 1215. P3_LOW_SIGNAL — Infatoshi/x-mcp

- Path: `LLMs.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Infatoshi/x-mcp/blob/09f9d8379d49dc86b970f7855b5f4f6658104f78/LLMs.md
- Repository URL: https://github.com/Infatoshi/x-mcp
- Assessment: unconfirmed; do not use or test any credentials.

### 1216. P3_LOW_SIGNAL — Infinity-X-One-Systems/infinity-core-memory

- Path: `SECURITY.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Infinity-X-One-Systems/infinity-core-memory/blob/036da23135dc8134c55a8398e02a61d6033a6bd8/SECURITY.md
- Repository URL: https://github.com/Infinity-X-One-Systems/infinity-core-memory
- Assessment: unconfirmed; do not use or test any credentials.

### 1217. P3_LOW_SIGNAL — IngmarKrusch/claude-docker

- Path: `README.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/IngmarKrusch/claude-docker/blob/a8fa7350283aa07c9c5eece07bab8465e32845c6/README.md
- Repository URL: https://github.com/IngmarKrusch/claude-docker
- Assessment: unconfirmed; do not use or test any credentials.

### 1218. P3_LOW_SIGNAL — Innei/Kagura

- Path: `llm.txt`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Innei/Kagura/blob/6a2bb42142e918da6b9aa84f5232bc18fc74e0a7/llm.txt
- Repository URL: https://github.com/Innei/Kagura
- Assessment: unconfirmed; do not use or test any credentials.

### 1219. P3_LOW_SIGNAL — J-coder118/LLM-Twin

- Path: `RAG.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/J-coder118/LLM-Twin/blob/707f9d8bb1cf402e04644bff9c5c521ce0938087/RAG.md
- Repository URL: https://github.com/J-coder118/LLM-Twin
- Assessment: unconfirmed; do not use or test any credentials.

### 1220. P3_LOW_SIGNAL — JARVIS-03/Terraform-AWS

- Path: `.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/JARVIS-03/Terraform-AWS/blob/0cf44b2edc28d5422fb4909d35810568b29bb1c1/.terraform.tfstate.lock.info
- Repository URL: https://github.com/JARVIS-03/Terraform-AWS
- Assessment: unconfirmed; do not use or test any credentials.

### 1221. P3_LOW_SIGNAL — JCBarry/argyle

- Path: `README.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/JCBarry/argyle/blob/bff4dc0c395f37c411fdf856433ff9dab56d3191/README.md
- Repository URL: https://github.com/JCBarry/argyle
- Assessment: unconfirmed; do not use or test any credentials.

### 1222. P3_LOW_SIGNAL — JChanOnto/github-copilot-cli-agent

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/JChanOnto/github-copilot-cli-agent/blob/004cf710af40ef3f2c1a1126bc11eb3c0516baf5/README.md
- Repository URL: https://github.com/JChanOnto/github-copilot-cli-agent
- Assessment: unconfirmed; do not use or test any credentials.

### 1223. P3_LOW_SIGNAL — JackChan1999/Android_Develop

- Path: `net.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/JackChan1999/Android_Develop/blob/cbcc497e507f5ec5ef70239336a88405f478eab9/net.md
- Repository URL: https://github.com/JackChan1999/Android_Develop
- Assessment: unconfirmed; do not use or test any credentials.

### 1224. P3_LOW_SIGNAL — Jalicia150/kavitools

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Jalicia150/kavitools/blob/c15ad1feb97dbb436450c1aa8b752b6b94f89c38/README.md
- Repository URL: https://github.com/Jalicia150/kavitools
- Assessment: unconfirmed; do not use or test any credentials.

### 1225. P3_LOW_SIGNAL — JamesElstone/SwallowTail

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/JamesElstone/SwallowTail/blob/910fc1e31d4dc431290a1ca47e534730c5985176/API.md
- Repository URL: https://github.com/JamesElstone/SwallowTail
- Assessment: unconfirmed; do not use or test any credentials.

### 1226. P3_LOW_SIGNAL — JamesShi96/safe-push

- Path: `SKILL.md`
- Indicator: `github_token_prefix;github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/JamesShi96/safe-push/blob/bbd9ad83b06e1863a2c9756ab621e4bb041c3d9a/SKILL.md
- Repository URL: https://github.com/JamesShi96/safe-push
- Assessment: unconfirmed; do not use or test any credentials.

### 1227. P3_LOW_SIGNAL — JayP09/TragicSimpBot

- Path: `setup.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/JayP09/TragicSimpBot/blob/22a41d34ab6bc84b03b0b967d727875e0d7933c6/setup.md
- Repository URL: https://github.com/JayP09/TragicSimpBot
- Assessment: unconfirmed; do not use or test any credentials.

### 1228. P3_LOW_SIGNAL — Jeangowhy/opendocs

- Path: `CTF.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Jeangowhy/opendocs/blob/25a77d63fd77ef03055191d6d83c30b26098a650/CTF.md
- Repository URL: https://github.com/Jeangowhy/opendocs
- Assessment: unconfirmed; do not use or test any credentials.

### 1229. P3_LOW_SIGNAL — Jeangowhy/opendocs

- Path: `ES6.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Jeangowhy/opendocs/blob/25a77d63fd77ef03055191d6d83c30b26098a650/ES6.md
- Repository URL: https://github.com/Jeangowhy/opendocs
- Assessment: unconfirmed; do not use or test any credentials.

### 1230. P3_LOW_SIGNAL — Jenderal92/shin

- Path: `Iam.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Jenderal92/shin/blob/96a1722f7314a37ffafcc016c1637f2e3a6ef214/Iam.txt
- Repository URL: https://github.com/Jenderal92/shin
- Assessment: unconfirmed; do not use or test any credentials.

### 1231. P3_LOW_SIGNAL — JesseZhao1990/blog

- Path: `nvm.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/JesseZhao1990/blog/blob/c2acb0d573e37bdb56b95319a43a88c3073e1949/nvm.md
- Repository URL: https://github.com/JesseZhao1990/blog
- Assessment: unconfirmed; do not use or test any credentials.

### 1232. P3_LOW_SIGNAL — JohnCoene/packer

- Path: `NEWS.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/JohnCoene/packer/blob/2b87a1b4c34eae10e6a97f1d8d011afb5898ed0d/NEWS.md
- Repository URL: https://github.com/JohnCoene/packer
- Assessment: unconfirmed; do not use or test any credentials.

### 1233. P3_LOW_SIGNAL — JoshuaKGoldberg/octokit-from-auth

- Path: `README.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/JoshuaKGoldberg/octokit-from-auth/blob/65e5e76bb6f66b612d575113d200e1b05c06402a/README.md
- Repository URL: https://github.com/JoshuaKGoldberg/octokit-from-auth
- Assessment: unconfirmed; do not use or test any credentials.

### 1234. P3_LOW_SIGNAL — Juan-Severiano/Video-Transcriber

- Path: `USAGE.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Juan-Severiano/Video-Transcriber/blob/7ff87cfb2674c1520735315c243a00be8a3327e4/USAGE.md
- Repository URL: https://github.com/Juan-Severiano/Video-Transcriber
- Assessment: unconfirmed; do not use or test any credentials.

### 1235. P3_LOW_SIGNAL — Jude95/Know

- Path: `api.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Jude95/Know/blob/88a0f8ee4a6229bcdade9bcd8a5324ffa3811a96/api.md
- Repository URL: https://github.com/Jude95/Know
- Assessment: unconfirmed; do not use or test any credentials.

### 1236. P3_LOW_SIGNAL — Jumbo-WJB/site-dir

- Path: `jsp.txt`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Jumbo-WJB/site-dir/blob/3651faa807b996a680bc15095b22efc95518f38c/jsp.txt
- Repository URL: https://github.com/Jumbo-WJB/site-dir
- Assessment: unconfirmed; do not use or test any credentials.

### 1237. P3_LOW_SIGNAL — Jumbo-WJB/site-dir

- Path: `php.txt`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Jumbo-WJB/site-dir/blob/3651faa807b996a680bc15095b22efc95518f38c/php.txt
- Repository URL: https://github.com/Jumbo-WJB/site-dir
- Assessment: unconfirmed; do not use or test any credentials.

### 1238. P3_LOW_SIGNAL — Kaiziron/numen_ctf_2023_writeup

- Path: `hexp.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Kaiziron/numen_ctf_2023_writeup/blob/d0791bed8ffc760ea0cc07de2bbb78e1a06f4912/hexp.md
- Repository URL: https://github.com/Kaiziron/numen_ctf_2023_writeup
- Assessment: unconfirmed; do not use or test any credentials.

### 1239. P3_LOW_SIGNAL — Kan116-sys/Climate-IQ

- Path: `a.txt`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Kan116-sys/Climate-IQ/blob/11a81bbdb7c66812fc0ff743f57f1c379a71126f/a.txt
- Repository URL: https://github.com/Kan116-sys/Climate-IQ
- Assessment: unconfirmed; do not use or test any credentials.

### 1240. P3_LOW_SIGNAL — KarmaRuntime/Aztec-One-Command-Installation-Run

- Path: `FAQ.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/KarmaRuntime/Aztec-One-Command-Installation-Run/blob/4c4f402101bb13479336d8f1176057a3c8ba5f9a/FAQ.md
- Repository URL: https://github.com/KarmaRuntime/Aztec-One-Command-Installation-Run
- Assessment: unconfirmed; do not use or test any credentials.

### 1241. P3_LOW_SIGNAL — KartikLabhshetwar/ReadMeLingo

- Path: `ARCHITECTURE.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/KartikLabhshetwar/ReadMeLingo/blob/4d9c5a089ffb11b2ca1de9fb3e29026ba61b46b1/ARCHITECTURE.md
- Repository URL: https://github.com/KartikLabhshetwar/ReadMeLingo
- Assessment: unconfirmed; do not use or test any credentials.

### 1242. P3_LOW_SIGNAL — Kcodess2807/graphsight

- Path: `BETA.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Kcodess2807/graphsight/blob/b00443d2a2095a846e24e14d4db1f9d9fb33e6f5/BETA.md
- Repository URL: https://github.com/Kcodess2807/graphsight
- Assessment: unconfirmed; do not use or test any credentials.

### 1243. P3_LOW_SIGNAL — KevinInoCol/Project-LangChain-Agent-for-Whatsapp-with-KB-CH-Multitool-and-Security-Langfuse

- Path: `NOTAS.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/KevinInoCol/Project-LangChain-Agent-for-Whatsapp-with-KB-CH-Multitool-and-Security-Langfuse/blob/ad7693aeaade855c0ff50f291e3e6b05ca994fc9/NOTAS.md
- Repository URL: https://github.com/KevinInoCol/Project-LangChain-Agent-for-Whatsapp-with-KB-CH-Multitool-and-Security-Langfuse
- Assessment: unconfirmed; do not use or test any credentials.

### 1244. P3_LOW_SIGNAL — Khushilbhavsar/QuoteAgent

- Path: `AUDIT.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Khushilbhavsar/QuoteAgent/blob/83b2176a705f9bbd556272f0a6747171d249f4a8/AUDIT.md
- Repository URL: https://github.com/Khushilbhavsar/QuoteAgent
- Assessment: unconfirmed; do not use or test any credentials.

### 1245. P3_LOW_SIGNAL — Kjorri/data-sanitizer

- Path: `CONTRIBUTING.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Kjorri/data-sanitizer/blob/15d1da263f1b8737388eddfa3521a7d62a2e4ec9/CONTRIBUTING.md
- Repository URL: https://github.com/Kjorri/data-sanitizer
- Assessment: unconfirmed; do not use or test any credentials.

### 1246. P3_LOW_SIGNAL — Klosmi/html-basics

- Path: `Node.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Klosmi/html-basics/blob/c6729b77c9c4eadd7dcf8b8b7c4a0107a9df4cd2/Node.md
- Repository URL: https://github.com/Klosmi/html-basics
- Assessment: unconfirmed; do not use or test any credentials.

### 1247. P3_LOW_SIGNAL — KooshaPari/BytePort

- Path: `SPEC.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/KooshaPari/BytePort/blob/bb0fe56de8304af9fe792aade9be1646f4161774/SPEC.md
- Repository URL: https://github.com/KooshaPari/BytePort
- Assessment: unconfirmed; do not use or test any credentials.

### 1248. P3_LOW_SIGNAL — Kualarz/bridge

- Path: `AUDIT.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Kualarz/bridge/blob/96510e184af7c014bb26a1416aaf665009a0dde3/AUDIT.md
- Repository URL: https://github.com/Kualarz/bridge
- Assessment: unconfirmed; do not use or test any credentials.

### 1249. P3_LOW_SIGNAL — LKbaba/Gemini-mcp

- Path: `PRD.md`
- Indicator: `private_key_label;google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/LKbaba/Gemini-mcp/blob/c4274c527a165b7d2410f23d24f02d47965469d6/PRD.md
- Repository URL: https://github.com/LKbaba/Gemini-mcp
- Assessment: unconfirmed; do not use or test any credentials.

### 1250. P3_LOW_SIGNAL — LabQS-ITA/lab

- Path: `USE.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/LabQS-ITA/lab/blob/6076758df142b01b7d7c2b902378aacb3c928935/USE.md
- Repository URL: https://github.com/LabQS-ITA/lab
- Assessment: unconfirmed; do not use or test any credentials.

### 1251. P3_LOW_SIGNAL — Layr-Labs/lighter-prover-challenge

- Path: `README.md`
- Indicator: `github_app_token_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Layr-Labs/lighter-prover-challenge/blob/ce919deaf8c8820b7d066feabb2ea2a2aec5dcb0/README.md
- Repository URL: https://github.com/Layr-Labs/lighter-prover-challenge
- Assessment: unconfirmed; do not use or test any credentials.

### 1252. P3_LOW_SIGNAL — Lercas/prowl

- Path: `wiki/Verifiers.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Lercas/prowl/blob/61126387b51a714cd13339eefcf09d5b25cc68fd/wiki/Verifiers.md
- Repository URL: https://github.com/Lercas/prowl
- Assessment: unconfirmed; do not use or test any credentials.

### 1253. P3_LOW_SIGNAL — LeverCapital/vaults

- Path: `cmds.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/LeverCapital/vaults/blob/e8288622103cfea6a3bbb7bd210b17ecb2eef1fd/cmds.md
- Repository URL: https://github.com/LeverCapital/vaults
- Assessment: unconfirmed; do not use or test any credentials.

### 1254. P3_LOW_SIGNAL — Lexus2016/hermes-agent-evolution

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Lexus2016/hermes-agent-evolution/blob/9efba6dcfa78013a3763778aaca4fe37921c495e/README.md
- Repository URL: https://github.com/Lexus2016/hermes-agent-evolution
- Assessment: unconfirmed; do not use or test any credentials.

### 1255. P3_LOW_SIGNAL — Lidprex/Lidbridge

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Lidprex/Lidbridge/blob/920b39f51da2b7347a45708f0ff2f3d4f846ddf4/README.md
- Repository URL: https://github.com/Lidprex/Lidbridge
- Assessment: unconfirmed; do not use or test any credentials.

### 1256. P3_LOW_SIGNAL — Life-Experimentalist/ActionsCounter

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Life-Experimentalist/ActionsCounter/blob/1861b0b8242f94467a7561257ef3622b8f0a82c2/SETUP.md
- Repository URL: https://github.com/Life-Experimentalist/ActionsCounter
- Assessment: unconfirmed; do not use or test any credentials.

### 1257. P3_LOW_SIGNAL — Link-/gh-token

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Link-/gh-token/blob/4719ce7e22e6b1af1f993a9c71b163d3bd112e87/README.md
- Repository URL: https://github.com/Link-/gh-token
- Assessment: unconfirmed; do not use or test any credentials.

### 1258. P3_LOW_SIGNAL — LittleWolf-Code/tp_devops_07_04_2026

- Path: `.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/LittleWolf-Code/tp_devops_07_04_2026/blob/2f58e973d2f3dacf5a5d456dbc280025690dcc00/.terraform.tfstate.lock.info
- Repository URL: https://github.com/LittleWolf-Code/tp_devops_07_04_2026
- Assessment: unconfirmed; do not use or test any credentials.

### 1259. P3_LOW_SIGNAL — LiveXY/elearning

- Path: `go.txt`
- Indicator: `secret_access_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/LiveXY/elearning/blob/fa7989893369a83c825aaadea4b938d1eaa3b989/go.txt
- Repository URL: https://github.com/LiveXY/elearning
- Assessment: unconfirmed; do not use or test any credentials.

### 1260. P3_LOW_SIGNAL — LlmLaraHub/docs-vitepress

- Path: `api.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/LlmLaraHub/docs-vitepress/blob/6242543cb867460bc8677c953e1941d13d3c581e/api.md
- Repository URL: https://github.com/LlmLaraHub/docs-vitepress
- Assessment: unconfirmed; do not use or test any credentials.

### 1261. P3_LOW_SIGNAL — LovK45/LoveNote-AI

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/LovK45/LoveNote-AI/blob/1cf0c6c4888f103cae6dd05b0e5148be83dec7f6/README.md
- Repository URL: https://github.com/LovK45/LoveNote-AI
- Assessment: unconfirmed; do not use or test any credentials.

### 1262. P3_LOW_SIGNAL — LuNiZz/websec101

- Path: `18.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/LuNiZz/websec101/blob/f3bc18a714beeaf82a12f90eb78b15926783e3a1/18.md
- Repository URL: https://github.com/LuNiZz/websec101
- Assessment: unconfirmed; do not use or test any credentials.

### 1263. P3_LOW_SIGNAL — LuNiZz/websec101

- Path: `2.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/LuNiZz/websec101/blob/f3bc18a714beeaf82a12f90eb78b15926783e3a1/2.md
- Repository URL: https://github.com/LuNiZz/websec101
- Assessment: unconfirmed; do not use or test any credentials.

### 1264. P3_LOW_SIGNAL — Luigigreco/gitforms

- Path: `ai.txt`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Luigigreco/gitforms/blob/2593c2ba1b8ba0591c2409be9c3ab55b1fa0949e/ai.txt
- Repository URL: https://github.com/Luigigreco/gitforms
- Assessment: unconfirmed; do not use or test any credentials.

### 1265. P3_LOW_SIGNAL — Luiso50/skilltwin

- Path: `API.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Luiso50/skilltwin/blob/c5c821ad5484c204561ebfb9c411a0ec4e5fd704/API.md
- Repository URL: https://github.com/Luiso50/skilltwin
- Assessment: unconfirmed; do not use or test any credentials.

### 1266. P3_LOW_SIGNAL — LuxembourgTechSchool/ai_everywhere-project-examples

- Path: `README.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/LuxembourgTechSchool/ai_everywhere-project-examples/blob/1078c80b516473c55a3f95d194dd422e489de627/README.md
- Repository URL: https://github.com/LuxembourgTechSchool/ai_everywhere-project-examples
- Assessment: unconfirmed; do not use or test any credentials.

### 1267. P3_LOW_SIGNAL — M4cs/TrackrAPI

- Path: `docs.md`
- Indicator: `secret_access_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/M4cs/TrackrAPI/blob/ce0b3327e804db464785c3ab8adefd28cc7cff60/docs.md
- Repository URL: https://github.com/M4cs/TrackrAPI
- Assessment: unconfirmed; do not use or test any credentials.

### 1268. P3_LOW_SIGNAL — MCPWorks-Technologies-Inc/mcpworks-api

- Path: `SPEC.md`
- Indicator: `github_token_prefix;aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/MCPWorks-Technologies-Inc/mcpworks-api/blob/c7e1afe48df19e19da92d35d4c7f3d4233851c45/SPEC.md
- Repository URL: https://github.com/MCPWorks-Technologies-Inc/mcpworks-api
- Assessment: unconfirmed; do not use or test any credentials.

### 1269. P3_LOW_SIGNAL — MH4GF/issync

- Path: `AGENTS.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/MH4GF/issync/blob/49c5603a1567eb901f85545e6afeede318239cad/AGENTS.md
- Repository URL: https://github.com/MH4GF/issync
- Assessment: unconfirmed; do not use or test any credentials.

### 1270. P3_LOW_SIGNAL — MILE-IISc/ocr-web-app

- Path: `Build.md`
- Indicator: `secret_access_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/MILE-IISc/ocr-web-app/blob/7482bc72681de15b23e9cdbfe9f0cf27b6372a02/Build.md
- Repository URL: https://github.com/MILE-IISc/ocr-web-app
- Assessment: unconfirmed; do not use or test any credentials.

### 1271. P3_LOW_SIGNAL — MITHILESHK11/BountyHunter-Agent

- Path: `SETUP.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/MITHILESHK11/BountyHunter-Agent/blob/4197b84539bc1f2feb5d1231a751b468cf9d0f29/SETUP.md
- Repository URL: https://github.com/MITHILESHK11/BountyHunter-Agent
- Assessment: unconfirmed; do not use or test any credentials.

### 1272. P3_LOW_SIGNAL — MLSC-BSOITR/Web-development-Resources

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/MLSC-BSOITR/Web-development-Resources/blob/f600358f3a952d241933bf5af9982e3f99fae0d6/README.md
- Repository URL: https://github.com/MLSC-BSOITR/Web-development-Resources
- Assessment: unconfirmed; do not use or test any credentials.

### 1273. P3_LOW_SIGNAL — MadB0i/KAVACH

- Path: `docs/redaction.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/MadB0i/KAVACH/blob/01007049143a6aebad791a263d5ff1b3bbc8fca9/docs/redaction.md
- Repository URL: https://github.com/MadB0i/KAVACH
- Assessment: unconfirmed; do not use or test any credentials.

### 1274. P3_LOW_SIGNAL — MadaPetru/terraform-tutorial

- Path: `.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/MadaPetru/terraform-tutorial/blob/0a06c340e6f31771d301cd0c9af04560a70e262d/.terraform.tfstate.lock.info
- Repository URL: https://github.com/MadaPetru/terraform-tutorial
- Assessment: unconfirmed; do not use or test any credentials.

### 1275. P3_LOW_SIGNAL — Mai0313/VibeCodingTracker

- Path: `docs/quota.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Mai0313/VibeCodingTracker/blob/74eb884f1378d5600e2324158ac66b57925fd2f4/docs/quota.md
- Repository URL: https://github.com/Mai0313/VibeCodingTracker
- Assessment: unconfirmed; do not use or test any credentials.

### 1276. P3_LOW_SIGNAL — MaigoLabs/refray

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/MaigoLabs/refray/blob/b363aac736a84c2c85cc9049e985c001ac03b8ed/README.md
- Repository URL: https://github.com/MaigoLabs/refray
- Assessment: unconfirmed; do not use or test any credentials.

### 1277. P3_LOW_SIGNAL — Majinuni/Bear

- Path: `terraform/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Majinuni/Bear/blob/e0057ba5e9fc22c4aeaad326ddf230192e3aaa3b/terraform/.terraform.tfstate.lock.info
- Repository URL: https://github.com/Majinuni/Bear
- Assessment: unconfirmed; do not use or test any credentials.

### 1278. P3_LOW_SIGNAL — Manushprajwal7/virtual-network-functuion

- Path: `API.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Manushprajwal7/virtual-network-functuion/blob/3111018e46d1fbe24b54ce8f8491a60aa6de8810/API.md
- Repository URL: https://github.com/Manushprajwal7/virtual-network-functuion
- Assessment: unconfirmed; do not use or test any credentials.

### 1279. P3_LOW_SIGNAL — MarcLlobet/wordle-app

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/MarcLlobet/wordle-app/blob/001ec14dd250bcef0e4b7540bea808af9bf17186/README.md
- Repository URL: https://github.com/MarcLlobet/wordle-app
- Assessment: unconfirmed; do not use or test any credentials.

### 1280. P3_LOW_SIGNAL — Maritimes/Mar.datawrangling

- Path: `NEWS.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Maritimes/Mar.datawrangling/blob/3fbfe0f9c66ad0a873052dd47c2f63ee130dbd16/NEWS.md
- Repository URL: https://github.com/Maritimes/Mar.datawrangling
- Assessment: unconfirmed; do not use or test any credentials.

### 1281. P3_LOW_SIGNAL — MartiSuvik/marti-mvp-app

- Path: `chat.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/MartiSuvik/marti-mvp-app/blob/f00f03622ac74fa945650edb16e91308969899bf/chat.md
- Repository URL: https://github.com/MartiSuvik/marti-mvp-app
- Assessment: unconfirmed; do not use or test any credentials.

### 1282. P3_LOW_SIGNAL — MaxwellCalkin/sentinel-ai

- Path: `README.md`
- Indicator: `github_oauth_prefix;github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/MaxwellCalkin/sentinel-ai/blob/876aff3cdbca15955b0e649cc19117730b10a203/README.md
- Repository URL: https://github.com/MaxwellCalkin/sentinel-ai
- Assessment: unconfirmed; do not use or test any credentials.

### 1283. P3_LOW_SIGNAL — MaybeJaydeep/Spark.chat

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/MaybeJaydeep/Spark.chat/blob/6594aedd2de60011918ea1a687aba7ff900285aa/API.md
- Repository URL: https://github.com/MaybeJaydeep/Spark.chat
- Assessment: unconfirmed; do not use or test any credentials.

### 1284. P3_LOW_SIGNAL — MiYogurt/electron-flyer

- Path: `10.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/MiYogurt/electron-flyer/blob/25c170ff92d8259ebe61de2bc5a98e870a77f3ea/10.md
- Repository URL: https://github.com/MiYogurt/electron-flyer
- Assessment: unconfirmed; do not use or test any credentials.

### 1285. P3_LOW_SIGNAL — MiYogurt/electron-flyer

- Path: `11.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/MiYogurt/electron-flyer/blob/25c170ff92d8259ebe61de2bc5a98e870a77f3ea/11.md
- Repository URL: https://github.com/MiYogurt/electron-flyer
- Assessment: unconfirmed; do not use or test any credentials.

### 1286. P3_LOW_SIGNAL — MichaelDanCurtis/AI-Usage-UI

- Path: `WARP.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/MichaelDanCurtis/AI-Usage-UI/blob/554462ad757943ff559e87aae5b20625f2888630/WARP.md
- Repository URL: https://github.com/MichaelDanCurtis/AI-Usage-UI
- Assessment: unconfirmed; do not use or test any credentials.

### 1287. P3_LOW_SIGNAL — MichaelWeissDEV/RefHound

- Path: `docs/detectors.rst`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/MichaelWeissDEV/RefHound/blob/a3d456d4d5f15664d5d3d85e0912d5d22c816629/docs/detectors.rst
- Repository URL: https://github.com/MichaelWeissDEV/RefHound
- Assessment: unconfirmed; do not use or test any credentials.

### 1288. P3_LOW_SIGNAL — MihanEntalpo/cryptboard.io

- Path: `SPEC.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/MihanEntalpo/cryptboard.io/blob/0bf2f413ac4ef33175a3c09ae9d23c8ae2797585/SPEC.md
- Repository URL: https://github.com/MihanEntalpo/cryptboard.io
- Assessment: unconfirmed; do not use or test any credentials.

### 1289. P3_LOW_SIGNAL — MinhThang1009/dotclaude

- Path: `rules/security.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/MinhThang1009/dotclaude/blob/0e380033c0b9692409c16da88f002281fdfb287b/rules/security.md
- Repository URL: https://github.com/MinhThang1009/dotclaude
- Assessment: unconfirmed; do not use or test any credentials.

### 1290. P3_LOW_SIGNAL — MironCo/indiekku

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/MironCo/indiekku/blob/bd0437b38fdef96235ae0f1d35e53a9e0140b53b/API.md
- Repository URL: https://github.com/MironCo/indiekku
- Assessment: unconfirmed; do not use or test any credentials.

### 1291. P3_LOW_SIGNAL — MisakiKata/python_code_audit

- Path: `CTF.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/MisakiKata/python_code_audit/blob/43753d06590f9d512674da82e77e3aeed2d54307/CTF.md
- Repository URL: https://github.com/MisakiKata/python_code_audit
- Assessment: unconfirmed; do not use or test any credentials.

### 1292. P3_LOW_SIGNAL — ModallMedia/hyperspeed-sdk

- Path: `v1.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ModallMedia/hyperspeed-sdk/blob/f1f705d37e3015276f24290b3f51f9d333083d5b/v1.md
- Repository URL: https://github.com/ModallMedia/hyperspeed-sdk
- Assessment: unconfirmed; do not use or test any credentials.

### 1293. P3_LOW_SIGNAL — Moneybench/moneybench

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Moneybench/moneybench/blob/34d4e99db400db04332c664d5fe5cefc0fe2ca93/README.md
- Repository URL: https://github.com/Moneybench/moneybench
- Assessment: unconfirmed; do not use or test any credentials.

### 1294. P3_LOW_SIGNAL — Msmastr74/Bogobot

- Path: `AI.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Msmastr74/Bogobot/blob/ab4ae9a18cb2d3c57514a58b39397d35d8f2622d/AI.md
- Repository URL: https://github.com/Msmastr74/Bogobot
- Assessment: unconfirmed; do not use or test any credentials.

### 1295. P3_LOW_SIGNAL — Murodbektuychiyev/CareerPath

- Path: `FAQ.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Murodbektuychiyev/CareerPath/blob/2f80c70cb076112a373faa01a69c650361fb9214/FAQ.md
- Repository URL: https://github.com/Murodbektuychiyev/CareerPath
- Assessment: unconfirmed; do not use or test any credentials.

### 1296. P3_LOW_SIGNAL — NASA-IMPACT/science-support

- Path: `README.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/NASA-IMPACT/science-support/blob/6788fcf538576ee84a58f48fecd648ac2662a953/README.md
- Repository URL: https://github.com/NASA-IMPACT/science-support
- Assessment: unconfirmed; do not use or test any credentials.

### 1297. P3_LOW_SIGNAL — NBISweden/single-cell_sib_scilifelab_2021

- Path: `faq.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/NBISweden/single-cell_sib_scilifelab_2021/blob/f88496f6af4f6780f1769768f812583bc790ad77/faq.md
- Repository URL: https://github.com/NBISweden/single-cell_sib_scilifelab_2021
- Assessment: unconfirmed; do not use or test any credentials.

### 1298. P3_LOW_SIGNAL — NBISweden/slack-bot-base

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/NBISweden/slack-bot-base/blob/a2f886ec23225e0484bbcbc5d47a1f9f46bba8c5/README.md
- Repository URL: https://github.com/NBISweden/slack-bot-base
- Assessment: unconfirmed; do not use or test any credentials.

### 1299. P3_LOW_SIGNAL — NDilanka/envseal

- Path: `PLAN.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/NDilanka/envseal/blob/e4786dd72672c99a113ceece85a5553822a3e783/PLAN.md
- Repository URL: https://github.com/NDilanka/envseal
- Assessment: unconfirmed; do not use or test any credentials.

### 1300. P3_LOW_SIGNAL — NERC-CEH/llm-eval

- Path: `cml.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/NERC-CEH/llm-eval/blob/c8162f30ab0f9616b26526c273e55dfa2a1c3b1a/cml.md
- Repository URL: https://github.com/NERC-CEH/llm-eval
- Assessment: unconfirmed; do not use or test any credentials.

### 1301. P3_LOW_SIGNAL — NakoPayHQ/cli

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/NakoPayHQ/cli/blob/9938378c41a9f0fa4e16f192068abad87b523987/README.md
- Repository URL: https://github.com/NakoPayHQ/cli
- Assessment: unconfirmed; do not use or test any credentials.

### 1302. P3_LOW_SIGNAL — NakoPayHQ/plugin-n8n

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/NakoPayHQ/plugin-n8n/blob/b046c2ced7b655a171dbc8df12da33ff0d70eea2/README.md
- Repository URL: https://github.com/NakoPayHQ/plugin-n8n
- Assessment: unconfirmed; do not use or test any credentials.

### 1303. P3_LOW_SIGNAL — Nick-Maro/owl-py

- Path: `flow.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Nick-Maro/owl-py/blob/992fba9ff4921924f9263164057cb154d1d5be80/flow.md
- Repository URL: https://github.com/Nick-Maro/owl-py
- Assessment: unconfirmed; do not use or test any credentials.

### 1304. P3_LOW_SIGNAL — Nightingale13/CGLCreatorLicenseManager

- Path: `FAQ.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Nightingale13/CGLCreatorLicenseManager/blob/395a80bf349aed787c3b34036ae7c89b96b9a77f/FAQ.md
- Repository URL: https://github.com/Nightingale13/CGLCreatorLicenseManager
- Assessment: unconfirmed; do not use or test any credentials.

### 1305. P3_LOW_SIGNAL — NikoMalik/jwt-zig

- Path: `rsa.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/NikoMalik/jwt-zig/blob/49e1339a259b5c5d66c5050ce515ab71c1192386/rsa.md
- Repository URL: https://github.com/NikoMalik/jwt-zig
- Assessment: unconfirmed; do not use or test any credentials.

### 1306. P3_LOW_SIGNAL — Nirmalkoswatta/Monitoring-Dashboard

- Path: `SETUP.md`
- Indicator: `github_token_prefix;github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Nirmalkoswatta/Monitoring-Dashboard/blob/990b7ff762cc89a13bf3ba46159e77f01798a7c0/SETUP.md
- Repository URL: https://github.com/Nirmalkoswatta/Monitoring-Dashboard
- Assessment: unconfirmed; do not use or test any credentials.

### 1307. P3_LOW_SIGNAL — Nolunga/medusa-payment-yoco

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Nolunga/medusa-payment-yoco/blob/212ad192fd512cad3dad4b38643d5c3537a73bca/README.md
- Repository URL: https://github.com/Nolunga/medusa-payment-yoco
- Assessment: unconfirmed; do not use or test any credentials.

### 1308. P3_LOW_SIGNAL — Nouyeutchui28/VeriFAI

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Nouyeutchui28/VeriFAI/blob/3fdf2972bc6f22098b31b3705d4e5d59c8c9d107/SETUP.md
- Repository URL: https://github.com/Nouyeutchui28/VeriFAI
- Assessment: unconfirmed; do not use or test any credentials.

### 1309. P3_LOW_SIGNAL — OMGZui/noteBook

- Path: `docker.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/OMGZui/noteBook/blob/19d48d912e5e07271b370dbe00e498e5f18a29e7/docker.md
- Repository URL: https://github.com/OMGZui/noteBook
- Assessment: unconfirmed; do not use or test any credentials.

### 1310. P3_LOW_SIGNAL — ObscuritySRL/umbriel

- Path: `AI.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ObscuritySRL/umbriel/blob/752d5f28be46ea510f47400e805927b9e9fd44b5/AI.md
- Repository URL: https://github.com/ObscuritySRL/umbriel
- Assessment: unconfirmed; do not use or test any credentials.

### 1311. P3_LOW_SIGNAL — Odunade/MERN-Ecommerce

- Path: `env.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Odunade/MERN-Ecommerce/blob/4edded4afa0933411f920cea5fdf10a7a783ddde/env.md
- Repository URL: https://github.com/Odunade/MERN-Ecommerce
- Assessment: unconfirmed; do not use or test any credentials.

### 1312. P3_LOW_SIGNAL — Oluwasetemi/oluwasetemi.dev

- Path: `llm.txt`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Oluwasetemi/oluwasetemi.dev/blob/8ea525c892083928a726f545077e88b3bd38890b/llm.txt
- Repository URL: https://github.com/Oluwasetemi/oluwasetemi.dev
- Assessment: unconfirmed; do not use or test any credentials.

### 1313. P3_LOW_SIGNAL — OmniSharp/OmniSharp.github.io

- Path: `index.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/OmniSharp/OmniSharp.github.io/blob/d68a2716659afb8dbbe40228a55b6fc6f77147ef/index.md
- Repository URL: https://github.com/OmniSharp/OmniSharp.github.io
- Assessment: unconfirmed; do not use or test any credentials.

### 1314. P3_LOW_SIGNAL — OpenBankProject/OBP-Hola

- Path: `WIP.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/OpenBankProject/OBP-Hola/blob/53b167b9447b12678c4fafa82558ebab2aeae135/WIP.md
- Repository URL: https://github.com/OpenBankProject/OBP-Hola
- Assessment: unconfirmed; do not use or test any credentials.

### 1315. P3_LOW_SIGNAL — OpenHVX/openhvx-backend

- Path: `api.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/OpenHVX/openhvx-backend/blob/414fb095b93182eb3f9a6cae902354c133310b9d/api.md
- Repository URL: https://github.com/OpenHVX/openhvx-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 1316. P3_LOW_SIGNAL — OpenIRL/srt-live-server

- Path: `API.md`
- Indicator: `api_key_label;bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/OpenIRL/srt-live-server/blob/e0348adbd02ce5f5400e452bbac630f42989c6bc/API.md
- Repository URL: https://github.com/OpenIRL/srt-live-server
- Assessment: unconfirmed; do not use or test any credentials.

### 1317. P3_LOW_SIGNAL — OpenSourceMalware/vercel-april2026-incident-response

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/OpenSourceMalware/vercel-april2026-incident-response/blob/5f40993f068dba8988e964756633d66a7b126f75/README.md
- Repository URL: https://github.com/OpenSourceMalware/vercel-april2026-incident-response
- Assessment: unconfirmed; do not use or test any credentials.

### 1318. P3_LOW_SIGNAL — OpsOrch/opsorch-slack-adapter

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/OpsOrch/opsorch-slack-adapter/blob/9caf25a5199cd17fea66dae956cc143952590a7a/README.md
- Repository URL: https://github.com/OpsOrch/opsorch-slack-adapter
- Assessment: unconfirmed; do not use or test any credentials.

### 1319. P3_LOW_SIGNAL — OrkeeAI/orkee

- Path: `DOCS.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/OrkeeAI/orkee/blob/606870b13a05ef400982eeeb6aaa0760030fecc6/DOCS.md
- Repository URL: https://github.com/OrkeeAI/orkee
- Assessment: unconfirmed; do not use or test any credentials.

### 1320. P3_LOW_SIGNAL — Otus-DevOps-2018-11/Sergii703_infra

- Path: `terraform/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Otus-DevOps-2018-11/Sergii703_infra/blob/496ecf1ecd1e827b113785435c87f5384e4c910f/terraform/.terraform.tfstate.lock.info
- Repository URL: https://github.com/Otus-DevOps-2018-11/Sergii703_infra
- Assessment: unconfirmed; do not use or test any credentials.

### 1321. P3_LOW_SIGNAL — Otus-DevOps-2019-08/Actisha_infra

- Path: `terraform/stage/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Otus-DevOps-2019-08/Actisha_infra/blob/fffb84c3945afe7f876279129c1b8dadc91026a1/terraform/stage/.terraform.tfstate.lock.info
- Repository URL: https://github.com/Otus-DevOps-2019-08/Actisha_infra
- Assessment: unconfirmed; do not use or test any credentials.

### 1322. P3_LOW_SIGNAL — Otus-DevOps-2021-05/IlyaBabkin_infra

- Path: `terraform/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Otus-DevOps-2021-05/IlyaBabkin_infra/blob/3ac720d2650d7d260aab7ca17835dda1367b408b/terraform/.terraform.tfstate.lock.info
- Repository URL: https://github.com/Otus-DevOps-2021-05/IlyaBabkin_infra
- Assessment: unconfirmed; do not use or test any credentials.

### 1323. P3_LOW_SIGNAL — Otus-DevOps-2022-05/savimar_infra

- Path: `terraform/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Otus-DevOps-2022-05/savimar_infra/blob/a1a97fe458d3a578b32ccbc719fd5a27189f8e2e/terraform/.terraform.tfstate.lock.info
- Repository URL: https://github.com/Otus-DevOps-2022-05/savimar_infra
- Assessment: unconfirmed; do not use or test any credentials.

### 1324. P3_LOW_SIGNAL — OutOfOrder/sshproxy

- Path: `INSTALL`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/OutOfOrder/sshproxy/blob/a207b44ae1dba5a416ab429074b1f60e3d5d4523/INSTALL
- Repository URL: https://github.com/OutOfOrder/sshproxy
- Assessment: unconfirmed; do not use or test any credentials.

### 1325. P3_LOW_SIGNAL — PAVAN2005-LAB/-LLM-App-Builder-Deployer

- Path: `env.txt`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/PAVAN2005-LAB/-LLM-App-Builder-Deployer/blob/ae8505d25cb6707461f82504839cfb07c768044e/env.txt
- Repository URL: https://github.com/PAVAN2005-LAB/-LLM-App-Builder-Deployer
- Assessment: unconfirmed; do not use or test any credentials.

### 1326. P3_LOW_SIGNAL — PKUJohnson/LearnJaqsByExample

- Path: `AI.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/PKUJohnson/LearnJaqsByExample/blob/fb50168d83280955407d626d1c2dc82037113439/AI.md
- Repository URL: https://github.com/PKUJohnson/LearnJaqsByExample
- Assessment: unconfirmed; do not use or test any credentials.

### 1327. P3_LOW_SIGNAL — PT-Faisal/registry-loot

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/PT-Faisal/registry-loot/blob/d23f74511fe6c08843c2544d45f75138bf763c76/README.md
- Repository URL: https://github.com/PT-Faisal/registry-loot
- Assessment: unconfirmed; do not use or test any credentials.

### 1328. P3_LOW_SIGNAL — PacktPublishing/GitHub-Actions-Cookbook

- Path: `TOC.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/PacktPublishing/GitHub-Actions-Cookbook/blob/6c37b15525334c1a1cb864f4682b79c972618237/TOC.md
- Repository URL: https://github.com/PacktPublishing/GitHub-Actions-Cookbook
- Assessment: unconfirmed; do not use or test any credentials.

### 1329. P3_LOW_SIGNAL — PaoloRollo/openclaw-sec

- Path: `SKILL.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/PaoloRollo/openclaw-sec/blob/6d2666d7f4819b319b2ad8623f2d00756fe6410b/SKILL.md
- Repository URL: https://github.com/PaoloRollo/openclaw-sec
- Assessment: unconfirmed; do not use or test any credentials.

### 1330. P3_LOW_SIGNAL — Parallels/aws-terraform-automation

- Path: `aws_hosts/terraform.tfstate2`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Parallels/aws-terraform-automation/blob/7041aff60138b147680a16361dcc3f70a9372665/aws_hosts/terraform.tfstate2
- Repository URL: https://github.com/Parallels/aws-terraform-automation
- Assessment: unconfirmed; do not use or test any credentials.

### 1331. P3_LOW_SIGNAL — Paulkelvin/WhatsAppMarketPlace

- Path: `SETUP.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Paulkelvin/WhatsAppMarketPlace/blob/094afcb5659beb0ce7570c761c42e0e443b3599a/SETUP.md
- Repository URL: https://github.com/Paulkelvin/WhatsAppMarketPlace
- Assessment: unconfirmed; do not use or test any credentials.

### 1332. P3_LOW_SIGNAL — Phantom-IN/keyreach

- Path: `plan.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Phantom-IN/keyreach/blob/a73f16629289c8a0e132b59c0fb483d3ebe9c800/plan.md
- Repository URL: https://github.com/Phantom-IN/keyreach
- Assessment: unconfirmed; do not use or test any credentials.

### 1333. P3_LOW_SIGNAL — Picrew/codex-claude-relay

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Picrew/codex-claude-relay/blob/4e9af779bdb81395602fc84c2d7d38ae001c7cb1/README.md
- Repository URL: https://github.com/Picrew/codex-claude-relay
- Assessment: unconfirmed; do not use or test any credentials.

### 1334. P3_LOW_SIGNAL — PlugaDotCo/pluga-docs-developers

- Path: `app.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/PlugaDotCo/pluga-docs-developers/blob/65fdd5adeb6bd1fc600dc7e64426a624e70008c8/app.md
- Repository URL: https://github.com/PlugaDotCo/pluga-docs-developers
- Assessment: unconfirmed; do not use or test any credentials.

### 1335. P3_LOW_SIGNAL — Podginator/KoboOmnivoreConverter

- Path: `guide.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Podginator/KoboOmnivoreConverter/blob/7e7742f2c7c2db037a04eb3e6de97db1667fc783/guide.md
- Repository URL: https://github.com/Podginator/KoboOmnivoreConverter
- Assessment: unconfirmed; do not use or test any credentials.

### 1336. P3_LOW_SIGNAL — Pranav03Nair/Goal-Setter

- Path: `env.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Pranav03Nair/Goal-Setter/blob/d06e3a8347f2be16f3b3a0755c1803e0f0aa004f/env.md
- Repository URL: https://github.com/Pranav03Nair/Goal-Setter
- Assessment: unconfirmed; do not use or test any credentials.

### 1337. P3_LOW_SIGNAL — PrintNow/ninebot-monitor

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/PrintNow/ninebot-monitor/blob/06c72a7dc153b4635fa5b8b9d3bba4bd8ed6e358/API.md
- Repository URL: https://github.com/PrintNow/ninebot-monitor
- Assessment: unconfirmed; do not use or test any credentials.

### 1338. P3_LOW_SIGNAL — PrivadoID/polygonid-flutter-sdk

- Path: `AUTH.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/PrivadoID/polygonid-flutter-sdk/blob/632fff77f960df830b6d027a5d9e424d2dca010f/AUTH.md
- Repository URL: https://github.com/PrivadoID/polygonid-flutter-sdk
- Assessment: unconfirmed; do not use or test any credentials.

### 1339. P3_LOW_SIGNAL — ProsusAI/prism

- Path: `DOCS.md`
- Indicator: `github_token_prefix;github_pat_prefix;github_oauth_prefix;github_app_token_prefix;aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ProsusAI/prism/blob/6571f730d896539c0a4d88ceaf0a8d5a83fd47f1/DOCS.md
- Repository URL: https://github.com/ProsusAI/prism
- Assessment: unconfirmed; do not use or test any credentials.

### 1340. P3_LOW_SIGNAL — Ps-Neko/project-doctor

- Path: `PLAN.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Ps-Neko/project-doctor/blob/08977921885b689cd970ffbdd31e0af89c8393e6/PLAN.md
- Repository URL: https://github.com/Ps-Neko/project-doctor
- Assessment: unconfirmed; do not use or test any credentials.

### 1341. P3_LOW_SIGNAL — PublicQuantumNetwork/pqn-node

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/PublicQuantumNetwork/pqn-node/blob/2536160a73db72cd2b0b4cd6d0d24b5c81a0cf08/README.md
- Repository URL: https://github.com/PublicQuantumNetwork/pqn-node
- Assessment: unconfirmed; do not use or test any credentials.

### 1342. P3_LOW_SIGNAL — PushpenderIndia/oscp-notes

- Path: `pwk.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/PushpenderIndia/oscp-notes/blob/a441bffeedc82a2976b3b70120b82ad43111370c/pwk.md
- Repository URL: https://github.com/PushpenderIndia/oscp-notes
- Assessment: unconfirmed; do not use or test any credentials.

### 1343. P3_LOW_SIGNAL — PydaVi/rastro

- Path: `PLAN.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/PydaVi/rastro/blob/4fa396c9b17dfeaa7eb04a1baa6a6dfc2aeac47f/PLAN.md
- Repository URL: https://github.com/PydaVi/rastro
- Assessment: unconfirmed; do not use or test any credentials.

### 1344. P3_LOW_SIGNAL — QodeXcli/QodeX

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/QodeXcli/QodeX/blob/a86e8255c8ee10dfb869f749c152f263be4aaade/README.md
- Repository URL: https://github.com/QodeXcli/QodeX
- Assessment: unconfirmed; do not use or test any credentials.

### 1345. P3_LOW_SIGNAL — RE-EVOLVE-ON-HGI/re-evolve-hgi-amd-act2

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/RE-EVOLVE-ON-HGI/re-evolve-hgi-amd-act2/blob/02be549b1f672eecdb7abe9f303e4126ad9afa40/API.md
- Repository URL: https://github.com/RE-EVOLVE-ON-HGI/re-evolve-hgi-amd-act2
- Assessment: unconfirmed; do not use or test any credentials.

### 1346. P3_LOW_SIGNAL — RHEcosystemAppEng/agentic-plugins

- Path: `SECURITY.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/RHEcosystemAppEng/agentic-plugins/blob/53fa7d8ec99b613eaaf929524de7e391850d9e80/SECURITY.md
- Repository URL: https://github.com/RHEcosystemAppEng/agentic-plugins
- Assessment: unconfirmed; do not use or test any credentials.

### 1347. P3_LOW_SIGNAL — RPBLC-hq/DAM

- Path: `docs/dam-detect.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/RPBLC-hq/DAM/blob/a66461febc452f0ba9c89a589552fafd68290e89/docs/dam-detect.md
- Repository URL: https://github.com/RPBLC-hq/DAM
- Assessment: unconfirmed; do not use or test any credentials.

### 1348. P3_LOW_SIGNAL — RachidChabane/mcp-secrets-vault

- Path: `DEMO.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/RachidChabane/mcp-secrets-vault/blob/8fb014be501ad77df5130029bc7b33b6e9c7e2c9/DEMO.md
- Repository URL: https://github.com/RachidChabane/mcp-secrets-vault
- Assessment: unconfirmed; do not use or test any credentials.

### 1349. P3_LOW_SIGNAL — Radix-Obsidian/apex-factory-core

- Path: `SPEC.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Radix-Obsidian/apex-factory-core/blob/a1a90bcfce531fbec9caacce2afff43c148baefc/SPEC.md
- Repository URL: https://github.com/Radix-Obsidian/apex-factory-core
- Assessment: unconfirmed; do not use or test any credentials.

### 1350. P3_LOW_SIGNAL — Rafael-Martins-Paiva/bioscan-backend

- Path: `p.txt`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Rafael-Martins-Paiva/bioscan-backend/blob/a83c34bb9a8c5780b11bed17fa4620318ff32407/p.txt
- Repository URL: https://github.com/Rafael-Martins-Paiva/bioscan-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 1351. P3_LOW_SIGNAL — Raidan-Ai/RaidanOpencode

- Path: `SECURITY.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Raidan-Ai/RaidanOpencode/blob/89700dddad883f49816446d4ef55c2e9cf881021/SECURITY.md
- Repository URL: https://github.com/Raidan-Ai/RaidanOpencode
- Assessment: unconfirmed; do not use or test any credentials.

### 1352. P3_LOW_SIGNAL — RajLabMSSM/catalogueR

- Path: `NEWS.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/RajLabMSSM/catalogueR/blob/45e3c0c8b3265242cb05d9501ecd822b365fbd06/NEWS.md
- Repository URL: https://github.com/RajLabMSSM/catalogueR
- Assessment: unconfirmed; do not use or test any credentials.

### 1353. P3_LOW_SIGNAL — RajLabMSSM/echolocatoR

- Path: `NEWS.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/RajLabMSSM/echolocatoR/blob/a2a1061772de1e303b01b3be00166af7a1f4ab7d/NEWS.md
- Repository URL: https://github.com/RajLabMSSM/echolocatoR
- Assessment: unconfirmed; do not use or test any credentials.

### 1354. P3_LOW_SIGNAL — Ramakm/ai-agents

- Path: `run.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Ramakm/ai-agents/blob/778e293d1355cc73df354ee3585cb6f06b9bad71/run.md
- Repository URL: https://github.com/Ramakm/ai-agents
- Assessment: unconfirmed; do not use or test any credentials.

### 1355. P3_LOW_SIGNAL — Ramavo22/gestion

- Path: `Note.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Ramavo22/gestion/blob/a23595dfa42965f0be12b2ca4ffd6d572d8ce618/Note.md
- Repository URL: https://github.com/Ramavo22/gestion
- Assessment: unconfirmed; do not use or test any credentials.

### 1356. P3_LOW_SIGNAL — Rambalac/ACDDokanNet

- Path: `Build.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Rambalac/ACDDokanNet/blob/e0d2a7580e2aafc5b0cb632a3448cfbc5f8f947d/Build.md
- Repository URL: https://github.com/Rambalac/ACDDokanNet
- Assessment: unconfirmed; do not use or test any credentials.

### 1357. P3_LOW_SIGNAL — RaoHai/github-bot-token-skill

- Path: `SKILL.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/RaoHai/github-bot-token-skill/blob/da6d24da11b93813a9897472470beb0955447b6f/SKILL.md
- Repository URL: https://github.com/RaoHai/github-bot-token-skill
- Assessment: unconfirmed; do not use or test any credentials.

### 1358. P3_LOW_SIGNAL — Raoof128/mempalace-autopilot

- Path: `SECURITY.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Raoof128/mempalace-autopilot/blob/240a2924c5fb7726d250f50162451715daf40d49/SECURITY.md
- Repository URL: https://github.com/Raoof128/mempalace-autopilot
- Assessment: unconfirmed; do not use or test any credentials.

### 1359. P3_LOW_SIGNAL — Reginaldoportella/TO-DO-SAAS

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Reginaldoportella/TO-DO-SAAS/blob/99cbff92a5d8324b8c6ddee1bb118ebe36eb3597/API.md
- Repository URL: https://github.com/Reginaldoportella/TO-DO-SAAS
- Assessment: unconfirmed; do not use or test any credentials.

### 1360. P3_LOW_SIGNAL — RomiconEZ/agentiq-platform

- Path: `DOC.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/RomiconEZ/agentiq-platform/blob/806074e05d0d86fc8a85c6c3fa9a3ee17066c8df/DOC.md
- Repository URL: https://github.com/RomiconEZ/agentiq-platform
- Assessment: unconfirmed; do not use or test any credentials.

### 1361. P3_LOW_SIGNAL — RominM/Argent_Bank

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/RominM/Argent_Bank/blob/599beb802d82dcc47afdeb800e1fc8a65f4ee933/README.md
- Repository URL: https://github.com/RominM/Argent_Bank
- Assessment: unconfirmed; do not use or test any credentials.

### 1362. P3_LOW_SIGNAL — RoseSecurity/Red-Teaming-TTPs

- Path: `Linux.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/RoseSecurity/Red-Teaming-TTPs/blob/c4080a5ded29017b8163969d54f9382b3eaf2359/Linux.md
- Repository URL: https://github.com/RoseSecurity/Red-Teaming-TTPs
- Assessment: unconfirmed; do not use or test any credentials.

### 1363. P3_LOW_SIGNAL — Rosnaky/portfolio

- Path: `.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Rosnaky/portfolio/blob/a8d4f142076f7e839240c7ac77a8954fe2b4170f/.terraform.tfstate.lock.info
- Repository URL: https://github.com/Rosnaky/portfolio
- Assessment: unconfirmed; do not use or test any credentials.

### 1364. P3_LOW_SIGNAL — Ruhal-Doshi/hld-bench

- Path: `PLAN.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Ruhal-Doshi/hld-bench/blob/3ea452ad8443f2526bdc07e459cf3d4a12788745/PLAN.md
- Repository URL: https://github.com/Ruhal-Doshi/hld-bench
- Assessment: unconfirmed; do not use or test any credentials.

### 1365. P3_LOW_SIGNAL — S8Y/prompt-guard

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/S8Y/prompt-guard/blob/faff812c805f213efcd0159802eac42ebea7c1ea/README.md
- Repository URL: https://github.com/S8Y/prompt-guard
- Assessment: unconfirmed; do not use or test any credentials.

### 1366. P3_LOW_SIGNAL — SIOCODE-Open/local-idp

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/SIOCODE-Open/local-idp/blob/38ba3811698afe6080f874a4eefcfac9e169c6c0/API.md
- Repository URL: https://github.com/SIOCODE-Open/local-idp
- Assessment: unconfirmed; do not use or test any credentials.

### 1367. P3_LOW_SIGNAL — SUNET/edusign-app

- Path: `API.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/SUNET/edusign-app/blob/772201fa9e1413d12b54b9b672b06f737a9f45f9/API.md
- Repository URL: https://github.com/SUNET/edusign-app
- Assessment: unconfirmed; do not use or test any credentials.

### 1368. P3_LOW_SIGNAL — SahanY/tech-briefing

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/SahanY/tech-briefing/blob/fc08bc294ee1bc52b79b15a484b69146924a0595/README.md
- Repository URL: https://github.com/SahanY/tech-briefing
- Assessment: unconfirmed; do not use or test any credentials.

### 1369. P3_LOW_SIGNAL — Sahana-Lakshmipathy/Tutor-WebApp

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Sahana-Lakshmipathy/Tutor-WebApp/blob/136b2eda7ece2f07ef818c0dba9f1924de7f2dcb/SETUP.md
- Repository URL: https://github.com/Sahana-Lakshmipathy/Tutor-WebApp
- Assessment: unconfirmed; do not use or test any credentials.

### 1370. P3_LOW_SIGNAL — SalekhM8/portal365

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/SalekhM8/portal365/blob/f3ac90c5b98058a636137f070d40dc6824c62d37/README.md
- Repository URL: https://github.com/SalekhM8/portal365
- Assessment: unconfirmed; do not use or test any credentials.

### 1371. P3_LOW_SIGNAL — Sathisha/multi-agent-orchestrator

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Sathisha/multi-agent-orchestrator/blob/7f3d3fcb6ef34ef98531cfe0343d42af821bdae3/API.md
- Repository URL: https://github.com/Sathisha/multi-agent-orchestrator
- Assessment: unconfirmed; do not use or test any credentials.

### 1372. P3_LOW_SIGNAL — Seazean/JavaNote

- Path: `Web.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Seazean/JavaNote/blob/5721d65d367c2ecdba3156f84ab73a69ee435019/Web.md
- Repository URL: https://github.com/Seazean/JavaNote
- Assessment: unconfirmed; do not use or test any credentials.

### 1373. P3_LOW_SIGNAL — Semigradsky/fe-events-talks-meetups

- Path: `2017.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Semigradsky/fe-events-talks-meetups/blob/7d04168934f7f6ac8ce948aa97b8efab0f995251/2017.md
- Repository URL: https://github.com/Semigradsky/fe-events-talks-meetups
- Assessment: unconfirmed; do not use or test any credentials.

### 1374. P3_LOW_SIGNAL — Semigradsky/fe-events-talks-meetups

- Path: `2019.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Semigradsky/fe-events-talks-meetups/blob/7d04168934f7f6ac8ce948aa97b8efab0f995251/2019.md
- Repository URL: https://github.com/Semigradsky/fe-events-talks-meetups
- Assessment: unconfirmed; do not use or test any credentials.

### 1375. P3_LOW_SIGNAL — SemilleroDigitalIntro/Proyecto-Ogtic

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/SemilleroDigitalIntro/Proyecto-Ogtic/blob/ee6ea662159482325bce425a640c57af6aff047e/API.md
- Repository URL: https://github.com/SemilleroDigitalIntro/Proyecto-Ogtic
- Assessment: unconfirmed; do not use or test any credentials.

### 1376. P3_LOW_SIGNAL — Senpai-Sama7/nexus-mcp-server

- Path: `PLAN.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Senpai-Sama7/nexus-mcp-server/blob/04a7a66d961e2ecd6dff84e310874df22e2b126f/PLAN.md
- Repository URL: https://github.com/Senpai-Sama7/nexus-mcp-server
- Assessment: unconfirmed; do not use or test any credentials.

### 1377. P3_LOW_SIGNAL — Shadowscr-7/flowmind

- Path: `AUDIT.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Shadowscr-7/flowmind/blob/7351f5eb5b620fadaddb36f4e384d013ed766e72/AUDIT.md
- Repository URL: https://github.com/Shadowscr-7/flowmind
- Assessment: unconfirmed; do not use or test any credentials.

### 1378. P3_LOW_SIGNAL — Sharann-del/API-Keychain

- Path: `FAQ.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Sharann-del/API-Keychain/blob/dbbb6b2d1f2721a4816ce7c5800a980d09668866/FAQ.md
- Repository URL: https://github.com/Sharann-del/API-Keychain
- Assessment: unconfirmed; do not use or test any credentials.

### 1379. P3_LOW_SIGNAL — Sharper-Flow/Advance

- Path: `SETUP.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Sharper-Flow/Advance/blob/c10573e6d3ad771159ea1872f5b477f3c06934a2/SETUP.md
- Repository URL: https://github.com/Sharper-Flow/Advance
- Assessment: unconfirmed; do not use or test any credentials.

### 1380. P3_LOW_SIGNAL — ShiyuNee/AI-Practice

- Path: `key.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ShiyuNee/AI-Practice/blob/62a0e6ec044187f2c432b84af49cb0ebb2ca152a/key.md
- Repository URL: https://github.com/ShiyuNee/AI-Practice
- Assessment: unconfirmed; do not use or test any credentials.

### 1381. P3_LOW_SIGNAL — ShlomiPorush/auth-master

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ShlomiPorush/auth-master/blob/1b99cc6f441c6d32ddb9f44a641f06e535c4bfdf/API.md
- Repository URL: https://github.com/ShlomiPorush/auth-master
- Assessment: unconfirmed; do not use or test any credentials.

### 1382. P3_LOW_SIGNAL — ShujaaPay/shujaapay-sdk-go

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ShujaaPay/shujaapay-sdk-go/blob/693a52c8695a237f243ec4e5049420c0699dfd71/README.md
- Repository URL: https://github.com/ShujaaPay/shujaapay-sdk-go
- Assessment: unconfirmed; do not use or test any credentials.

### 1383. P3_LOW_SIGNAL — Skarlso/slack-notification-action

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Skarlso/slack-notification-action/blob/28f5c1166e2fba7ed5a1d9ceaeb4f2c89a4e5bc5/README.md
- Repository URL: https://github.com/Skarlso/slack-notification-action
- Assessment: unconfirmed; do not use or test any credentials.

### 1384. P3_LOW_SIGNAL — Skizzy-create/redesigned-broccoli

- Path: `PLAN.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Skizzy-create/redesigned-broccoli/blob/8cae72a1197955623b90f754e0d3203a50b30517/PLAN.md
- Repository URL: https://github.com/Skizzy-create/redesigned-broccoli
- Assessment: unconfirmed; do not use or test any credentials.

### 1385. P3_LOW_SIGNAL — SocialGouv/egapro

- Path: `CODEX.md`
- Indicator: `github_token_prefix;github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/SocialGouv/egapro/blob/0c707ccf9dcf38771187b649d7fda0d5f9e5203b/CODEX.md
- Repository URL: https://github.com/SocialGouv/egapro
- Assessment: unconfirmed; do not use or test any credentials.

### 1386. P3_LOW_SIGNAL — Somil450/spectrax_1

- Path: `FAQ.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Somil450/spectrax_1/blob/c81d48c3d218aa51293ff5b3812fa8584b1374a2/FAQ.md
- Repository URL: https://github.com/Somil450/spectrax_1
- Assessment: unconfirmed; do not use or test any credentials.

### 1387. P3_LOW_SIGNAL — Sparky1743/CommunityHero

- Path: `RUN.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Sparky1743/CommunityHero/blob/813fa4531a00ea0da4f1cb3c62bae2dfb60641be/RUN.md
- Repository URL: https://github.com/Sparky1743/CommunityHero
- Assessment: unconfirmed; do not use or test any credentials.

### 1388. P3_LOW_SIGNAL — Spatially/labs

- Path: `ATA.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Spatially/labs/blob/aa386b879a3b7ec43137df34d2d666225efcb01b/ATA.md
- Repository URL: https://github.com/Spatially/labs
- Assessment: unconfirmed; do not use or test any credentials.

### 1389. P3_LOW_SIGNAL — Spatially/labs

- Path: `DB.md`
- Indicator: `access_token_label;bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Spatially/labs/blob/aa386b879a3b7ec43137df34d2d666225efcb01b/DB.md
- Repository URL: https://github.com/Spatially/labs
- Assessment: unconfirmed; do not use or test any credentials.

### 1390. P3_LOW_SIGNAL — SqrtNegInf/Rosettacode-Raku-Smoke

- Path: `F/FTP`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/SqrtNegInf/Rosettacode-Raku-Smoke/blob/eeda2d3a9e26b3ed767c9168ac6791a20515d353/F/FTP
- Repository URL: https://github.com/SqrtNegInf/Rosettacode-Raku-Smoke
- Assessment: unconfirmed; do not use or test any credentials.

### 1391. P3_LOW_SIGNAL — SrLuther/ARKLAND

- Path: `SETUP.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/SrLuther/ARKLAND/blob/94120bb1827dd6e18e2e3c12c5fe29ea4d7906b3/SETUP.md
- Repository URL: https://github.com/SrLuther/ARKLAND
- Assessment: unconfirmed; do not use or test any credentials.

### 1392. P3_LOW_SIGNAL — SreejanPersonal/Automate-YT-Shorts-Video-Resource-

- Path: `ENV.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/SreejanPersonal/Automate-YT-Shorts-Video-Resource-/blob/dd8a495a450750771204338291d86d4b74c602e4/ENV.md
- Repository URL: https://github.com/SreejanPersonal/Automate-YT-Shorts-Video-Resource-
- Assessment: unconfirmed; do not use or test any credentials.

### 1393. P3_LOW_SIGNAL — StamKavid/last-ds-mile

- Path: `AUDIT.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/StamKavid/last-ds-mile/blob/5d2d7405c4a83424a30e86710114b6d0972d58fa/AUDIT.md
- Repository URL: https://github.com/StamKavid/last-ds-mile
- Assessment: unconfirmed; do not use or test any credentials.

### 1394. P3_LOW_SIGNAL — Stevebel/Slack-Standup-Bot

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Stevebel/Slack-Standup-Bot/blob/a7e7615b221bfd0641c9d6612b661734200316f0/README.md
- Repository URL: https://github.com/Stevebel/Slack-Standup-Bot
- Assessment: unconfirmed; do not use or test any credentials.

### 1395. P3_LOW_SIGNAL — StratocasterO/Node-IT-Academy

- Path: `MERN.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/StratocasterO/Node-IT-Academy/blob/01d650ecb39ae86464356fd9f83f58f0bdca03d6/MERN.md
- Repository URL: https://github.com/StratocasterO/Node-IT-Academy
- Assessment: unconfirmed; do not use or test any credentials.

### 1396. P3_LOW_SIGNAL — Su1ph3r/vercelsior

- Path: `TODO.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Su1ph3r/vercelsior/blob/6b90e29ca7f7f55f552c588c6d6121abc6a6d8bd/TODO.md
- Repository URL: https://github.com/Su1ph3r/vercelsior
- Assessment: unconfirmed; do not use or test any credentials.

### 1397. P3_LOW_SIGNAL — Swastik2425/LekhaJokha

- Path: `RUN.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Swastik2425/LekhaJokha/blob/59a61391780aa3caa47dd17b106419c4b576ad58/RUN.md
- Repository URL: https://github.com/Swastik2425/LekhaJokha
- Assessment: unconfirmed; do not use or test any credentials.

### 1398. P3_LOW_SIGNAL — Sync-CAPACITI/movie_database

- Path: `.rest`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Sync-CAPACITI/movie_database/blob/f9cb4321b37322af00cbc895f9b4a6df33646d6e/.rest
- Repository URL: https://github.com/Sync-CAPACITI/movie_database
- Assessment: unconfirmed; do not use or test any credentials.

### 1399. P3_LOW_SIGNAL — T8mars/T8-penguin-canvas

- Path: `rh.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/T8mars/T8-penguin-canvas/blob/08ba7fb6e96004648f5cf8b05fce8ee5ed3169b9/rh.md
- Repository URL: https://github.com/T8mars/T8-penguin-canvas
- Assessment: unconfirmed; do not use or test any credentials.

### 1400. P3_LOW_SIGNAL — TGDK-ST108/OliviaAI-SO

- Path: `M0.1`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/TGDK-ST108/OliviaAI-SO/blob/51beac2e755687d934b20d85c0ed21f94ca74ce9/M0.1
- Repository URL: https://github.com/TGDK-ST108/OliviaAI-SO
- Assessment: unconfirmed; do not use or test any credentials.

### 1401. P3_LOW_SIGNAL — Taka1304/Emoji-Notification-SlackBot

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Taka1304/Emoji-Notification-SlackBot/blob/d3962305108e6ec22d1a2b73e61dbe30b448370e/README.md
- Repository URL: https://github.com/Taka1304/Emoji-Notification-SlackBot
- Assessment: unconfirmed; do not use or test any credentials.

### 1402. P3_LOW_SIGNAL — TapTap-Pay/sdk-php

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/TapTap-Pay/sdk-php/blob/6d97f84f20d8bf630221b839e6cedb05e1b1b031/README.md
- Repository URL: https://github.com/TapTap-Pay/sdk-php
- Assessment: unconfirmed; do not use or test any credentials.

### 1403. P3_LOW_SIGNAL — Tekergo2004/Windows-PS

- Path: `dhcp.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Tekergo2004/Windows-PS/blob/284515f990e00282210a38c66d5d8451b547ea60/dhcp.md
- Repository URL: https://github.com/Tekergo2004/Windows-PS
- Assessment: unconfirmed; do not use or test any credentials.

### 1404. P3_LOW_SIGNAL — Teycir/ApiHunter

- Path: `README.md`
- Indicator: `github_token_prefix;github_pat_prefix;stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Teycir/ApiHunter/blob/ab26ccf3e25bf5e79e3c1a7926a99dfa2bf8764b/README.md
- Repository URL: https://github.com/Teycir/ApiHunter
- Assessment: unconfirmed; do not use or test any credentials.

### 1405. P3_LOW_SIGNAL — Thatgfsj/neuroweave-timeline

- Path: `SECURITY.md`
- Indicator: `github_oauth_prefix;github_app_token_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Thatgfsj/neuroweave-timeline/blob/c99ecf02af93142ef3556d983d4ee33b4f582a3d/SECURITY.md
- Repository URL: https://github.com/Thatgfsj/neuroweave-timeline
- Assessment: unconfirmed; do not use or test any credentials.

### 1406. P3_LOW_SIGNAL — The-Swarm-Corporation/slop-detector

- Path: `DOCS.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/The-Swarm-Corporation/slop-detector/blob/f6bcd6f6189431d3c95dbb352d9cd165f4344662/DOCS.md
- Repository URL: https://github.com/The-Swarm-Corporation/slop-detector
- Assessment: unconfirmed; do not use or test any credentials.

### 1407. P3_LOW_SIGNAL — TheSnowyxGIT/mocha-light

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/TheSnowyxGIT/mocha-light/blob/92e323ef17d4bcc2ef2cdae1f25c52451ce9c66d/README.md
- Repository URL: https://github.com/TheSnowyxGIT/mocha-light
- Assessment: unconfirmed; do not use or test any credentials.

### 1408. P3_LOW_SIGNAL — ThomasRohde/hue-mcp

- Path: `mcp.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ThomasRohde/hue-mcp/blob/4b414f61e6ce427b3776d3a52d7cefcd11af7989/mcp.md
- Repository URL: https://github.com/ThomasRohde/hue-mcp
- Assessment: unconfirmed; do not use or test any credentials.

### 1409. P3_LOW_SIGNAL — ThoughtLeaders-io/thoughtleaders-cli

- Path: `API.md`
- Indicator: `api_key_label;bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ThoughtLeaders-io/thoughtleaders-cli/blob/a914815437266f281df864fab5126a91f428703a/API.md
- Repository URL: https://github.com/ThoughtLeaders-io/thoughtleaders-cli
- Assessment: unconfirmed; do not use or test any credentials.

### 1410. P3_LOW_SIGNAL — Tochey/CPSS

- Path: `.rest`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Tochey/CPSS/blob/e410e5109092f670c0758ecf32ed678be1cc3636/.rest
- Repository URL: https://github.com/Tochey/CPSS
- Assessment: unconfirmed; do not use or test any credentials.

### 1411. P3_LOW_SIGNAL — TonyVM/qa-assistant

- Path: `DEMO.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/TonyVM/qa-assistant/blob/8b8d1c875f49d3c0818da61ea50ef6608eb081a4/DEMO.md
- Repository URL: https://github.com/TonyVM/qa-assistant
- Assessment: unconfirmed; do not use or test any credentials.

### 1412. P3_LOW_SIGNAL — Torxed/github-autorun

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Torxed/github-autorun/blob/068816a61e6918374ca4dc9a8e54008a2918e7d7/README.md
- Repository URL: https://github.com/Torxed/github-autorun
- Assessment: unconfirmed; do not use or test any credentials.

### 1413. P3_LOW_SIGNAL — TotalLag/curl-mcp-fly

- Path: `README.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/TotalLag/curl-mcp-fly/blob/0e37d4de077445105f70183bcd7d1d797a3f7946/README.md
- Repository URL: https://github.com/TotalLag/curl-mcp-fly
- Assessment: unconfirmed; do not use or test any credentials.

### 1414. P3_LOW_SIGNAL — Trendyol/awesome-regex-list

- Path: `README.md`
- Indicator: `github_pat_prefix;github_app_token_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Trendyol/awesome-regex-list/blob/1ede3f6a7d58807fcf7271b7988623b434bb728f/README.md
- Repository URL: https://github.com/Trendyol/awesome-regex-list
- Assessment: unconfirmed; do not use or test any credentials.

### 1415. P3_LOW_SIGNAL — Twingate-Labs/tg-group-profile-manager-helm

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Twingate-Labs/tg-group-profile-manager-helm/blob/60affada2a8e6be465c3dab35ec456e62b278826/README.md
- Repository URL: https://github.com/Twingate-Labs/tg-group-profile-manager-helm
- Assessment: unconfirmed; do not use or test any credentials.

### 1416. P3_LOW_SIGNAL — TwistingTwists/learning-concurrent-elixir

- Path: `logs.md`
- Indicator: `secret_access_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/TwistingTwists/learning-concurrent-elixir/blob/24e3d6e49e8683785574bb4aac0f6fd138a4aaed/logs.md
- Repository URL: https://github.com/TwistingTwists/learning-concurrent-elixir
- Assessment: unconfirmed; do not use or test any credentials.

### 1417. P3_LOW_SIGNAL — UniAIStudio2048/uniai-studio

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/UniAIStudio2048/uniai-studio/blob/5bf2fa4f7f83a3e27600478f8ca759eeaa1749da/API.md
- Repository URL: https://github.com/UniAIStudio2048/uniai-studio
- Assessment: unconfirmed; do not use or test any credentials.

### 1418. P3_LOW_SIGNAL — Valentine-Mario/Graph_FS

- Path: `DOC.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Valentine-Mario/Graph_FS/blob/4894c46c6b2802f30aaf3495ecc001e417b51a6e/DOC.md
- Repository URL: https://github.com/Valentine-Mario/Graph_FS
- Assessment: unconfirmed; do not use or test any credentials.

### 1419. P3_LOW_SIGNAL — VeeqoAPI/api-docs

- Path: `api.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/VeeqoAPI/api-docs/blob/b567d7c16a068ed69c395c71a27e0c7b12a8f1a9/api.md
- Repository URL: https://github.com/VeeqoAPI/api-docs
- Assessment: unconfirmed; do not use or test any credentials.

### 1420. P3_LOW_SIGNAL — Vespa314/bilibili-api

- Path: `api.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Vespa314/bilibili-api/blob/42b6b90aa7c141f5cfb0fdc754435518106f6966/api.md
- Repository URL: https://github.com/Vespa314/bilibili-api
- Assessment: unconfirmed; do not use or test any credentials.

### 1421. P3_LOW_SIGNAL — Vincenius/sponsor-ninja

- Path: `README.MD`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Vincenius/sponsor-ninja/blob/6aafc5f3cf78e28d586660bc313970509f3ad422/README.MD
- Repository URL: https://github.com/Vincenius/sponsor-ninja
- Assessment: unconfirmed; do not use or test any credentials.

### 1422. P3_LOW_SIGNAL — Viviansillage/Hushtohues125

- Path: `DOCS.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Viviansillage/Hushtohues125/blob/27616c94ecb3633730bcfb58e49b345da3173c3c/DOCS.md
- Repository URL: https://github.com/Viviansillage/Hushtohues125
- Assessment: unconfirmed; do not use or test any credentials.

### 1423. P3_LOW_SIGNAL — Vyary/tiny-guides

- Path: `k3s.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Vyary/tiny-guides/blob/f9fd5edc093cc2d3a34f44763781b7794c004104/k3s.md
- Repository URL: https://github.com/Vyary/tiny-guides
- Assessment: unconfirmed; do not use or test any credentials.

### 1424. P3_LOW_SIGNAL — WangLaoShi/Aliyun-Python

- Path: `All.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/WangLaoShi/Aliyun-Python/blob/df3bc4c1bf80a3340677f9c1d4e98fab55522ad7/All.md
- Repository URL: https://github.com/WangLaoShi/Aliyun-Python
- Assessment: unconfirmed; do not use or test any credentials.

### 1425. P3_LOW_SIGNAL — WildVision-AI/WildVision-Arena

- Path: `GCP.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/WildVision-AI/WildVision-Arena/blob/364d739c1f4fcf369db8363f17dc49e38dfb7ac4/GCP.md
- Repository URL: https://github.com/WildVision-AI/WildVision-Arena
- Assessment: unconfirmed; do not use or test any credentials.

### 1426. P3_LOW_SIGNAL — WiredMind2/WiredMind2

- Path: `AGENTS.md`
- Indicator: `github_pat_prefix;github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/WiredMind2/WiredMind2/blob/147070b8ad8be72ed05931ccc765dcf3700bfdb9/AGENTS.md
- Repository URL: https://github.com/WiredMind2/WiredMind2
- Assessment: unconfirmed; do not use or test any credentials.

### 1427. P3_LOW_SIGNAL — XORCISM-AI/XORCISM

- Path: `API.md`
- Indicator: `api_key_label;bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/XORCISM-AI/XORCISM/blob/0e496167f0d8a069161bdbaa390523cbc04bc271/API.md
- Repository URL: https://github.com/XORCISM-AI/XORCISM
- Assessment: unconfirmed; do not use or test any credentials.

### 1428. P3_LOW_SIGNAL — Xrenes/DBMS-main

- Path: `PUSH.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Xrenes/DBMS-main/blob/62869ae1d5039e629f8ec6a55d509885b321d42e/PUSH.md
- Repository URL: https://github.com/Xrenes/DBMS-main
- Assessment: unconfirmed; do not use or test any credentials.

### 1429. P3_LOW_SIGNAL — XyraSinclair/skills

- Path: `AGENTS.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/XyraSinclair/skills/blob/2659571645ea4727ffc0ff69e5c0fe2200cd610a/AGENTS.md
- Repository URL: https://github.com/XyraSinclair/skills
- Assessment: unconfirmed; do not use or test any credentials.

### 1430. P3_LOW_SIGNAL — YOYOW-Association/Homeland-with-YOYOW

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/YOYOW-Association/Homeland-with-YOYOW/blob/88a0f0f5ee956cf9d1fb9db5025a3f6e0f85813b/API.md
- Repository URL: https://github.com/YOYOW-Association/Homeland-with-YOYOW
- Assessment: unconfirmed; do not use or test any credentials.

### 1431. P3_LOW_SIGNAL — Yarden-zamir/gh-source

- Path: `Readme.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Yarden-zamir/gh-source/blob/82ffd100a5cc4eab306d3234ab71b9ea55122062/Readme.md
- Repository URL: https://github.com/Yarden-zamir/gh-source
- Assessment: unconfirmed; do not use or test any credentials.

### 1432. P3_LOW_SIGNAL — YibinLong/MessageAI

- Path: `PRD.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/YibinLong/MessageAI/blob/c55d85f553a8a09d7cc1d77315126abb9e0c3f1c/PRD.md
- Repository URL: https://github.com/YibinLong/MessageAI
- Assessment: unconfirmed; do not use or test any credentials.

### 1433. P3_LOW_SIGNAL — YiwuZhong/Sub-GC

- Path: `DATA.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/YiwuZhong/Sub-GC/blob/5170ccd4b21ed7dc5854b170400b5ff979d2ec1c/DATA.md
- Repository URL: https://github.com/YiwuZhong/Sub-GC
- Assessment: unconfirmed; do not use or test any credentials.

### 1434. P3_LOW_SIGNAL — YoavLax/agent-compass

- Path: `plan.md`
- Indicator: `github_token_prefix;aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/YoavLax/agent-compass/blob/06fc57831655b9fc773767dd82f190f8657d5609/plan.md
- Repository URL: https://github.com/YoavLax/agent-compass
- Assessment: unconfirmed; do not use or test any credentials.

### 1435. P3_LOW_SIGNAL — YorkUITInnovation/markitdown-api

- Path: `SOP.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/YorkUITInnovation/markitdown-api/blob/e3d6f1994a42f3e5170c725d25ea30a923ed9d76/SOP.md
- Repository URL: https://github.com/YorkUITInnovation/markitdown-api
- Assessment: unconfirmed; do not use or test any credentials.

### 1436. P3_LOW_SIGNAL — Youshu31415926/aliyun-cloudpush

- Path: `README.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Youshu31415926/aliyun-cloudpush/blob/d427739cb957dedf740829f95d118f847f79a401/README.md
- Repository URL: https://github.com/Youshu31415926/aliyun-cloudpush
- Assessment: unconfirmed; do not use or test any credentials.

### 1437. P3_LOW_SIGNAL — Yubico/yubico-piv-tool

- Path: `NEWS`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Yubico/yubico-piv-tool/blob/c987afb892a565d210d5d674fa2e3300e19e14da/NEWS
- Repository URL: https://github.com/Yubico/yubico-piv-tool
- Assessment: unconfirmed; do not use or test any credentials.

### 1438. P3_LOW_SIGNAL — Yuiinars/short-link-tracker-remover

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Yuiinars/short-link-tracker-remover/blob/7778f6f19a5c1269297d29256da3805088a336ac/API.md
- Repository URL: https://github.com/Yuiinars/short-link-tracker-remover
- Assessment: unconfirmed; do not use or test any credentials.

### 1439. P3_LOW_SIGNAL — ZainulabdeenOfficial/github-language-stats-card-main

- Path: `learn.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ZainulabdeenOfficial/github-language-stats-card-main/blob/d237851a20de639a166057f58c4b69d2dd1ad535/learn.md
- Repository URL: https://github.com/ZainulabdeenOfficial/github-language-stats-card-main
- Assessment: unconfirmed; do not use or test any credentials.

### 1440. P3_LOW_SIGNAL — Zarl-prog/Smart-git-commit

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Zarl-prog/Smart-git-commit/blob/29198720171df80317ca228d0bf508c70f95621f/README.md
- Repository URL: https://github.com/Zarl-prog/Smart-git-commit
- Assessment: unconfirmed; do not use or test any credentials.

### 1441. P3_LOW_SIGNAL — Zen-Open-Source/coyote-security-scanner

- Path: `README.md`
- Indicator: `github_app_token_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Zen-Open-Source/coyote-security-scanner/blob/05942524fa9d941b6b78179ffdc5e45bca625ac3/README.md
- Repository URL: https://github.com/Zen-Open-Source/coyote-security-scanner
- Assessment: unconfirmed; do not use or test any credentials.

### 1442. P3_LOW_SIGNAL — ZenLuca170018137/AC41004-project

- Path: `.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ZenLuca170018137/AC41004-project/blob/9a66195125a6881cca484c171c91431b278f0ea5/.terraform.tfstate.lock.info
- Repository URL: https://github.com/ZenLuca170018137/AC41004-project
- Assessment: unconfirmed; do not use or test any credentials.

### 1443. P3_LOW_SIGNAL — Zeuyel/navie_

- Path: `tfa.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Zeuyel/navie_/blob/10830ae5aa982d6c6bbca4930ffe0ff93cebe3de/tfa.md
- Repository URL: https://github.com/Zeuyel/navie_
- Assessment: unconfirmed; do not use or test any credentials.

### 1444. P3_LOW_SIGNAL — ZhuoJiayanStudio/blog

- Path: `5.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ZhuoJiayanStudio/blog/blob/2995248aa2d115086f3a7c555639fcb8448dee77/5.md
- Repository URL: https://github.com/ZhuoJiayanStudio/blog
- Assessment: unconfirmed; do not use or test any credentials.

### 1445. P3_LOW_SIGNAL — Zierax/My-Recon-Methology

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Zierax/My-Recon-Methology/blob/6ee5874ebf270e0f7511d29439110392575179b4/README.md
- Repository URL: https://github.com/Zierax/My-Recon-Methology
- Assessment: unconfirmed; do not use or test any credentials.

### 1446. P3_LOW_SIGNAL — Zitihsk-leduap/omnidata-rag

- Path: `Run.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Zitihsk-leduap/omnidata-rag/blob/2f7370938b73c789af50cbe5c6b6fa48cfda4866/Run.md
- Repository URL: https://github.com/Zitihsk-leduap/omnidata-rag
- Assessment: unconfirmed; do not use or test any credentials.

### 1447. P3_LOW_SIGNAL — Zunderene/Terraform

- Path: `.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/Zunderene/Terraform/blob/0586d8fdfde292c1ad536015a6387f0cca600b7e/.terraform.tfstate.lock.info
- Repository URL: https://github.com/Zunderene/Terraform
- Assessment: unconfirmed; do not use or test any credentials.

### 1448. P3_LOW_SIGNAL — a-qalmuratov/Kara_One

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/a-qalmuratov/Kara_One/blob/a788d747db7b642faf16c698f94123d7cdcf5ddc/API.md
- Repository URL: https://github.com/a-qalmuratov/Kara_One
- Assessment: unconfirmed; do not use or test any credentials.

### 1449. P3_LOW_SIGNAL — a2wio/lucas

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/a2wio/lucas/blob/b1efde07855f1895a2b9b9957890348133766ac2/README.md
- Repository URL: https://github.com/a2wio/lucas
- Assessment: unconfirmed; do not use or test any credentials.

### 1450. P3_LOW_SIGNAL — a5c-ai/registry

- Path: `a5c.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/a5c-ai/registry/blob/a3cc7ae9608f006b0708d77583f43e981a5b9813/a5c.md
- Repository URL: https://github.com/a5c-ai/registry
- Assessment: unconfirmed; do not use or test any credentials.

### 1451. P3_LOW_SIGNAL — aaronching15/ciss_web

- Path: `id_rsa_gitee`
- Indicator: `private_key_file`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/aaronching15/ciss_web/blob/d56418c71b8df0a9120cd4cdbcb7550ae25608b1/id_rsa_gitee
- Repository URL: https://github.com/aaronching15/ciss_web
- Assessment: unconfirmed; do not use or test any credentials.

### 1452. P3_LOW_SIGNAL — abachurin/2048

- Path: `aws.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/abachurin/2048/blob/460ffd2f50fc4c696daadae76b7a11457abc0af8/aws.md
- Repository URL: https://github.com/abachurin/2048
- Assessment: unconfirmed; do not use or test any credentials.

### 1453. P3_LOW_SIGNAL — abduznik/reposnap-mcp

- Path: `API.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/abduznik/reposnap-mcp/blob/2e69dd6db96d6ae2dc409a2e25cde3ddbda88344/API.md
- Repository URL: https://github.com/abduznik/reposnap-mcp
- Assessment: unconfirmed; do not use or test any credentials.

### 1454. P3_LOW_SIGNAL — abhijeetkakade1234/PROMPT-WARS

- Path: `KEYS.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/abhijeetkakade1234/PROMPT-WARS/blob/6aafe1f11dd59b84cc9c5433460c8334ffbb47c9/KEYS.md
- Repository URL: https://github.com/abhijeetkakade1234/PROMPT-WARS
- Assessment: unconfirmed; do not use or test any credentials.

### 1455. P3_LOW_SIGNAL — abhishekbhonde/why-production-is-down

- Path: `SETUP.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/abhishekbhonde/why-production-is-down/blob/f8606a556e4e10f905333c5be6949313843596c6/SETUP.md
- Repository URL: https://github.com/abhishekbhonde/why-production-is-down
- Assessment: unconfirmed; do not use or test any credentials.

### 1456. P3_LOW_SIGNAL — acoshift/go-project-guideline

- Path: `sql.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/acoshift/go-project-guideline/blob/6ed357c6a0419b385d34b01bae324372e530be77/sql.md
- Repository URL: https://github.com/acoshift/go-project-guideline
- Assessment: unconfirmed; do not use or test any credentials.

### 1457. P3_LOW_SIGNAL — actions/delete-package-versions

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/actions/delete-package-versions/blob/4dbb860504f6d0cde296a192842138c03915746a/README.md
- Repository URL: https://github.com/actions/delete-package-versions
- Assessment: unconfirmed; do not use or test any credentials.

### 1458. P3_LOW_SIGNAL — adaliea/FantasyFirstSlackBot

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/adaliea/FantasyFirstSlackBot/blob/5d3b5622a2f53b3a5db1f6a05455ad4a1134f61e/README.md
- Repository URL: https://github.com/adaliea/FantasyFirstSlackBot
- Assessment: unconfirmed; do not use or test any credentials.

### 1459. P3_LOW_SIGNAL — adamhjouj/ShieldClaw

- Path: `FGA.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/adamhjouj/ShieldClaw/blob/87db66122f78b3c78108921b7bc73217c01ff587/FGA.md
- Repository URL: https://github.com/adamhjouj/ShieldClaw
- Assessment: unconfirmed; do not use or test any credentials.

### 1460. P3_LOW_SIGNAL — adarshmishra07/claw-control

- Path: `SKILL.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/adarshmishra07/claw-control/blob/bfb0c17497a98c3f11c371faf5d07af4814fbec1/SKILL.md
- Repository URL: https://github.com/adarshmishra07/claw-control
- Assessment: unconfirmed; do not use or test any credentials.

### 1461. P3_LOW_SIGNAL — adarshsri880/Terraform-Based-AWS-Infrastructure-Setup-IAM-EC2-S3-

- Path: `.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/adarshsri880/Terraform-Based-AWS-Infrastructure-Setup-IAM-EC2-S3-/blob/b48fc92c8f08d9b45e279f3fc020ac9770040423/.terraform.tfstate.lock.info
- Repository URL: https://github.com/adarshsri880/Terraform-Based-AWS-Infrastructure-Setup-IAM-EC2-S3-
- Assessment: unconfirmed; do not use or test any credentials.

### 1462. P3_LOW_SIGNAL — adervark/chatbot

- Path: `DEMO.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/adervark/chatbot/blob/26331c547e5b12be44b7c0e3b067c56f4e7c2e34/DEMO.md
- Repository URL: https://github.com/adervark/chatbot
- Assessment: unconfirmed; do not use or test any credentials.

### 1463. P3_LOW_SIGNAL — adhikarisidd17/ai-based-data-engineering

- Path: `README.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/adhikarisidd17/ai-based-data-engineering/blob/a2b9a9d7652afb57c0ac5e99913874b0b9fd2fd8/README.md
- Repository URL: https://github.com/adhikarisidd17/ai-based-data-engineering
- Assessment: unconfirmed; do not use or test any credentials.

### 1464. P3_LOW_SIGNAL — adithyan-ak/agentmask

- Path: `CLAUDE.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/adithyan-ak/agentmask/blob/a6c5ebcf1cb2f2baff45a1c3584586a1c47e814f/CLAUDE.md
- Repository URL: https://github.com/adithyan-ak/agentmask
- Assessment: unconfirmed; do not use or test any credentials.

### 1465. P3_LOW_SIGNAL — adobe/second-o-pi-nion

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/adobe/second-o-pi-nion/blob/97dcc132d7f88c76126708ffdeed31dad40db065/README.md
- Repository URL: https://github.com/adobe/second-o-pi-nion
- Assessment: unconfirmed; do not use or test any credentials.

### 1466. P3_LOW_SIGNAL — adoresever/big-blue-book

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/adoresever/big-blue-book/blob/f4d01ca6be58a361b23b4f62f0fc4af4c3a8d4ef/README.md
- Repository URL: https://github.com/adoresever/big-blue-book
- Assessment: unconfirmed; do not use or test any credentials.

### 1467. P3_LOW_SIGNAL — aethyriion/five-ai

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/aethyriion/five-ai/blob/b260f455e2c88ff773d9ca9f26c87bb0535da7c4/SETUP.md
- Repository URL: https://github.com/aethyriion/five-ai
- Assessment: unconfirmed; do not use or test any credentials.

### 1468. P3_LOW_SIGNAL — afiz05/sintesa_NEXT

- Path: `.rest`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/afiz05/sintesa_NEXT/blob/4fbd5e85c972c45dce54e15aa62132f734f481f9/.rest
- Repository URL: https://github.com/afiz05/sintesa_NEXT
- Assessment: unconfirmed; do not use or test any credentials.

### 1469. P3_LOW_SIGNAL — afria85/LogShield

- Path: `ROADMAP.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/afria85/LogShield/blob/ac13855d7d0043f8f063557b2ca3df5729d444a9/ROADMAP.md
- Repository URL: https://github.com/afria85/LogShield
- Assessment: unconfirmed; do not use or test any credentials.

### 1470. P3_LOW_SIGNAL — agent37-platform/custom-agent-image

- Path: `SETUP.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/agent37-platform/custom-agent-image/blob/d5b6aa9e1771879cf80aa97877038a55c222021e/SETUP.md
- Repository URL: https://github.com/agent37-platform/custom-agent-image
- Assessment: unconfirmed; do not use or test any credentials.

### 1471. P3_LOW_SIGNAL — agent37-platform/hermes-byo-model

- Path: `SETUP.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/agent37-platform/hermes-byo-model/blob/93c0627c3bec24fd2f7211bdbeee8f7d972acc04/SETUP.md
- Repository URL: https://github.com/agent37-platform/hermes-byo-model
- Assessment: unconfirmed; do not use or test any credentials.

### 1472. P3_LOW_SIGNAL — agent37-platform/hermes-openclaw-composio

- Path: `SETUP.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/agent37-platform/hermes-openclaw-composio/blob/aeb79c8444e6e443b4b71d88a2bf0d620ab31f72/SETUP.md
- Repository URL: https://github.com/agent37-platform/hermes-openclaw-composio
- Assessment: unconfirmed; do not use or test any credentials.

### 1473. P3_LOW_SIGNAL — agentstation/ripley

- Path: `PLAN.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/agentstation/ripley/blob/8592956b5e8380e26aae770be7ef0618fde0d1f3/PLAN.md
- Repository URL: https://github.com/agentstation/ripley
- Assessment: unconfirmed; do not use or test any credentials.

### 1474. P3_LOW_SIGNAL — aglili/paystackpay

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/aglili/paystackpay/blob/d74f961c60165309a795213103d5b50302854778/README.md
- Repository URL: https://github.com/aglili/paystackpay
- Assessment: unconfirmed; do not use or test any credentials.

### 1475. P3_LOW_SIGNAL — agno-agi/coda

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/agno-agi/coda/blob/8a94cf54f3cc135027f8de75188930e0467b4fa1/README.md
- Repository URL: https://github.com/agno-agi/coda
- Assessment: unconfirmed; do not use or test any credentials.

### 1476. P3_LOW_SIGNAL — agstack/OpenAgri-GateKeeper

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/agstack/OpenAgri-GateKeeper/blob/49f4bc3c37e5c2d08e715049b55ae8d902e2ec7a/API.md
- Repository URL: https://github.com/agstack/OpenAgri-GateKeeper
- Assessment: unconfirmed; do not use or test any credentials.

### 1477. P3_LOW_SIGNAL — agstack/OpenAgri-PestAndDiseaseManagement

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/agstack/OpenAgri-PestAndDiseaseManagement/blob/3aa67a9ad3de6ff8a772dc635db041ec53845aa4/API.md
- Repository URL: https://github.com/agstack/OpenAgri-PestAndDiseaseManagement
- Assessment: unconfirmed; do not use or test any credentials.

### 1478. P3_LOW_SIGNAL — ahmadawais/dotfiles

- Path: `.zshrc`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ahmadawais/dotfiles/blob/4ce4b3fa0873299d7ef276fe6686fecb396c3c5d/.zshrc
- Repository URL: https://github.com/ahmadawais/dotfiles
- Assessment: unconfirmed; do not use or test any credentials.

### 1479. P3_LOW_SIGNAL — aibcdev/adsapp

- Path: `ENV.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/aibcdev/adsapp/blob/098908bb48caa06e08a73fe7763e9bbd46d8f29b/ENV.md
- Repository URL: https://github.com/aibcdev/adsapp
- Assessment: unconfirmed; do not use or test any credentials.

### 1480. P3_LOW_SIGNAL — aichisuan/asd-command

- Path: `info.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/aichisuan/asd-command/blob/d098067e6738a7fafb9e395d4db7ad900f534f34/info.md
- Repository URL: https://github.com/aichisuan/asd-command
- Assessment: unconfirmed; do not use or test any credentials.

### 1481. P3_LOW_SIGNAL — akaanakbaik/coding-agent-template

- Path: `AGENTS.md`
- Indicator: `github_app_token_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/akaanakbaik/coding-agent-template/blob/9633ea014df1ba6c1f340814acab04acbfea4110/AGENTS.md
- Repository URL: https://github.com/akaanakbaik/coding-agent-template
- Assessment: unconfirmed; do not use or test any credentials.

### 1482. P3_LOW_SIGNAL — akhilathuluri/Quiz-app

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/akhilathuluri/Quiz-app/blob/eaaa9643fb2636e3fda96cdad4f786d1f4bdc855/SETUP.md
- Repository URL: https://github.com/akhilathuluri/Quiz-app
- Assessment: unconfirmed; do not use or test any credentials.

### 1483. P3_LOW_SIGNAL — aktechpoint/terraform_class9pm-27-08-2025

- Path: `terraform.tfstate-hyd`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/aktechpoint/terraform_class9pm-27-08-2025/blob/baac885a026ecfb85284cd895ac635c9959ae414/terraform.tfstate-hyd
- Repository URL: https://github.com/aktechpoint/terraform_class9pm-27-08-2025
- Assessment: unconfirmed; do not use or test any credentials.

### 1484. P3_LOW_SIGNAL — alexander-morris/tool-usage

- Path: `s.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/alexander-morris/tool-usage/blob/c9cd2d207e50d9a813840d92bdb9d30903958503/s.md
- Repository URL: https://github.com/alexander-morris/tool-usage
- Assessment: unconfirmed; do not use or test any credentials.

### 1485. P3_LOW_SIGNAL — alexandriashai/cbrowser

- Path: `ISA.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/alexandriashai/cbrowser/blob/4159efbd8b913c6de2377a5f4451b82477226ed4/ISA.md
- Repository URL: https://github.com/alexandriashai/cbrowser
- Assessment: unconfirmed; do not use or test any credentials.

### 1486. P3_LOW_SIGNAL — alexellis/derek

- Path: `DEV.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/alexellis/derek/blob/9226bcd5d02d31bd209a2ce43c88f681eb113db2/DEV.md
- Repository URL: https://github.com/alexellis/derek
- Assessment: unconfirmed; do not use or test any credentials.

### 1487. P3_LOW_SIGNAL — alexhokl/notes

- Path: `age.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/alexhokl/notes/blob/54845b55c830087b549a59ba17865ffd98a279e7/age.md
- Repository URL: https://github.com/alexhokl/notes
- Assessment: unconfirmed; do not use or test any credentials.

### 1488. P3_LOW_SIGNAL — alextanhongpin/go-learn

- Path: `mock.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/alextanhongpin/go-learn/blob/544d5b97cf8975a93f5ab0d4bebc8d3fe71a511f/mock.md
- Repository URL: https://github.com/alextanhongpin/go-learn
- Assessment: unconfirmed; do not use or test any credentials.

### 1489. P3_LOW_SIGNAL — alextanhongpin/go-learn

- Path: `orm.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/alextanhongpin/go-learn/blob/544d5b97cf8975a93f5ab0d4bebc8d3fe71a511f/orm.md
- Repository URL: https://github.com/alextanhongpin/go-learn
- Assessment: unconfirmed; do not use or test any credentials.

### 1490. P3_LOW_SIGNAL — alfdav/TempFox

- Path: `TODO.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/alfdav/TempFox/blob/94c8984a5cf1debbf000280380d3bbd3425edf0e/TODO.md
- Repository URL: https://github.com/alfdav/TempFox
- Assessment: unconfirmed; do not use or test any credentials.

### 1491. P3_LOW_SIGNAL — algorismo-au/lanekeep

- Path: `REFERENCE.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/algorismo-au/lanekeep/blob/e19cee5ef4a234d36113ec3f4b17840be832202c/REFERENCE.md
- Repository URL: https://github.com/algorismo-au/lanekeep
- Assessment: unconfirmed; do not use or test any credentials.

### 1492. P3_LOW_SIGNAL — altairyash/lexiAI

- Path: `USAGE.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/altairyash/lexiAI/blob/dad48e129b11574c9bd60c9729d36a0d0bc3b60e/USAGE.md
- Repository URL: https://github.com/altairyash/lexiAI
- Assessment: unconfirmed; do not use or test any credentials.

### 1493. P3_LOW_SIGNAL — alvarofpp/import-from-github-to-pulumi

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/alvarofpp/import-from-github-to-pulumi/blob/bc441146bde95115c2accaf35ba005eb355a14fd/README.md
- Repository URL: https://github.com/alvarofpp/import-from-github-to-pulumi
- Assessment: unconfirmed; do not use or test any credentials.

### 1494. P3_LOW_SIGNAL — amanaiproduct/openclaw-setup

- Path: `PROMPT.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/amanaiproduct/openclaw-setup/blob/0076472a7121537a10b96bdc2b988f43eaedec6e/PROMPT.md
- Repository URL: https://github.com/amanaiproduct/openclaw-setup
- Assessment: unconfirmed; do not use or test any credentials.

### 1495. P3_LOW_SIGNAL — amirilovic/ai-crew

- Path: `PRD.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/amirilovic/ai-crew/blob/9dd8045ef78d11fc1521451cd399b1eb3389f187/PRD.md
- Repository URL: https://github.com/amirilovic/ai-crew
- Assessment: unconfirmed; do not use or test any credentials.

### 1496. P3_LOW_SIGNAL — amlalabs/blastradius

- Path: `SPEC.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/amlalabs/blastradius/blob/da965e7d7604f2abe5ebad8dccdccb436a11f3ae/SPEC.md
- Repository URL: https://github.com/amlalabs/blastradius
- Assessment: unconfirmed; do not use or test any credentials.

### 1497. P3_LOW_SIGNAL — amrixsol/karma-agent

- Path: `SKILL.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/amrixsol/karma-agent/blob/51fe2c22e404ba05f03594cf6a0da084a2237666/SKILL.md
- Repository URL: https://github.com/amrixsol/karma-agent
- Assessment: unconfirmed; do not use or test any credentials.

### 1498. P3_LOW_SIGNAL — anand-s-kale/Unified-Server

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/anand-s-kale/Unified-Server/blob/2d282655fb8b6b51517993184ab09f6098ec05ad/SETUP.md
- Repository URL: https://github.com/anand-s-kale/Unified-Server
- Assessment: unconfirmed; do not use or test any credentials.

### 1499. P3_LOW_SIGNAL — ananthamapod/AutoAccountant

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ananthamapod/AutoAccountant/blob/7ebd1121870a62f1687525ed01a576ac0d8f89b4/API.md
- Repository URL: https://github.com/ananthamapod/AutoAccountant
- Assessment: unconfirmed; do not use or test any credentials.

### 1500. P3_LOW_SIGNAL — andersonaguiar/haiflow

- Path: `API.md`
- Indicator: `api_key_label;bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/andersonaguiar/haiflow/blob/c3f491d397d860f16fbf99bd1c6d4e40cab280be/API.md
- Repository URL: https://github.com/andersonaguiar/haiflow
- Assessment: unconfirmed; do not use or test any credentials.

### 1501. P3_LOW_SIGNAL — andrewsmhay/cazador

- Path: `README.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/andrewsmhay/cazador/blob/94e2af66d74dd977e36878b28af3de98efe28a09/README.md
- Repository URL: https://github.com/andrewsmhay/cazador
- Assessment: unconfirmed; do not use or test any credentials.

### 1502. P3_LOW_SIGNAL — annibuliful/infisical-leaked-scanner

- Path: `DEMO.md`
- Indicator: `github_token_prefix;aws_access_key;stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/annibuliful/infisical-leaked-scanner/blob/02fe113d4877d36e57276a8d00189b5875340f7e/DEMO.md
- Repository URL: https://github.com/annibuliful/infisical-leaked-scanner
- Assessment: unconfirmed; do not use or test any credentials.

### 1503. P3_LOW_SIGNAL — annismckenzie/x-article-exporter

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/annismckenzie/x-article-exporter/blob/cabb00d7e858b796eb0e2bc9c532de95f9e52b36/API.md
- Repository URL: https://github.com/annismckenzie/x-article-exporter
- Assessment: unconfirmed; do not use or test any credentials.

### 1504. P3_LOW_SIGNAL — anshul-garg27/claude-picker

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/anshul-garg27/claude-picker/blob/57c198936b38784fa1558dbc3fe0657c1155cc40/README.md
- Repository URL: https://github.com/anshul-garg27/claude-picker
- Assessment: unconfirmed; do not use or test any credentials.

### 1505. P3_LOW_SIGNAL — anthonywu/gensay

- Path: `USAGE.md`
- Indicator: `aws_access_key;google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/anthonywu/gensay/blob/e8b6ff2a10540f53729f7fb50a9c5bfc272eb7e8/USAGE.md
- Repository URL: https://github.com/anthonywu/gensay
- Assessment: unconfirmed; do not use or test any credentials.

### 1506. P3_LOW_SIGNAL — anuragkumarak95/wordnet

- Path: `README.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/anuragkumarak95/wordnet/blob/dc18a8aeac5dae7d557707821a6fb465526155d3/README.md
- Repository URL: https://github.com/anuragkumarak95/wordnet
- Assessment: unconfirmed; do not use or test any credentials.

### 1507. P3_LOW_SIGNAL — anuragnedunuri/fieldshield

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/anuragnedunuri/fieldshield/blob/4b9f9980797023aaebe147a14655dc8c2cebe80c/README.md
- Repository URL: https://github.com/anuragnedunuri/fieldshield
- Assessment: unconfirmed; do not use or test any credentials.

### 1508. P3_LOW_SIGNAL — anvaka/greview

- Path: `HOW.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/anvaka/greview/blob/a67cb37f2cbc0f7e11c1bd60bc97f3456f4411da/HOW.md
- Repository URL: https://github.com/anvaka/greview
- Assessment: unconfirmed; do not use or test any credentials.

### 1509. P3_LOW_SIGNAL — anxkhn/iNotes

- Path: `README.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/anxkhn/iNotes/blob/713a15e3aaf983d2960eb8c13553fa12cfa15b39/README.md
- Repository URL: https://github.com/anxkhn/iNotes
- Assessment: unconfirmed; do not use or test any credentials.

### 1510. P3_LOW_SIGNAL — aozorahack/aozorahack

- Path: `tools.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/aozorahack/aozorahack/blob/6fb02dd236efcbb83687cbc39f0b6fefd0042c99/tools.md
- Repository URL: https://github.com/aozorahack/aozorahack
- Assessment: unconfirmed; do not use or test any credentials.

### 1511. P3_LOW_SIGNAL — aphp/rgho

- Path: `NEWS.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/aphp/rgho/blob/fed84ac4f618266637bbf889bd32aeed6233419d/NEWS.md
- Repository URL: https://github.com/aphp/rgho
- Assessment: unconfirmed; do not use or test any credentials.

### 1512. P3_LOW_SIGNAL — appium-pro/TheApp

- Path: `CI.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/appium-pro/TheApp/blob/f8cd33f7b8d5887f1ba95608088eb347578328df/CI.md
- Repository URL: https://github.com/appium-pro/TheApp
- Assessment: unconfirmed; do not use or test any credentials.

### 1513. P3_LOW_SIGNAL — appleboy/drone-sftp-cache

- Path: `DOCS.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/appleboy/drone-sftp-cache/blob/7e2f0fd71d91ed79c9f009a3c54e05f036057df1/DOCS.md
- Repository URL: https://github.com/appleboy/drone-sftp-cache
- Assessment: unconfirmed; do not use or test any credentials.

### 1514. P3_LOW_SIGNAL — appmeee/ClawFreelance

- Path: `Skill.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/appmeee/ClawFreelance/blob/256cd7fa56a9eba0e91f293f95a39ca65c3626ef/Skill.md
- Repository URL: https://github.com/appmeee/ClawFreelance
- Assessment: unconfirmed; do not use or test any credentials.

### 1515. P3_LOW_SIGNAL — aptise/peter_sslers

- Path: `TODO.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/aptise/peter_sslers/blob/1381e936af8a66da69a3ba9130ce15a7a368ac53/TODO.md
- Repository URL: https://github.com/aptise/peter_sslers
- Assessment: unconfirmed; do not use or test any credentials.

### 1516. P3_LOW_SIGNAL — araray/confy-cpp

- Path: `API.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/araray/confy-cpp/blob/8965c2158f880f63f450ce554fe074d50e60b884/API.md
- Repository URL: https://github.com/araray/confy-cpp
- Assessment: unconfirmed; do not use or test any credentials.

### 1517. P3_LOW_SIGNAL — araray/confy-cpp

- Path: `USAGE.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/araray/confy-cpp/blob/8965c2158f880f63f450ce554fe074d50e60b884/USAGE.md
- Repository URL: https://github.com/araray/confy-cpp
- Assessment: unconfirmed; do not use or test any credentials.

### 1518. P3_LOW_SIGNAL — arbazkhan971/godmode

- Path: `PROGRESS.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/arbazkhan971/godmode/blob/18bfc31d669804856ba232f04cdbd172afbdc379/PROGRESS.md
- Repository URL: https://github.com/arbazkhan971/godmode
- Assessment: unconfirmed; do not use or test any credentials.

### 1519. P3_LOW_SIGNAL — ardantus/mysaas

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ardantus/mysaas/blob/8de4723803d78e57e65cd5ff384d92b8ed3583bf/API.md
- Repository URL: https://github.com/ardantus/mysaas
- Assessment: unconfirmed; do not use or test any credentials.

### 1520. P3_LOW_SIGNAL — arik1165/linksai-tokenbank-templates2

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/arik1165/linksai-tokenbank-templates2/blob/9569cdab0b51136b57ee5e4c265600b3b0576d76/README.md
- Repository URL: https://github.com/arik1165/linksai-tokenbank-templates2
- Assessment: unconfirmed; do not use or test any credentials.

### 1521. P3_LOW_SIGNAL — arkon-ai/arkon

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/arkon-ai/arkon/blob/5ca5730c455e742ce4edee302065aaaab674fbfc/API.md
- Repository URL: https://github.com/arkon-ai/arkon
- Assessment: unconfirmed; do not use or test any credentials.

### 1522. P3_LOW_SIGNAL — arloor/nywc

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/arloor/nywc/blob/1a591983bb9628ab0bfbc2297bfe5f5c9cb843ce/API.md
- Repository URL: https://github.com/arloor/nywc
- Assessment: unconfirmed; do not use or test any credentials.

### 1523. P3_LOW_SIGNAL — armando71988padilla-cloud/citadel-armor-showcase

- Path: `DEMO.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/armando71988padilla-cloud/citadel-armor-showcase/blob/afa444ca2b493ead4356036c827540bc0362dcdb/DEMO.md
- Repository URL: https://github.com/armando71988padilla-cloud/citadel-armor-showcase
- Assessment: unconfirmed; do not use or test any credentials.

### 1524. P3_LOW_SIGNAL — artqcid/agent-chat-misc

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/artqcid/agent-chat-misc/blob/bdea31894d24773bc235c6cb2edb2c8c0438a497/API.md
- Repository URL: https://github.com/artqcid/agent-chat-misc
- Assessment: unconfirmed; do not use or test any credentials.

### 1525. P3_LOW_SIGNAL — arubis/npm-publish-action

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/arubis/npm-publish-action/blob/5e73fb51501410a087e15039e152db8ebce3b367/README.md
- Repository URL: https://github.com/arubis/npm-publish-action
- Assessment: unconfirmed; do not use or test any credentials.

### 1526. P3_LOW_SIGNAL — aryan0078/storykit-skill

- Path: `SKILL.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/aryan0078/storykit-skill/blob/619b43de4bb7c4fbebde7c65051f2fb13cfb0d79/SKILL.md
- Repository URL: https://github.com/aryan0078/storykit-skill
- Assessment: unconfirmed; do not use or test any credentials.

### 1527. P3_LOW_SIGNAL — asishrs/smartthings-ringalarmv2

- Path: `v2.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/asishrs/smartthings-ringalarmv2/blob/87b616576bfc7b04ea4ae0824ba6c7c72649c112/v2.md
- Repository URL: https://github.com/asishrs/smartthings-ringalarmv2
- Assessment: unconfirmed; do not use or test any credentials.

### 1528. P3_LOW_SIGNAL — asquarezone/TerraformZone

- Path: `Dec17/Nginx/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/asquarezone/TerraformZone/blob/f97d19e8dfc133e9442759cfbe7669329bcf3347/Dec17/Nginx/.terraform.tfstate.lock.info
- Repository URL: https://github.com/asquarezone/TerraformZone
- Assessment: unconfirmed; do not use or test any credentials.

### 1529. P3_LOW_SIGNAL — asquarezone/TerraformZone

- Path: `Dec21/actvitity4/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/asquarezone/TerraformZone/blob/f97d19e8dfc133e9442759cfbe7669329bcf3347/Dec21/actvitity4/.terraform.tfstate.lock.info
- Repository URL: https://github.com/asquarezone/TerraformZone
- Assessment: unconfirmed; do not use or test any credentials.

### 1530. P3_LOW_SIGNAL — asquarezone/TerraformZone

- Path: `May19/azure_ntier/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/asquarezone/TerraformZone/blob/f97d19e8dfc133e9442759cfbe7669329bcf3347/May19/azure_ntier/.terraform.tfstate.lock.info
- Repository URL: https://github.com/asquarezone/TerraformZone
- Assessment: unconfirmed; do not use or test any credentials.

### 1531. P3_LOW_SIGNAL — asquarezone/TerraformZone

- Path: `Oct22/dynamic_demo/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/asquarezone/TerraformZone/blob/f97d19e8dfc133e9442759cfbe7669329bcf3347/Oct22/dynamic_demo/.terraform.tfstate.lock.info
- Repository URL: https://github.com/asquarezone/TerraformZone
- Assessment: unconfirmed; do not use or test any credentials.

### 1532. P3_LOW_SIGNAL — atelic/dotfiles

- Path: `GUIDE.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/atelic/dotfiles/blob/dbc7a07aad253bf79f5b9780ea9d30acf33677bd/GUIDE.md
- Repository URL: https://github.com/atelic/dotfiles
- Assessment: unconfirmed; do not use or test any credentials.

### 1533. P3_LOW_SIGNAL — atinarapukarthik/ci-healing-agent

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/atinarapukarthik/ci-healing-agent/blob/f68bb1ce458e930d94d9e907c64f24be6eb80647/SETUP.md
- Repository URL: https://github.com/atinarapukarthik/ci-healing-agent
- Assessment: unconfirmed; do not use or test any credentials.

### 1534. P3_LOW_SIGNAL — atorus-research/xportr

- Path: `NEWS.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/atorus-research/xportr/blob/fe958b8afbb8a1a19a8c44c2f16af4b6f0c2611b/NEWS.md
- Repository URL: https://github.com/atorus-research/xportr
- Assessment: unconfirmed; do not use or test any credentials.

### 1535. P3_LOW_SIGNAL — atulghandhi/meeting-recorder

- Path: `TODO.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/atulghandhi/meeting-recorder/blob/c11da841dc317e96cf2f0dc3bc878e0c8c1adf26/TODO.md
- Repository URL: https://github.com/atulghandhi/meeting-recorder
- Assessment: unconfirmed; do not use or test any credentials.

### 1536. P3_LOW_SIGNAL — aunjum/secret-guardian-ts

- Path: `README.md`
- Indicator: `github_app_token_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/aunjum/secret-guardian-ts/blob/0669c419a00a0d996cd633986d8ed996a9f7b503/README.md
- Repository URL: https://github.com/aunjum/secret-guardian-ts
- Assessment: unconfirmed; do not use or test any credentials.

### 1537. P3_LOW_SIGNAL — auth0/angular2-jwt

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/auth0/angular2-jwt/blob/ad6f75bc0b4600fa247f13521956ad6870f2b6cf/API.md
- Repository URL: https://github.com/auth0/angular2-jwt
- Assessment: unconfirmed; do not use or test any credentials.

### 1538. P3_LOW_SIGNAL — authfi/authfi-ruby-sdk

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/authfi/authfi-ruby-sdk/blob/9a0f0edbd756870db11dbd47ebd1494055b4fa3d/README.md
- Repository URL: https://github.com/authfi/authfi-ruby-sdk
- Assessment: unconfirmed; do not use or test any credentials.

### 1539. P3_LOW_SIGNAL — awesome-mlss/awesome-mlss

- Path: `PAST.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/awesome-mlss/awesome-mlss/blob/a9f2a36d20232c28cc79b6030cf0ecb9a03c0dd7/PAST.md
- Repository URL: https://github.com/awesome-mlss/awesome-mlss
- Assessment: unconfirmed; do not use or test any credentials.

### 1540. P3_LOW_SIGNAL — aws-samples/sample-agent-greenhouse

- Path: `SECURITY.md`
- Indicator: `github_oauth_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/aws-samples/sample-agent-greenhouse/blob/4f5b12e614554c885414732460bfb36c08701cf9/SECURITY.md
- Repository URL: https://github.com/aws-samples/sample-agent-greenhouse
- Assessment: unconfirmed; do not use or test any credentials.

### 1541. P3_LOW_SIGNAL — axetroy/watchdog

- Path: `docs.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/axetroy/watchdog/blob/53df558d69a1ac39954abfa213eea24249dc8d76/docs.md
- Repository URL: https://github.com/axetroy/watchdog
- Assessment: unconfirmed; do not use or test any credentials.

### 1542. P3_LOW_SIGNAL — bakosbits/terralab

- Path: `terraform/services/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/bakosbits/terralab/blob/7c023230b03ad61421448317598b552e915a895c/terraform/services/.terraform.tfstate.lock.info
- Repository URL: https://github.com/bakosbits/terralab
- Assessment: unconfirmed; do not use or test any credentials.

### 1543. P3_LOW_SIGNAL — balakrish181/virtual_try_on

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/balakrish181/virtual_try_on/blob/692025c02c80e1cf52aa69e91ed74c74684c67c3/README.md
- Repository URL: https://github.com/balakrish181/virtual_try_on
- Assessment: unconfirmed; do not use or test any credentials.

### 1544. P3_LOW_SIGNAL — ballerina-platform/module-ballerinax-github

- Path: `README.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ballerina-platform/module-ballerinax-github/blob/5938a08e1ed8f280bc053bd7738eac7f97bf5fe6/README.md
- Repository URL: https://github.com/ballerina-platform/module-ballerinax-github
- Assessment: unconfirmed; do not use or test any credentials.

### 1545. P3_LOW_SIGNAL — ballerina-platform/module-ballerinax-github

- Path: `ballerina/README.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ballerina-platform/module-ballerinax-github/blob/5938a08e1ed8f280bc053bd7738eac7f97bf5fe6/ballerina/README.md
- Repository URL: https://github.com/ballerina-platform/module-ballerinax-github
- Assessment: unconfirmed; do not use or test any credentials.

### 1546. P3_LOW_SIGNAL — bambora/wallet-js

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/bambora/wallet-js/blob/33ca85bc2242812823a0cbfe59d1347badcbc5a8/README.md
- Repository URL: https://github.com/bambora/wallet-js
- Assessment: unconfirmed; do not use or test any credentials.

### 1547. P3_LOW_SIGNAL — banana2556/leakhound

- Path: `README.md`
- Indicator: `github_app_token_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/banana2556/leakhound/blob/88380c3907ba96a487a0b67dd87499c4daaeba64/README.md
- Repository URL: https://github.com/banana2556/leakhound
- Assessment: unconfirmed; do not use or test any credentials.

### 1548. P3_LOW_SIGNAL — bartei/git-agecrypt

- Path: `todo.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/bartei/git-agecrypt/blob/219b576b829e5971a57e202804074784fb8ffe9f/todo.md
- Repository URL: https://github.com/bartei/git-agecrypt
- Assessment: unconfirmed; do not use or test any credentials.

### 1549. P3_LOW_SIGNAL — basecamp/audits1984

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/basecamp/audits1984/blob/3622629fb124b081c273eb3df80814f413b0a02f/API.md
- Repository URL: https://github.com/basecamp/audits1984
- Assessment: unconfirmed; do not use or test any credentials.

### 1550. P3_LOW_SIGNAL — bastndev/fixnow

- Path: `NOTES.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/bastndev/fixnow/blob/4866a74014def58b50112b54e9c8dc4707a5d5fc/NOTES.md
- Repository URL: https://github.com/bastndev/fixnow
- Assessment: unconfirmed; do not use or test any credentials.

### 1551. P3_LOW_SIGNAL — bastndev/svghub

- Path: `NOTES.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/bastndev/svghub/blob/2ca93e7528deb6a71086403273ab6330832433a3/NOTES.md
- Repository URL: https://github.com/bastndev/svghub
- Assessment: unconfirmed; do not use or test any credentials.

### 1552. P3_LOW_SIGNAL — becerra-alberto/oss-prep

- Path: `oss-guard/README.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/becerra-alberto/oss-prep/blob/13f6f434677fc8657024bcad99eae0bea72762ae/oss-guard/README.md
- Repository URL: https://github.com/becerra-alberto/oss-prep
- Assessment: unconfirmed; do not use or test any credentials.

### 1553. P3_LOW_SIGNAL — bengalih/ABS-scripts

- Path: `AeRu.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/bengalih/ABS-scripts/blob/352af453d42c9e8d74dce12ea300fd04791ee4c4/AeRu.md
- Repository URL: https://github.com/bengalih/ABS-scripts
- Assessment: unconfirmed; do not use or test any credentials.

### 1554. P3_LOW_SIGNAL — bennycode/stop-merging

- Path: `FAQ.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/bennycode/stop-merging/blob/632cf4a9355871b357be56e72271e573291f8f3b/FAQ.md
- Repository URL: https://github.com/bennycode/stop-merging
- Assessment: unconfirmed; do not use or test any credentials.

### 1555. P3_LOW_SIGNAL — berry-13/matterbridge-railway

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/berry-13/matterbridge-railway/blob/b00de1bc6766227a30e889198aa0ba3d9b13633f/README.md
- Repository URL: https://github.com/berry-13/matterbridge-railway
- Assessment: unconfirmed; do not use or test any credentials.

### 1556. P3_LOW_SIGNAL — bethington/re-universe

- Path: `TODO.md`
- Indicator: `github_token_prefix;github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/bethington/re-universe/blob/c6eea0185485a9025d8528e20e49ae292c6ea5ae/TODO.md
- Repository URL: https://github.com/bethington/re-universe
- Assessment: unconfirmed; do not use or test any credentials.

### 1557. P3_LOW_SIGNAL — biaapedrosa/Projeto-DS

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/biaapedrosa/Projeto-DS/blob/a4b0456b6554b7bc82a6c6edcb164b0ce4e2208e/API.md
- Repository URL: https://github.com/biaapedrosa/Projeto-DS
- Assessment: unconfirmed; do not use or test any credentials.

### 1558. P3_LOW_SIGNAL — billybox1926-jpg/mdguard

- Path: `SECURITY.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/billybox1926-jpg/mdguard/blob/64fa3cf5713a46d59e9369eb417020056d302df2/SECURITY.md
- Repository URL: https://github.com/billybox1926-jpg/mdguard
- Assessment: unconfirmed; do not use or test any credentials.

### 1559. P3_LOW_SIGNAL — binaryeq/jpatch

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/binaryeq/jpatch/blob/d99ce4ea3db8269b16a6a24c2f8a602dc5b7eb18/README.md
- Repository URL: https://github.com/binaryeq/jpatch
- Assessment: unconfirmed; do not use or test any credentials.

### 1560. P3_LOW_SIGNAL — binsee/wxmp-auth

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/binsee/wxmp-auth/blob/8e1546decc9f66ee044157cc00f059304745f00e/API.md
- Repository URL: https://github.com/binsee/wxmp-auth
- Assessment: unconfirmed; do not use or test any credentials.

### 1561. P3_LOW_SIGNAL — bips1996/AskBiplaba

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/bips1996/AskBiplaba/blob/dfba46a56a0bf98bfbd7e47a5a534f56d31a6d00/SETUP.md
- Repository URL: https://github.com/bips1996/AskBiplaba
- Assessment: unconfirmed; do not use or test any credentials.

### 1562. P3_LOW_SIGNAL — bireggbaum-beep/timerec-sync

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/bireggbaum-beep/timerec-sync/blob/10b9d8fa0c66d21f21ef26d647b9d6949afcf969/README.md
- Repository URL: https://github.com/bireggbaum-beep/timerec-sync
- Assessment: unconfirmed; do not use or test any credentials.

### 1563. P3_LOW_SIGNAL — bitengineers/slack_mcp_server

- Path: `SETUP.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/bitengineers/slack_mcp_server/blob/9366771920d83361881d9de07aa427854913bbed/SETUP.md
- Repository URL: https://github.com/bitengineers/slack_mcp_server
- Assessment: unconfirmed; do not use or test any credentials.

### 1564. P3_LOW_SIGNAL — bjornmolin90/vteam15

- Path: `db.txt`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/bjornmolin90/vteam15/blob/c8e99219e83e7a61e5fd3dce935de5328707eb67/db.txt
- Repository URL: https://github.com/bjornmolin90/vteam15
- Assessment: unconfirmed; do not use or test any credentials.

### 1565. P3_LOW_SIGNAL — bkalafat/DiffPilot

- Path: `SECURITY.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/bkalafat/DiffPilot/blob/f3ba53d646568b4c1c438ce9428590e8d59e517e/SECURITY.md
- Repository URL: https://github.com/bkalafat/DiffPilot
- Assessment: unconfirmed; do not use or test any credentials.

### 1566. P3_LOW_SIGNAL — bkbilly/asterisk_call_status

- Path: `info.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/bkbilly/asterisk_call_status/blob/bbaf9a4e2edb43825b9980912c88fb4dbbe7780f/info.md
- Repository URL: https://github.com/bkbilly/asterisk_call_status
- Assessment: unconfirmed; do not use or test any credentials.

### 1567. P3_LOW_SIGNAL — blacksinisterx/Job-Search-Agent

- Path: `PLAN.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/blacksinisterx/Job-Search-Agent/blob/1235c91988c08f2284cde0aad7e4bdb55f0d9722/PLAN.md
- Repository URL: https://github.com/blacksinisterx/Job-Search-Agent
- Assessment: unconfirmed; do not use or test any credentials.

### 1568. P3_LOW_SIGNAL — blackwell-systems/shelfctl

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/blackwell-systems/shelfctl/blob/62ee0f256e1f85d09e31d7bc1e10edc1dc6098f0/README.md
- Repository URL: https://github.com/blackwell-systems/shelfctl
- Assessment: unconfirmed; do not use or test any credentials.

### 1569. P3_LOW_SIGNAL — blagoySimandov/ampledata-apify

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/blagoySimandov/ampledata-apify/blob/38bf4e34175bfbb78257c892fcd1a43c4386d3c9/README.md
- Repository URL: https://github.com/blagoySimandov/ampledata-apify
- Assessment: unconfirmed; do not use or test any credentials.

### 1570. P3_LOW_SIGNAL — blc-iletisim/blc-terraform-Hadoop

- Path: `.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/blc-iletisim/blc-terraform-Hadoop/blob/3029fb4092c52978fb4be05cc26d0f81c082a293/.terraform.tfstate.lock.info
- Repository URL: https://github.com/blc-iletisim/blc-terraform-Hadoop
- Assessment: unconfirmed; do not use or test any credentials.

### 1571. P3_LOW_SIGNAL — blendflare/blendflare-python-sdk

- Path: `README.MD`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/blendflare/blendflare-python-sdk/blob/644af3e115685dc1f2430db939593d13b221a0b7/README.MD
- Repository URL: https://github.com/blendflare/blendflare-python-sdk
- Assessment: unconfirmed; do not use or test any credentials.

### 1572. P3_LOW_SIGNAL — blp/ovs-reviews

- Path: `NEWS`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/blp/ovs-reviews/blob/d7abfe39cfd234227bb6174b7f959a16dc803b83/NEWS
- Repository URL: https://github.com/blp/ovs-reviews
- Assessment: unconfirmed; do not use or test any credentials.

### 1573. P3_LOW_SIGNAL — bmcgauley/PM-Agents

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/bmcgauley/PM-Agents/blob/520da6368d11d5e7e486ae67706bae18588c759f/SETUP.md
- Repository URL: https://github.com/bmcgauley/PM-Agents
- Assessment: unconfirmed; do not use or test any credentials.

### 1574. P3_LOW_SIGNAL — bogdanticu88/AuthBridge

- Path: `docs/USAGE.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/bogdanticu88/AuthBridge/blob/c90d96b415df10940e7efbad45dce2a13c7cf5d4/docs/USAGE.md
- Repository URL: https://github.com/bogdanticu88/AuthBridge
- Assessment: unconfirmed; do not use or test any credentials.

### 1575. P3_LOW_SIGNAL — boinger/zorille

- Path: `CI.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/boinger/zorille/blob/a345554a219e8ca517cd6bcc455d746060bf6aad/CI.md
- Repository URL: https://github.com/boinger/zorille
- Assessment: unconfirmed; do not use or test any credentials.

### 1576. P3_LOW_SIGNAL — bookalope/Bookalope

- Path: `API.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/bookalope/Bookalope/blob/15cb86121d5f73d976208f147565214c23eab83f/API.md
- Repository URL: https://github.com/bookalope/Bookalope
- Assessment: unconfirmed; do not use or test any credentials.

### 1577. P3_LOW_SIGNAL — boostsecurityio/bagel

- Path: `README.md`
- Indicator: `github_oauth_prefix;github_app_token_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/boostsecurityio/bagel/blob/b22cc4c91910845a1f73220e5018071274e7c856/README.md
- Repository URL: https://github.com/boostsecurityio/bagel
- Assessment: unconfirmed; do not use or test any credentials.

### 1578. P3_LOW_SIGNAL — botiverse/agent-vault

- Path: `DESIGN.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/botiverse/agent-vault/blob/8f0bacf22eaa82938e4a8158926b29d82e678321/DESIGN.md
- Repository URL: https://github.com/botiverse/agent-vault
- Assessment: unconfirmed; do not use or test any credentials.

### 1579. P3_LOW_SIGNAL — braaaax/braaaax.github.io

- Path: `ctf.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/braaaax/braaaax.github.io/blob/84b8cd07ef04a87f1ffa84db3e1b1540306a1c83/ctf.md
- Repository URL: https://github.com/braaaax/braaaax.github.io
- Assessment: unconfirmed; do not use or test any credentials.

### 1580. P3_LOW_SIGNAL — breadwallet/nettle

- Path: `NEWS`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/breadwallet/nettle/blob/fd05a0e2558af7b9314c3f7e76334832e6697116/NEWS
- Repository URL: https://github.com/breadwallet/nettle
- Assessment: unconfirmed; do not use or test any credentials.

### 1581. P3_LOW_SIGNAL — brevity1swos/agx

- Path: `ROADMAP.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/brevity1swos/agx/blob/79b9215a84814d12334b99cb56bcdae42d9ff9b3/ROADMAP.md
- Repository URL: https://github.com/brevity1swos/agx
- Assessment: unconfirmed; do not use or test any credentials.

### 1582. P3_LOW_SIGNAL — briancurt/bitreminder

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/briancurt/bitreminder/blob/3e28265474b8788325837387f38dd2a446e194dd/README.md
- Repository URL: https://github.com/briancurt/bitreminder
- Assessment: unconfirmed; do not use or test any credentials.

### 1583. P3_LOW_SIGNAL — briangershon/briangershon

- Path: `dev.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/briangershon/briangershon/blob/64f7267ccd64a843ae257fa17c9350a0f5895a1d/dev.md
- Repository URL: https://github.com/briangershon/briangershon
- Assessment: unconfirmed; do not use or test any credentials.

### 1584. P3_LOW_SIGNAL — briankwest/stirshaken-ruby

- Path: `CERT.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/briankwest/stirshaken-ruby/blob/006d19f08dbe5c6770f3323b365a6311a8ac563f/CERT.md
- Repository URL: https://github.com/briankwest/stirshaken-ruby
- Assessment: unconfirmed; do not use or test any credentials.

### 1585. P3_LOW_SIGNAL — broadinstitute/nebelung

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/broadinstitute/nebelung/blob/591164819fa890accc3a38eccbbc01f346d8c1f9/README.md
- Repository URL: https://github.com/broadinstitute/nebelung
- Assessment: unconfirmed; do not use or test any credentials.

### 1586. P3_LOW_SIGNAL — brownag/rgeedim

- Path: `NEWS.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/brownag/rgeedim/blob/a946d8b22ba1f484b34f268a8364f8ac01ed0106/NEWS.md
- Repository URL: https://github.com/brownag/rgeedim
- Assessment: unconfirmed; do not use or test any credentials.

### 1587. P3_LOW_SIGNAL — bs7280/markdown-notes-web

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/bs7280/markdown-notes-web/blob/b2702438af78e2d0f71d31d584ab6e6b8cba0d29/README.md
- Repository URL: https://github.com/bs7280/markdown-notes-web
- Assessment: unconfirmed; do not use or test any credentials.

### 1588. P3_LOW_SIGNAL — btnguyen2k/action-semrelease

- Path: `.dev.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/btnguyen2k/action-semrelease/blob/aa5bf1128ced4a65260e96f489fd05d4b417ffd9/.dev.md
- Repository URL: https://github.com/btnguyen2k/action-semrelease
- Assessment: unconfirmed; do not use or test any credentials.

### 1589. P3_LOW_SIGNAL — bugminer/bugminer

- Path: `FAQ.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/bugminer/bugminer/blob/3d03237a8220229fa0762bacf8d5b3d345b3e2f9/FAQ.md
- Repository URL: https://github.com/bugminer/bugminer
- Assessment: unconfirmed; do not use or test any credentials.

### 1590. P3_LOW_SIGNAL — byXewl/book

- Path: `jdbc.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/byXewl/book/blob/a93f96b2d9a327e08669a535ce8f0230cea6dd91/jdbc.md
- Repository URL: https://github.com/byXewl/book
- Assessment: unconfirmed; do not use or test any credentials.

### 1591. P3_LOW_SIGNAL — bystrogenomics/bystro

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/bystrogenomics/bystro/blob/a234be3f0cd7c5cb45b65a923a71e98066b35c36/API.md
- Repository URL: https://github.com/bystrogenomics/bystro
- Assessment: unconfirmed; do not use or test any credentials.

### 1592. P3_LOW_SIGNAL — bytedance/ovs-dpdk

- Path: `NEWS`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/bytedance/ovs-dpdk/blob/b8b208785132ec1c59516ce8c6e439d31ae9f2d0/NEWS
- Repository URL: https://github.com/bytedance/ovs-dpdk
- Assessment: unconfirmed; do not use or test any credentials.

### 1593. P3_LOW_SIGNAL — c0tton-fluff/secret-scrubber

- Path: `README.md`
- Indicator: `github_pat_prefix;github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/c0tton-fluff/secret-scrubber/blob/91b34d6f1a0767c1e10b8f78b202da5d86cc1a3d/README.md
- Repository URL: https://github.com/c0tton-fluff/secret-scrubber
- Assessment: unconfirmed; do not use or test any credentials.

### 1594. P3_LOW_SIGNAL — ca0s/gitgrep

- Path: `res.txt`
- Indicator: `aws_access_key;stripe_live_prefix;google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ca0s/gitgrep/blob/2b1712576b24a036da7953bbf290ac49bd66c32d/res.txt
- Repository URL: https://github.com/ca0s/gitgrep
- Assessment: unconfirmed; do not use or test any credentials.

### 1595. P3_LOW_SIGNAL — caffeinepub/local-eyes

- Path: `spec.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/caffeinepub/local-eyes/blob/1b5e740b792a636c35de064a1ac790e30294e53a/spec.md
- Repository URL: https://github.com/caffeinepub/local-eyes
- Assessment: unconfirmed; do not use or test any credentials.

### 1596. P3_LOW_SIGNAL — cagataycali/devduck

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/cagataycali/devduck/blob/f6b226cd37a27bc6701ecf1563719ea46f2b9eb7/README.md
- Repository URL: https://github.com/cagataycali/devduck
- Assessment: unconfirmed; do not use or test any credentials.

### 1597. P3_LOW_SIGNAL — calculator-jsj/ai-travel-planner

- Path: `RUN.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/calculator-jsj/ai-travel-planner/blob/6d310a032242a2c408aaae7d7083cbbfce1bf340/RUN.md
- Repository URL: https://github.com/calculator-jsj/ai-travel-planner
- Assessment: unconfirmed; do not use or test any credentials.

### 1598. P3_LOW_SIGNAL — calorieTrack/calorieWeb

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/calorieTrack/calorieWeb/blob/0120f9068ca625c3a83ba8b79e80953614e7d754/API.md
- Repository URL: https://github.com/calorieTrack/calorieWeb
- Assessment: unconfirmed; do not use or test any credentials.

### 1599. P3_LOW_SIGNAL — caltechlibrary/wsfn

- Path: `tls.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/caltechlibrary/wsfn/blob/10c078c1d4481bbc920eae350f709c123e6f22f2/tls.md
- Repository URL: https://github.com/caltechlibrary/wsfn
- Assessment: unconfirmed; do not use or test any credentials.

### 1600. P3_LOW_SIGNAL — candrholdings/slack-console

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/candrholdings/slack-console/blob/085c00045f6cbcac7bf7f9aa6468e71fe23da267/README.md
- Repository URL: https://github.com/candrholdings/slack-console
- Assessment: unconfirmed; do not use or test any credentials.

### 1601. P3_LOW_SIGNAL — canlii/API_documentation

- Path: `EN.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/canlii/API_documentation/blob/84fe1c4c97cf29fec30000532a7e6876ced85a7a/EN.md
- Repository URL: https://github.com/canlii/API_documentation
- Assessment: unconfirmed; do not use or test any credentials.

### 1602. P3_LOW_SIGNAL — canlii/API_documentation

- Path: `FR.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/canlii/API_documentation/blob/84fe1c4c97cf29fec30000532a7e6876ced85a7a/FR.md
- Repository URL: https://github.com/canlii/API_documentation
- Assessment: unconfirmed; do not use or test any credentials.

### 1603. P3_LOW_SIGNAL — caprietoj/tvs

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/caprietoj/tvs/blob/333e43dd3372e6f654c6fef2096b0794cbcaa74f/API.md
- Repository URL: https://github.com/caprietoj/tvs
- Assessment: unconfirmed; do not use or test any credentials.

### 1604. P3_LOW_SIGNAL — cbuchert/tool-club

- Path: `MCP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/cbuchert/tool-club/blob/d2fd71cb4261000a2f4bcbad89b73b281ddd2bdd/MCP.md
- Repository URL: https://github.com/cbuchert/tool-club
- Assessment: unconfirmed; do not use or test any credentials.

### 1605. P3_LOW_SIGNAL — cdaviiis/open-message

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/cdaviiis/open-message/blob/1e76becbe81ff00ccdcf58c845e93ed07fbbc4e0/README.md
- Repository URL: https://github.com/cdaviiis/open-message
- Assessment: unconfirmed; do not use or test any credentials.

### 1606. P3_LOW_SIGNAL — cdklabs/cdk-enterprise-iac

- Path: `API.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/cdklabs/cdk-enterprise-iac/blob/7e0cafb1dbc33190991a416422a6c61701e1192a/API.md
- Repository URL: https://github.com/cdklabs/cdk-enterprise-iac
- Assessment: unconfirmed; do not use or test any credentials.

### 1607. P3_LOW_SIGNAL — cflowe/ACE

- Path: `NEWS`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/cflowe/ACE/blob/5ff60b41adbe1772372d1a43bcc1f2726ff8f810/NEWS
- Repository URL: https://github.com/cflowe/ACE
- Assessment: unconfirmed; do not use or test any credentials.

### 1608. P3_LOW_SIGNAL — chandika/mirage-proxy

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/chandika/mirage-proxy/blob/9f66f544cd008134b180ef4cda45db64a17343d8/README.md
- Repository URL: https://github.com/chandika/mirage-proxy
- Assessment: unconfirmed; do not use or test any credentials.

### 1609. P3_LOW_SIGNAL — chaoss/chaoss-slack-bot

- Path: `SETUP.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/chaoss/chaoss-slack-bot/blob/600d98145e7e0904e22f28d6d285567b3425b278/SETUP.md
- Repository URL: https://github.com/chaoss/chaoss-slack-bot
- Assessment: unconfirmed; do not use or test any credentials.

### 1610. P3_LOW_SIGNAL — charann29/opensource

- Path: `fdp.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/charann29/opensource/blob/1dfcb31ec8bb73cb4a34bc99f41d749198ccdf5f/fdp.md
- Repository URL: https://github.com/charann29/opensource
- Assessment: unconfirmed; do not use or test any credentials.

### 1611. P3_LOW_SIGNAL — cheretbe/notes

- Path: `ai.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/cheretbe/notes/blob/abf1a0924cec45dc5414bd05575d97a77fa543fa/ai.md
- Repository URL: https://github.com/cheretbe/notes
- Assessment: unconfirmed; do not use or test any credentials.

### 1612. P3_LOW_SIGNAL — chhaytheanly/pyfarm

- Path: `README.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/chhaytheanly/pyfarm/blob/edce96bf2a79498c2c43237cd8273fbb19bda143/README.md
- Repository URL: https://github.com/chhaytheanly/pyfarm
- Assessment: unconfirmed; do not use or test any credentials.

### 1613. P3_LOW_SIGNAL — chief-builder/local-vs-remote-mcp

- Path: `redaction/README.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/chief-builder/local-vs-remote-mcp/blob/eb4bf6a4a4e8a42d34748a3b69617f07b641fc0b/redaction/README.md
- Repository URL: https://github.com/chief-builder/local-vs-remote-mcp
- Assessment: unconfirmed; do not use or test any credentials.

### 1614. P3_LOW_SIGNAL — chriseidhof/pi-agent

- Path: `plan.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/chriseidhof/pi-agent/blob/aedc4c8bbf6275f004a8a00f8769e8aee24c2f5f/plan.md
- Repository URL: https://github.com/chriseidhof/pi-agent
- Assessment: unconfirmed; do not use or test any credentials.

### 1615. P3_LOW_SIGNAL — chrisokchen/aia-swd

- Path: `C6.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/chrisokchen/aia-swd/blob/562d8b54db12844d9f01d2057c8f77166e805383/C6.md
- Repository URL: https://github.com/chrisokchen/aia-swd
- Assessment: unconfirmed; do not use or test any credentials.

### 1616. P3_LOW_SIGNAL — chrisreddington/flight-school

- Path: `docs/architecture.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/chrisreddington/flight-school/blob/c68af204516501a46288c181170c20831f3c341e/docs/architecture.md
- Repository URL: https://github.com/chrisreddington/flight-school
- Assessment: unconfirmed; do not use or test any credentials.

### 1617. P3_LOW_SIGNAL — chriswblake/cheat-sheets

- Path: `act.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/chriswblake/cheat-sheets/blob/547965621ca90301b9f6231b97d91eafa9953c32/act.md
- Repository URL: https://github.com/chriswblake/cheat-sheets
- Assessment: unconfirmed; do not use or test any credentials.

### 1618. P3_LOW_SIGNAL — cisco/hash-sigs

- Path: `read.me`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/cisco/hash-sigs/blob/cea4dda4f937e56ab42e1a74665f6397473a2838/read.me
- Repository URL: https://github.com/cisco/hash-sigs
- Assessment: unconfirmed; do not use or test any credentials.

### 1619. P3_LOW_SIGNAL — citizenlabsgr/adopt-a-drain-hapi-api

- Path: `ROLES.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/citizenlabsgr/adopt-a-drain-hapi-api/blob/e8c44bc14ea454e0d4b758f6c64174cb1ed1a223/ROLES.md
- Repository URL: https://github.com/citizenlabsgr/adopt-a-drain-hapi-api
- Assessment: unconfirmed; do not use or test any credentials.

### 1620. P3_LOW_SIGNAL — clairBuoyant/swellhub

- Path: `AGENTS.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/clairBuoyant/swellhub/blob/084815cca558ec34fa7c37c0afc174162d79a6d9/AGENTS.md
- Repository URL: https://github.com/clairBuoyant/swellhub
- Assessment: unconfirmed; do not use or test any credentials.

### 1621. P3_LOW_SIGNAL — claranet/php

- Path: `TODO.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/claranet/php/blob/b76e80e56a67c6f74ddbb29f43f8049eeb4094ba/TODO.md
- Repository URL: https://github.com/claranet/php
- Assessment: unconfirmed; do not use or test any credentials.

### 1622. P3_LOW_SIGNAL — clawdbotatg/agent-bounty-board

- Path: `DEMO.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/clawdbotatg/agent-bounty-board/blob/c9700a2bb4fe3811339280e688fb5254da95dfa4/DEMO.md
- Repository URL: https://github.com/clawdbotatg/agent-bounty-board
- Assessment: unconfirmed; do not use or test any credentials.

### 1623. P3_LOW_SIGNAL — clawdsec/clawsec

- Path: `CLAUDE.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/clawdsec/clawsec/blob/6d6eabc1387e7a0a65ed00e27b7cba5c6c7ef7e7/CLAUDE.md
- Repository URL: https://github.com/clawdsec/clawsec
- Assessment: unconfirmed; do not use or test any credentials.

### 1624. P3_LOW_SIGNAL — cleanlab/codex-python

- Path: `api.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/cleanlab/codex-python/blob/7b6bc0ace9e5eb67f37598f178010a16467747e4/api.md
- Repository URL: https://github.com/cleanlab/codex-python
- Assessment: unconfirmed; do not use or test any credentials.

### 1625. P3_LOW_SIGNAL — cliffordp/cliff-wp-plugin-boilerplate

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/cliffordp/cliff-wp-plugin-boilerplate/blob/5fb486bfec2a8eddfe468d04ae8129d0ae6f5291/README.md
- Repository URL: https://github.com/cliffordp/cliff-wp-plugin-boilerplate
- Assessment: unconfirmed; do not use or test any credentials.

### 1626. P3_LOW_SIGNAL — cloudbase/openvswitch-hyperv

- Path: `INSTALL`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/cloudbase/openvswitch-hyperv/blob/e27a8508fcb61df0f3315b85c08fbb359f2b49d9/INSTALL
- Repository URL: https://github.com/cloudbase/openvswitch-hyperv
- Assessment: unconfirmed; do not use or test any credentials.

### 1627. P3_LOW_SIGNAL — cloudbase/openvswitch-hyperv

- Path: `NEWS`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/cloudbase/openvswitch-hyperv/blob/e27a8508fcb61df0f3315b85c08fbb359f2b49d9/NEWS
- Repository URL: https://github.com/cloudbase/openvswitch-hyperv
- Assessment: unconfirmed; do not use or test any credentials.

### 1628. P3_LOW_SIGNAL — cloudera-labs/cldr-runner

- Path: `FAQ.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/cloudera-labs/cldr-runner/blob/96e0a6db52c6b40d2300e4260cff32d369f13a05/FAQ.md
- Repository URL: https://github.com/cloudera-labs/cldr-runner
- Assessment: unconfirmed; do not use or test any credentials.

### 1629. P3_LOW_SIGNAL — cloudexter-wasy/python-app-tst2

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/cloudexter-wasy/python-app-tst2/blob/f3c1ae9a44517d558c13adbc7576ad5a96cb6bdf/README.md
- Repository URL: https://github.com/cloudexter-wasy/python-app-tst2
- Assessment: unconfirmed; do not use or test any credentials.

### 1630. P3_LOW_SIGNAL — cloudnativelabs/kube-router

- Path: `AGENTS.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/cloudnativelabs/kube-router/blob/e75e29e3b81687a9eaafb85909b6d2cb728e66ad/AGENTS.md
- Repository URL: https://github.com/cloudnativelabs/kube-router
- Assessment: unconfirmed; do not use or test any credentials.

### 1631. P3_LOW_SIGNAL — clouds56-bot/chatbox

- Path: `server/README.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/clouds56-bot/chatbox/blob/a5570071b57b9dd76d749446ab8abab2bbe36ef2/server/README.md
- Repository URL: https://github.com/clouds56-bot/chatbox
- Assessment: unconfirmed; do not use or test any credentials.

### 1632. P3_LOW_SIGNAL — cnumr/best-practices

- Path: `DEV.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/cnumr/best-practices/blob/7fe39f127c19df0d7695f5c683912ce9743d250b/DEV.md
- Repository URL: https://github.com/cnumr/best-practices
- Assessment: unconfirmed; do not use or test any credentials.

### 1633. P3_LOW_SIGNAL — code-a2z/jarvis

- Path: `SETUP.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/code-a2z/jarvis/blob/486b2b1c67639e4986070f92728766fce91fca27/SETUP.md
- Repository URL: https://github.com/code-a2z/jarvis
- Assessment: unconfirmed; do not use or test any credentials.

### 1634. P3_LOW_SIGNAL — code-by-timo/NoCMS

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/code-by-timo/NoCMS/blob/b81f3f63f8025924361e8ec120e54972d9d59f1f/README.md
- Repository URL: https://github.com/code-by-timo/NoCMS
- Assessment: unconfirmed; do not use or test any credentials.

### 1635. P3_LOW_SIGNAL — codekakitai51/vulnerable-actions-test

- Path: `README.md`
- Indicator: `github_pat_prefix;github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/codekakitai51/vulnerable-actions-test/blob/7ee89685d71a0cd8ca84600e309bb1e0d70b8351/README.md
- Repository URL: https://github.com/codekakitai51/vulnerable-actions-test
- Assessment: unconfirmed; do not use or test any credentials.

### 1636. P3_LOW_SIGNAL — codemogged/CodeCollab

- Path: `README.md`
- Indicator: `github_oauth_prefix;github_app_token_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/codemogged/CodeCollab/blob/2f42037f3e6f0005fad8b2187f7f880f2416eccd/README.md
- Repository URL: https://github.com/codemogged/CodeCollab
- Assessment: unconfirmed; do not use or test any credentials.

### 1637. P3_LOW_SIGNAL — colinc86/tape

- Path: `SPEC.md`
- Indicator: `aws_access_key;npm_token_prefix;google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/colinc86/tape/blob/ae951489f4b7e5ffad230a6451ed34a6ffa4d100/SPEC.md
- Repository URL: https://github.com/colinc86/tape
- Assessment: unconfirmed; do not use or test any credentials.

### 1638. P3_LOW_SIGNAL — convex/stripe

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/convex/stripe/blob/5681a698cb59d96e87a2dc219904fc848b90ec9d/README.md
- Repository URL: https://github.com/convex/stripe
- Assessment: unconfirmed; do not use or test any credentials.

### 1639. P3_LOW_SIGNAL — coo-quack/sensitive-canary

- Path: `docs/rules.md`
- Indicator: `github_oauth_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/coo-quack/sensitive-canary/blob/cc014eb35c5af5424e47286d64884d335b020c2a/docs/rules.md
- Repository URL: https://github.com/coo-quack/sensitive-canary
- Assessment: unconfirmed; do not use or test any credentials.

### 1640. P3_LOW_SIGNAL — coppinger/stream-leak-guard

- Path: `README.md`
- Indicator: `github_app_token_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/coppinger/stream-leak-guard/blob/798a07065b47788dc642b2a17dbb6c5aeff52f7a/README.md
- Repository URL: https://github.com/coppinger/stream-leak-guard
- Assessment: unconfirmed; do not use or test any credentials.

### 1641. P3_LOW_SIGNAL — cpkkcb/fuzzDicts

- Path: `php.txt`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/cpkkcb/fuzzDicts/blob/1aa1cbfb73c5a065da3696f11526021c3b545b7a/php.txt
- Repository URL: https://github.com/cpkkcb/fuzzDicts
- Assessment: unconfirmed; do not use or test any credentials.

### 1642. P3_LOW_SIGNAL — cpredef/predef

- Path: `Compilers.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/cpredef/predef/blob/80605e6fd286ff2a14f35346199b785eb7813c2d/Compilers.md
- Repository URL: https://github.com/cpredef/predef
- Assessment: unconfirmed; do not use or test any credentials.

### 1643. P3_LOW_SIGNAL — cran/gh

- Path: `NEWS.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/cran/gh/blob/73aa2e424f57265ec7e8da9d8e190860feb51366/NEWS.md
- Repository URL: https://github.com/cran/gh
- Assessment: unconfirmed; do not use or test any credentials.

### 1644. P3_LOW_SIGNAL — crosstyan/crosstyan-notes

- Path: `Maven.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/crosstyan/crosstyan-notes/blob/5bd4eba88b31a7a0bd61a52bd7bf91b0704a1b0f/Maven.md
- Repository URL: https://github.com/crosstyan/crosstyan-notes
- Assessment: unconfirmed; do not use or test any credentials.

### 1645. P3_LOW_SIGNAL — curiouslearning/ImageInstaller

- Path: `src/.id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/curiouslearning/ImageInstaller/blob/3b9ba0f1eddfac4de17266facb86eaea5e5d9d7d/src/.id_rsa
- Repository URL: https://github.com/curiouslearning/ImageInstaller
- Assessment: unconfirmed; do not use or test any credentials.

### 1646. P3_LOW_SIGNAL — curtcox/JLHTTP

- Path: `faq.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/curtcox/JLHTTP/blob/8e2b12df2bc24b0b53fa82902edc71591ee10130/faq.md
- Repository URL: https://github.com/curtcox/JLHTTP
- Assessment: unconfirmed; do not use or test any credentials.

### 1647. P3_LOW_SIGNAL — cxai/Docker-CxCore

- Path: `run.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/cxai/Docker-CxCore/blob/4d7842a10242acc45867595b711611337531f52c/run.md
- Repository URL: https://github.com/cxai/Docker-CxCore
- Assessment: unconfirmed; do not use or test any credentials.

### 1648. P3_LOW_SIGNAL — cyclone-tw/cyclone-workflow

- Path: `key.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/cyclone-tw/cyclone-workflow/blob/f8a8374a1fd96eb4ac76fc86c594db6ab49242ad/key.md
- Repository URL: https://github.com/cyclone-tw/cyclone-workflow
- Assessment: unconfirmed; do not use or test any credentials.

### 1649. P3_LOW_SIGNAL — cyfinoid/ghnavigator

- Path: `AGENTS.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/cyfinoid/ghnavigator/blob/b0b5be55d5cfac3542d41647a6c02003505d0be4/AGENTS.md
- Repository URL: https://github.com/cyfinoid/ghnavigator
- Assessment: unconfirmed; do not use or test any credentials.

### 1650. P3_LOW_SIGNAL — cyfinoid/sbomplay

- Path: `CHANGELOG.md`
- Indicator: `github_oauth_prefix;github_app_token_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/cyfinoid/sbomplay/blob/337604afaa214003fc1fd3d32447074c21ba1c62/CHANGELOG.md
- Repository URL: https://github.com/cyfinoid/sbomplay
- Assessment: unconfirmed; do not use or test any credentials.

### 1651. P3_LOW_SIGNAL — dan-hart/reprise

- Path: `SECURITY.md`
- Indicator: `github_oauth_prefix;github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dan-hart/reprise/blob/db6fabb2f1cf5b4c98fb44c3a193f5df32efcde5/SECURITY.md
- Repository URL: https://github.com/dan-hart/reprise
- Assessment: unconfirmed; do not use or test any credentials.

### 1652. P3_LOW_SIGNAL — dangdat182/VotingApp

- Path: `.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dangdat182/VotingApp/blob/6e017765c46dbdc0756c344b7967f8ae56ddd271/.terraform.tfstate.lock.info
- Repository URL: https://github.com/dangdat182/VotingApp
- Assessment: unconfirmed; do not use or test any credentials.

### 1653. P3_LOW_SIGNAL — danieltamas/cloak

- Path: `llms.txt`
- Indicator: `github_token_prefix;slack_token_prefix;stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/danieltamas/cloak/blob/fbc1aee59cba49edd8964baab8515ef3f3009453/llms.txt
- Repository URL: https://github.com/danieltamas/cloak
- Assessment: unconfirmed; do not use or test any credentials.

### 1654. P3_LOW_SIGNAL — danielvartan/logoactions

- Path: `NEWS.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/danielvartan/logoactions/blob/0751ef9d27dd33832cf2a44c9bcce84a72febff2/NEWS.md
- Repository URL: https://github.com/danielvartan/logoactions
- Assessment: unconfirmed; do not use or test any credentials.

### 1655. P3_LOW_SIGNAL — daniloamg-lang/portfolio

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/daniloamg-lang/portfolio/blob/4b347e4d8ca48b9412b531af85ea05b95a7d4d5e/README.md
- Repository URL: https://github.com/daniloamg-lang/portfolio
- Assessment: unconfirmed; do not use or test any credentials.

### 1656. P3_LOW_SIGNAL — danishdotdev/MeetBot

- Path: `CLAUDE.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/danishdotdev/MeetBot/blob/5c97c2c5d257f8cad63dfc7e99eb1de723ce14a0/CLAUDE.md
- Repository URL: https://github.com/danishdotdev/MeetBot
- Assessment: unconfirmed; do not use or test any credentials.

### 1657. P3_LOW_SIGNAL — danishdotdev/Scribely

- Path: `CLAUDE.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/danishdotdev/Scribely/blob/6131fe1c44d72c29ae6785514c1925d449e244c7/CLAUDE.md
- Repository URL: https://github.com/danishdotdev/Scribely
- Assessment: unconfirmed; do not use or test any credentials.

### 1658. P3_LOW_SIGNAL — darkresq14/Advent-Of-Cyber-2021

- Path: `17.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/darkresq14/Advent-Of-Cyber-2021/blob/b415a3c978f92b49be7635f9ca40402785f897dd/17.md
- Repository URL: https://github.com/darkresq14/Advent-Of-Cyber-2021
- Assessment: unconfirmed; do not use or test any credentials.

### 1659. P3_LOW_SIGNAL — darrenoakey/dazllm

- Path: `USAGE.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/darrenoakey/dazllm/blob/d0762cca594299f8c9fa757533e5d5d0148f8917/USAGE.md
- Repository URL: https://github.com/darrenoakey/dazllm
- Assessment: unconfirmed; do not use or test any credentials.

### 1660. P3_LOW_SIGNAL — darrynjordan/pyfers

- Path: `dev.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/darrynjordan/pyfers/blob/c58e325c933350fc5967ade55980761365610235/dev.md
- Repository URL: https://github.com/darrynjordan/pyfers
- Assessment: unconfirmed; do not use or test any credentials.

### 1661. P3_LOW_SIGNAL — dashroshan/mess-management-system

- Path: `SETUP.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dashroshan/mess-management-system/blob/ef8fb600429f16721733abe8ec473077faebc383/SETUP.md
- Repository URL: https://github.com/dashroshan/mess-management-system
- Assessment: unconfirmed; do not use or test any credentials.

### 1662. P3_LOW_SIGNAL — databrary/analytics

- Path: `_tmp.qmd`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/databrary/analytics/blob/4972406e2c715993ea6e4ab9229e36e26e332927/_tmp.qmd
- Repository URL: https://github.com/databrary/analytics
- Assessment: unconfirmed; do not use or test any credentials.

### 1663. P3_LOW_SIGNAL — datastone-spirit/spirit-gpu

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/datastone-spirit/spirit-gpu/blob/acf6af0c4e46b27047c48db079ac16743ca277f8/API.md
- Repository URL: https://github.com/datastone-spirit/spirit-gpu
- Assessment: unconfirmed; do not use or test any credentials.

### 1664. P3_LOW_SIGNAL — datboyblu3/azure_wazuh_terraform

- Path: `.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/datboyblu3/azure_wazuh_terraform/blob/f9b1a64e818411f7ba615fae8d471910386048a5/.terraform.tfstate.lock.info
- Repository URL: https://github.com/datboyblu3/azure_wazuh_terraform
- Assessment: unconfirmed; do not use or test any credentials.

### 1665. P3_LOW_SIGNAL — davemelk100/themal

- Path: `SETUP.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/davemelk100/themal/blob/9fe403982548637a92aaaf02f3ac78483d09d63b/SETUP.md
- Repository URL: https://github.com/davemelk100/themal
- Assessment: unconfirmed; do not use or test any credentials.

### 1666. P3_LOW_SIGNAL — davideuler/agent-watch

- Path: `spec.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/davideuler/agent-watch/blob/8696d2e9895cdcc1cceaaff9a430dd746b224c48/spec.md
- Repository URL: https://github.com/davideuler/agent-watch
- Assessment: unconfirmed; do not use or test any credentials.

### 1667. P3_LOW_SIGNAL — davidheryanto/etc

- Path: `ssh.txt`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/davidheryanto/etc/blob/ede405c3d8d20aed6a5846bfb8430205c03f15ef/ssh.txt
- Repository URL: https://github.com/davidheryanto/etc
- Assessment: unconfirmed; do not use or test any credentials.

### 1668. P3_LOW_SIGNAL — davidmosiah/delx-memory

- Path: `llms.txt`
- Indicator: `github_token_prefix;github_pat_prefix;slack_token_prefix;stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/davidmosiah/delx-memory/blob/4937ca37edc08c5f55e2a0790d437829e6d676c7/llms.txt
- Repository URL: https://github.com/davidmosiah/delx-memory
- Assessment: unconfirmed; do not use or test any credentials.

### 1669. P3_LOW_SIGNAL — dawksh/leaklint

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dawksh/leaklint/blob/aad48adde0ab02c29424d9c9a371ea5a964c888c/README.md
- Repository URL: https://github.com/dawksh/leaklint
- Assessment: unconfirmed; do not use or test any credentials.

### 1670. P3_LOW_SIGNAL — dayt0n/minivault

- Path: `DOCS.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dayt0n/minivault/blob/a57c732ee0c8c5460c99507781378a8b18a049d6/DOCS.md
- Repository URL: https://github.com/dayt0n/minivault
- Assessment: unconfirmed; do not use or test any credentials.

### 1671. P3_LOW_SIGNAL — dcSpark/shinkai-slackbot-python

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dcSpark/shinkai-slackbot-python/blob/37eeb259fc2fd1d0a6b8ad5b0be3bdc0059db432/README.md
- Repository URL: https://github.com/dcSpark/shinkai-slackbot-python
- Assessment: unconfirmed; do not use or test any credentials.

### 1672. P3_LOW_SIGNAL — deciduously/music

- Path: `post.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/deciduously/music/blob/2afcbf0a44fcb0800d8a35ea5af8141f2c49e7e7/post.md
- Repository URL: https://github.com/deciduously/music
- Assessment: unconfirmed; do not use or test any credentials.

### 1673. P3_LOW_SIGNAL — deepesh-sr/arc-design-in-seconds

- Path: `README.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/deepesh-sr/arc-design-in-seconds/blob/3492e5e89c59caf6a77b33f92214839d6c319c38/README.md
- Repository URL: https://github.com/deepesh-sr/arc-design-in-seconds
- Assessment: unconfirmed; do not use or test any credentials.

### 1674. P3_LOW_SIGNAL — delivops/jenkins-failures-analyzer

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/delivops/jenkins-failures-analyzer/blob/0438332d849d7266484e5c69abc7134a96ad595f/README.md
- Repository URL: https://github.com/delivops/jenkins-failures-analyzer
- Assessment: unconfirmed; do not use or test any credentials.

### 1675. P3_LOW_SIGNAL — delucis/astro-badge

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/delucis/astro-badge/blob/e300a3d96138891fb70b58cc2d9ded5ed0e04b7c/README.md
- Repository URL: https://github.com/delucis/astro-badge
- Assessment: unconfirmed; do not use or test any credentials.

### 1676. P3_LOW_SIGNAL — demo-space/github-oauth-demo

- Path: `HOW.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/demo-space/github-oauth-demo/blob/1fef36bea17ae64f1ffc1952f8a22f05afe38e8c/HOW.md
- Repository URL: https://github.com/demo-space/github-oauth-demo
- Assessment: unconfirmed; do not use or test any credentials.

### 1677. P3_LOW_SIGNAL — denisgriban-ai/firstmyhtml-site

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/denisgriban-ai/firstmyhtml-site/blob/bbf8a4c01093fc2654075c9d48faa431605da91c/README.md
- Repository URL: https://github.com/denisgriban-ai/firstmyhtml-site
- Assessment: unconfirmed; do not use or test any credentials.

### 1678. P3_LOW_SIGNAL — dennisdevulder/ltm

- Path: `SPEC.md`
- Indicator: `github_token_prefix;aws_access_key;stripe_live_prefix;google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dennisdevulder/ltm/blob/153eee5fc08949db80d48ea5f61ccb3d54df6d80/SPEC.md
- Repository URL: https://github.com/dennisdevulder/ltm
- Assessment: unconfirmed; do not use or test any credentials.

### 1679. P3_LOW_SIGNAL — denocn/deno_docs

- Path: `node.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/denocn/deno_docs/blob/eb10ad7d025fbaaf43a70b9e6349372e89661a4f/node.md
- Repository URL: https://github.com/denocn/deno_docs
- Assessment: unconfirmed; do not use or test any credentials.

### 1680. P3_LOW_SIGNAL — deontologician/pipr

- Path: `tut.org`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/deontologician/pipr/blob/a8f0468bbc7ec28116f9dc4af3565754bcd10ba1/tut.org
- Repository URL: https://github.com/deontologician/pipr
- Assessment: unconfirmed; do not use or test any credentials.

### 1681. P3_LOW_SIGNAL — des4maisons/til

- Path: `til.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/des4maisons/til/blob/7e3fb09f21d86dbc53b3394dda658f0d3b932e59/til.md
- Repository URL: https://github.com/des4maisons/til
- Assessment: unconfirmed; do not use or test any credentials.

### 1682. P3_LOW_SIGNAL — designinlife/version-checker

- Path: `RUN.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/designinlife/version-checker/blob/0f88905a660ea69fed26a86a876ff1c103f46512/RUN.md
- Repository URL: https://github.com/designinlife/version-checker
- Assessment: unconfirmed; do not use or test any credentials.

### 1683. P3_LOW_SIGNAL — desplega-ai/github-issues-swipe

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/desplega-ai/github-issues-swipe/blob/58d261c4e7eb3f2219da8ccec7435cc583aa8e32/SETUP.md
- Repository URL: https://github.com/desplega-ai/github-issues-swipe
- Assessment: unconfirmed; do not use or test any credentials.

### 1684. P3_LOW_SIGNAL — desplega-ai/qa-use

- Path: `MCP.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/desplega-ai/qa-use/blob/ee45336391d121667f6a8b4f8147593afdb456ef/MCP.md
- Repository URL: https://github.com/desplega-ai/qa-use
- Assessment: unconfirmed; do not use or test any credentials.

### 1685. P3_LOW_SIGNAL — dev-asadali/paydirectly-php

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dev-asadali/paydirectly-php/blob/f8a34f7a7e61e7b9d3679be3faa60e88bd948c28/README.md
- Repository URL: https://github.com/dev-asadali/paydirectly-php
- Assessment: unconfirmed; do not use or test any credentials.

### 1686. P3_LOW_SIGNAL — devalkotak/GRC-AWS-Lab

- Path: `TODO.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/devalkotak/GRC-AWS-Lab/blob/21ceb8a73be1c3084c16e00f9c12c94780af5287/TODO.md
- Repository URL: https://github.com/devalkotak/GRC-AWS-Lab
- Assessment: unconfirmed; do not use or test any credentials.

### 1687. P3_LOW_SIGNAL — devanshuruhela/react-native-feedback-hub

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/devanshuruhela/react-native-feedback-hub/blob/eb9d12a6ca6a5c3e6dfcdb48e325508c6106e23a/README.md
- Repository URL: https://github.com/devanshuruhela/react-native-feedback-hub
- Assessment: unconfirmed; do not use or test any credentials.

### 1688. P3_LOW_SIGNAL — deve1070/Bus-tracking-app

- Path: `api.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/deve1070/Bus-tracking-app/blob/b476f987a439fa233c1f84e159d588eaa0d799f9/api.md
- Repository URL: https://github.com/deve1070/Bus-tracking-app
- Assessment: unconfirmed; do not use or test any credentials.

### 1689. P3_LOW_SIGNAL — devrgar-cyber/ghostlinklabs

- Path: `3.txt`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/devrgar-cyber/ghostlinklabs/blob/bc5e0100a80f4d963312c61565d879b99c73402c/3.txt
- Repository URL: https://github.com/devrgar-cyber/ghostlinklabs
- Assessment: unconfirmed; do not use or test any credentials.

### 1690. P3_LOW_SIGNAL — devx-cafe/gh-tt

- Path: `docs/auth.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/devx-cafe/gh-tt/blob/dc44520145b1f076a6b9350f7b2612dd9e0fd737/docs/auth.md
- Repository URL: https://github.com/devx-cafe/gh-tt
- Assessment: unconfirmed; do not use or test any credentials.

### 1691. P3_LOW_SIGNAL — dewi-alliance/hotspot-manufacturers

- Path: `wifx.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dewi-alliance/hotspot-manufacturers/blob/2d40a2b79a4f04f0e1d16ce302a59b90971fb046/wifx.md
- Repository URL: https://github.com/dewi-alliance/hotspot-manufacturers
- Assessment: unconfirmed; do not use or test any credentials.

### 1692. P3_LOW_SIGNAL — dfdeshom/sfpy

- Path: `README`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dfdeshom/sfpy/blob/99121d06e0fd72f4ef3d3319456fc01ecc6d1d19/README
- Repository URL: https://github.com/dfdeshom/sfpy
- Assessment: unconfirmed; do not use or test any credentials.

### 1693. P3_LOW_SIGNAL — dheybenclave/DClaveria_Playwright_Python_BDD

- Path: `KILO.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dheybenclave/DClaveria_Playwright_Python_BDD/blob/d5242eb63fb20ce24ce501a70535ff24142918d3/KILO.md
- Repository URL: https://github.com/dheybenclave/DClaveria_Playwright_Python_BDD
- Assessment: unconfirmed; do not use or test any credentials.

### 1694. P3_LOW_SIGNAL — dhui808/software-concepts

- Path: `jq.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dhui808/software-concepts/blob/0a31d2cb7855246b2aabf037a8644d2d816bc063/jq.md
- Repository URL: https://github.com/dhui808/software-concepts
- Assessment: unconfirmed; do not use or test any credentials.

### 1695. P3_LOW_SIGNAL — dhwani-ris/frappe-stack

- Path: `PLAN.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dhwani-ris/frappe-stack/blob/69204a188a02f5368fc45ba02301b099954c70c2/PLAN.md
- Repository URL: https://github.com/dhwani-ris/frappe-stack
- Assessment: unconfirmed; do not use or test any credentials.

### 1696. P3_LOW_SIGNAL — digidem/mapeo-map-server

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/digidem/mapeo-map-server/blob/3bca921e961e5e6cd20cefff69771067f26ec423/API.md
- Repository URL: https://github.com/digidem/mapeo-map-server
- Assessment: unconfirmed; do not use or test any credentials.

### 1697. P3_LOW_SIGNAL — digistump/docs

- Path: `api.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/digistump/docs/blob/8d8eded5a49f7c640a4627dd1689100a8890912d/api.md
- Repository URL: https://github.com/digistump/docs
- Assessment: unconfirmed; do not use or test any credentials.

### 1698. P3_LOW_SIGNAL — digitaldrreamer/broomsticks

- Path: `PLAN.md`
- Indicator: `aws_access_key;google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/digitaldrreamer/broomsticks/blob/e175aa072d509e7f69f20b47adc3fdbd044add86/PLAN.md
- Repository URL: https://github.com/digitaldrreamer/broomsticks
- Assessment: unconfirmed; do not use or test any credentials.

### 1699. P3_LOW_SIGNAL — digitalocean/ovs

- Path: `NEWS`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/digitalocean/ovs/blob/22d4614ddf83988a3771fb379ea029e663b4455a/NEWS
- Repository URL: https://github.com/digitalocean/ovs
- Assessment: unconfirmed; do not use or test any credentials.

### 1700. P3_LOW_SIGNAL — dimetron/mcp-servers

- Path: `MCP.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dimetron/mcp-servers/blob/3f367d2309aad605d5f29ba7f3bd4543e93f31de/MCP.md
- Repository URL: https://github.com/dimetron/mcp-servers
- Assessment: unconfirmed; do not use or test any credentials.

### 1701. P3_LOW_SIGNAL — dkahle/ggmap

- Path: `NEWS`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dkahle/ggmap/blob/a0fed5c9fd6d3ef1f040496b1fce341fd60bd62e/NEWS
- Repository URL: https://github.com/dkahle/ggmap
- Assessment: unconfirmed; do not use or test any credentials.

### 1702. P3_LOW_SIGNAL — docToolchain/docToolchain

- Path: `LLM.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/docToolchain/docToolchain/blob/530994519bd0364eac7d2c671922b18b2ae3dd03/LLM.md
- Repository URL: https://github.com/docToolchain/docToolchain
- Assessment: unconfirmed; do not use or test any credentials.

### 1703. P3_LOW_SIGNAL — docker/portcullis

- Path: `rules.go`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/docker/portcullis/blob/a2eb85db2b08ca2c73739d87df4de58e99fe1b86/rules.go
- Repository URL: https://github.com/docker/portcullis
- Assessment: unconfirmed; do not use or test any credentials.

### 1704. P3_LOW_SIGNAL — doggy8088/build-web-application-with-golang-zhtw

- Path: `14.4.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/doggy8088/build-web-application-with-golang-zhtw/blob/6f78a19ff83725ed311e47c1306b56c5b1e6204d/14.4.md
- Repository URL: https://github.com/doggy8088/build-web-application-with-golang-zhtw
- Assessment: unconfirmed; do not use or test any credentials.

### 1705. P3_LOW_SIGNAL — dollarkillerx/plumber

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dollarkillerx/plumber/blob/06ba2a117237381a9dbf7264e47c9d7a0cf85fa2/API.md
- Repository URL: https://github.com/dollarkillerx/plumber
- Assessment: unconfirmed; do not use or test any credentials.

### 1706. P3_LOW_SIGNAL — dotlang/language

- Path: `howto.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dotlang/language/blob/27a6a5f5349035402ce14e0630795c6ce83d7384/howto.md
- Repository URL: https://github.com/dotlang/language
- Assessment: unconfirmed; do not use or test any credentials.

### 1707. P3_LOW_SIGNAL — dragoonis/terraform-jenkins

- Path: `.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dragoonis/terraform-jenkins/blob/69f3d91e9635af579769e7b88d6a7ea0e3a72a2b/.terraform.tfstate.lock.info
- Repository URL: https://github.com/dragoonis/terraform-jenkins
- Assessment: unconfirmed; do not use or test any credentials.

### 1708. P3_LOW_SIGNAL — drakonstein/cephbot

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/drakonstein/cephbot/blob/5cd51c4ac1c0f04c5e12ce803bb6b823483c8c25/README.md
- Repository URL: https://github.com/drakonstein/cephbot
- Assessment: unconfirmed; do not use or test any credentials.

### 1709. P3_LOW_SIGNAL — drkennetz/slackgpt

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/drkennetz/slackgpt/blob/e8848a0c276a7aa68c02415e7e87bd5733dd5fd5/README.md
- Repository URL: https://github.com/drkennetz/slackgpt
- Assessment: unconfirmed; do not use or test any credentials.

### 1710. P3_LOW_SIGNAL — dsegovia90/github-release-downloader

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dsegovia90/github-release-downloader/blob/6de76ebf527c3b5401fdc1734283a70671e97783/README.md
- Repository URL: https://github.com/dsegovia90/github-release-downloader
- Assessment: unconfirmed; do not use or test any credentials.

### 1711. P3_LOW_SIGNAL — dsifry/goodtogo

- Path: `USAGE.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dsifry/goodtogo/blob/08bc6ad7290ae603615e77e5b7b918489b07529e/USAGE.md
- Repository URL: https://github.com/dsifry/goodtogo
- Assessment: unconfirmed; do not use or test any credentials.

### 1712. P3_LOW_SIGNAL — dspereira/42Cursus-transcendence

- Path: `env.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dspereira/42Cursus-transcendence/blob/6d038c7fc77c3939534d1f10263614e9b221bd9b/env.md
- Repository URL: https://github.com/dspereira/42Cursus-transcendence
- Assessment: unconfirmed; do not use or test any credentials.

### 1713. P3_LOW_SIGNAL — dsw0214/linux-commands

- Path: `scp.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dsw0214/linux-commands/blob/1172b23982b76cc24e4c08b028e5003a5ec23bd5/scp.md
- Repository URL: https://github.com/dsw0214/linux-commands
- Assessment: unconfirmed; do not use or test any credentials.

### 1714. P3_LOW_SIGNAL — dtbuchholz/agent-context

- Path: `PLAN.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dtbuchholz/agent-context/blob/066beb6122ed8c6c146ad88b897f9082f6477f54/PLAN.md
- Repository URL: https://github.com/dtbuchholz/agent-context
- Assessment: unconfirmed; do not use or test any credentials.

### 1715. P3_LOW_SIGNAL — dukanov/research-monitor

- Path: `USAGE.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dukanov/research-monitor/blob/00f3cfc70dc154a850f5d7500c2661dcb9a394d8/USAGE.md
- Repository URL: https://github.com/dukanov/research-monitor
- Assessment: unconfirmed; do not use or test any credentials.

### 1716. P3_LOW_SIGNAL — dunova/ContextGO

- Path: `docs/MIGRATION.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dunova/ContextGO/blob/66376f4d478c6911263c8e3c727c724a06ae669e/docs/MIGRATION.md
- Repository URL: https://github.com/dunova/ContextGO
- Assessment: unconfirmed; do not use or test any credentials.

### 1717. P3_LOW_SIGNAL — dvstLab/docker-builder

- Path: `Arch`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dvstLab/docker-builder/blob/c66a4711ca3acb38aab03c8636aaee04178afb04/Arch
- Repository URL: https://github.com/dvstLab/docker-builder
- Assessment: unconfirmed; do not use or test any credentials.

### 1718. P3_LOW_SIGNAL — dvstLab/docker-builder

- Path: `Focal`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dvstLab/docker-builder/blob/c66a4711ca3acb38aab03c8636aaee04178afb04/Focal
- Repository URL: https://github.com/dvstLab/docker-builder
- Assessment: unconfirmed; do not use or test any credentials.

### 1719. P3_LOW_SIGNAL — dvstLab/docker-builder

- Path: `Lite`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/dvstLab/docker-builder/blob/c66a4711ca3acb38aab03c8636aaee04178afb04/Lite
- Repository URL: https://github.com/dvstLab/docker-builder
- Assessment: unconfirmed; do not use or test any credentials.

### 1720. P3_LOW_SIGNAL — eXist-db/exist

- Path: `BUILD.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/eXist-db/exist/blob/970242ae9855f7dc3fee11bcb5d7ab902e8a0d45/BUILD.md
- Repository URL: https://github.com/eXist-db/exist
- Assessment: unconfirmed; do not use or test any credentials.

### 1721. P3_LOW_SIGNAL — eastlondoner/vibe-tools

- Path: `README.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/eastlondoner/vibe-tools/blob/4a1d17cf501db3a719a9c2bf0ee0d288282a63a7/README.md
- Repository URL: https://github.com/eastlondoner/vibe-tools
- Assessment: unconfirmed; do not use or test any credentials.

### 1722. P3_LOW_SIGNAL — easyeye163/vimax-agnes

- Path: `zh.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/easyeye163/vimax-agnes/blob/422745f91debc8de79b357862060c372d684f95d/zh.md
- Repository URL: https://github.com/easyeye163/vimax-agnes
- Assessment: unconfirmed; do not use or test any credentials.

### 1723. P3_LOW_SIGNAL — eduardohitek/brag-cli

- Path: `README.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/eduardohitek/brag-cli/blob/99506cf75e7af9ed129737de98eb1866325a9217/README.md
- Repository URL: https://github.com/eduardohitek/brag-cli
- Assessment: unconfirmed; do not use or test any credentials.

### 1724. P3_LOW_SIGNAL — eeeeeeeeee-code/e0e1-wx

- Path: `SKILL.md`
- Indicator: `github_token_prefix;github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/eeeeeeeeee-code/e0e1-wx/blob/1f8dded6a3e8c3c76806fb504999dc45ed61eac0/SKILL.md
- Repository URL: https://github.com/eeeeeeeeee-code/e0e1-wx
- Assessment: unconfirmed; do not use or test any credentials.

### 1725. P3_LOW_SIGNAL — effectiveailabs/effective-claude-plugin

- Path: `README.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/effectiveailabs/effective-claude-plugin/blob/1e9f71c68b641bceb31ae9c8c718f0ec9e8c297f/README.md
- Repository URL: https://github.com/effectiveailabs/effective-claude-plugin
- Assessment: unconfirmed; do not use or test any credentials.

### 1726. P3_LOW_SIGNAL — ego-debug/safeship-demo

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ego-debug/safeship-demo/blob/0d3453c032ce82fa794dec08f28e289d1ca3624c/README.md
- Repository URL: https://github.com/ego-debug/safeship-demo
- Assessment: unconfirmed; do not use or test any credentials.

### 1727. P3_LOW_SIGNAL — elastic/supply-chain-monitor

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/elastic/supply-chain-monitor/blob/78fa132597779e1ba9de903fb91c7f0bfb9bbf87/README.md
- Repository URL: https://github.com/elastic/supply-chain-monitor
- Assessment: unconfirmed; do not use or test any credentials.

### 1728. P3_LOW_SIGNAL — elberrd/impactus-cli

- Path: `DOCS.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/elberrd/impactus-cli/blob/554920fbc4d23857784bdabee2d2632314e06815/DOCS.md
- Repository URL: https://github.com/elberrd/impactus-cli
- Assessment: unconfirmed; do not use or test any credentials.

### 1729. P3_LOW_SIGNAL — electricimp/Builder

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/electricimp/Builder/blob/f6f5f45d269b9ece7ac0b0d4412c4ef198e09c86/README.md
- Repository URL: https://github.com/electricimp/Builder
- Assessment: unconfirmed; do not use or test any credentials.

### 1730. P3_LOW_SIGNAL — elijah629/som-econ

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/elijah629/som-econ/blob/8dbdd0ca5e416ccd5d88263e27cf9d3ae69efba9/README.md
- Repository URL: https://github.com/elijah629/som-econ
- Assessment: unconfirmed; do not use or test any credentials.

### 1731. P3_LOW_SIGNAL — eloklam/oh-my-hermes-agent

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/eloklam/oh-my-hermes-agent/blob/3c51f099933bd15e041b182554cda853c7d0f7b3/README.md
- Repository URL: https://github.com/eloklam/oh-my-hermes-agent
- Assessment: unconfirmed; do not use or test any credentials.

### 1732. P3_LOW_SIGNAL — elvyn/ml-agent-scanner

- Path: `plan.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/elvyn/ml-agent-scanner/blob/4fcff38b89ce869138b3ab03990b4a183f3abf50/plan.md
- Repository URL: https://github.com/elvyn/ml-agent-scanner
- Assessment: unconfirmed; do not use or test any credentials.

### 1733. P3_LOW_SIGNAL — emedege/Tienda-Mandarino

- Path: `SETUP.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/emedege/Tienda-Mandarino/blob/9745451ffe492880ce8414b6163ba3b36073cdea/SETUP.md
- Repository URL: https://github.com/emedege/Tienda-Mandarino
- Assessment: unconfirmed; do not use or test any credentials.

### 1734. P3_LOW_SIGNAL — emersonbusson/ramshared

- Path: `TASK.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/emersonbusson/ramshared/blob/1bcc98068218f48aa357103b21e7ee692df91939/TASK.md
- Repository URL: https://github.com/emersonbusson/ramshared
- Assessment: unconfirmed; do not use or test any credentials.

### 1735. P3_LOW_SIGNAL — emfcamp/badge-2024-app-store

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/emfcamp/badge-2024-app-store/blob/d90cb5925ed74061f61aaa6357710c20f5c003bd/README.md
- Repository URL: https://github.com/emfcamp/badge-2024-app-store
- Assessment: unconfirmed; do not use or test any credentials.

### 1736. P3_LOW_SIGNAL — emilywang188/educ-final-project

- Path: `SETUP.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/emilywang188/educ-final-project/blob/4d008a07b70029ed208462b413908e9cec45e60d/SETUP.md
- Repository URL: https://github.com/emilywang188/educ-final-project
- Assessment: unconfirmed; do not use or test any credentials.

### 1737. P3_LOW_SIGNAL — emmcygn/slack-builder-bot

- Path: `SETUP.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/emmcygn/slack-builder-bot/blob/b8bba70709095162c70af7a56e53e3c4a1f7a1ad/SETUP.md
- Repository URL: https://github.com/emmcygn/slack-builder-bot
- Assessment: unconfirmed; do not use or test any credentials.

### 1738. P3_LOW_SIGNAL — emsi/gh_copilot_unofficial_openai_client

- Path: `README.MD`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/emsi/gh_copilot_unofficial_openai_client/blob/795f122b08d68dd8e00f00c3959ff39f9cd23f10/README.MD
- Repository URL: https://github.com/emsi/gh_copilot_unofficial_openai_client
- Assessment: unconfirmed; do not use or test any credentials.

### 1739. P3_LOW_SIGNAL — encyc/vibe-trading

- Path: `TODO.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/encyc/vibe-trading/blob/1319be9ac819365f82abd4a186e157a2fa58ca30/TODO.md
- Repository URL: https://github.com/encyc/vibe-trading
- Assessment: unconfirmed; do not use or test any credentials.

### 1740. P3_LOW_SIGNAL — endomorphosis/lift_coding

- Path: `SECURITY.md`
- Indicator: `github_oauth_prefix;github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/endomorphosis/lift_coding/blob/58d123053e605a54ab3111ec3576047d5fd04a5f/SECURITY.md
- Repository URL: https://github.com/endomorphosis/lift_coding
- Assessment: unconfirmed; do not use or test any credentials.

### 1741. P3_LOW_SIGNAL — engineers-hub-ltd-in-house-project/slack-claude-code-integration

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/engineers-hub-ltd-in-house-project/slack-claude-code-integration/blob/3dcf144e8100d3592ed42058ebd44c26e1893387/README.md
- Repository URL: https://github.com/engineers-hub-ltd-in-house-project/slack-claude-code-integration
- Assessment: unconfirmed; do not use or test any credentials.

### 1742. P3_LOW_SIGNAL — enginterzi/amazon-seller-mcp

- Path: `SETUP.md`
- Indicator: `secret_access_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/enginterzi/amazon-seller-mcp/blob/c58550f9d1b245af1773755fbe15f500b51f9a73/SETUP.md
- Repository URL: https://github.com/enginterzi/amazon-seller-mcp
- Assessment: unconfirmed; do not use or test any credentials.

### 1743. P3_LOW_SIGNAL — erickalfaro/multitable

- Path: `CLAUDE.md`
- Indicator: `github_pat_prefix;github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/erickalfaro/multitable/blob/eefdd06f0681b0111591bb8e0eef8cfa5408d490/CLAUDE.md
- Repository URL: https://github.com/erickalfaro/multitable
- Assessment: unconfirmed; do not use or test any credentials.

### 1744. P3_LOW_SIGNAL — escopecz/mautic-do-action

- Path: `README.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/escopecz/mautic-do-action/blob/3677c96253bfb766d566b83dd25c569ef66cc75d/README.md
- Repository URL: https://github.com/escopecz/mautic-do-action
- Assessment: unconfirmed; do not use or test any credentials.

### 1745. P3_LOW_SIGNAL — eternalmangekyo022/hono-backend

- Path: `.rest`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/eternalmangekyo022/hono-backend/blob/71f099dfb61317cdc3370187a3f3b91073790e64/.rest
- Repository URL: https://github.com/eternalmangekyo022/hono-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 1746. P3_LOW_SIGNAL — ethan0905/youtubeurl_to_shorts

- Path: `SETUP.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ethan0905/youtubeurl_to_shorts/blob/2e18c3f3515cac1a39772f120fb92109cc077f81/SETUP.md
- Repository URL: https://github.com/ethan0905/youtubeurl_to_shorts
- Assessment: unconfirmed; do not use or test any credentials.

### 1747. P3_LOW_SIGNAL — ethereum/devp2p

- Path: `rlpx.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ethereum/devp2p/blob/2c19a28b25c29487773ad6b07243e290fa8d65ec/rlpx.md
- Repository URL: https://github.com/ethereum/devp2p
- Assessment: unconfirmed; do not use or test any credentials.

### 1748. P3_LOW_SIGNAL — ety001/oh-slack

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ety001/oh-slack/blob/e3643fcd09715a3d7ffa4dd6c2c9d5afde346646/README.md
- Repository URL: https://github.com/ety001/oh-slack
- Assessment: unconfirmed; do not use or test any credentials.

### 1749. P3_LOW_SIGNAL — evan-gan/ticketSlackBot

- Path: `readme.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/evan-gan/ticketSlackBot/blob/699eb608b1d960eb13844bec00fa11e09df23124/readme.md
- Repository URL: https://github.com/evan-gan/ticketSlackBot
- Assessment: unconfirmed; do not use or test any credentials.

### 1750. P3_LOW_SIGNAL — evina29/EvinaHennovate2026-Deldot-DMV-team

- Path: `DEMO.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/evina29/EvinaHennovate2026-Deldot-DMV-team/blob/b0047afdbc9c1c9c899c83ff40185a9f65d80927/DEMO.md
- Repository URL: https://github.com/evina29/EvinaHennovate2026-Deldot-DMV-team
- Assessment: unconfirmed; do not use or test any credentials.

### 1751. P3_LOW_SIGNAL — exasol/dbt-exasol

- Path: `uv.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/exasol/dbt-exasol/blob/4dcaeba882cffebc3a549e159ec73c32099adbf4/uv.md
- Repository URL: https://github.com/exasol/dbt-exasol
- Assessment: unconfirmed; do not use or test any credentials.

### 1752. P3_LOW_SIGNAL — exfil0/FalconOne-IMSI

- Path: `USAGE.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/exfil0/FalconOne-IMSI/blob/8c48f9bf5506b4708453c05ab3a50fe402d1596a/USAGE.md
- Repository URL: https://github.com/exfil0/FalconOne-IMSI
- Assessment: unconfirmed; do not use or test any credentials.

### 1753. P3_LOW_SIGNAL — exoad/linkvault

- Path: `SECURITY.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/exoad/linkvault/blob/48a1f62ad9cd3757720fa45db550ab5470e5ba21/SECURITY.md
- Repository URL: https://github.com/exoad/linkvault
- Assessment: unconfirmed; do not use or test any credentials.

### 1754. P3_LOW_SIGNAL — ez-xu/agent-memory-graph

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ez-xu/agent-memory-graph/blob/94c6171269e6cfa29d523d77d1209202be165bf3/README.md
- Repository URL: https://github.com/ez-xu/agent-memory-graph
- Assessment: unconfirmed; do not use or test any credentials.

### 1755. P3_LOW_SIGNAL — f-o-a-m/foam.lite

- Path: `PI.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/f-o-a-m/foam.lite/blob/f6b30e2e5a5a0679040eda5f5c552e10c7b41e64/PI.md
- Repository URL: https://github.com/f-o-a-m/foam.lite
- Assessment: unconfirmed; do not use or test any credentials.

### 1756. P3_LOW_SIGNAL — f00-sh/clun

- Path: `PLAN.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/f00-sh/clun/blob/ccdbe50b66e2b7ee253c8f9df73450372252a89c/PLAN.md
- Repository URL: https://github.com/f00-sh/clun
- Assessment: unconfirmed; do not use or test any credentials.

### 1757. P3_LOW_SIGNAL — fabianbrash/Recipes

- Path: `TAP.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/fabianbrash/Recipes/blob/eab923cff292ee7466afd0b554b3ed522520fd0e/TAP.md
- Repository URL: https://github.com/fabianbrash/Recipes
- Assessment: unconfirmed; do not use or test any credentials.

### 1758. P3_LOW_SIGNAL — fabriziosalmi/synapseed

- Path: `docs/security/dlp.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/fabriziosalmi/synapseed/blob/c2ae0922599a768004b29d62fc665251e9549c28/docs/security/dlp.md
- Repository URL: https://github.com/fabriziosalmi/synapseed
- Assessment: unconfirmed; do not use or test any credentials.

### 1759. P3_LOW_SIGNAL — fantasiiio/AIDocStringGenerator

- Path: `CI.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/fantasiiio/AIDocStringGenerator/blob/21e2dc2d591941b8759a8047fa9f9bdf4277dbba/CI.md
- Repository URL: https://github.com/fantasiiio/AIDocStringGenerator
- Assessment: unconfirmed; do not use or test any credentials.

### 1760. P3_LOW_SIGNAL — favstats/vacccprogress

- Path: `t.Rmd`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/favstats/vacccprogress/blob/3b136ac4e5a163a23ae8914c56f144ba10532b40/t.Rmd
- Repository URL: https://github.com/favstats/vacccprogress
- Assessment: unconfirmed; do not use or test any credentials.

### 1761. P3_LOW_SIGNAL — fdciabdul/Google-Trends-Keywords-Scraper

- Path: `id.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/fdciabdul/Google-Trends-Keywords-Scraper/blob/e7556dd8de4a8315a8a3befcd27b818c0882d4dc/id.txt
- Repository URL: https://github.com/fdciabdul/Google-Trends-Keywords-Scraper
- Assessment: unconfirmed; do not use or test any credentials.

### 1762. P3_LOW_SIGNAL — fdhhhdjd/Class_NodeJs_Systems

- Path: `SQL.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/fdhhhdjd/Class_NodeJs_Systems/blob/53c59392d58e2301a70d51893ed778595eada111/SQL.md
- Repository URL: https://github.com/fdhhhdjd/Class_NodeJs_Systems
- Assessment: unconfirmed; do not use or test any credentials.

### 1763. P3_LOW_SIGNAL — feederbox826/notes

- Path: `vpn.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/feederbox826/notes/blob/560f643a0cc50ee302e3f99d4c0561a17459fcfb/vpn.md
- Repository URL: https://github.com/feederbox826/notes
- Assessment: unconfirmed; do not use or test any credentials.

### 1764. P3_LOW_SIGNAL — feenkcom/feenk-download-auth-client

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/feenkcom/feenk-download-auth-client/blob/393186ca88c0e9d3a828eb703e1f950f9b0c765c/README.md
- Repository URL: https://github.com/feenkcom/feenk-download-auth-client
- Assessment: unconfirmed; do not use or test any credentials.

### 1765. P3_LOW_SIGNAL — felipemeriga/socket-flow

- Path: `TLS.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/felipemeriga/socket-flow/blob/6290b3ce2eb46c080c5b3ccf1c13b2d791bc1578/TLS.md
- Repository URL: https://github.com/felipemeriga/socket-flow
- Assessment: unconfirmed; do not use or test any credentials.

### 1766. P3_LOW_SIGNAL — felixrieseberg/electron-forge-maker-nsis

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/felixrieseberg/electron-forge-maker-nsis/blob/d9e9213a1bb36281fbf6bb6a9aead8c097b6713f/README.md
- Repository URL: https://github.com/felixrieseberg/electron-forge-maker-nsis
- Assessment: unconfirmed; do not use or test any credentials.

### 1767. P3_LOW_SIGNAL — fenrus75/turbostar2

- Path: `docs/copilot.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/fenrus75/turbostar2/blob/a14b1ea2a4492df0a286591f23e94ec5fdb3b56a/docs/copilot.md
- Repository URL: https://github.com/fenrus75/turbostar2
- Assessment: unconfirmed; do not use or test any credentials.

### 1768. P3_LOW_SIGNAL — fernandes/caco

- Path: `LLM.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/fernandes/caco/blob/9bf70c0dcfb19f9055983f40669b7db75dfaf23b/LLM.md
- Repository URL: https://github.com/fernandes/caco
- Assessment: unconfirmed; do not use or test any credentials.

### 1769. P3_LOW_SIGNAL — fimilfaneea/terminal-workspace

- Path: `plan.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/fimilfaneea/terminal-workspace/blob/8a4b08f34bf2dccc56d49f61ba4c9006f5534c56/plan.md
- Repository URL: https://github.com/fimilfaneea/terminal-workspace
- Assessment: unconfirmed; do not use or test any credentials.

### 1770. P3_LOW_SIGNAL — flamehaven01/copilot-guardian

- Path: `SECURITY.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/flamehaven01/copilot-guardian/blob/2e50e4335c4aa28dfe4c3cff08424736795a6f79/SECURITY.md
- Repository URL: https://github.com/flamehaven01/copilot-guardian
- Assessment: unconfirmed; do not use or test any credentials.

### 1771. P3_LOW_SIGNAL — flancian/garden

- Path: `yarn.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/flancian/garden/blob/ddac525147d0ef964ebcd8fb01a3546861a16d3f/yarn.md
- Repository URL: https://github.com/flancian/garden
- Assessment: unconfirmed; do not use or test any credentials.

### 1772. P3_LOW_SIGNAL — flycoder-io/custie

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/flycoder-io/custie/blob/ac22b85732305bb0624aaf8b0e6bd1ea629eeacb/README.md
- Repository URL: https://github.com/flycoder-io/custie
- Assessment: unconfirmed; do not use or test any credentials.

### 1773. P3_LOW_SIGNAL — flywithbug-vue-admin/vue-eladmin

- Path: `Tree.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/flywithbug-vue-admin/vue-eladmin/blob/a2c54df3e8469c0602e90dd2ee9b435725bb0c5b/Tree.md
- Repository URL: https://github.com/flywithbug-vue-admin/vue-eladmin
- Assessment: unconfirmed; do not use or test any credentials.

### 1774. P3_LOW_SIGNAL — fmolinadev/PI-Pokemon

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/fmolinadev/PI-Pokemon/blob/8b50403f98f85266c37318be4e63984bc2e19866/README.md
- Repository URL: https://github.com/fmolinadev/PI-Pokemon
- Assessment: unconfirmed; do not use or test any credentials.

### 1775. P3_LOW_SIGNAL — forj-oss/forjj

- Path: `POC.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/forj-oss/forjj/blob/e867e266c37a712aea1c4b369438327fd30e3e6c/POC.md
- Repository URL: https://github.com/forj-oss/forjj
- Assessment: unconfirmed; do not use or test any credentials.

### 1776. P3_LOW_SIGNAL — fpereiro/ustack

- Path: `llms.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/fpereiro/ustack/blob/552959420d45b9a5ad01d4232fdd94cda6bbccff/llms.md
- Repository URL: https://github.com/fpereiro/ustack
- Assessment: unconfirmed; do not use or test any credentials.

### 1777. P3_LOW_SIGNAL — fproulx-boostsecurity/ghappjwt

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/fproulx-boostsecurity/ghappjwt/blob/81ad348b9590efefb5860aababfbe102b6df0364/README.md
- Repository URL: https://github.com/fproulx-boostsecurity/ghappjwt
- Assessment: unconfirmed; do not use or test any credentials.

### 1778. P3_LOW_SIGNAL — fr0tt/benotes

- Path: `api.md`
- Indicator: `access_token_label;bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/fr0tt/benotes/blob/cb803b32340eb7720131a9d0b93261d01800c896/api.md
- Repository URL: https://github.com/fr0tt/benotes
- Assessment: unconfirmed; do not use or test any credentials.

### 1779. P3_LOW_SIGNAL — freshwaterbruce2/Vibe-Tutor

- Path: `AI.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/freshwaterbruce2/Vibe-Tutor/blob/a9fb2ce6e7bfc05e5d65e10e5bb0e6c1b14146ce/AI.md
- Repository URL: https://github.com/freshwaterbruce2/Vibe-Tutor
- Assessment: unconfirmed; do not use or test any credentials.

### 1780. P3_LOW_SIGNAL — friday-platform/friday-studio

- Path: `CHANGELOG.md`
- Indicator: `github_oauth_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/friday-platform/friday-studio/blob/fb3069a951f23fbde243cd1d25d0980fe550be28/CHANGELOG.md
- Repository URL: https://github.com/friday-platform/friday-studio
- Assessment: unconfirmed; do not use or test any credentials.

### 1781. P3_LOW_SIGNAL — fslongjin/fastcommit

- Path: `docs/sanitizer.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/fslongjin/fastcommit/blob/14f5e9a9f8d584a5c73e08e60a460ad1558c4bc9/docs/sanitizer.md
- Repository URL: https://github.com/fslongjin/fastcommit
- Assessment: unconfirmed; do not use or test any credentials.

### 1782. P3_LOW_SIGNAL — fullof-work/ansible-role-npc_setup

- Path: `V2.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/fullof-work/ansible-role-npc_setup/blob/e6be53a312361efdb61eeb162200c456e127461e/V2.md
- Repository URL: https://github.com/fullof-work/ansible-role-npc_setup
- Assessment: unconfirmed; do not use or test any credentials.

### 1783. P3_LOW_SIGNAL — funinkina/dotfiles

- Path: `snapshot.sh`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/funinkina/dotfiles/blob/618d3c5355c7f75d3e2a6c91e42df6490472be07/snapshot.sh
- Repository URL: https://github.com/funinkina/dotfiles
- Assessment: unconfirmed; do not use or test any credentials.

### 1784. P3_LOW_SIGNAL — gabe0000/uv5rmini-live

- Path: `SECURITY.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/gabe0000/uv5rmini-live/blob/0ba766dd0d5fc17423de6ed177cd2882f75f0857/SECURITY.md
- Repository URL: https://github.com/gabe0000/uv5rmini-live
- Assessment: unconfirmed; do not use or test any credentials.

### 1785. P3_LOW_SIGNAL — gabrieltetz/JSOwned

- Path: `key.txt`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/gabrieltetz/JSOwned/blob/5c5438163afb27080710ed310a4418a4d6e06335/key.txt
- Repository URL: https://github.com/gabrieltetz/JSOwned
- Assessment: unconfirmed; do not use or test any credentials.

### 1786. P3_LOW_SIGNAL — gabriersdev/issues-em-lote

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/gabriersdev/issues-em-lote/blob/8b417f0798e5e54b19d5904df6807b6c3b1175ec/README.md
- Repository URL: https://github.com/gabriersdev/issues-em-lote
- Assessment: unconfirmed; do not use or test any credentials.

### 1787. P3_LOW_SIGNAL — gacerioni/rediscloud-terraform-labs

- Path: `.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/gacerioni/rediscloud-terraform-labs/blob/5cdad33591b48a33c8db97822b9ee31f17d141aa/.terraform.tfstate.lock.info
- Repository URL: https://github.com/gacerioni/rediscloud-terraform-labs
- Assessment: unconfirmed; do not use or test any credentials.

### 1788. P3_LOW_SIGNAL — gammons/ai-session

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/gammons/ai-session/blob/36f5fcbfa18f8b3fefbb67dd9cbf5b38c48ccc10/README.md
- Repository URL: https://github.com/gammons/ai-session
- Assessment: unconfirmed; do not use or test any credentials.

### 1789. P3_LOW_SIGNAL — gannonh/kata-symphony

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/gannonh/kata-symphony/blob/e7c160f5e4d485fdfb6d79296f56d36c8872b2a9/README.md
- Repository URL: https://github.com/gannonh/kata-symphony
- Assessment: unconfirmed; do not use or test any credentials.

### 1790. P3_LOW_SIGNAL — gathering/loggy

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/gathering/loggy/blob/ea6217ced204379ad2c34c11c8da81de4f743656/README.md
- Repository URL: https://github.com/gathering/loggy
- Assessment: unconfirmed; do not use or test any credentials.

### 1791. P3_LOW_SIGNAL — gatovillano/KognitoAI

- Path: `TODO.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/gatovillano/KognitoAI/blob/9e04aca34f045821393ba52b561f24eb190233fa/TODO.md
- Repository URL: https://github.com/gatovillano/KognitoAI
- Assessment: unconfirmed; do not use or test any credentials.

### 1792. P3_LOW_SIGNAL — gaurav337/TechSpar

- Path: `n.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/gaurav337/TechSpar/blob/415e0cb07b849d24922e7eda65f486aea810431e/n.md
- Repository URL: https://github.com/gaurav337/TechSpar
- Assessment: unconfirmed; do not use or test any credentials.

### 1793. P3_LOW_SIGNAL — gaureshpai/docmetry

- Path: `RUN.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/gaureshpai/docmetry/blob/71ff02abff73235d300f535eb5b27c9b186a3ace/RUN.md
- Repository URL: https://github.com/gaureshpai/docmetry
- Assessment: unconfirmed; do not use or test any credentials.

### 1794. P3_LOW_SIGNAL — gauri17-pro/ec2-using-terraform

- Path: `.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/gauri17-pro/ec2-using-terraform/blob/429757e8d3da8be0063d0d7ccf055e3f1b5e3910/.terraform.tfstate.lock.info
- Repository URL: https://github.com/gauri17-pro/ec2-using-terraform
- Assessment: unconfirmed; do not use or test any credentials.

### 1795. P3_LOW_SIGNAL — gazerlabs/datachat

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/gazerlabs/datachat/blob/bc550393d3350e55626b38c25b6a20866a4eb941/README.md
- Repository URL: https://github.com/gazerlabs/datachat
- Assessment: unconfirmed; do not use or test any credentials.

### 1796. P3_LOW_SIGNAL — gbrembati/cloudguard-cnapp-azure-org-onboarding

- Path: `README.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/gbrembati/cloudguard-cnapp-azure-org-onboarding/blob/f1b24305f92ccd568bae0860cb68f5ee7d917fb5/README.md
- Repository URL: https://github.com/gbrembati/cloudguard-cnapp-azure-org-onboarding
- Assessment: unconfirmed; do not use or test any credentials.

### 1797. P3_LOW_SIGNAL — geantrevisan/gcp-gke

- Path: `terraform/terraform.tfstate-2`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/geantrevisan/gcp-gke/blob/08309f4e34d4a5b770b5515bb7931bb8344e8cef/terraform/terraform.tfstate-2
- Repository URL: https://github.com/geantrevisan/gcp-gke
- Assessment: unconfirmed; do not use or test any credentials.

### 1798. P3_LOW_SIGNAL — george-hawkins/material-wifi-setup

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/george-hawkins/material-wifi-setup/blob/82210ea36edd783decb6fdf5ca41241c66008e56/README.md
- Repository URL: https://github.com/george-hawkins/material-wifi-setup
- Assessment: unconfirmed; do not use or test any credentials.

### 1799. P3_LOW_SIGNAL — georgeacquahjunior/Wifi_Capping_NCUK

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/georgeacquahjunior/Wifi_Capping_NCUK/blob/60e6e928d0d73b9a034b9e4aafdca9794224ed96/API.md
- Repository URL: https://github.com/georgeacquahjunior/Wifi_Capping_NCUK
- Assessment: unconfirmed; do not use or test any credentials.

### 1800. P3_LOW_SIGNAL — georgekobaidze/noterunway

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/georgekobaidze/noterunway/blob/6f048764ae10e8cfe683ba048f0a61bb091408a1/README.md
- Repository URL: https://github.com/georgekobaidze/noterunway
- Assessment: unconfirmed; do not use or test any credentials.

### 1801. P3_LOW_SIGNAL — get-engram/engram

- Path: `PLAN.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/get-engram/engram/blob/26b84946e5c8e82d2a151164caaeb264e0721150/PLAN.md
- Repository URL: https://github.com/get-engram/engram
- Assessment: unconfirmed; do not use or test any credentials.

### 1802. P3_LOW_SIGNAL — getaero-io/deepline-gtm-agent

- Path: `SETUP.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/getaero-io/deepline-gtm-agent/blob/665635d5a9912c1e9a58d5bbb669ba8118923e89/SETUP.md
- Repository URL: https://github.com/getaero-io/deepline-gtm-agent
- Assessment: unconfirmed; do not use or test any credentials.

### 1803. P3_LOW_SIGNAL — getzoop/zoop-package-public

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/getzoop/zoop-package-public/blob/dd5f8fa94a34874cde82574eb51da070ea212baf/README.md
- Repository URL: https://github.com/getzoop/zoop-package-public
- Assessment: unconfirmed; do not use or test any credentials.

### 1804. P3_LOW_SIGNAL — gg582/fly.board

- Path: `S3.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/gg582/fly.board/blob/2fbc6945a121dc4eb9e4f5e4e8c8fbe74331a8d6/S3.md
- Repository URL: https://github.com/gg582/fly.board
- Assessment: unconfirmed; do not use or test any credentials.

### 1805. P3_LOW_SIGNAL — ggg4566/Havoc_windows

- Path: `WIKI.MD`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ggg4566/Havoc_windows/blob/92a6f2b23415f833c8e1773d83567cdb61f4b788/WIKI.MD
- Repository URL: https://github.com/ggg4566/Havoc_windows
- Assessment: unconfirmed; do not use or test any credentials.

### 1806. P3_LOW_SIGNAL — ghostwright/specter

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ghostwright/specter/blob/7c8dd1ffd5d1d40080bc78c4b97be5ab9bb12854/README.md
- Repository URL: https://github.com/ghostwright/specter
- Assessment: unconfirmed; do not use or test any credentials.

### 1807. P3_LOW_SIGNAL — ghostwriter/redaction

- Path: `README.md`
- Indicator: `github_oauth_prefix;github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ghostwriter/redaction/blob/f877c2b54f111b168623017ee5b0d49b8443794e/README.md
- Repository URL: https://github.com/ghostwriter/redaction
- Assessment: unconfirmed; do not use or test any credentials.

### 1808. P3_LOW_SIGNAL — ghsec/webHunt

- Path: `AWS.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ghsec/webHunt/blob/5906edafccf0bad7c2535202125382484982a9e6/AWS.md
- Repository URL: https://github.com/ghsec/webHunt
- Assessment: unconfirmed; do not use or test any credentials.

### 1809. P3_LOW_SIGNAL — ghsjulian/acode-terminal

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ghsjulian/acode-terminal/blob/75e8dac24980bc9227f1f4de288215653e99d49d/README.md
- Repository URL: https://github.com/ghsjulian/acode-terminal
- Assessment: unconfirmed; do not use or test any credentials.

### 1810. P3_LOW_SIGNAL — gimmie/quickstart

- Path: `ruby.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/gimmie/quickstart/blob/327d8c3d4b2460d94648dd61db660550c5a18c74/ruby.md
- Repository URL: https://github.com/gimmie/quickstart
- Assessment: unconfirmed; do not use or test any credentials.

### 1811. P3_LOW_SIGNAL — girliemac/slack-httpstatuscats

- Path: `diff.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/girliemac/slack-httpstatuscats/blob/142f75d2c7744491c4aa2a79e722dc977668462a/diff.md
- Repository URL: https://github.com/girliemac/slack-httpstatuscats
- Assessment: unconfirmed; do not use or test any credentials.

### 1812. P3_LOW_SIGNAL — githubbuch/githubbuch.github.io

- Path: `CH09.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/githubbuch/githubbuch.github.io/blob/fe96aa5740b163005b284665ce08f9d35aa73b65/CH09.md
- Repository URL: https://github.com/githubbuch/githubbuch.github.io
- Assessment: unconfirmed; do not use or test any credentials.

### 1813. P3_LOW_SIGNAL — glaszig/drone-capistrano

- Path: `DOCS.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/glaszig/drone-capistrano/blob/c7a4b8703d9bed58877abdfef58ab2e67902d592/DOCS.md
- Repository URL: https://github.com/glaszig/drone-capistrano
- Assessment: unconfirmed; do not use or test any credentials.

### 1814. P3_LOW_SIGNAL — glimmercharger/Slack-Channel-Details

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/glimmercharger/Slack-Channel-Details/blob/c856eb1a2577c1a0103a2511d34c3b35f81ef338/README.md
- Repository URL: https://github.com/glimmercharger/Slack-Channel-Details
- Assessment: unconfirmed; do not use or test any credentials.

### 1815. P3_LOW_SIGNAL — globelabs/api

- Path: `Sms.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/globelabs/api/blob/0ea008e3fdb7361c1afafb83f3fb854d13756071/Sms.md
- Repository URL: https://github.com/globelabs/api
- Assessment: unconfirmed; do not use or test any credentials.

### 1816. P3_LOW_SIGNAL — gm3dmo/the-power

- Path: `setup.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/gm3dmo/the-power/blob/f0a7b8e9f1528b4ec69c330379f11e724454d7da/setup.md
- Repository URL: https://github.com/gm3dmo/the-power
- Assessment: unconfirmed; do not use or test any credentials.

### 1817. P3_LOW_SIGNAL — gnutls/nettle

- Path: `NEWS`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/gnutls/nettle/blob/236fbdb554353e16e1e3b051c95f73d46d51cc05/NEWS
- Repository URL: https://github.com/gnutls/nettle
- Assessment: unconfirmed; do not use or test any credentials.

### 1818. P3_LOW_SIGNAL — gobridge/gopherbot

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/gobridge/gopherbot/blob/5fb48e90bf53cb2b0b4f0388ce9920cedf4c661d/README.md
- Repository URL: https://github.com/gobridge/gopherbot
- Assessment: unconfirmed; do not use or test any credentials.

### 1819. P3_LOW_SIGNAL — gokdt/quadlayer

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/gokdt/quadlayer/blob/6c5b48a79f3107a1eaf7db202ed39e9a5b1f781d/README.md
- Repository URL: https://github.com/gokdt/quadlayer
- Assessment: unconfirmed; do not use or test any credentials.

### 1820. P3_LOW_SIGNAL — gonchigars/AWS_Class

- Path: `AI.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/gonchigars/AWS_Class/blob/70e2ea76cb9c7fe2a2c6265c020d74026f676404/AI.md
- Repository URL: https://github.com/gonchigars/AWS_Class
- Assessment: unconfirmed; do not use or test any credentials.

### 1821. P3_LOW_SIGNAL — gouzil/autoTable

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/gouzil/autoTable/blob/2a000e15c7e900ba0adeab4d5a58ccd4aa14d0ad/README.md
- Repository URL: https://github.com/gouzil/autoTable
- Assessment: unconfirmed; do not use or test any credentials.

### 1822. P3_LOW_SIGNAL — govuk-one-login/di-lead-observable-notebook

- Path: `env.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/govuk-one-login/di-lead-observable-notebook/blob/0e1246d98ae1ae91810ad45e5f956e8265568ba8/env.md
- Repository URL: https://github.com/govuk-one-login/di-lead-observable-notebook
- Assessment: unconfirmed; do not use or test any credentials.

### 1823. P3_LOW_SIGNAL — graphpilot-oss/graphpilot

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/graphpilot-oss/graphpilot/blob/ebd80de8eb7c9abec6647e4cb8567eb12aa1e8f2/README.md
- Repository URL: https://github.com/graphpilot-oss/graphpilot
- Assessment: unconfirmed; do not use or test any credentials.

### 1824. P3_LOW_SIGNAL — grzlz/negocia-cdmx

- Path: `SETUP.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/grzlz/negocia-cdmx/blob/e27b675e9ed3ef8b1e93241ea7306c6983b0b1e9/SETUP.md
- Repository URL: https://github.com/grzlz/negocia-cdmx
- Assessment: unconfirmed; do not use or test any credentials.

### 1825. P3_LOW_SIGNAL — gtri/lowendinsight

- Path: `gha.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/gtri/lowendinsight/blob/1e3fccf92d4c806f5157480af297b02e3d31425d/gha.md
- Repository URL: https://github.com/gtri/lowendinsight
- Assessment: unconfirmed; do not use or test any credentials.

### 1826. P3_LOW_SIGNAL — gupsho/redactly

- Path: `CHANGELOG.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/gupsho/redactly/blob/d0b9556433c17f8c13dd1084e12ac8c1acc970cb/CHANGELOG.md
- Repository URL: https://github.com/gupsho/redactly
- Assessment: unconfirmed; do not use or test any credentials.

### 1827. P3_LOW_SIGNAL — guytheguytheguy/envshield

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/guytheguytheguy/envshield/blob/30106ea1efc04a4b36fc70c068a33d29211cfd5f/README.md
- Repository URL: https://github.com/guytheguytheguy/envshield
- Assessment: unconfirmed; do not use or test any credentials.

### 1828. P3_LOW_SIGNAL — h4ckologic/bughunter-ai

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/h4ckologic/bughunter-ai/blob/22693cc1cde0c9432339a5c2704cd7c5727f3abe/SETUP.md
- Repository URL: https://github.com/h4ckologic/bughunter-ai
- Assessment: unconfirmed; do not use or test any credentials.

### 1829. P3_LOW_SIGNAL — hac/kerhouse

- Path: `README.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hac/kerhouse/blob/30be43f1243ce0aef793c88c4baad0c427bab1c4/README.md
- Repository URL: https://github.com/hac/kerhouse
- Assessment: unconfirmed; do not use or test any credentials.

### 1830. P3_LOW_SIGNAL — hackforla/knowledgebase

- Path: `x2.txt`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hackforla/knowledgebase/blob/03234c463e3e4213d613922b5b1cea1e179511d1/x2.txt
- Repository URL: https://github.com/hackforla/knowledgebase
- Assessment: unconfirmed; do not use or test any credentials.

### 1831. P3_LOW_SIGNAL — hackhub-education/web-tweet-express

- Path: `api.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hackhub-education/web-tweet-express/blob/8f8b19267aae8ed7d346cdeb304e4a9863f23f9e/api.md
- Repository URL: https://github.com/hackhub-education/web-tweet-express
- Assessment: unconfirmed; do not use or test any credentials.

### 1832. P3_LOW_SIGNAL — hahah0ho/swarm_framework

- Path: `1.txt`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hahah0ho/swarm_framework/blob/2d71d3de01df73c4c6816fdcd0f85a08d1cbbe94/1.txt
- Repository URL: https://github.com/hahah0ho/swarm_framework
- Assessment: unconfirmed; do not use or test any credentials.

### 1833. P3_LOW_SIGNAL — hamdisoudani/nous-pool

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hamdisoudani/nous-pool/blob/a0ae47c7a4c76cf8e45dc24038907f5893044cd2/README.md
- Repository URL: https://github.com/hamdisoudani/nous-pool
- Assessment: unconfirmed; do not use or test any credentials.

### 1834. P3_LOW_SIGNAL — hammadxcm/hammadxcm

- Path: `CICD.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hammadxcm/hammadxcm/blob/f688b99f6494ec32753445a0937b9789f628f9eb/CICD.md
- Repository URL: https://github.com/hammadxcm/hammadxcm
- Assessment: unconfirmed; do not use or test any credentials.

### 1835. P3_LOW_SIGNAL — hapijs/cookie

- Path: `API.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hapijs/cookie/blob/953af48de1bcde93807c012fdc89bfba43974340/API.md
- Repository URL: https://github.com/hapijs/cookie
- Assessment: unconfirmed; do not use or test any credentials.

### 1836. P3_LOW_SIGNAL — happypeter/haoduoshipin

- Path: `264.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/happypeter/haoduoshipin/blob/3d9155a7c6c082e29c50b11bf15c148e68276fcf/264.md
- Repository URL: https://github.com/happypeter/haoduoshipin
- Assessment: unconfirmed; do not use or test any credentials.

### 1837. P3_LOW_SIGNAL — harekrishnarai/flowlyt

- Path: `CHANGELOG.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/harekrishnarai/flowlyt/blob/47671ea6214dcd6cc8697ca1487c03e5978da8b4/CHANGELOG.md
- Repository URL: https://github.com/harekrishnarai/flowlyt
- Assessment: unconfirmed; do not use or test any credentials.

### 1838. P3_LOW_SIGNAL — harishmsgit/E-CommerceStore

- Path: `terraform/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/harishmsgit/E-CommerceStore/blob/67da498ab25b2bdfc9832413aa84cb6da38a2631/terraform/.terraform.tfstate.lock.info
- Repository URL: https://github.com/harishmsgit/E-CommerceStore
- Assessment: unconfirmed; do not use or test any credentials.

### 1839. P3_LOW_SIGNAL — harnexa/nexa-gauge

- Path: `PR.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/harnexa/nexa-gauge/blob/d79f901d2de2a8cd7fc75b424701f66c3c769be4/PR.md
- Repository URL: https://github.com/harnexa/nexa-gauge
- Assessment: unconfirmed; do not use or test any credentials.

### 1840. P3_LOW_SIGNAL — harrysun-code/create-your-own-php-framework

- Path: `05.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/harrysun-code/create-your-own-php-framework/blob/2487b1ac89417cd918cd80418e07d94c3bce221d/05.md
- Repository URL: https://github.com/harrysun-code/create-your-own-php-framework
- Assessment: unconfirmed; do not use or test any credentials.

### 1841. P3_LOW_SIGNAL — harrysun-code/create-your-own-php-framework

- Path: `06.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/harrysun-code/create-your-own-php-framework/blob/2487b1ac89417cd918cd80418e07d94c3bce221d/06.md
- Repository URL: https://github.com/harrysun-code/create-your-own-php-framework
- Assessment: unconfirmed; do not use or test any credentials.

### 1842. P3_LOW_SIGNAL — harrysun-code/create-your-own-php-framework

- Path: `08.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/harrysun-code/create-your-own-php-framework/blob/2487b1ac89417cd918cd80418e07d94c3bce221d/08.md
- Repository URL: https://github.com/harrysun-code/create-your-own-php-framework
- Assessment: unconfirmed; do not use or test any credentials.

### 1843. P3_LOW_SIGNAL — hasit/gitsignal

- Path: `README.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hasit/gitsignal/blob/caa871f6c8d229582d980b2ebef4e8c6c929cadb/README.md
- Repository URL: https://github.com/hasit/gitsignal
- Assessment: unconfirmed; do not use or test any credentials.

### 1844. P3_LOW_SIGNAL — hasura/hasura-ecommerce

- Path: `Setup.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hasura/hasura-ecommerce/blob/1090f8a9f2b16729516c86861a5647352b2f6314/Setup.md
- Repository URL: https://github.com/hasura/hasura-ecommerce
- Assessment: unconfirmed; do not use or test any credentials.

### 1845. P3_LOW_SIGNAL — hdahme/clawdbot-output-sentinel

- Path: `README.md`
- Indicator: `github_token_prefix;github_oauth_prefix;stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hdahme/clawdbot-output-sentinel/blob/956ef471a649adde4378b49c1e60990a209c0b41/README.md
- Repository URL: https://github.com/hdahme/clawdbot-output-sentinel
- Assessment: unconfirmed; do not use or test any credentials.

### 1846. P3_LOW_SIGNAL — he9lin/pyramid-client

- Path: `README.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/he9lin/pyramid-client/blob/61ec4820b56d55407119033fe590c475b6700c05/README.md
- Repository URL: https://github.com/he9lin/pyramid-client
- Assessment: unconfirmed; do not use or test any credentials.

### 1847. P3_LOW_SIGNAL — hefgi/bocal

- Path: `PRD.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hefgi/bocal/blob/fa181d05041b284604eebc207f38ba1801c2086a/PRD.md
- Repository URL: https://github.com/hefgi/bocal
- Assessment: unconfirmed; do not use or test any credentials.

### 1848. P3_LOW_SIGNAL — helmcode/bender

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/helmcode/bender/blob/677124efc6a0d811b8ea3be2a68dbb3042e594b2/README.md
- Repository URL: https://github.com/helmcode/bender
- Assessment: unconfirmed; do not use or test any credentials.

### 1849. P3_LOW_SIGNAL — henriquelaia/KeyZero

- Path: `DOCS.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/henriquelaia/KeyZero/blob/325275fa1bf61177718cac8a1b1fd04eed3dc965/DOCS.md
- Repository URL: https://github.com/henriquelaia/KeyZero
- Assessment: unconfirmed; do not use or test any credentials.

### 1850. P3_LOW_SIGNAL — hiroppy/orchestrators

- Path: `SETUP.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hiroppy/orchestrators/blob/c9cf00c46a682541c9c6956321720a8615342631/SETUP.md
- Repository URL: https://github.com/hiroppy/orchestrators
- Assessment: unconfirmed; do not use or test any credentials.

### 1851. P3_LOW_SIGNAL — hjue/JustWriting

- Path: `api.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hjue/JustWriting/blob/49731e03280e0474a1e862b73baabacb4ffccbfa/api.md
- Repository URL: https://github.com/hjue/JustWriting
- Assessment: unconfirmed; do not use or test any credentials.

### 1852. P3_LOW_SIGNAL — hms-dbmi/pic-sure-bdc-infrastructure

- Path: `deployment-s3-bucket/terraform.tfstate_baseline`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hms-dbmi/pic-sure-bdc-infrastructure/blob/2d2b4ff97262d1c18275be4ef6c83a4ab805b4a2/deployment-s3-bucket/terraform.tfstate_baseline
- Repository URL: https://github.com/hms-dbmi/pic-sure-bdc-infrastructure
- Assessment: unconfirmed; do not use or test any credentials.

### 1853. P3_LOW_SIGNAL — hoangsonww/AI-RAG-Assistant-Chatbot

- Path: `RAG.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hoangsonww/AI-RAG-Assistant-Chatbot/blob/e909fa4726bb92f328d3f22a0f189df21bde6521/RAG.md
- Repository URL: https://github.com/hoangsonww/AI-RAG-Assistant-Chatbot
- Assessment: unconfirmed; do not use or test any credentials.

### 1854. P3_LOW_SIGNAL — hoangsonww/ReproVM-Virtual-Machine

- Path: `WIKI.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hoangsonww/ReproVM-Virtual-Machine/blob/eb0631ecb46381dfc0ff46ad7009de75cd00cf07/WIKI.md
- Repository URL: https://github.com/hoangsonww/ReproVM-Virtual-Machine
- Assessment: unconfirmed; do not use or test any credentials.

### 1855. P3_LOW_SIGNAL — hoklims/secure-pdf

- Path: `FAQ.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hoklims/secure-pdf/blob/16ea5464f733b1af3a979879191a82c62906ef47/FAQ.md
- Repository URL: https://github.com/hoklims/secure-pdf
- Assessment: unconfirmed; do not use or test any credentials.

### 1856. P3_LOW_SIGNAL — honeycombio/dynsampler-go

- Path: `Makefile`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/honeycombio/dynsampler-go/blob/1eb29d715df6402bc305ff660b4d188b543e918d/Makefile
- Repository URL: https://github.com/honeycombio/dynsampler-go
- Assessment: unconfirmed; do not use or test any credentials.

### 1857. P3_LOW_SIGNAL — hongruiqi/openstack-on-centos6

- Path: `3.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hongruiqi/openstack-on-centos6/blob/c6393f5c067a628a17226203b006ab4aa2ccbe96/3.md
- Repository URL: https://github.com/hongruiqi/openstack-on-centos6
- Assessment: unconfirmed; do not use or test any credentials.

### 1858. P3_LOW_SIGNAL — hongruiqi/openstack-on-centos6

- Path: `5.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hongruiqi/openstack-on-centos6/blob/c6393f5c067a628a17226203b006ab4aa2ccbe96/5.md
- Repository URL: https://github.com/hongruiqi/openstack-on-centos6
- Assessment: unconfirmed; do not use or test any credentials.

### 1859. P3_LOW_SIGNAL — hongruiqi/openstack-on-centos6

- Path: `6.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hongruiqi/openstack-on-centos6/blob/c6393f5c067a628a17226203b006ab4aa2ccbe96/6.md
- Repository URL: https://github.com/hongruiqi/openstack-on-centos6
- Assessment: unconfirmed; do not use or test any credentials.

### 1860. P3_LOW_SIGNAL — horms/ovs

- Path: `NEWS`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/horms/ovs/blob/4727452c2fa806350c2c74ec5a3c619b765d8ea0/NEWS
- Repository URL: https://github.com/horms/ovs
- Assessment: unconfirmed; do not use or test any credentials.

### 1861. P3_LOW_SIGNAL — howardpen9/hermes-gbrain-bridge

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/howardpen9/hermes-gbrain-bridge/blob/a057b5864b82c40a4575838689e238b86a622833/README.md
- Repository URL: https://github.com/howardpen9/hermes-gbrain-bridge
- Assessment: unconfirmed; do not use or test any credentials.

### 1862. P3_LOW_SIGNAL — hpreston/python_networking

- Path: `lab.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hpreston/python_networking/blob/046b9476f175f160d2a526dabfc419685e876981/lab.md
- Repository URL: https://github.com/hpreston/python_networking
- Assessment: unconfirmed; do not use or test any credentials.

### 1863. P3_LOW_SIGNAL — hsborges-msr/github-proxy-server

- Path: `AGENTS.md`
- Indicator: `github_pat_prefix;github_oauth_prefix;github_app_token_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hsborges-msr/github-proxy-server/blob/4071396bb7c926093ab6725504d3daedaaf2f974/AGENTS.md
- Repository URL: https://github.com/hsborges-msr/github-proxy-server
- Assessment: unconfirmed; do not use or test any credentials.

### 1864. P3_LOW_SIGNAL — hubble-exchange/python-sdk

- Path: `DEV.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hubble-exchange/python-sdk/blob/856ab04a2b5addf8eb6d67e5d3414a976f459a21/DEV.md
- Repository URL: https://github.com/hubble-exchange/python-sdk
- Assessment: unconfirmed; do not use or test any credentials.

### 1865. P3_LOW_SIGNAL — hulisang/vmqfox-backend

- Path: `bt.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hulisang/vmqfox-backend/blob/85dd73e3a665c8b80756d854c0a83b7b39753a69/bt.md
- Repository URL: https://github.com/hulisang/vmqfox-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 1866. P3_LOW_SIGNAL — hyperflow-wms/hyperflow

- Path: `SPEC.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hyperflow-wms/hyperflow/blob/53bdb6f75bb14f54908a870162dbf2e740c6d988/SPEC.md
- Repository URL: https://github.com/hyperflow-wms/hyperflow
- Assessment: unconfirmed; do not use or test any credentials.

### 1867. P3_LOW_SIGNAL — hyperi-io/repo-backup

- Path: `AWS.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/hyperi-io/repo-backup/blob/04619c8a890c373447c4a448b89f3a893b4bd4f4/AWS.md
- Repository URL: https://github.com/hyperi-io/repo-backup
- Assessment: unconfirmed; do not use or test any credentials.

### 1868. P3_LOW_SIGNAL — i5nipe/nipejs

- Path: `files/regex.txt`
- Indicator: `github_oauth_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/i5nipe/nipejs/blob/2775f8f2110cf15f1b9d35fc2dc2cebd84cde77c/files/regex.txt
- Repository URL: https://github.com/i5nipe/nipejs
- Assessment: unconfirmed; do not use or test any credentials.

### 1869. P3_LOW_SIGNAL — i5ting/nodejs-fullstack

- Path: `moa.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/i5ting/nodejs-fullstack/blob/68b9a7a03dc19908ea9c5e7e5a0e0b2b39ea97a6/moa.md
- Repository URL: https://github.com/i5ting/nodejs-fullstack
- Assessment: unconfirmed; do not use or test any credentials.

### 1870. P3_LOW_SIGNAL — iAmAjayTeli/interview-autopsy

- Path: `PRD.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/iAmAjayTeli/interview-autopsy/blob/7a7fd0a860f4e88bfc10f87140ed980fbe2a8f46/PRD.md
- Repository URL: https://github.com/iAmAjayTeli/interview-autopsy
- Assessment: unconfirmed; do not use or test any credentials.

### 1871. P3_LOW_SIGNAL — iGLOO-be/amaging-documentation

- Path: `api.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/iGLOO-be/amaging-documentation/blob/3fa405304760c19ddfb9d80355731db8933a3cb2/api.md
- Repository URL: https://github.com/iGLOO-be/amaging-documentation
- Assessment: unconfirmed; do not use or test any credentials.

### 1872. P3_LOW_SIGNAL — iKislay/copium

- Path: `PR.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/iKislay/copium/blob/28759a663bc16299222769ca07d53e46caa48fdb/PR.md
- Repository URL: https://github.com/iKislay/copium
- Assessment: unconfirmed; do not use or test any credentials.

### 1873. P3_LOW_SIGNAL — iTranslateX/odoo-cookbook

- Path: `20.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/iTranslateX/odoo-cookbook/blob/66da4e88051db26d632f21872625e80b83a86db3/20.md
- Repository URL: https://github.com/iTranslateX/odoo-cookbook
- Assessment: unconfirmed; do not use or test any credentials.

### 1874. P3_LOW_SIGNAL — iamneur0/syncio

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/iamneur0/syncio/blob/2a053f9b6cb8b58b1f16d9dbfcf3349fde975b38/API.md
- Repository URL: https://github.com/iamneur0/syncio
- Assessment: unconfirmed; do not use or test any credentials.

### 1875. P3_LOW_SIGNAL — iamshafayat/JSpider

- Path: `script.js`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/iamshafayat/JSpider/blob/0e06aeed0d8fd946f66e4c8edff53985497d65eb/script.js
- Repository URL: https://github.com/iamshafayat/JSpider
- Assessment: unconfirmed; do not use or test any credentials.

### 1876. P3_LOW_SIGNAL — ianscrivener/rpi-rclone-dropbox

- Path: `conf.txt`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ianscrivener/rpi-rclone-dropbox/blob/5337142aea78ac99ed9d2469696bf3fb6e3f3611/conf.txt
- Repository URL: https://github.com/ianscrivener/rpi-rclone-dropbox
- Assessment: unconfirmed; do not use or test any credentials.

### 1877. P3_LOW_SIGNAL — iarna/private-bot

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/iarna/private-bot/blob/c4770765b04ed344a9306c1578c71873ef04dbcf/README.md
- Repository URL: https://github.com/iarna/private-bot
- Assessment: unconfirmed; do not use or test any credentials.

### 1878. P3_LOW_SIGNAL — ibm-cloud-docs/appid

- Path: `spa.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ibm-cloud-docs/appid/blob/0e06aa53e977b2515e59d7f0541b3b302702b53a/spa.md
- Repository URL: https://github.com/ibm-cloud-docs/appid
- Assessment: unconfirmed; do not use or test any credentials.

### 1879. P3_LOW_SIGNAL — ibm-cloud-docs/appid

- Path: `sso.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ibm-cloud-docs/appid/blob/0e06aa53e977b2515e59d7f0541b3b302702b53a/sso.md
- Repository URL: https://github.com/ibm-cloud-docs/appid
- Assessment: unconfirmed; do not use or test any credentials.

### 1880. P3_LOW_SIGNAL — icculus/ghtodo

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/icculus/ghtodo/blob/a8450bf96dc44df394ee961be21994782ce1b715/README.md
- Repository URL: https://github.com/icculus/ghtodo
- Assessment: unconfirmed; do not use or test any credentials.

### 1881. P3_LOW_SIGNAL — igorsatsyuk/jwt-demo

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/igorsatsyuk/jwt-demo/blob/7582654e82cc2373ad643a476c291143c81d0f5a/API.md
- Repository URL: https://github.com/igorsatsyuk/jwt-demo
- Assessment: unconfirmed; do not use or test any credentials.

### 1882. P3_LOW_SIGNAL — iljoong/azure-terraform

- Path: `DOC.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/iljoong/azure-terraform/blob/fb6128cc10ac56b0296f1b2f95b555df94e6c9a2/DOC.md
- Repository URL: https://github.com/iljoong/azure-terraform
- Assessment: unconfirmed; do not use or test any credentials.

### 1883. P3_LOW_SIGNAL — ilude/claude-code-config

- Path: `commands/commit.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ilude/claude-code-config/blob/35874660219dd4f213200064c2c065de4a86bd50/commands/commit.md
- Repository URL: https://github.com/ilude/claude-code-config
- Assessment: unconfirmed; do not use or test any credentials.

### 1884. P3_LOW_SIGNAL — imfromfuture3000-Android/Realdeployergene

- Path: `terraform/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/imfromfuture3000-Android/Realdeployergene/blob/fa24fb00d1b21786b558a71eec444efcec5af5b1/terraform/.terraform.tfstate.lock.info
- Repository URL: https://github.com/imfromfuture3000-Android/Realdeployergene
- Assessment: unconfirmed; do not use or test any credentials.

### 1885. P3_LOW_SIGNAL — imgompanda/drsaju-opensource

- Path: `llm.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/imgompanda/drsaju-opensource/blob/cae2df33e929fa3fd8ec12fc290520cbf4f464da/llm.md
- Repository URL: https://github.com/imgompanda/drsaju-opensource
- Assessment: unconfirmed; do not use or test any credentials.

### 1886. P3_LOW_SIGNAL — inaniwaudon/github-issues-due

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/inaniwaudon/github-issues-due/blob/02812fe7072857dc73695a0c5504fd4cf0e09430/README.md
- Repository URL: https://github.com/inaniwaudon/github-issues-due
- Assessment: unconfirmed; do not use or test any credentials.

### 1887. P3_LOW_SIGNAL — inbo/checklist

- Path: `NEWS.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/inbo/checklist/blob/5e93a3b6ae945aaac666e2a490ff2fd4f94244c7/NEWS.md
- Repository URL: https://github.com/inbo/checklist
- Assessment: unconfirmed; do not use or test any credentials.

### 1888. P3_LOW_SIGNAL — inbrainfun/inbrain

- Path: `TODOS.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/inbrainfun/inbrain/blob/5231990fa7b13ab348cf1e03c84dad16aa5614b1/TODOS.md
- Repository URL: https://github.com/inbrainfun/inbrain
- Assessment: unconfirmed; do not use or test any credentials.

### 1889. P3_LOW_SIGNAL — infinri/A.S.E

- Path: `CHANGELOG.md`
- Indicator: `github_oauth_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/infinri/A.S.E/blob/210efb58d05f1451cbf885b453831ca999ac54b3/CHANGELOG.md
- Repository URL: https://github.com/infinri/A.S.E
- Assessment: unconfirmed; do not use or test any credentials.

### 1890. P3_LOW_SIGNAL — infochimps-labs/ironfan

- Path: `ELB.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/infochimps-labs/ironfan/blob/5a30f94eea9dcc95304d2cd19dff5ef19b5babbe/ELB.md
- Repository URL: https://github.com/infochimps-labs/ironfan
- Assessment: unconfirmed; do not use or test any credentials.

### 1891. P3_LOW_SIGNAL — innovationacademy-kr/24hane-backend

- Path: `guide.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/innovationacademy-kr/24hane-backend/blob/e864c8e2a8e8e19c59fac4f3aab05871e61d0eac/guide.md
- Repository URL: https://github.com/innovationacademy-kr/24hane-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 1892. P3_LOW_SIGNAL — inputmd/input

- Path: `API.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/inputmd/input/blob/b523de0764e0abac65efafde20033100d5577a10/API.md
- Repository URL: https://github.com/inputmd/input
- Assessment: unconfirmed; do not use or test any credentials.

### 1893. P3_LOW_SIGNAL — investo2o/security-configs

- Path: `CLAUDE.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/investo2o/security-configs/blob/2da7c729403a9de5db36e6e311997743e082c08f/CLAUDE.md
- Repository URL: https://github.com/investo2o/security-configs
- Assessment: unconfirmed; do not use or test any credentials.

### 1894. P3_LOW_SIGNAL — irasnyd/freeradius-ldap

- Path: `ldap`
- Indicator: `private_key_label;password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/irasnyd/freeradius-ldap/blob/83c1951b689f401f9aa93e33f1c4a33536170897/ldap
- Repository URL: https://github.com/irasnyd/freeradius-ldap
- Assessment: unconfirmed; do not use or test any credentials.

### 1895. P3_LOW_SIGNAL — isabelsousac/Cycle-Tracker

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/isabelsousac/Cycle-Tracker/blob/14d15bdfea381fa17a5fc93c49d96f8410163b0a/API.md
- Repository URL: https://github.com/isabelsousac/Cycle-Tracker
- Assessment: unconfirmed; do not use or test any credentials.

### 1896. P3_LOW_SIGNAL — isak792/mlops_team_20

- Path: `setup.md`
- Indicator: `secret_access_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/isak792/mlops_team_20/blob/6a864a9a5b50908370b378c5e7ac8d39e5a4b50f/setup.md
- Repository URL: https://github.com/isak792/mlops_team_20
- Assessment: unconfirmed; do not use or test any credentials.

### 1897. P3_LOW_SIGNAL — itcloudy/base-framework-tutorial

- Path: `02.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/itcloudy/base-framework-tutorial/blob/4f36b20735aa803a653b741099a9179c9dbf473c/02.md
- Repository URL: https://github.com/itcloudy/base-framework-tutorial
- Assessment: unconfirmed; do not use or test any credentials.

### 1898. P3_LOW_SIGNAL — itfin-git/Querize

- Path: `TODO.txt`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/itfin-git/Querize/blob/6dd8571cda0a02dffa897b5de385a37a701ba6d9/TODO.txt
- Repository URL: https://github.com/itfin-git/Querize
- Assessment: unconfirmed; do not use or test any credentials.

### 1899. P3_LOW_SIGNAL — its-kundan/hitl1

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/its-kundan/hitl1/blob/33e6d4b2fd45c902760cac17070a21752ccff81d/SETUP.md
- Repository URL: https://github.com/its-kundan/hitl1
- Assessment: unconfirmed; do not use or test any credentials.

### 1900. P3_LOW_SIGNAL — itseasy21/mcp-codebase-index

- Path: `PLAN.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/itseasy21/mcp-codebase-index/blob/8c823cd30dfb0147d3b20468d2369dd4dc8960fe/PLAN.md
- Repository URL: https://github.com/itseasy21/mcp-codebase-index
- Assessment: unconfirmed; do not use or test any credentials.

### 1901. P3_LOW_SIGNAL — ix-infrastructure/ix-claude-plugin

- Path: `TASKS.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ix-infrastructure/ix-claude-plugin/blob/9c0eefa70502c871ef216727f4019302a8168e5c/TASKS.md
- Repository URL: https://github.com/ix-infrastructure/ix-claude-plugin
- Assessment: unconfirmed; do not use or test any credentials.

### 1902. P3_LOW_SIGNAL — jaiswaladi246/Python-4-DevOps

- Path: `Day-8.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jaiswaladi246/Python-4-DevOps/blob/cf33aa7b3c0e543cafa832032ab1933497619527/Day-8.md
- Repository URL: https://github.com/jaiswaladi246/Python-4-DevOps
- Assessment: unconfirmed; do not use or test any credentials.

### 1903. P3_LOW_SIGNAL — jakubbutryn/terraform-openssh-server

- Path: `dev/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jakubbutryn/terraform-openssh-server/blob/4f38c13089c9e9c4b486c454cb5bb9ed528c0790/dev/.terraform.tfstate.lock.info
- Repository URL: https://github.com/jakubbutryn/terraform-openssh-server
- Assessment: unconfirmed; do not use or test any credentials.

### 1904. P3_LOW_SIGNAL — james28909/clipboard-plus-plus

- Path: `SPEC.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/james28909/clipboard-plus-plus/blob/a52f951175dcde91d98a8975722e064cfcac02e5/SPEC.md
- Repository URL: https://github.com/james28909/clipboard-plus-plus
- Assessment: unconfirmed; do not use or test any credentials.

### 1905. P3_LOW_SIGNAL — janbodnar/Python-Datovy-Analytik-Skolenie

- Path: `ai.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/janbodnar/Python-Datovy-Analytik-Skolenie/blob/8ddc3b990e206bc14de6e526cb8b28cf23102376/ai.md
- Repository URL: https://github.com/janbodnar/Python-Datovy-Analytik-Skolenie
- Assessment: unconfirmed; do not use or test any credentials.

### 1906. P3_LOW_SIGNAL — janbodnar/Rust-Examples

- Path: `ai.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/janbodnar/Rust-Examples/blob/a6f32890ee5a5d04de8ecedc6656bb90f120ef0a/ai.md
- Repository URL: https://github.com/janbodnar/Rust-Examples
- Assessment: unconfirmed; do not use or test any credentials.

### 1907. P3_LOW_SIGNAL — janyksteenbeek/uppi

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/janyksteenbeek/uppi/blob/8b2cc00df30d707f903b16d648fa27d43753c9cb/API.md
- Repository URL: https://github.com/janyksteenbeek/uppi
- Assessment: unconfirmed; do not use or test any credentials.

### 1908. P3_LOW_SIGNAL — jasonkneen/dario-code

- Path: `plan.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jasonkneen/dario-code/blob/879be3d8eb5c97b459fa730b869cb9132f23cc06/plan.md
- Repository URL: https://github.com/jasonkneen/dario-code
- Assessment: unconfirmed; do not use or test any credentials.

### 1909. P3_LOW_SIGNAL — javanf/todo-list

- Path: `7.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/javanf/todo-list/blob/5bad2a5b9a174da580bd391198b117f1a8b780c3/7.md
- Repository URL: https://github.com/javanf/todo-list
- Assessment: unconfirmed; do not use or test any credentials.

### 1910. P3_LOW_SIGNAL — jayluxferro/resilient-write

- Path: `docs/POLICY.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jayluxferro/resilient-write/blob/14e9cd80aef2386972ae211dbd364a17241f588a/docs/POLICY.md
- Repository URL: https://github.com/jayluxferro/resilient-write
- Assessment: unconfirmed; do not use or test any credentials.

### 1911. P3_LOW_SIGNAL — jbcodeforce/flink-studies

- Path: `deployment/cc-flink-rbac/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jbcodeforce/flink-studies/blob/e5a80d386ffde47662c6c792f2a78ad4ad8189b4/deployment/cc-flink-rbac/.terraform.tfstate.lock.info
- Repository URL: https://github.com/jbcodeforce/flink-studies
- Assessment: unconfirmed; do not use or test any credentials.

### 1912. P3_LOW_SIGNAL — jbruned/Poll-App

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jbruned/Poll-App/blob/c4fcb43f14e548b527b408f2758fb3cd9d3bcee9/README.md
- Repository URL: https://github.com/jbruned/Poll-App
- Assessment: unconfirmed; do not use or test any credentials.

### 1913. P3_LOW_SIGNAL — jcast90/relay

- Path: `CI.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jcast90/relay/blob/7bd5a2f6a13ce62db53ca3c55f2a7ef89e36e710/CI.md
- Repository URL: https://github.com/jcast90/relay
- Assessment: unconfirmed; do not use or test any credentials.

### 1914. P3_LOW_SIGNAL — jdp1901/Fullmetal-Anatomist

- Path: `spec.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jdp1901/Fullmetal-Anatomist/blob/53f36dd249c0b21fb29bd9b77fef266c433ed164/spec.md
- Repository URL: https://github.com/jdp1901/Fullmetal-Anatomist
- Assessment: unconfirmed; do not use or test any credentials.

### 1915. P3_LOW_SIGNAL — jeeve05/chrisdaly-site

- Path: `SETUP.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jeeve05/chrisdaly-site/blob/ee726e8f5f8e66d57b098a2cec18d79a903598e9/SETUP.md
- Repository URL: https://github.com/jeeve05/chrisdaly-site
- Assessment: unconfirmed; do not use or test any credentials.

### 1916. P3_LOW_SIGNAL — jeffhollan/hosted-copilot-sdk-support-intelligence

- Path: `readme.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jeffhollan/hosted-copilot-sdk-support-intelligence/blob/1a124cfdafe4ded2d34e8d36af80f18b07cb8310/readme.md
- Repository URL: https://github.com/jeffhollan/hosted-copilot-sdk-support-intelligence
- Assessment: unconfirmed; do not use or test any credentials.

### 1917. P3_LOW_SIGNAL — jeffryhawchab/leakgorilla

- Path: `main.py`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jeffryhawchab/leakgorilla/blob/1ad57c62d843b315f23df69c4d287c1c055558a8/main.py
- Repository URL: https://github.com/jeffryhawchab/leakgorilla
- Assessment: unconfirmed; do not use or test any credentials.

### 1918. P3_LOW_SIGNAL — jenkinsci/violation-comments-to-gitlab-plugin

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jenkinsci/violation-comments-to-gitlab-plugin/blob/df78b7bd8fb52e1a7570f6e040c4afc05c480405/README.md
- Repository URL: https://github.com/jenkinsci/violation-comments-to-gitlab-plugin
- Assessment: unconfirmed; do not use or test any credentials.

### 1919. P3_LOW_SIGNAL — jenkinsci/violation-comments-to-stash-plugin

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jenkinsci/violation-comments-to-stash-plugin/blob/2a2e3594050af6e9504d49501a3c65542833ecd7/README.md
- Repository URL: https://github.com/jenkinsci/violation-comments-to-stash-plugin
- Assessment: unconfirmed; do not use or test any credentials.

### 1920. P3_LOW_SIGNAL — jenniferumoke/BrilliantCode

- Path: `DOCS.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jenniferumoke/BrilliantCode/blob/17b77cb7ac542b63fee346e694181e527247584f/DOCS.md
- Repository URL: https://github.com/jenniferumoke/BrilliantCode
- Assessment: unconfirmed; do not use or test any credentials.

### 1921. P3_LOW_SIGNAL — jeremymcs/patchdeck

- Path: `AGENTS.md`
- Indicator: `github_oauth_prefix;github_app_token_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jeremymcs/patchdeck/blob/165f82c86d562f6fa037c178d061c6dcc786c1c6/AGENTS.md
- Repository URL: https://github.com/jeremymcs/patchdeck
- Assessment: unconfirmed; do not use or test any credentials.

### 1922. P3_LOW_SIGNAL — jezweb/twenty-mcp

- Path: `OAUTH.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jezweb/twenty-mcp/blob/741118a157e50da971c02da83ddc4f248b12794f/OAUTH.md
- Repository URL: https://github.com/jezweb/twenty-mcp
- Assessment: unconfirmed; do not use or test any credentials.

### 1923. P3_LOW_SIGNAL — jfloff/mac-developer-setup

- Path: `git.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jfloff/mac-developer-setup/blob/677b51ee7ea4eee6313f1f89c170200dad8140e9/git.md
- Repository URL: https://github.com/jfloff/mac-developer-setup
- Assessment: unconfirmed; do not use or test any credentials.

### 1924. P3_LOW_SIGNAL — jgnagy/waylon-slack

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jgnagy/waylon-slack/blob/392d348b0c1bc019b6a767fa72965fab67dd4ccc/README.md
- Repository URL: https://github.com/jgnagy/waylon-slack
- Assessment: unconfirmed; do not use or test any credentials.

### 1925. P3_LOW_SIGNAL — jhooper94/ucrm-freeradius-auth

- Path: `sql`
- Indicator: `private_key_label;password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jhooper94/ucrm-freeradius-auth/blob/9b04ed53ea9fc2a431c729d6cd1efb32ff07db71/sql
- Repository URL: https://github.com/jhooper94/ucrm-freeradius-auth
- Assessment: unconfirmed; do not use or test any credentials.

### 1926. P3_LOW_SIGNAL — jina-ai/meta-prompt

- Path: `v0.txt`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jina-ai/meta-prompt/blob/b5f3f7be8ee6648afcca6b98d8054ef47342a46a/v0.txt
- Repository URL: https://github.com/jina-ai/meta-prompt
- Assessment: unconfirmed; do not use or test any credentials.

### 1927. P3_LOW_SIGNAL — jina-ai/meta-prompt

- Path: `v1.txt`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jina-ai/meta-prompt/blob/b5f3f7be8ee6648afcca6b98d8054ef47342a46a/v1.txt
- Repository URL: https://github.com/jina-ai/meta-prompt
- Assessment: unconfirmed; do not use or test any credentials.

### 1928. P3_LOW_SIGNAL — jina-ai/meta-prompt

- Path: `v2.txt`
- Indicator: `api_key_label;access_token_label;bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jina-ai/meta-prompt/blob/b5f3f7be8ee6648afcca6b98d8054ef47342a46a/v2.txt
- Repository URL: https://github.com/jina-ai/meta-prompt
- Assessment: unconfirmed; do not use or test any credentials.

### 1929. P3_LOW_SIGNAL — jina-ai/meta-prompt

- Path: `v6.txt`
- Indicator: `api_key_label;bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jina-ai/meta-prompt/blob/b5f3f7be8ee6648afcca6b98d8054ef47342a46a/v6.txt
- Repository URL: https://github.com/jina-ai/meta-prompt
- Assessment: unconfirmed; do not use or test any credentials.

### 1930. P3_LOW_SIGNAL — jina-ai/meta-prompt

- Path: `v8.txt`
- Indicator: `api_key_label;bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jina-ai/meta-prompt/blob/b5f3f7be8ee6648afcca6b98d8054ef47342a46a/v8.txt
- Repository URL: https://github.com/jina-ai/meta-prompt
- Assessment: unconfirmed; do not use or test any credentials.

### 1931. P3_LOW_SIGNAL — jishanahmed-shaikh/slack-thread-exporter

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jishanahmed-shaikh/slack-thread-exporter/blob/5ce269634c4f06ae1a929d1258f990635d1338bb/README.md
- Repository URL: https://github.com/jishanahmed-shaikh/slack-thread-exporter
- Assessment: unconfirmed; do not use or test any credentials.

### 1932. P3_LOW_SIGNAL — jlord/git-it

- Path: `docu.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jlord/git-it/blob/85b31b48a2b1f22dcd332fd846ee94feab9b2b7a/docu.md
- Repository URL: https://github.com/jlord/git-it
- Assessment: unconfirmed; do not use or test any credentials.

### 1933. P3_LOW_SIGNAL — jmccann/drone-chef

- Path: `DOCS.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jmccann/drone-chef/blob/2e80c8c2ce1876f1bd1e3e2c743079458bba64a5/DOCS.md
- Repository URL: https://github.com/jmccann/drone-chef
- Assessment: unconfirmed; do not use or test any credentials.

### 1934. P3_LOW_SIGNAL — jmccann/drone-chef-supermarket

- Path: `DOCS.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jmccann/drone-chef-supermarket/blob/f49e61e16c17088920d62a7d42afdca38931d572/DOCS.md
- Repository URL: https://github.com/jmccann/drone-chef-supermarket
- Assessment: unconfirmed; do not use or test any credentials.

### 1935. P3_LOW_SIGNAL — joearms/paradis

- Path: `e7.org`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/joearms/paradis/blob/62055b8db643926fd86c8b79f038beb9ac50916f/e7.org
- Repository URL: https://github.com/joearms/paradis
- Assessment: unconfirmed; do not use or test any credentials.

### 1936. P3_LOW_SIGNAL — joern1811/homebrew-tap

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/joern1811/homebrew-tap/blob/305f927ce78e257ecdfeb5610cf846f7ed124eac/README.md
- Repository URL: https://github.com/joern1811/homebrew-tap
- Assessment: unconfirmed; do not use or test any credentials.

### 1937. P3_LOW_SIGNAL — johnhoopes/wiki

- Path: `jq.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnhoopes/wiki/blob/b18d0c5d473bf904fe557ca27c146f53ea103eb2/jq.md
- Repository URL: https://github.com/johnhoopes/wiki
- Assessment: unconfirmed; do not use or test any credentials.

### 1938. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `8581.txt`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/8581.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1939. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `8602.txt`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/8602.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1940. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `8611.txt`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/8611.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1941. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `941.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/941.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1942. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `942.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/942.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1943. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `943.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/943.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1944. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `944.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/944.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1945. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `945.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/945.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1946. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `946.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/946.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1947. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `947.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/947.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1948. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `948.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/948.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1949. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `950.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/950.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1950. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `951.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/951.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1951. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `952.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/952.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1952. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `953.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/953.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1953. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `954.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/954.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1954. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `955.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/955.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1955. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `956.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/956.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1956. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `957.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/957.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1957. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `958.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/958.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1958. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `959.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/959.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1959. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `960.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/960.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1960. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `961.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/961.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1961. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `962.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/962.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1962. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `963.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/963.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1963. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `964.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/964.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1964. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `965.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/965.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1965. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `966.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/966.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1966. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `967.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/967.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1967. P3_LOW_SIGNAL — johnkavin123/domains

- Path: `968.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnkavin123/domains/blob/8308d23bebbcecc2db8375279cdf19139ef090c5/968.txt
- Repository URL: https://github.com/johnkavin123/domains
- Assessment: unconfirmed; do not use or test any credentials.

### 1968. P3_LOW_SIGNAL — johnnyvng/PeopleSoft-CICD

- Path: `.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/johnnyvng/PeopleSoft-CICD/blob/f7b29c4c4a3ab6ae12a4b8501a43112e0fa137c3/.terraform.tfstate.lock.info
- Repository URL: https://github.com/johnnyvng/PeopleSoft-CICD
- Assessment: unconfirmed; do not use or test any credentials.

### 1969. P3_LOW_SIGNAL — jolynt24/tech-learning-repo

- Path: `scan.md`
- Indicator: `github_token_prefix;aws_access_key;stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jolynt24/tech-learning-repo/blob/d0bab2454b8792ef1d442f89c5a9b8b7068272f0/scan.md
- Repository URL: https://github.com/jolynt24/tech-learning-repo
- Assessment: unconfirmed; do not use or test any credentials.

### 1970. P3_LOW_SIGNAL — jonathanrao99/GitWrapped2.0

- Path: `setup.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jonathanrao99/GitWrapped2.0/blob/71f5568db6a9d78c8794221cb57b5afc837b8e45/setup.md
- Repository URL: https://github.com/jonathanrao99/GitWrapped2.0
- Assessment: unconfirmed; do not use or test any credentials.

### 1971. P3_LOW_SIGNAL — jorditorresBCN/Assignments-2017

- Path: `Lab02.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jorditorresBCN/Assignments-2017/blob/92c585792585d4567583a40e48ea4bbacec94723/Lab02.md
- Repository URL: https://github.com/jorditorresBCN/Assignments-2017
- Assessment: unconfirmed; do not use or test any credentials.

### 1972. P3_LOW_SIGNAL — jorditorresBCN/Assignments-2017

- Path: `Lab05.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jorditorresBCN/Assignments-2017/blob/92c585792585d4567583a40e48ea4bbacec94723/Lab05.md
- Repository URL: https://github.com/jorditorresBCN/Assignments-2017
- Assessment: unconfirmed; do not use or test any credentials.

### 1973. P3_LOW_SIGNAL — joshink/render

- Path: `KDL.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/joshink/render/blob/bb6f5db2af6741afc2b656a491a47a00a1f832d4/KDL.md
- Repository URL: https://github.com/joshink/render
- Assessment: unconfirmed; do not use or test any credentials.

### 1974. P3_LOW_SIGNAL — jpatokal/openflights

- Path: `INSTALL`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jpatokal/openflights/blob/56a3cce4d50309cb79948103a48c7f87d09b3056/INSTALL
- Repository URL: https://github.com/jpatokal/openflights
- Assessment: unconfirmed; do not use or test any credentials.

### 1975. P3_LOW_SIGNAL — jrandall54/PollRequest

- Path: `SETUP.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jrandall54/PollRequest/blob/5ead08aefea2f96e9011d34da37c05178262b945/SETUP.md
- Repository URL: https://github.com/jrandall54/PollRequest
- Assessment: unconfirmed; do not use or test any credentials.

### 1976. P3_LOW_SIGNAL — jritsema/golang-build

- Path: `Dockerfile`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jritsema/golang-build/blob/bfb8553710bf334065a222f87b8a391d8c60cd84/Dockerfile
- Repository URL: https://github.com/jritsema/golang-build
- Assessment: unconfirmed; do not use or test any credentials.

### 1977. P3_LOW_SIGNAL — jsegov/gh-opinionated-eng-dashboard

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jsegov/gh-opinionated-eng-dashboard/blob/f2f033824d98a2c5f9e6b539fde3b647c442037d/README.md
- Repository URL: https://github.com/jsegov/gh-opinionated-eng-dashboard
- Assessment: unconfirmed; do not use or test any credentials.

### 1978. P3_LOW_SIGNAL — julio22b/movie-app-backend

- Path: `.rest`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/julio22b/movie-app-backend/blob/e98114f5d115ff9bd88106fea321fffbb29ef16f/.rest
- Repository URL: https://github.com/julio22b/movie-app-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 1979. P3_LOW_SIGNAL — junh0328/prepare_frontend_interview

- Path: `cs.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/junh0328/prepare_frontend_interview/blob/dbfb55c841f7a8cbda0e23ec7d5602a1bcd27ab8/cs.md
- Repository URL: https://github.com/junh0328/prepare_frontend_interview
- Assessment: unconfirmed; do not use or test any credentials.

### 1980. P3_LOW_SIGNAL — jupegarnica/regular_expressions

- Path: `src/auth.ts`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jupegarnica/regular_expressions/blob/0f95fb9015062819be82fd848ff442114ad3ac3a/src/auth.ts
- Repository URL: https://github.com/jupegarnica/regular_expressions
- Assessment: unconfirmed; do not use or test any credentials.

### 1981. P3_LOW_SIGNAL — justin-thakral/DullyPDF

- Path: `GSC.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/justin-thakral/DullyPDF/blob/f38b33d1e791f4cf81d2dc2fd77ba1c56cfaeaed/GSC.md
- Repository URL: https://github.com/justin-thakral/DullyPDF
- Assessment: unconfirmed; do not use or test any credentials.

### 1982. P3_LOW_SIGNAL — justinzm/FCMS

- Path: `auth.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/justinzm/FCMS/blob/3a876655fba144c5278b9b7538ed9095a8127d0b/auth.md
- Repository URL: https://github.com/justinzm/FCMS
- Assessment: unconfirmed; do not use or test any credentials.

### 1983. P3_LOW_SIGNAL — justrach/bhumi

- Path: `PR.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/justrach/bhumi/blob/355545d6b8ec2e35b9976ae8e2977c76fa303f1d/PR.md
- Repository URL: https://github.com/justrach/bhumi
- Assessment: unconfirmed; do not use or test any credentials.

### 1984. P3_LOW_SIGNAL — jusuchin85/github-device-flow-examples

- Path: `README.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jusuchin85/github-device-flow-examples/blob/e8172ca27c72e0f6fdd776228485aa93133e6c66/README.md
- Repository URL: https://github.com/jusuchin85/github-device-flow-examples
- Assessment: unconfirmed; do not use or test any credentials.

### 1985. P3_LOW_SIGNAL — jusuchin85/github-device-flow-examples

- Path: `oauth-app/go.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jusuchin85/github-device-flow-examples/blob/e8172ca27c72e0f6fdd776228485aa93133e6c66/oauth-app/go.md
- Repository URL: https://github.com/jusuchin85/github-device-flow-examples
- Assessment: unconfirmed; do not use or test any credentials.

### 1986. P3_LOW_SIGNAL — jweijdert-eng/dl-pmgithub

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jweijdert-eng/dl-pmgithub/blob/1d8ee908f108d5d987af36f60c37a90a91d5a8bd/README.md
- Repository URL: https://github.com/jweijdert-eng/dl-pmgithub
- Assessment: unconfirmed; do not use or test any credentials.

### 1987. P3_LOW_SIGNAL — jweir/ScaleDown

- Path: `README.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jweir/ScaleDown/blob/39b64fd181a27b875fdb377ca18a8aec66a64210/README.md
- Repository URL: https://github.com/jweir/ScaleDown
- Assessment: unconfirmed; do not use or test any credentials.

### 1988. P3_LOW_SIGNAL — jwilk/japama

- Path: `README`
- Indicator: `password_assignment;secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jwilk/japama/blob/fe1899d8f23dba1707104a305407039c3685014c/README
- Repository URL: https://github.com/jwilk/japama
- Assessment: unconfirmed; do not use or test any credentials.

### 1989. P3_LOW_SIGNAL — jwilleke/geohazardwatch

- Path: `SETUP.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jwilleke/geohazardwatch/blob/c5e60b3247db2147c7af206a3d0305fb10a682a5/SETUP.md
- Repository URL: https://github.com/jwilleke/geohazardwatch
- Assessment: unconfirmed; do not use or test any credentials.

### 1990. P3_LOW_SIGNAL — jwilleke/mj-infra-flux

- Path: `SETUP.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jwilleke/mj-infra-flux/blob/d81294d7884bdf50733ab20b5d2bf2a212467660/SETUP.md
- Repository URL: https://github.com/jwilleke/mj-infra-flux
- Assessment: unconfirmed; do not use or test any credentials.

### 1991. P3_LOW_SIGNAL — jwr1995/dc1d

- Path: `TODO.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jwr1995/dc1d/blob/43234d2d55249774510bcc255dfa39b6375e8a79/TODO.md
- Repository URL: https://github.com/jwr1995/dc1d
- Assessment: unconfirmed; do not use or test any credentials.

### 1992. P3_LOW_SIGNAL — jxxghp/MoviePilot-Wiki

- Path: `cli.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/jxxghp/MoviePilot-Wiki/blob/df4d472e20b561ea2232d388449ebdd79e8ed1a6/cli.md
- Repository URL: https://github.com/jxxghp/MoviePilot-Wiki
- Assessment: unconfirmed; do not use or test any credentials.

### 1993. P3_LOW_SIGNAL — k8gege/Ladon

- Path: `id_rsa_2048`
- Indicator: `private_key_file`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/k8gege/Ladon/blob/a2adce3f3639d08df53483729df7a518366f0a54/id_rsa_2048
- Repository URL: https://github.com/k8gege/Ladon
- Assessment: unconfirmed; do not use or test any credentials.

### 1994. P3_LOW_SIGNAL — kafkaex/kafka_ex

- Path: `AUTH.md`
- Indicator: `aws_access_key;aws_secret_key_label;secret_access_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kafkaex/kafka_ex/blob/d9d6e40445a5a8858d1b05213c007a93d0b5848d/AUTH.md
- Repository URL: https://github.com/kafkaex/kafka_ex
- Assessment: unconfirmed; do not use or test any credentials.

### 1995. P3_LOW_SIGNAL — kahramanemir/Vallum

- Path: `SECURITY.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kahramanemir/Vallum/blob/1d10c73598f2c5f146d68ec83fc57de5e47a75e2/SECURITY.md
- Repository URL: https://github.com/kahramanemir/Vallum
- Assessment: unconfirmed; do not use or test any credentials.

### 1996. P3_LOW_SIGNAL — kaitoii11/mycluster

- Path: `MEMO.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kaitoii11/mycluster/blob/da0906cde6f277f2b97daf0838d418582e6ee11c/MEMO.md
- Repository URL: https://github.com/kaitoii11/mycluster
- Assessment: unconfirmed; do not use or test any credentials.

### 1997. P3_LOW_SIGNAL — kaivyy/kabot

- Path: `CHANGELOG.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kaivyy/kabot/blob/7b2c500439361a3d8412f24f2ca8d97e78bd4e03/CHANGELOG.md
- Repository URL: https://github.com/kaivyy/kabot
- Assessment: unconfirmed; do not use or test any credentials.

### 1998. P3_LOW_SIGNAL — kamalsrini/sentinel-cve

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kamalsrini/sentinel-cve/blob/466f03b6332bcde94148f57f6cfb97574daa64af/README.md
- Repository URL: https://github.com/kamalsrini/sentinel-cve
- Assessment: unconfirmed; do not use or test any credentials.

### 1999. P3_LOW_SIGNAL — karimFin/gpm-distributed-systems-research

- Path: `cmd.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/karimFin/gpm-distributed-systems-research/blob/c3ac928bbab133ca91bd447db716d21497cad2c5/cmd.md
- Repository URL: https://github.com/karimFin/gpm-distributed-systems-research
- Assessment: unconfirmed; do not use or test any credentials.

### 2000. P3_LOW_SIGNAL — karson/mpesa-php-sdk

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/karson/mpesa-php-sdk/blob/c4932ea8685ffc8cc8f8598e9bdf100a803da883/API.md
- Repository URL: https://github.com/karson/mpesa-php-sdk
- Assessment: unconfirmed; do not use or test any credentials.

### 2001. P3_LOW_SIGNAL — kartoza/MyGreatCircle

- Path: `SETUP.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kartoza/MyGreatCircle/blob/6f82a9cbd187a9f063246686ec656398e8040917/SETUP.md
- Repository URL: https://github.com/kartoza/MyGreatCircle
- Assessment: unconfirmed; do not use or test any credentials.

### 2002. P3_LOW_SIGNAL — kase1111-hash/HeLpER

- Path: `plan.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kase1111-hash/HeLpER/blob/64ff8fb43680aa9571ed9014e48ea6ee177dca60/plan.md
- Repository URL: https://github.com/kase1111-hash/HeLpER
- Assessment: unconfirmed; do not use or test any credentials.

### 2003. P3_LOW_SIGNAL — katarikapil/IntelliSQL-Intelligent-SQL-Querying-with-LLMs-Using-Gemini-Pro

- Path: `env.txt`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/katarikapil/IntelliSQL-Intelligent-SQL-Querying-with-LLMs-Using-Gemini-Pro/blob/fe2a914f16b3c1730360958960c19004bfa9ef81/env.txt
- Repository URL: https://github.com/katarikapil/IntelliSQL-Intelligent-SQL-Querying-with-LLMs-Using-Gemini-Pro
- Assessment: unconfirmed; do not use or test any credentials.

### 2004. P3_LOW_SIGNAL — kaynejohns/nutrition-planner

- Path: `SETUP.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kaynejohns/nutrition-planner/blob/04e180bca516d60c62f6656b4dee408873bd67f4/SETUP.md
- Repository URL: https://github.com/kaynejohns/nutrition-planner
- Assessment: unconfirmed; do not use or test any credentials.

### 2005. P3_LOW_SIGNAL — kcenon/claude_code_agent

- Path: `docs/monitoring.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kcenon/claude_code_agent/blob/68141c6aed47a3fd069e0ec8a51c3266a885e5f8/docs/monitoring.md
- Repository URL: https://github.com/kcenon/claude_code_agent
- Assessment: unconfirmed; do not use or test any credentials.

### 2006. P3_LOW_SIGNAL — kciter/MySQLForNonDeveloper

- Path: `R.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kciter/MySQLForNonDeveloper/blob/1d15451e6fbdd875c9141dde861f3a64b7419809/R.md
- Repository URL: https://github.com/kciter/MySQLForNonDeveloper
- Assessment: unconfirmed; do not use or test any credentials.

### 2007. P3_LOW_SIGNAL — kdlti/kdl_api_afericao

- Path: `f1.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kdlti/kdl_api_afericao/blob/c94d3ea10504710f2f17d397ca64270e61131d51/f1.md
- Repository URL: https://github.com/kdlti/kdl_api_afericao
- Assessment: unconfirmed; do not use or test any credentials.

### 2008. P3_LOW_SIGNAL — kds1019/swing-finder-v2

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kds1019/swing-finder-v2/blob/c567607f9b81361515e7797bba00b1860ff056eb/SETUP.md
- Repository URL: https://github.com/kds1019/swing-finder-v2
- Assessment: unconfirmed; do not use or test any credentials.

### 2009. P3_LOW_SIGNAL — kedarv/votey

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kedarv/votey/blob/d2711f6f9656aa7c1d0640035e1877d1bc713dcc/README.md
- Repository URL: https://github.com/kedarv/votey
- Assessment: unconfirmed; do not use or test any credentials.

### 2010. P3_LOW_SIGNAL — kedarvaidya/react-use-realm

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kedarvaidya/react-use-realm/blob/ec39292351a02c5d935e82621c2503a29a32c0f6/README.md
- Repository URL: https://github.com/kedarvaidya/react-use-realm
- Assessment: unconfirmed; do not use or test any credentials.

### 2011. P3_LOW_SIGNAL — kelvin-zhang-git/QueenBee

- Path: `todo.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kelvin-zhang-git/QueenBee/blob/7d10a9fe4d4a13148a4c12ab87a21d2efd4d4cd8/todo.md
- Repository URL: https://github.com/kelvin-zhang-git/QueenBee
- Assessment: unconfirmed; do not use or test any credentials.

### 2012. P3_LOW_SIGNAL — kenbod/sysadmin

- Path: `ssh.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kenbod/sysadmin/blob/4fa5b0b0b4f63cea1a917145590f1f6590e9eb35/ssh.md
- Repository URL: https://github.com/kenbod/sysadmin
- Assessment: unconfirmed; do not use or test any credentials.

### 2013. P3_LOW_SIGNAL — kenhuangus/arc-ai-agents

- Path: `TODO.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kenhuangus/arc-ai-agents/blob/c2f447992fdff96493dbdfe0f50b4b74fcb7c801/TODO.md
- Repository URL: https://github.com/kenhuangus/arc-ai-agents
- Assessment: unconfirmed; do not use or test any credentials.

### 2014. P3_LOW_SIGNAL — kenych/terraform_exs

- Path: `3-asg/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kenych/terraform_exs/blob/9d4de300b06efc36a92ab829ba0274a1f6bce19d/3-asg/.terraform.tfstate.lock.info
- Repository URL: https://github.com/kenych/terraform_exs
- Assessment: unconfirmed; do not use or test any credentials.

### 2015. P3_LOW_SIGNAL — kerneltime/BasicTaskTracker

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kerneltime/BasicTaskTracker/blob/f64d9d0e85fd044ec85ec18d6abae0d58b2f774d/README.md
- Repository URL: https://github.com/kerneltime/BasicTaskTracker
- Assessment: unconfirmed; do not use or test any credentials.

### 2016. P3_LOW_SIGNAL — kerollosmakary-ai/FANTOMAS-BOT

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kerollosmakary-ai/FANTOMAS-BOT/blob/e0f4bc4630f9a2b94660d5530cbf4b35583d9815/README.md
- Repository URL: https://github.com/kerollosmakary-ai/FANTOMAS-BOT
- Assessment: unconfirmed; do not use or test any credentials.

### 2017. P3_LOW_SIGNAL — keshhaav/Gdrive-organizer-app

- Path: `readme.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/keshhaav/Gdrive-organizer-app/blob/04ec0b4dc2ce9c3ecfa5d945158ba71ba0276d06/readme.md
- Repository URL: https://github.com/keshhaav/Gdrive-organizer-app
- Assessment: unconfirmed; do not use or test any credentials.

### 2018. P3_LOW_SIGNAL — kevinniel/mds2223veille

- Path: `Npm.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kevinniel/mds2223veille/blob/055778b0589a8483085352a9347b445ab8f17dcb/Npm.md
- Repository URL: https://github.com/kevinniel/mds2223veille
- Assessment: unconfirmed; do not use or test any credentials.

### 2019. P3_LOW_SIGNAL — kewalaka/terraform-github-githubapp

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kewalaka/terraform-github-githubapp/blob/cc89a11f70711c8d8a9f9e993108d01b563b4fff/README.md
- Repository URL: https://github.com/kewalaka/terraform-github-githubapp
- Assessment: unconfirmed; do not use or test any credentials.

### 2020. P3_LOW_SIGNAL — kgilpin/opentips

- Path: `CI.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kgilpin/opentips/blob/a840982e0bebd2e7c8e18cb8888afd0475b452d5/CI.md
- Repository URL: https://github.com/kgilpin/opentips
- Assessment: unconfirmed; do not use or test any credentials.

### 2021. P3_LOW_SIGNAL — kidoom/PR-Copilot

- Path: `API.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kidoom/PR-Copilot/blob/46299df2c7456cc7ba2b3130c7c1f7cb6dbbf886/API.md
- Repository URL: https://github.com/kidoom/PR-Copilot
- Assessment: unconfirmed; do not use or test any credentials.

### 2022. P3_LOW_SIGNAL — kirbudilov01/telegramleadgenerator

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kirbudilov01/telegramleadgenerator/blob/1e874dfddb3db0fd0f0e1188928ff7869d9d10c9/SETUP.md
- Repository URL: https://github.com/kirbudilov01/telegramleadgenerator
- Assessment: unconfirmed; do not use or test any credentials.

### 2023. P3_LOW_SIGNAL — kirillsaidov/mywebsite

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kirillsaidov/mywebsite/blob/12311c16b3e8368519e84721bd121e6dc3ccbf9a/API.md
- Repository URL: https://github.com/kirillsaidov/mywebsite
- Assessment: unconfirmed; do not use or test any credentials.

### 2024. P3_LOW_SIGNAL — kitgriului/Nexus

- Path: `DONE.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kitgriului/Nexus/blob/fcca8f5ec1d288169b4bb84ce5b38903e6959246/DONE.md
- Repository URL: https://github.com/kitgriului/Nexus
- Assessment: unconfirmed; do not use or test any credentials.

### 2025. P3_LOW_SIGNAL — kitnil/notes

- Path: `nix.org`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kitnil/notes/blob/035c46ff1d88c2aeb9a4d5c0cfd71b428d7599d5/nix.org
- Repository URL: https://github.com/kitnil/notes
- Assessment: unconfirmed; do not use or test any credentials.

### 2026. P3_LOW_SIGNAL — kkunkunya/ppt-maker-agent-plugin

- Path: `SECURITY.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kkunkunya/ppt-maker-agent-plugin/blob/a8c4a6391341e84dd69d4db43a1cf5b2d4120a49/SECURITY.md
- Repository URL: https://github.com/kkunkunya/ppt-maker-agent-plugin
- Assessment: unconfirmed; do not use or test any credentials.

### 2027. P3_LOW_SIGNAL — knostic/openclaw-telemetry

- Path: `README.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/knostic/openclaw-telemetry/blob/86c2458a0dfe82d639c208c5220396feb9d53c45/README.md
- Repository URL: https://github.com/knostic/openclaw-telemetry
- Assessment: unconfirmed; do not use or test any credentials.

### 2028. P3_LOW_SIGNAL — kpconnell/cloudprint

- Path: `PLAN.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kpconnell/cloudprint/blob/1d166c9ac70ec4a5b872060fe52aa1c1249f7937/PLAN.md
- Repository URL: https://github.com/kpconnell/cloudprint
- Assessment: unconfirmed; do not use or test any credentials.

### 2029. P3_LOW_SIGNAL — krishnamohanathota/DEVOPS

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/krishnamohanathota/DEVOPS/blob/cfb24816942ed00ea6881ca87b35062d2c9cba06/README.md
- Repository URL: https://github.com/krishnamohanathota/DEVOPS
- Assessment: unconfirmed; do not use or test any credentials.

### 2030. P3_LOW_SIGNAL — ksbicorp/Json-Naked

- Path: `FAQ.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ksbicorp/Json-Naked/blob/77934899074b67901b98d3d7464250fea5dd0932/FAQ.md
- Repository URL: https://github.com/ksbicorp/Json-Naked
- Assessment: unconfirmed; do not use or test any credentials.

### 2031. P3_LOW_SIGNAL — ktoetotam/NewFeeds

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ktoetotam/NewFeeds/blob/5da35b68f0c57c9888e25b517ccfc0a9c8d72e92/README.md
- Repository URL: https://github.com/ktoetotam/NewFeeds
- Assessment: unconfirmed; do not use or test any credentials.

### 2032. P3_LOW_SIGNAL — kumcp/aws-learning-example

- Path: `TF/labDeployment/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/kumcp/aws-learning-example/blob/5020a52d019f73369d43451418feb8b96f23cbba/TF/labDeployment/.terraform.tfstate.lock.info
- Repository URL: https://github.com/kumcp/aws-learning-example
- Assessment: unconfirmed; do not use or test any credentials.

### 2033. P3_LOW_SIGNAL — l0z4n0-a1/cognitive-claude

- Path: `CHANGELOG.md`
- Indicator: `github_oauth_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/l0z4n0-a1/cognitive-claude/blob/e69318cd65b596966eba0ca64e238c56d50e754d/CHANGELOG.md
- Repository URL: https://github.com/l0z4n0-a1/cognitive-claude
- Assessment: unconfirmed; do not use or test any credentials.

### 2034. P3_LOW_SIGNAL — l0z4n0-a1/cognitive-claude

- Path: `SECURITY.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/l0z4n0-a1/cognitive-claude/blob/e69318cd65b596966eba0ca64e238c56d50e754d/SECURITY.md
- Repository URL: https://github.com/l0z4n0-a1/cognitive-claude
- Assessment: unconfirmed; do not use or test any credentials.

### 2035. P3_LOW_SIGNAL — lakshit1001/CampusBox-API

- Path: `docs.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/lakshit1001/CampusBox-API/blob/e250d0b1acb357ca3631963cb96ac027523380ff/docs.md
- Repository URL: https://github.com/lakshit1001/CampusBox-API
- Assessment: unconfirmed; do not use or test any credentials.

### 2036. P3_LOW_SIGNAL — laplaque/it2mcp-secfilter

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/laplaque/it2mcp-secfilter/blob/82e6795f34351c577f8b7a761f88b6aa71840185/README.md
- Repository URL: https://github.com/laplaque/it2mcp-secfilter
- Assessment: unconfirmed; do not use or test any credentials.

### 2037. P3_LOW_SIGNAL — laplaque/piitools

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/laplaque/piitools/blob/bf4b16cd2b596912cff08a8df18b43c2ed1475dc/README.md
- Repository URL: https://github.com/laplaque/piitools
- Assessment: unconfirmed; do not use or test any credentials.

### 2038. P3_LOW_SIGNAL — laypal/ai-leak-checker

- Path: `ERRORS.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/laypal/ai-leak-checker/blob/8e761c3e28b82a809c7f8e80a132d045d0145588/ERRORS.md
- Repository URL: https://github.com/laypal/ai-leak-checker
- Assessment: unconfirmed; do not use or test any credentials.

### 2039. P3_LOW_SIGNAL — lazymarcus005-maker/kg-system

- Path: `GO.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/lazymarcus005-maker/kg-system/blob/f55b17877ed62908fb4ba40cd609101a052113f7/GO.md
- Repository URL: https://github.com/lazymarcus005-maker/kg-system
- Assessment: unconfirmed; do not use or test any credentials.

### 2040. P3_LOW_SIGNAL — lboel/acx

- Path: `SPEC.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/lboel/acx/blob/85f1358947a84dd5f82860aa69ae44648f84a675/SPEC.md
- Repository URL: https://github.com/lboel/acx
- Assessment: unconfirmed; do not use or test any credentials.

### 2041. P3_LOW_SIGNAL — lcmrcs/relat.incidentes.zabbix

- Path: `SEGURANCA.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/lcmrcs/relat.incidentes.zabbix/blob/9b97b74ee1acfa547870ce9f4e8bf2ddd46825f1/SEGURANCA.md
- Repository URL: https://github.com/lcmrcs/relat.incidentes.zabbix
- Assessment: unconfirmed; do not use or test any credentials.

### 2042. P3_LOW_SIGNAL — leafo/cloud_storage

- Path: `TODO.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/leafo/cloud_storage/blob/d26135c24dcaf2a15eceaac1c480eed5e9c76cd7/TODO.md
- Repository URL: https://github.com/leafo/cloud_storage
- Assessment: unconfirmed; do not use or test any credentials.

### 2043. P3_LOW_SIGNAL — leandercosta/scrumrun

- Path: `SPEC.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/leandercosta/scrumrun/blob/f6f9b86a0c130d7cbd10986185bdac3732eacf59/SPEC.md
- Repository URL: https://github.com/leandercosta/scrumrun
- Assessment: unconfirmed; do not use or test any credentials.

### 2044. P3_LOW_SIGNAL — leecoder/opencode-slack-agent

- Path: `SETUP.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/leecoder/opencode-slack-agent/blob/e45498d1260b06e61455edcf40c99e2125436d75/SETUP.md
- Repository URL: https://github.com/leecoder/opencode-slack-agent
- Assessment: unconfirmed; do not use or test any credentials.

### 2045. P3_LOW_SIGNAL — leejaycoke/pilot-react

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/leejaycoke/pilot-react/blob/9098444a3f7b6c3438ed1d8749375ef1278222d0/API.md
- Repository URL: https://github.com/leejaycoke/pilot-react
- Assessment: unconfirmed; do not use or test any credentials.

### 2046. P3_LOW_SIGNAL — leereilly/claw-counter

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/leereilly/claw-counter/blob/93db80ead93ead92758437b4cdfb8c892f1f4724/README.md
- Repository URL: https://github.com/leereilly/claw-counter
- Assessment: unconfirmed; do not use or test any credentials.

### 2047. P3_LOW_SIGNAL — legido-ai/mcp-github-app-auth

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/legido-ai/mcp-github-app-auth/blob/5b86fa9785d60b262acc8307d5d5075f5427b039/README.md
- Repository URL: https://github.com/legido-ai/mcp-github-app-auth
- Assessment: unconfirmed; do not use or test any credentials.

### 2048. P3_LOW_SIGNAL — lenaxia/k8s-mechanic

- Path: `SECURITY.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/lenaxia/k8s-mechanic/blob/5d6015cd8324aa8f0214cb054e1478db372bbdc0/SECURITY.md
- Repository URL: https://github.com/lenaxia/k8s-mechanic
- Assessment: unconfirmed; do not use or test any credentials.

### 2049. P3_LOW_SIGNAL — lenondpaula/clipagem

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/lenondpaula/clipagem/blob/2f9de46275485f1141a249aba7f61667f9b36c42/SETUP.md
- Repository URL: https://github.com/lenondpaula/clipagem
- Assessment: unconfirmed; do not use or test any credentials.

### 2050. P3_LOW_SIGNAL — leostephan/secret-santa

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/leostephan/secret-santa/blob/fd6f463347a23334fb42cd3287c688f314e287c1/API.md
- Repository URL: https://github.com/leostephan/secret-santa
- Assessment: unconfirmed; do not use or test any credentials.

### 2051. P3_LOW_SIGNAL — lhendre/simplyvitahlth

- Path: `id_rsa1.txt`
- Indicator: `private_key_file`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/lhendre/simplyvitahlth/blob/31b21d8eded686753041c4fa4608913ffbd7edc6/id_rsa1.txt
- Repository URL: https://github.com/lhendre/simplyvitahlth
- Assessment: unconfirmed; do not use or test any credentials.

### 2052. P3_LOW_SIGNAL — lhendre/simplyvitahlth

- Path: `id_rsa2`
- Indicator: `private_key_file`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/lhendre/simplyvitahlth/blob/31b21d8eded686753041c4fa4608913ffbd7edc6/id_rsa2
- Repository URL: https://github.com/lhendre/simplyvitahlth
- Assessment: unconfirmed; do not use or test any credentials.

### 2053. P3_LOW_SIGNAL — liatrio-labs/otel-instrumentation-mcp

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/liatrio-labs/otel-instrumentation-mcp/blob/7e8d81cb2cd762bb5d76eaffebe7d69b24880258/README.md
- Repository URL: https://github.com/liatrio-labs/otel-instrumentation-mcp
- Assessment: unconfirmed; do not use or test any credentials.

### 2054. P3_LOW_SIGNAL — libhugetlbfs/libhugetlbfs

- Path: `alloc.c`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/libhugetlbfs/libhugetlbfs/blob/6e7985b1e248b1d13aff0b83b49b4bd1b7c8a952/alloc.c
- Repository URL: https://github.com/libhugetlbfs/libhugetlbfs
- Assessment: unconfirmed; do not use or test any credentials.

### 2055. P3_LOW_SIGNAL — library-data-platform/ldlite

- Path: `srs.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/library-data-platform/ldlite/blob/c2fb94268e062bbafe806344faaeb2f844094245/srs.md
- Repository URL: https://github.com/library-data-platform/ldlite
- Assessment: unconfirmed; do not use or test any credentials.

### 2056. P3_LOW_SIGNAL — libz-renlab-ai/TeamBrain

- Path: `bugs.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/libz-renlab-ai/TeamBrain/blob/f077a8ab7d6cdbb210b0416d2badac137b0e954d/bugs.md
- Repository URL: https://github.com/libz-renlab-ai/TeamBrain
- Assessment: unconfirmed; do not use or test any credentials.

### 2057. P3_LOW_SIGNAL — lidzmarjaradi-glitch/ssc-elearning-platform

- Path: `ss.txt`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/lidzmarjaradi-glitch/ssc-elearning-platform/blob/b54124217a03abc25fb4e0a0a36ebc7247726d65/ss.txt
- Repository URL: https://github.com/lidzmarjaradi-glitch/ssc-elearning-platform
- Assessment: unconfirmed; do not use or test any credentials.

### 2058. P3_LOW_SIGNAL — lightforgemedia/copilot-more

- Path: `README.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/lightforgemedia/copilot-more/blob/5763617bcc00a296665ce1fd2063fbbec8b9adc0/README.md
- Repository URL: https://github.com/lightforgemedia/copilot-more
- Assessment: unconfirmed; do not use or test any credentials.

### 2059. P3_LOW_SIGNAL — lightstep/lightstep-tracer-android

- Path: `DEV.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/lightstep/lightstep-tracer-android/blob/87cc09e47c006f5c0f63ff4d092932851b017f9f/DEV.md
- Repository URL: https://github.com/lightstep/lightstep-tracer-android
- Assessment: unconfirmed; do not use or test any credentials.

### 2060. P3_LOW_SIGNAL — lijianqiao/fastapi-admin-v2

- Path: `api.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/lijianqiao/fastapi-admin-v2/blob/3f52b6586d41aaa489886d5cb901bbaaee8e0b63/api.md
- Repository URL: https://github.com/lijianqiao/fastapi-admin-v2
- Assessment: unconfirmed; do not use or test any credentials.

### 2061. P3_LOW_SIGNAL — limelightseychelles-git/KidsTube-filter

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/limelightseychelles-git/KidsTube-filter/blob/2745eb8cf592bb000239c5c14c083436198245c0/API.md
- Repository URL: https://github.com/limelightseychelles-git/KidsTube-filter
- Assessment: unconfirmed; do not use or test any credentials.

### 2062. P3_LOW_SIGNAL — linkernetworks/vortex

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/linkernetworks/vortex/blob/fa46b7f12e82a43240efd2a72a66ff1124323b4f/API.md
- Repository URL: https://github.com/linkernetworks/vortex
- Assessment: unconfirmed; do not use or test any credentials.

### 2063. P3_LOW_SIGNAL — liviasab/GymProject_api

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/liviasab/GymProject_api/blob/c01a4eb533525e7af6fbfaf24bcfefb9644b4fba/API.md
- Repository URL: https://github.com/liviasab/GymProject_api
- Assessment: unconfirmed; do not use or test any credentials.

### 2064. P3_LOW_SIGNAL — ljnchn/nodeseeker-docker

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ljnchn/nodeseeker-docker/blob/b5497569704f07f0e239dca84061081bb6f09e14/API.md
- Repository URL: https://github.com/ljnchn/nodeseeker-docker
- Assessment: unconfirmed; do not use or test any credentials.

### 2065. P3_LOW_SIGNAL — llmsecrets/llm-secrets

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/llmsecrets/llm-secrets/blob/f62b4a9a7803b7fd2db28acb49d7918ffa6fe1aa/README.md
- Repository URL: https://github.com/llmsecrets/llm-secrets
- Assessment: unconfirmed; do not use or test any credentials.

### 2066. P3_LOW_SIGNAL — lnicoletti/city-access-map

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/lnicoletti/city-access-map/blob/14d5baa9a2f8af48bc80b787e92ca8dbf081eda1/README.md
- Repository URL: https://github.com/lnicoletti/city-access-map
- Assessment: unconfirmed; do not use or test any credentials.

### 2067. P3_LOW_SIGNAL — lockcp/LiteGist

- Path: `API.md`
- Indicator: `access_token_label;bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/lockcp/LiteGist/blob/15e089e359de0b845eb4cbd91ec365a352715ac8/API.md
- Repository URL: https://github.com/lockcp/LiteGist
- Assessment: unconfirmed; do not use or test any credentials.

### 2068. P3_LOW_SIGNAL — longphamkhac/Data-Processing-System-for-Amazon-Reviews

- Path: `iac/terraform/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/longphamkhac/Data-Processing-System-for-Amazon-Reviews/blob/2afa73d47e92047dad0dfdc46aa0736c9abe3044/iac/terraform/.terraform.tfstate.lock.info
- Repository URL: https://github.com/longphamkhac/Data-Processing-System-for-Amazon-Reviews
- Assessment: unconfirmed; do not use or test any credentials.

### 2069. P3_LOW_SIGNAL — longzhi/clawhive-hub

- Path: `CLAUDE.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/longzhi/clawhive-hub/blob/645213a5dc181c07d504f0d80ce030907cd212e1/CLAUDE.md
- Repository URL: https://github.com/longzhi/clawhive-hub
- Assessment: unconfirmed; do not use or test any credentials.

### 2070. P3_LOW_SIGNAL — lookfirst/mui-rff

- Path: `CI.md`
- Indicator: `private_key_label;npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/lookfirst/mui-rff/blob/6200dc617fe9eeebf9dfc9ff2f71d30aa77f287f/CI.md
- Repository URL: https://github.com/lookfirst/mui-rff
- Assessment: unconfirmed; do not use or test any credentials.

### 2071. P3_LOW_SIGNAL — lsadehaan/electron-to-web

- Path: `SETUP.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/lsadehaan/electron-to-web/blob/47759f334d78329204a337d97bbf462c7c5e3896/SETUP.md
- Repository URL: https://github.com/lsadehaan/electron-to-web
- Assessment: unconfirmed; do not use or test any credentials.

### 2072. P3_LOW_SIGNAL — lsqkk/OrangePi

- Path: `2.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/lsqkk/OrangePi/blob/03252bcd9071603f0ab0c41010537617d1b18281/2.md
- Repository URL: https://github.com/lsqkk/OrangePi
- Assessment: unconfirmed; do not use or test any credentials.

### 2073. P3_LOW_SIGNAL — lufihubs/dealsuknow

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/lufihubs/dealsuknow/blob/1b96ff9dc20f8dcd61a8e387856a29febfb24b58/SETUP.md
- Repository URL: https://github.com/lufihubs/dealsuknow
- Assessment: unconfirmed; do not use or test any credentials.

### 2074. P3_LOW_SIGNAL — lukas-andre/bun-elysia-clean-architecture-example

- Path: `.rest`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/lukas-andre/bun-elysia-clean-architecture-example/blob/3d9fa4cf369dcc8d1645b41818ac68a85e8b5696/.rest
- Repository URL: https://github.com/lukas-andre/bun-elysia-clean-architecture-example
- Assessment: unconfirmed; do not use or test any credentials.

### 2075. P3_LOW_SIGNAL — lukilabs/craft-quick-notes

- Path: `PRD.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/lukilabs/craft-quick-notes/blob/5a95e4405b253a6822c6343879b7e66093b7500b/PRD.md
- Repository URL: https://github.com/lukilabs/craft-quick-notes
- Assessment: unconfirmed; do not use or test any credentials.

### 2076. P3_LOW_SIGNAL — luqmanoop/sync-dotenv-slack

- Path: `readme.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/luqmanoop/sync-dotenv-slack/blob/dfe26c1c7bbfeffa3a5ae9ac669fa76e64835331/readme.md
- Repository URL: https://github.com/luqmanoop/sync-dotenv-slack
- Assessment: unconfirmed; do not use or test any credentials.

### 2077. P3_LOW_SIGNAL — lxgicstudios/secretsweep

- Path: `SKILL.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/lxgicstudios/secretsweep/blob/1a02272c1ee5025c41161785723b5f87ac28be5c/SKILL.md
- Repository URL: https://github.com/lxgicstudios/secretsweep
- Assessment: unconfirmed; do not use or test any credentials.

### 2078. P3_LOW_SIGNAL — m7mdraafat/GitHubProfileHarvester

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/m7mdraafat/GitHubProfileHarvester/blob/38083e454a956fde3ef53d4dfcc4c3a6fe783c8a/SETUP.md
- Repository URL: https://github.com/m7mdraafat/GitHubProfileHarvester
- Assessment: unconfirmed; do not use or test any credentials.

### 2079. P3_LOW_SIGNAL — macamparone/Countries

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/macamparone/Countries/blob/c39a5c3e324a41626787354ac7cd314ff782bd10/README.md
- Repository URL: https://github.com/macamparone/Countries
- Assessment: unconfirmed; do not use or test any credentials.

### 2080. P3_LOW_SIGNAL — madreain/MadreainNote

- Path: `git.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/madreain/MadreainNote/blob/33888607c4b841787fd0f129a03fab6b19dc3c66/git.md
- Repository URL: https://github.com/madreain/MadreainNote
- Assessment: unconfirmed; do not use or test any credentials.

### 2081. P3_LOW_SIGNAL — mahmoud/awesome-python-applications

- Path: `TODO.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mahmoud/awesome-python-applications/blob/3c6550d0897a964b598c8d3135b21c2279e7e5d4/TODO.md
- Repository URL: https://github.com/mahmoud/awesome-python-applications
- Assessment: unconfirmed; do not use or test any credentials.

### 2082. P3_LOW_SIGNAL — mainawycliffe/ripper-the-github-griller

- Path: `WARP.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mainawycliffe/ripper-the-github-griller/blob/99dcf9f4eef050bca52d4d5a5669e281479d99d9/WARP.md
- Repository URL: https://github.com/mainawycliffe/ripper-the-github-griller
- Assessment: unconfirmed; do not use or test any credentials.

### 2083. P3_LOW_SIGNAL — makuga01/dnsFookup

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/makuga01/dnsFookup/blob/43fbeacfa0d16746267e5c773f7dab66229c400a/API.md
- Repository URL: https://github.com/makuga01/dnsFookup
- Assessment: unconfirmed; do not use or test any credentials.

### 2084. P3_LOW_SIGNAL — malamsyah/leakfix

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/malamsyah/leakfix/blob/8f49aaeeb0df3c7174d96b8109364a71066ce4ad/SETUP.md
- Repository URL: https://github.com/malamsyah/leakfix
- Assessment: unconfirmed; do not use or test any credentials.

### 2085. P3_LOW_SIGNAL — malaporte/pippin

- Path: `COPILOT.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/malaporte/pippin/blob/b9e2c8a45831a04c355aaf685d8fd61fbfa1949c/COPILOT.md
- Repository URL: https://github.com/malaporte/pippin
- Assessment: unconfirmed; do not use or test any credentials.

### 2086. P3_LOW_SIGNAL — malaporte/pippin

- Path: `GH.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/malaporte/pippin/blob/b9e2c8a45831a04c355aaf685d8fd61fbfa1949c/GH.md
- Repository URL: https://github.com/malaporte/pippin
- Assessment: unconfirmed; do not use or test any credentials.

### 2087. P3_LOW_SIGNAL — malinda1986/whyline

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/malinda1986/whyline/blob/592d1f2915e5f69e8efcf05d8a56d0ad19ba50b5/README.md
- Repository URL: https://github.com/malinda1986/whyline
- Assessment: unconfirmed; do not use or test any credentials.

### 2088. P3_LOW_SIGNAL — manav8498/Shadow

- Path: `SPEC.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/manav8498/Shadow/blob/fc515032ef4646b0a3a096a644991665a3de6ab0/SPEC.md
- Repository URL: https://github.com/manav8498/Shadow
- Assessment: unconfirmed; do not use or test any credentials.

### 2089. P3_LOW_SIGNAL — mane115/ucenter

- Path: `api.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mane115/ucenter/blob/b2601768de399da0dfcad8efd89ab3ae3d931531/api.md
- Repository URL: https://github.com/mane115/ucenter
- Assessment: unconfirmed; do not use or test any credentials.

### 2090. P3_LOW_SIGNAL — mangit955/trace

- Path: `TODO.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mangit955/trace/blob/012a218d479e4a1001663fe742475eb38ab979ef/TODO.md
- Repository URL: https://github.com/mangit955/trace
- Assessment: unconfirmed; do not use or test any credentials.

### 2091. P3_LOW_SIGNAL — maplehilllabs/mcp-slack-lists

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/maplehilllabs/mcp-slack-lists/blob/8389aa2783a0794954f63b418493f6462d1340e9/README.md
- Repository URL: https://github.com/maplehilllabs/mcp-slack-lists
- Assessment: unconfirmed; do not use or test any credentials.

### 2092. P3_LOW_SIGNAL — marcelocruzrpa/uipath-xaml-viewer

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/marcelocruzrpa/uipath-xaml-viewer/blob/492336112b524f271ac80f61ad935ebd9eaebd2b/README.md
- Repository URL: https://github.com/marcelocruzrpa/uipath-xaml-viewer
- Assessment: unconfirmed; do not use or test any credentials.

### 2093. P3_LOW_SIGNAL — marcelofarias/botscript

- Path: `STUCK.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/marcelofarias/botscript/blob/cdb48d4397d14d549d21757c7fcd194bfef63485/STUCK.md
- Repository URL: https://github.com/marcelofarias/botscript
- Assessment: unconfirmed; do not use or test any credentials.

### 2094. P3_LOW_SIGNAL — marmyx77/omni-ai-mcp

- Path: `SECURITY.md`
- Indicator: `github_app_token_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/marmyx77/omni-ai-mcp/blob/deb440b5309305b5df3b3a2acc2f25f4d6bdd0e1/SECURITY.md
- Repository URL: https://github.com/marmyx77/omni-ai-mcp
- Assessment: unconfirmed; do not use or test any credentials.

### 2095. P3_LOW_SIGNAL — martinmclarnon/opentelemetry-demo-cx-rum

- Path: `HELM.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/martinmclarnon/opentelemetry-demo-cx-rum/blob/a41ea09521089ab7e14a9cd31a9eaa4a061cfb99/HELM.md
- Repository URL: https://github.com/martinmclarnon/opentelemetry-demo-cx-rum
- Assessment: unconfirmed; do not use or test any credentials.

### 2096. P3_LOW_SIGNAL — marz-hunter/kontools

- Path: `e.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/marz-hunter/kontools/blob/300b4af0a34a6dd96dbebb02265b9a4896647867/e.md
- Repository URL: https://github.com/marz-hunter/kontools
- Assessment: unconfirmed; do not use or test any credentials.

### 2097. P3_LOW_SIGNAL — maseology/goLIA

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/maseology/goLIA/blob/ae62d14b9376032da0529d5c93bcaa6d9a6d866d/README.md
- Repository URL: https://github.com/maseology/goLIA
- Assessment: unconfirmed; do not use or test any credentials.

### 2098. P3_LOW_SIGNAL — masmovil/actions-notify-slack-k8s

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/masmovil/actions-notify-slack-k8s/blob/c7449bef72c6fa3d848c235455ddfb95e41b364a/README.md
- Repository URL: https://github.com/masmovil/actions-notify-slack-k8s
- Assessment: unconfirmed; do not use or test any credentials.

### 2099. P3_LOW_SIGNAL — massimoaria/pubmedR

- Path: `NEWS`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/massimoaria/pubmedR/blob/add34a2fbf21f1a344a228e2f3a759f54e23bb44/NEWS
- Repository URL: https://github.com/massimoaria/pubmedR
- Assessment: unconfirmed; do not use or test any credentials.

### 2100. P3_LOW_SIGNAL — mateusfg7/Happy

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mateusfg7/Happy/blob/4a1eecde57c7d30343ce0d9aaee8fdf19485627b/README.md
- Repository URL: https://github.com/mateusfg7/Happy
- Assessment: unconfirmed; do not use or test any credentials.

### 2101. P3_LOW_SIGNAL — mattrobenolt/vouch

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mattrobenolt/vouch/blob/e93c92f16f80deb04593b58a4d86c0c3dd689bcd/README.md
- Repository URL: https://github.com/mattrobenolt/vouch
- Assessment: unconfirmed; do not use or test any credentials.

### 2102. P3_LOW_SIGNAL — maxbeizer/gh-agent-viz

- Path: `docs/SECURITY.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/maxbeizer/gh-agent-viz/blob/d30791cbf411f535c9e549ba0d54999520542d36/docs/SECURITY.md
- Repository URL: https://github.com/maxbeizer/gh-agent-viz
- Assessment: unconfirmed; do not use or test any credentials.

### 2103. P3_LOW_SIGNAL — maxff77/tiendalohari

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/maxff77/tiendalohari/blob/c6bc82f95dcbeeafb5d1d564eeb10503594da50e/README.md
- Repository URL: https://github.com/maxff77/tiendalohari
- Assessment: unconfirmed; do not use or test any credentials.

### 2104. P3_LOW_SIGNAL — mbakgun/n8n-slack-socket-mode

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mbakgun/n8n-slack-socket-mode/blob/64f0aef935193c29a1bd7833e7bb2c163edc27eb/README.md
- Repository URL: https://github.com/mbakgun/n8n-slack-socket-mode
- Assessment: unconfirmed; do not use or test any credentials.

### 2105. P3_LOW_SIGNAL — mcollard0/subshift

- Path: `WARP.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mcollard0/subshift/blob/7e8f6b0efb051bbd945e717dc960bc24c9a27bbd/WARP.md
- Repository URL: https://github.com/mcollard0/subshift
- Assessment: unconfirmed; do not use or test any credentials.

### 2106. P3_LOW_SIGNAL — mdconaway/fastapi-cruddy-framework

- Path: `CLI.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mdconaway/fastapi-cruddy-framework/blob/03fe5a356544df46d158514af76b2e34c040b9a4/CLI.md
- Repository URL: https://github.com/mdconaway/fastapi-cruddy-framework
- Assessment: unconfirmed; do not use or test any credentials.

### 2107. P3_LOW_SIGNAL — mdd-uni/java

- Path: `web.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mdd-uni/java/blob/164d04a6c434d8c127881adef3dbd5922be10a84/web.md
- Repository URL: https://github.com/mdd-uni/java
- Assessment: unconfirmed; do not use or test any credentials.

### 2108. P3_LOW_SIGNAL — mdminhazulhaque/aws-cli-cheatsheet

- Path: `iam.rst`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mdminhazulhaque/aws-cli-cheatsheet/blob/b2f34fe6d8a047cacceedab2acfb31fd07c42831/iam.rst
- Repository URL: https://github.com/mdminhazulhaque/aws-cli-cheatsheet
- Assessment: unconfirmed; do not use or test any credentials.

### 2109. P3_LOW_SIGNAL — mechurial/whisper-matters

- Path: `SPEC.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mechurial/whisper-matters/blob/834a6e90685e05e56d345a53dd978022e83f2636/SPEC.md
- Repository URL: https://github.com/mechurial/whisper-matters
- Assessment: unconfirmed; do not use or test any credentials.

### 2110. P3_LOW_SIGNAL — megatonai/text-to-greenscreen

- Path: `SKILL.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/megatonai/text-to-greenscreen/blob/a5d7a6ad9bb3c716c02076edb328ffc1b8c43b4a/SKILL.md
- Repository URL: https://github.com/megatonai/text-to-greenscreen
- Assessment: unconfirmed; do not use or test any credentials.

### 2111. P3_LOW_SIGNAL — mejiasd3v/car-transfer-bot

- Path: `SETUP.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mejiasd3v/car-transfer-bot/blob/8c24f3687fbfcb6306f3768411492b9046215ddc/SETUP.md
- Repository URL: https://github.com/mejiasd3v/car-transfer-bot
- Assessment: unconfirmed; do not use or test any credentials.

### 2112. P3_LOW_SIGNAL — melvincarvalho/skill-dyndns

- Path: `INSTALL`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/melvincarvalho/skill-dyndns/blob/84cd986b785d5e62fa962ed4fcc06379153664c2/INSTALL
- Repository URL: https://github.com/melvincarvalho/skill-dyndns
- Assessment: unconfirmed; do not use or test any credentials.

### 2113. P3_LOW_SIGNAL — memgraph/rune

- Path: `docs.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/memgraph/rune/blob/32b776669810df8ba3a5488a962bd542358afb0a/docs.md
- Repository URL: https://github.com/memgraph/rune
- Assessment: unconfirmed; do not use or test any credentials.

### 2114. P3_LOW_SIGNAL — metcalf/saypi

- Path: `api.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/metcalf/saypi/blob/f05d2e93d0df5907f3f4f2347d8b3b9a6bce3353/api.md
- Repository URL: https://github.com/metcalf/saypi
- Assessment: unconfirmed; do not use or test any credentials.

### 2115. P3_LOW_SIGNAL — mi-fed17/javascript

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mi-fed17/javascript/blob/df42e9fd612f33dd906efd9531e545e463a94026/README.md
- Repository URL: https://github.com/mi-fed17/javascript
- Assessment: unconfirmed; do not use or test any credentials.

### 2116. P3_LOW_SIGNAL — michaelByrne/goBoard

- Path: `.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/michaelByrne/goBoard/blob/e7d7ca92780cad80962d5f0bed6b4c91f94bf24e/.terraform.tfstate.lock.info
- Repository URL: https://github.com/michaelByrne/goBoard
- Assessment: unconfirmed; do not use or test any credentials.

### 2117. P3_LOW_SIGNAL — michalswi/github-c2

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/michalswi/github-c2/blob/4349a64d31ebd22e6fab9192e0a2ed0434727fd5/README.md
- Repository URL: https://github.com/michalswi/github-c2
- Assessment: unconfirmed; do not use or test any credentials.

### 2118. P3_LOW_SIGNAL — micr0-dev/Altbot

- Path: `API.md`
- Indicator: `api_key_label;bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/micr0-dev/Altbot/blob/babab68f14d48908c176ad7dd7fc48ceb1ad3729/API.md
- Repository URL: https://github.com/micr0-dev/Altbot
- Assessment: unconfirmed; do not use or test any credentials.

### 2119. P3_LOW_SIGNAL — midlaj-muhammed/Replay-AI_Memory_Layer_for_Humanity

- Path: `SECURITY.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/midlaj-muhammed/Replay-AI_Memory_Layer_for_Humanity/blob/49f52fdb5ff944f28270dbab1eecf86f744a047c/SECURITY.md
- Repository URL: https://github.com/midlaj-muhammed/Replay-AI_Memory_Layer_for_Humanity
- Assessment: unconfirmed; do not use or test any credentials.

### 2120. P3_LOW_SIGNAL — mikeghen/blockflix

- Path: `infrastructure/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mikeghen/blockflix/blob/5a0cc394e43e2d583522c54be5c3650f9a1fbd79/infrastructure/.terraform.tfstate.lock.info
- Repository URL: https://github.com/mikeghen/blockflix
- Assessment: unconfirmed; do not use or test any credentials.

### 2121. P3_LOW_SIGNAL — minexcoin/atomicswap

- Path: `Lib.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/minexcoin/atomicswap/blob/5eabfa05b75d34dcc119ea07e817f4bcaf086b88/Lib.md
- Repository URL: https://github.com/minexcoin/atomicswap
- Assessment: unconfirmed; do not use or test any credentials.

### 2122. P3_LOW_SIGNAL — mingfang/terraform-k8s-modules

- Path: `examples/langfuse/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mingfang/terraform-k8s-modules/blob/6c6e95e3f8d93815d9d5bd53655269fc397c64b2/examples/langfuse/.terraform.tfstate.lock.info
- Repository URL: https://github.com/mingfang/terraform-k8s-modules
- Assessment: unconfirmed; do not use or test any credentials.

### 2123. P3_LOW_SIGNAL — miradamkhan/miradamkhan

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/miradamkhan/miradamkhan/blob/616aade0f40c669aedcae250f3084dd80787c122/SETUP.md
- Repository URL: https://github.com/miradamkhan/miradamkhan
- Assessment: unconfirmed; do not use or test any credentials.

### 2124. P3_LOW_SIGNAL — misskukuua/DevOps_Project

- Path: `terraform/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/misskukuua/DevOps_Project/blob/275226d29e47d11e1804132131bc1000a986ec8f/terraform/.terraform.tfstate.lock.info
- Repository URL: https://github.com/misskukuua/DevOps_Project
- Assessment: unconfirmed; do not use or test any credentials.

### 2125. P3_LOW_SIGNAL — mitchallen/calc

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mitchallen/calc/blob/db61c9e074d8c41ac11f408ac41ac5e66d766dad/README.md
- Repository URL: https://github.com/mitchallen/calc
- Assessment: unconfirmed; do not use or test any credentials.

### 2126. P3_LOW_SIGNAL — mkaidev/mkaidev-belajar

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mkaidev/mkaidev-belajar/blob/eec45d2fb64a394e372d680818e44e99be4498d8/README.md
- Repository URL: https://github.com/mkaidev/mkaidev-belajar
- Assessment: unconfirmed; do not use or test any credentials.

### 2127. P3_LOW_SIGNAL — mkusaka/mcp-server-slack-notify

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mkusaka/mcp-server-slack-notify/blob/9b49042f31398cdb48770b013282c619702afc0a/README.md
- Repository URL: https://github.com/mkusaka/mcp-server-slack-notify
- Assessment: unconfirmed; do not use or test any credentials.

### 2128. P3_LOW_SIGNAL — mockring/music-processor

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mockring/music-processor/blob/20402b5339426074c7d1965586dccd40af1c5196/API.md
- Repository URL: https://github.com/mockring/music-processor
- Assessment: unconfirmed; do not use or test any credentials.

### 2129. P3_LOW_SIGNAL — modbender/skill-library-mcp

- Path: `data/canary/SKILL.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/modbender/skill-library-mcp/blob/d9c8fe903b5b4e82237dbe8d0df8567783022e18/data/canary/SKILL.md
- Repository URL: https://github.com/modbender/skill-library-mcp
- Assessment: unconfirmed; do not use or test any credentials.

### 2130. P3_LOW_SIGNAL — mohamadalsalty/tf-makefile-gcp-poc

- Path: `app/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mohamadalsalty/tf-makefile-gcp-poc/blob/791ca058f2992544d6fa903c1eda9d0b09d693aa/app/.terraform.tfstate.lock.info
- Repository URL: https://github.com/mohamadalsalty/tf-makefile-gcp-poc
- Assessment: unconfirmed; do not use or test any credentials.

### 2131. P3_LOW_SIGNAL — mohan-chinnappan-n/cli-dx

- Path: `jwt.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mohan-chinnappan-n/cli-dx/blob/84d2f83ef08b43eb13a26106894fd40054d93ee3/jwt.md
- Repository URL: https://github.com/mohan-chinnappan-n/cli-dx
- Assessment: unconfirmed; do not use or test any credentials.

### 2132. P3_LOW_SIGNAL — mojaloop/documentation

- Path: `infra/state/terraform.tfstate_dep`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mojaloop/documentation/blob/46a2ae63ece609c1855f5ed3cc2c0a44674b7489/infra/state/terraform.tfstate_dep
- Repository URL: https://github.com/mojaloop/documentation
- Assessment: unconfirmed; do not use or test any credentials.

### 2133. P3_LOW_SIGNAL — moltar/projen-turborepo

- Path: `API.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/moltar/projen-turborepo/blob/287d079c498822e7894b4ae9e5790df6c0bb2ed2/API.md
- Repository URL: https://github.com/moltar/projen-turborepo
- Assessment: unconfirmed; do not use or test any credentials.

### 2134. P3_LOW_SIGNAL — morgenyu/antigravity2api

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/morgenyu/antigravity2api/blob/b8da7e57f1cd16606fe244971d5283a060d15bf8/API.md
- Repository URL: https://github.com/morgenyu/antigravity2api
- Assessment: unconfirmed; do not use or test any credentials.

### 2135. P3_LOW_SIGNAL — motionbug/detaartenfabriek

- Path: `API.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/motionbug/detaartenfabriek/blob/8e324d1d1b6a972bfe86a7a23fc38dbeb7e40a97/API.md
- Repository URL: https://github.com/motionbug/detaartenfabriek
- Assessment: unconfirmed; do not use or test any credentials.

### 2136. P3_LOW_SIGNAL — movielust-in/movielust-next

- Path: `.rest`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/movielust-in/movielust-next/blob/237073ee1086001f4f082fec54dec3a151bb34fd/.rest
- Repository URL: https://github.com/movielust-in/movielust-next
- Assessment: unconfirmed; do not use or test any credentials.

### 2137. P3_LOW_SIGNAL — msfeldstein/hooks-examples

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/msfeldstein/hooks-examples/blob/51cddbd8ee3fe8910eebd95fe8381710897ab303/README.md
- Repository URL: https://github.com/msfeldstein/hooks-examples
- Assessment: unconfirmed; do not use or test any credentials.

### 2138. P3_LOW_SIGNAL — mstraughan86/Mercurys-Charge

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mstraughan86/Mercurys-Charge/blob/dac2b8e82de9548fbbe6c7fbb467bda3d06cbbff/README.md
- Repository URL: https://github.com/mstraughan86/Mercurys-Charge
- Assessment: unconfirmed; do not use or test any credentials.

### 2139. P3_LOW_SIGNAL — mstream/presentation-nix

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mstream/presentation-nix/blob/e174a5084b694e941dab091356f545a0234fe155/README.md
- Repository URL: https://github.com/mstream/presentation-nix
- Assessment: unconfirmed; do not use or test any credentials.

### 2140. P3_LOW_SIGNAL — mudrii/openfang-docs

- Path: `sdk.md`
- Indicator: `api_key_label;bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mudrii/openfang-docs/blob/04acfadf9a4f0ffbc7957447c524b7afb8dfa3bb/sdk.md
- Repository URL: https://github.com/mudrii/openfang-docs
- Assessment: unconfirmed; do not use or test any credentials.

### 2141. P3_LOW_SIGNAL — muhammadrizkyqh/curah-hujan-streamlit

- Path: `FAQ.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/muhammadrizkyqh/curah-hujan-streamlit/blob/150c18fe833588561ba6cc7c7298fa6ed66d2131/FAQ.md
- Repository URL: https://github.com/muhammadrizkyqh/curah-hujan-streamlit
- Assessment: unconfirmed; do not use or test any credentials.

### 2142. P3_LOW_SIGNAL — myhere/vim-nodejs-complete

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/myhere/vim-nodejs-complete/blob/1e2f98f4366c6dec27fa8df72971fa9fa33e9f07/README.md
- Repository URL: https://github.com/myhere/vim-nodejs-complete
- Assessment: unconfirmed; do not use or test any credentials.

### 2143. P3_LOW_SIGNAL — myinterndev/myintern

- Path: `USAGE.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/myinterndev/myintern/blob/8f7e8889f1c6b28faefcf673e0dc7da879377fe7/USAGE.md
- Repository URL: https://github.com/myinterndev/myintern
- Assessment: unconfirmed; do not use or test any credentials.

### 2144. P3_LOW_SIGNAL — mythVibe/Serial

- Path: `ssh.id_rsa`
- Indicator: `private_key_file`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/mythVibe/Serial/blob/6e62fdff3c74408a3bd3327925f446575b44ea0d/ssh.id_rsa
- Repository URL: https://github.com/mythVibe/Serial
- Assessment: unconfirmed; do not use or test any credentials.

### 2145. P3_LOW_SIGNAL — myyrakle/bellboy

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/myyrakle/bellboy/blob/c56e273245cf71b3ef88d16a27df9e4916b681a4/README.md
- Repository URL: https://github.com/myyrakle/bellboy
- Assessment: unconfirmed; do not use or test any credentials.

### 2146. P3_LOW_SIGNAL — naiasyafina/Creating-AI

- Path: `api.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/naiasyafina/Creating-AI/blob/b883479171ba337f808ab92c96d5a00623587e8e/api.md
- Repository URL: https://github.com/naiasyafina/Creating-AI
- Assessment: unconfirmed; do not use or test any credentials.

### 2147. P3_LOW_SIGNAL — namenroh/a-vibe-check

- Path: `SKILL.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/namenroh/a-vibe-check/blob/4db05ec140d53350946812c8291a795b5467fe85/SKILL.md
- Repository URL: https://github.com/namenroh/a-vibe-check
- Assessment: unconfirmed; do not use or test any credentials.

### 2148. P3_LOW_SIGNAL — namin/argument-debugger

- Path: `APP.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/namin/argument-debugger/blob/0ef29db0db4355d06c87f9cf2c240d0b1a8a99fd/APP.md
- Repository URL: https://github.com/namin/argument-debugger
- Assessment: unconfirmed; do not use or test any credentials.

### 2149. P3_LOW_SIGNAL — natesmalley/Purple-Pipeline-Parser-Eater

- Path: `TODO.md`
- Indicator: `aws_access_key;google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/natesmalley/Purple-Pipeline-Parser-Eater/blob/964e01106b6ecf8e315f600d17de8081c5429ac7/TODO.md
- Repository URL: https://github.com/natesmalley/Purple-Pipeline-Parser-Eater
- Assessment: unconfirmed; do not use or test any credentials.

### 2150. P3_LOW_SIGNAL — nazdridoy/nazutils

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/nazdridoy/nazutils/blob/1aaa7f467e98af81069104d87fb190fcad03f070/README.md
- Repository URL: https://github.com/nazdridoy/nazutils
- Assessment: unconfirmed; do not use or test any credentials.

### 2151. P3_LOW_SIGNAL — necko-moe/necko3-backend

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/necko-moe/necko3-backend/blob/600f7c6162663cef46224d467d1f8a1a8d72d512/README.md
- Repository URL: https://github.com/necko-moe/necko3-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 2152. P3_LOW_SIGNAL — neokn/claude-slack-hook

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/neokn/claude-slack-hook/blob/ffa03f1e692bca3e74a61a176de761559b910bc8/README.md
- Repository URL: https://github.com/neokn/claude-slack-hook
- Assessment: unconfirmed; do not use or test any credentials.

### 2153. P3_LOW_SIGNAL — networkengineer-cloud/go-volunteer-media

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/networkengineer-cloud/go-volunteer-media/blob/249cf127cf0ace89b1b41612b099af3009acd324/API.md
- Repository URL: https://github.com/networkengineer-cloud/go-volunteer-media
- Assessment: unconfirmed; do not use or test any credentials.

### 2154. P3_LOW_SIGNAL — neutron420/sih-swarajdesk-2025

- Path: `terraform/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/neutron420/sih-swarajdesk-2025/blob/f02f9b9ef542db77c05fd418f010aa896d5c8e62/terraform/.terraform.tfstate.lock.info
- Repository URL: https://github.com/neutron420/sih-swarajdesk-2025
- Assessment: unconfirmed; do not use or test any credentials.

### 2155. P3_LOW_SIGNAL — nextgraph-org/nextgraph-rs

- Path: `DEV.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/nextgraph-org/nextgraph-rs/blob/05cfe6c4102710b4769c267caa5bfc34df10395b/DEV.md
- Repository URL: https://github.com/nextgraph-org/nextgraph-rs
- Assessment: unconfirmed; do not use or test any credentials.

### 2156. P3_LOW_SIGNAL — nftconcerts/porsche-ads

- Path: `SETUP.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/nftconcerts/porsche-ads/blob/aff5e4b66eec598530f4fbacf672504db6b8b0c9/SETUP.md
- Repository URL: https://github.com/nftconcerts/porsche-ads
- Assessment: unconfirmed; do not use or test any credentials.

### 2157. P3_LOW_SIGNAL — ngs-docs/2022-GGG201b-lab

- Path: `hw-1.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ngs-docs/2022-GGG201b-lab/blob/c3dc3bb2c8aa69ff6acededf6e8b520d173adf5b/hw-1.md
- Repository URL: https://github.com/ngs-docs/2022-GGG201b-lab
- Assessment: unconfirmed; do not use or test any credentials.

### 2158. P3_LOW_SIGNAL — ngs-docs/2023-ggg-201b-lab

- Path: `hw-1.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ngs-docs/2023-ggg-201b-lab/blob/a9bd43e3761584ca3335514329dd7902a4fb4f3c/hw-1.md
- Repository URL: https://github.com/ngs-docs/2023-ggg-201b-lab
- Assessment: unconfirmed; do not use or test any credentials.

### 2159. P3_LOW_SIGNAL — ngusadeep/ai-agentic-system

- Path: `RUN.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ngusadeep/ai-agentic-system/blob/9db1ecb2198a3e8e4b96c235d29ac41360bd595f/RUN.md
- Repository URL: https://github.com/ngusadeep/ai-agentic-system
- Assessment: unconfirmed; do not use or test any credentials.

### 2160. P3_LOW_SIGNAL — nheijmans/cheatsheets

- Path: `ssh.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/nheijmans/cheatsheets/blob/3a4c304a3fb2778fc05a38637c0b34a6323d2e92/ssh.md
- Repository URL: https://github.com/nheijmans/cheatsheets
- Assessment: unconfirmed; do not use or test any credentials.

### 2161. P3_LOW_SIGNAL — nhsengland/open-health-statistics

- Path: `blog.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/nhsengland/open-health-statistics/blob/66121b6ba1e53e86f2db55ff7e9bc7c6136967c0/blog.md
- Repository URL: https://github.com/nhsengland/open-health-statistics
- Assessment: unconfirmed; do not use or test any credentials.

### 2162. P3_LOW_SIGNAL — nibzard/agentlab

- Path: `llms.txt`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/nibzard/agentlab/blob/1f0629e9e58915e5f7f8ec9fdcbd4c393b7db362/llms.txt
- Repository URL: https://github.com/nibzard/agentlab
- Assessment: unconfirmed; do not use or test any credentials.

### 2163. P3_LOW_SIGNAL — nickschuetz/o3de-release-notes-generator

- Path: `SECURITY.md`
- Indicator: `github_app_token_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/nickschuetz/o3de-release-notes-generator/blob/3a851ca72e32cc40ef06be8b9d96578cbd6d911c/SECURITY.md
- Repository URL: https://github.com/nickschuetz/o3de-release-notes-generator
- Assessment: unconfirmed; do not use or test any credentials.

### 2164. P3_LOW_SIGNAL — nickvasilescu/nicks-stack

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/nickvasilescu/nicks-stack/blob/90b9975c5391591e98565d20d33554a6b91f2f85/README.md
- Repository URL: https://github.com/nickvasilescu/nicks-stack
- Assessment: unconfirmed; do not use or test any credentials.

### 2165. P3_LOW_SIGNAL — niekwit/ngs-tracker

- Path: `slack.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/niekwit/ngs-tracker/blob/eaf8b2fc9a9a6b075ac18de43c96f8ee68fd70d2/slack.md
- Repository URL: https://github.com/niekwit/ngs-tracker
- Assessment: unconfirmed; do not use or test any credentials.

### 2166. P3_LOW_SIGNAL — niels-numbers/laravel-localizer

- Path: `CHANGELOG.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/niels-numbers/laravel-localizer/blob/a5dc43b6d926b18b6c37c2fc935f936b4f210938/CHANGELOG.md
- Repository URL: https://github.com/niels-numbers/laravel-localizer
- Assessment: unconfirmed; do not use or test any credentials.

### 2167. P3_LOW_SIGNAL — nifetency/nife-litellm

- Path: `INDEX.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/nifetency/nife-litellm/blob/5296338784183cc0fcc28e15e62fa451973195f7/INDEX.md
- Repository URL: https://github.com/nifetency/nife-litellm
- Assessment: unconfirmed; do not use or test any credentials.

### 2168. P3_LOW_SIGNAL — nikhilbadyal/bitwarden-backup

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/nikhilbadyal/bitwarden-backup/blob/e0979b549be860677527e8e0f708c3ee5043032a/API.md
- Repository URL: https://github.com/nikhilbadyal/bitwarden-backup
- Assessment: unconfirmed; do not use or test any credentials.

### 2169. P3_LOW_SIGNAL — nikolaymatrosov/yc-alb-websocket

- Path: `terraform/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/nikolaymatrosov/yc-alb-websocket/blob/715e3b8799535ec07559b625caa24ddac594e315/terraform/.terraform.tfstate.lock.info
- Repository URL: https://github.com/nikolaymatrosov/yc-alb-websocket
- Assessment: unconfirmed; do not use or test any credentials.

### 2170. P3_LOW_SIGNAL — nikrich/hungry-ghost-hive

- Path: `SPEC.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/nikrich/hungry-ghost-hive/blob/5444b88c088a58f5ba81fcd1206ea45f4d28d8b7/SPEC.md
- Repository URL: https://github.com/nikrich/hungry-ghost-hive
- Assessment: unconfirmed; do not use or test any credentials.

### 2171. P3_LOW_SIGNAL — ninaframpton/multiagent

- Path: `TASK.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ninaframpton/multiagent/blob/2305827ca63c38085c400d0f7cc473a046137207/TASK.md
- Repository URL: https://github.com/ninaframpton/multiagent
- Assessment: unconfirmed; do not use or test any credentials.

### 2172. P3_LOW_SIGNAL — nirholas/solana-wallet-toolkit

- Path: `llms.txt`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/nirholas/solana-wallet-toolkit/blob/b8ef3b361cab9650257cfea5eaa1f49764db5446/llms.txt
- Repository URL: https://github.com/nirholas/solana-wallet-toolkit
- Assessment: unconfirmed; do not use or test any credentials.

### 2173. P3_LOW_SIGNAL — nitram509/jmacaroons

- Path: `README.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/nitram509/jmacaroons/blob/c56037b3d6e5869c1772c0d09715f0264079fee4/README.md
- Repository URL: https://github.com/nitram509/jmacaroons
- Assessment: unconfirmed; do not use or test any credentials.

### 2174. P3_LOW_SIGNAL — no-session/pstack

- Path: `cso/SKILL.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/no-session/pstack/blob/9a24d1408a10a5d0df624ffc128230424e405b82/cso/SKILL.md
- Repository URL: https://github.com/no-session/pstack
- Assessment: unconfirmed; do not use or test any credentials.

### 2175. P3_LOW_SIGNAL — nodeseeker/goImage

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/nodeseeker/goImage/blob/1c82e8aedd99a582e52283345ab50105dbbe3fc9/API.md
- Repository URL: https://github.com/nodeseeker/goImage
- Assessment: unconfirmed; do not use or test any credentials.

### 2176. P3_LOW_SIGNAL — noironetworks/ovs-geneve

- Path: `NEWS`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/noironetworks/ovs-geneve/blob/ee58e94e307510ff6e133b065de430466d425c96/NEWS
- Repository URL: https://github.com/noironetworks/ovs-geneve
- Assessment: unconfirmed; do not use or test any credentials.

### 2177. P3_LOW_SIGNAL — noktafa/sysadmin-ai

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/noktafa/sysadmin-ai/blob/18f25a290dbb52e3d3e79555f6b3672b203aac24/README.md
- Repository URL: https://github.com/noktafa/sysadmin-ai
- Assessment: unconfirmed; do not use or test any credentials.

### 2178. P3_LOW_SIGNAL — nopcorn/tokenrush

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/nopcorn/tokenrush/blob/88d4a9b1dfabf30a46e51f5c69b495d8f4a12389/README.md
- Repository URL: https://github.com/nopcorn/tokenrush
- Assessment: unconfirmed; do not use or test any credentials.

### 2179. P3_LOW_SIGNAL — nostr-jp/nips-ja

- Path: `44.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/nostr-jp/nips-ja/blob/c81f2a484f7f0af80b0bfd0ac85487eb726d00fa/44.md
- Repository URL: https://github.com/nostr-jp/nips-ja
- Assessment: unconfirmed; do not use or test any credentials.

### 2180. P3_LOW_SIGNAL — nostr-jp/nips-ja

- Path: `49.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/nostr-jp/nips-ja/blob/c81f2a484f7f0af80b0bfd0ac85487eb726d00fa/49.md
- Repository URL: https://github.com/nostr-jp/nips-ja
- Assessment: unconfirmed; do not use or test any credentials.

### 2181. P3_LOW_SIGNAL — notamperdata/notamperdata-dapp

- Path: `.rest`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/notamperdata/notamperdata-dapp/blob/2ce5b5ed5a8fddeae8724c5d26635f4675d262e9/.rest
- Repository URL: https://github.com/notamperdata/notamperdata-dapp
- Assessment: unconfirmed; do not use or test any credentials.

### 2182. P3_LOW_SIGNAL — nrkno/yr-weather-symbols

- Path: `BUILD.MD`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/nrkno/yr-weather-symbols/blob/34039b509167ba1701f1729df5cc95488813dd5f/BUILD.MD
- Repository URL: https://github.com/nrkno/yr-weather-symbols
- Assessment: unconfirmed; do not use or test any credentials.

### 2183. P3_LOW_SIGNAL — ntharish13/gitdemo

- Path: `git.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ntharish13/gitdemo/blob/30f73d03c1b4166384e90747b7232d7e1348b0a0/git.md
- Repository URL: https://github.com/ntharish13/gitdemo
- Assessment: unconfirmed; do not use or test any credentials.

### 2184. P3_LOW_SIGNAL — ntxinh/AspNetCore-DDD

- Path: `api.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ntxinh/AspNetCore-DDD/blob/29ca85df639ccd37b11e4a649340f22852aac9df/api.md
- Repository URL: https://github.com/ntxinh/AspNetCore-DDD
- Assessment: unconfirmed; do not use or test any credentials.

### 2185. P3_LOW_SIGNAL — nuggetenak/nugget-nihongo

- Path: `SETUP.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/nuggetenak/nugget-nihongo/blob/6c2909cb3e0d49f9959b173af4090aebcfe5f5bb/SETUP.md
- Repository URL: https://github.com/nuggetenak/nugget-nihongo
- Assessment: unconfirmed; do not use or test any credentials.

### 2186. P3_LOW_SIGNAL — nullfuzz-pentest/regex-list

- Path: `readme.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/nullfuzz-pentest/regex-list/blob/7ad7d1d0d58f8f58f257be0ccac5b6f7cc2584e8/readme.md
- Repository URL: https://github.com/nullfuzz-pentest/regex-list
- Assessment: unconfirmed; do not use or test any credentials.

### 2187. P3_LOW_SIGNAL — occludra/gateway

- Path: `README.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/occludra/gateway/blob/e948e230d78f83852c5662d312ed846c32520c17/README.md
- Repository URL: https://github.com/occludra/gateway
- Assessment: unconfirmed; do not use or test any credentials.

### 2188. P3_LOW_SIGNAL — octodemo/copilot-license

- Path: `DOCS.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/octodemo/copilot-license/blob/29cd153b222b984a81ab634ced46f8df0e83f922/DOCS.md
- Repository URL: https://github.com/octodemo/copilot-license
- Assessment: unconfirmed; do not use or test any credentials.

### 2189. P3_LOW_SIGNAL — octokit/auth-token.js

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/octokit/auth-token.js/blob/7265e62635a91994d35e5be6897dd94bf935a81b/README.md
- Repository URL: https://github.com/octokit/auth-token.js
- Assessment: unconfirmed; do not use or test any credentials.

### 2190. P3_LOW_SIGNAL — odin-labs-ai/ai-security-audit-prompts

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/odin-labs-ai/ai-security-audit-prompts/blob/2b59b32b8d4113123372cb86551372821bffce02/README.md
- Repository URL: https://github.com/odin-labs-ai/ai-security-audit-prompts
- Assessment: unconfirmed; do not use or test any credentials.

### 2191. P3_LOW_SIGNAL — odomojuli/regextokens

- Path: `CLAUDE.md`
- Indicator: `github_oauth_prefix;github_app_token_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/odomojuli/regextokens/blob/1c80404e0bda64485fd2d14568f7b211e404c33c/CLAUDE.md
- Repository URL: https://github.com/odomojuli/regextokens
- Assessment: unconfirmed; do not use or test any credentials.

### 2192. P3_LOW_SIGNAL — odomojuli/regextokens

- Path: `SHIPPING.md`
- Indicator: `github_oauth_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/odomojuli/regextokens/blob/1c80404e0bda64485fd2d14568f7b211e404c33c/SHIPPING.md
- Repository URL: https://github.com/odomojuli/regextokens
- Assessment: unconfirmed; do not use or test any credentials.

### 2193. P3_LOW_SIGNAL — okandemirel/Strada.MCP

- Path: `SECURITY.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/okandemirel/Strada.MCP/blob/34cd4b21b32548acc9e663d361b5e624792707b3/SECURITY.md
- Repository URL: https://github.com/okandemirel/Strada.MCP
- Assessment: unconfirmed; do not use or test any credentials.

### 2194. P3_LOW_SIGNAL — olucasandrade/github-live-notifications

- Path: `SECURITY.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/olucasandrade/github-live-notifications/blob/5673c7e09d9275669888d1af693c5e94c2af758c/SECURITY.md
- Repository URL: https://github.com/olucasandrade/github-live-notifications
- Assessment: unconfirmed; do not use or test any credentials.

### 2195. P3_LOW_SIGNAL — omarabid59/Bitcoin_LBTC_Trading

- Path: `KEYS.txt`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/omarabid59/Bitcoin_LBTC_Trading/blob/48c59cef74a48c9f47c916d7df035957ef1ea9ac/KEYS.txt
- Repository URL: https://github.com/omarabid59/Bitcoin_LBTC_Trading
- Assessment: unconfirmed; do not use or test any credentials.

### 2196. P3_LOW_SIGNAL — oneminch/notes

- Path: `NPM.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/oneminch/notes/blob/f057cb13bf2a0d369cae228898292045c60329c0/NPM.md
- Repository URL: https://github.com/oneminch/notes
- Assessment: unconfirmed; do not use or test any credentials.

### 2197. P3_LOW_SIGNAL — open-constructs/projen-pipelines

- Path: `llm.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/open-constructs/projen-pipelines/blob/2261183919551f21f034fa7756543e787d5661b7/llm.md
- Repository URL: https://github.com/open-constructs/projen-pipelines
- Assessment: unconfirmed; do not use or test any credentials.

### 2198. P3_LOW_SIGNAL — open-feature/dotnet-sdk-contrib

- Path: `CONTRIBUTING.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/open-feature/dotnet-sdk-contrib/blob/bba127f946e928bad7e1646552b5f992801019f5/CONTRIBUTING.md
- Repository URL: https://github.com/open-feature/dotnet-sdk-contrib
- Assessment: unconfirmed; do not use or test any credentials.

### 2199. P3_LOW_SIGNAL — open-gitagent/ComputerAgent

- Path: `docs.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/open-gitagent/ComputerAgent/blob/70d3323c47c086423d612e1c920b72d56076eed0/docs.md
- Repository URL: https://github.com/open-gitagent/ComputerAgent
- Assessment: unconfirmed; do not use or test any credentials.

### 2200. P3_LOW_SIGNAL — openjobs-hq/openjobs

- Path: `SDK.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/openjobs-hq/openjobs/blob/24030b7080d1a96678ff3550544408b1595d4ab7/SDK.md
- Repository URL: https://github.com/openjobs-hq/openjobs
- Assessment: unconfirmed; do not use or test any credentials.

### 2201. P3_LOW_SIGNAL — openoms/joininbox

- Path: `FAQ.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/openoms/joininbox/blob/3115bd91af8b39a40c75009163ef2e1424020e95/FAQ.md
- Repository URL: https://github.com/openoms/joininbox
- Assessment: unconfirmed; do not use or test any credentials.

### 2202. P3_LOW_SIGNAL — operatorequals/httpimport

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/operatorequals/httpimport/blob/9ce1a85cedf6deff97a51c44912f8f37c5b7cc3f/README.md
- Repository URL: https://github.com/operatorequals/httpimport
- Assessment: unconfirmed; do not use or test any credentials.

### 2203. P3_LOW_SIGNAL — opsstation/terraform-azure-log-analytics

- Path: `_example/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/opsstation/terraform-azure-log-analytics/blob/baa3b4fd321379092410f46d0654c117ff3bad1f/_example/.terraform.tfstate.lock.info
- Repository URL: https://github.com/opsstation/terraform-azure-log-analytics
- Assessment: unconfirmed; do not use or test any credentials.

### 2204. P3_LOW_SIGNAL — os-chip-design/chip-design-intro

- Path: `FAQ.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/os-chip-design/chip-design-intro/blob/15ff32b0bc3f2e05fb195b9b95bbf6709df14157/FAQ.md
- Repository URL: https://github.com/os-chip-design/chip-design-intro
- Assessment: unconfirmed; do not use or test any credentials.

### 2205. P3_LOW_SIGNAL — osbuild/koji-osbuild

- Path: `README.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/osbuild/koji-osbuild/blob/e6a99468af5f3f1e4e3ac650667f8aba5b18c8c4/README.md
- Repository URL: https://github.com/osbuild/koji-osbuild
- Assessment: unconfirmed; do not use or test any credentials.

### 2206. P3_LOW_SIGNAL — osinstom/P4-OvS

- Path: `NEWS`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/osinstom/P4-OvS/blob/6d3a6db64c050c935d33cd747450ad5c8181fee0/NEWS
- Repository URL: https://github.com/osinstom/P4-OvS
- Assessment: unconfirmed; do not use or test any credentials.

### 2207. P3_LOW_SIGNAL — osintbrazuca/osint-brazuca-regex

- Path: `README.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/osintbrazuca/osint-brazuca-regex/blob/5ec05893330bc90314796787bbf17a97301f9404/README.md
- Repository URL: https://github.com/osintbrazuca/osint-brazuca-regex
- Assessment: unconfirmed; do not use or test any credentials.

### 2208. P3_LOW_SIGNAL — overgrowncarrot1/Scripts

- Path: `find_id_rsa_keys.txt`
- Indicator: `private_key_file`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/overgrowncarrot1/Scripts/blob/7588afaa1cd713aac416a29bf3b7dd8f6a12e239/find_id_rsa_keys.txt
- Repository URL: https://github.com/overgrowncarrot1/Scripts
- Assessment: unconfirmed; do not use or test any credentials.

### 2209. P3_LOW_SIGNAL — oxsecurity/bank-connector

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/oxsecurity/bank-connector/blob/380337cd86b7a2c043f66cabe628cc2aa24e2f53/README.md
- Repository URL: https://github.com/oxsecurity/bank-connector
- Assessment: unconfirmed; do not use or test any credentials.

### 2210. P3_LOW_SIGNAL — painted-porch/marcus

- Path: `CLI.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/painted-porch/marcus/blob/a95eb4e9134b1d5c163d2add0a539d80320d3388/CLI.md
- Repository URL: https://github.com/painted-porch/marcus
- Assessment: unconfirmed; do not use or test any credentials.

### 2211. P3_LOW_SIGNAL — pass-culture/pass-culture-app-native

- Path: `ACT.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/pass-culture/pass-culture-app-native/blob/b163e545f5b9b32cba2b7bf98d4da7498f91b6d3/ACT.md
- Repository URL: https://github.com/pass-culture/pass-culture-app-native
- Assessment: unconfirmed; do not use or test any credentials.

### 2212. P3_LOW_SIGNAL — patrickverol/API-Property-Price-Prediction-Tool

- Path: `IaC/iac_deploy/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/patrickverol/API-Property-Price-Prediction-Tool/blob/5541cb652e42b9a94acb7799e3741ac38ba90a62/IaC/iac_deploy/.terraform.tfstate.lock.info
- Repository URL: https://github.com/patrickverol/API-Property-Price-Prediction-Tool
- Assessment: unconfirmed; do not use or test any credentials.

### 2213. P3_LOW_SIGNAL — paulovictorarmando/fastAPI_training

- Path: `p.txt`
- Indicator: `access_token_label;bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/paulovictorarmando/fastAPI_training/blob/af5ae250ca310e4706593b8b1691b0b15c59d062/p.txt
- Repository URL: https://github.com/paulovictorarmando/fastAPI_training
- Assessment: unconfirmed; do not use or test any credentials.

### 2214. P3_LOW_SIGNAL — paulrobello/par_ai_core

- Path: `AUDIT.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/paulrobello/par_ai_core/blob/afbe78eeb0fa0beb652e886018fa8f2085b3bc6d/AUDIT.md
- Repository URL: https://github.com/paulrobello/par_ai_core
- Assessment: unconfirmed; do not use or test any credentials.

### 2215. P3_LOW_SIGNAL — paytience/FindAPIs

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/paytience/FindAPIs/blob/84dddfed7cc97cefc7f4afa9bda769d7b4c41bc7/API.md
- Repository URL: https://github.com/paytience/FindAPIs
- Assessment: unconfirmed; do not use or test any credentials.

### 2216. P3_LOW_SIGNAL — pcc-labs/openclaw-in-a-box

- Path: `SKILL.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/pcc-labs/openclaw-in-a-box/blob/f57ad76ba9d3341540725194b73b2634984ed56d/SKILL.md
- Repository URL: https://github.com/pcc-labs/openclaw-in-a-box
- Assessment: unconfirmed; do not use or test any credentials.

### 2217. P3_LOW_SIGNAL — pdarleyjr/iplc-ai

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/pdarleyjr/iplc-ai/blob/ada5ba682cd9f939b3ff51422ff4090d4679eac7/README.md
- Repository URL: https://github.com/pdarleyjr/iplc-ai
- Assessment: unconfirmed; do not use or test any credentials.

### 2218. P3_LOW_SIGNAL — peaceorwell/pytorch_issue_digest

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/peaceorwell/pytorch_issue_digest/blob/8181d067af586d3a74046cd022064361f3ee85b1/README.md
- Repository URL: https://github.com/peaceorwell/pytorch_issue_digest
- Assessment: unconfirmed; do not use or test any credentials.

### 2219. P3_LOW_SIGNAL — pedrogao/lin-cms-java

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/pedrogao/lin-cms-java/blob/79aa4f58c9cec9da471f44b4f316767d067f1fb0/API.md
- Repository URL: https://github.com/pedrogao/lin-cms-java
- Assessment: unconfirmed; do not use or test any credentials.

### 2220. P3_LOW_SIGNAL — personium/app-slack-messenger

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/personium/app-slack-messenger/blob/fe3783cd88622b57c67e22579624c016ce001a51/README.md
- Repository URL: https://github.com/personium/app-slack-messenger
- Assessment: unconfirmed; do not use or test any credentials.

### 2221. P3_LOW_SIGNAL — petipoua/petiglyph

- Path: `CI.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/petipoua/petiglyph/blob/e8cc5e77e67829c950ab5879b666f920ece63974/CI.md
- Repository URL: https://github.com/petipoua/petiglyph
- Assessment: unconfirmed; do not use or test any credentials.

### 2222. P3_LOW_SIGNAL — pgr301-2019/labguide

- Path: `lab9.md`
- Indicator: `secret_access_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/pgr301-2019/labguide/blob/b025ccf23d7ec2e7cad2a93784b0a6f92d353165/lab9.md
- Repository URL: https://github.com/pgr301-2019/labguide
- Assessment: unconfirmed; do not use or test any credentials.

### 2223. P3_LOW_SIGNAL — philippelt/netatmo-api-python

- Path: `usage.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/philippelt/netatmo-api-python/blob/1d87aac44a3afeb2c22b8581b5049e19a902ce0e/usage.md
- Repository URL: https://github.com/philippelt/netatmo-api-python
- Assessment: unconfirmed; do not use or test any credentials.

### 2224. P3_LOW_SIGNAL — phpbrew/Onion

- Path: `TODO.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/phpbrew/Onion/blob/47db20c440206d266d7292c5657e6c4c3820bfb6/TODO.md
- Repository URL: https://github.com/phpbrew/Onion
- Assessment: unconfirmed; do not use or test any credentials.

### 2225. P3_LOW_SIGNAL — phrocker/sharkbite-site

- Path: `C++.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/phrocker/sharkbite-site/blob/e8d62d580bf7a9777fb530f16f546879fb74d03d/C++.md
- Repository URL: https://github.com/phrocker/sharkbite-site
- Assessment: unconfirmed; do not use or test any credentials.

### 2226. P3_LOW_SIGNAL — pietroborrello/CustomProcessingUnit

- Path: `Notes.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/pietroborrello/CustomProcessingUnit/blob/4237524fe7545c66e42dd986113f220662c06f6a/Notes.md
- Repository URL: https://github.com/pietroborrello/CustomProcessingUnit
- Assessment: unconfirmed; do not use or test any credentials.

### 2227. P3_LOW_SIGNAL — pijerotechnologies/pijero-time

- Path: `readme.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/pijerotechnologies/pijero-time/blob/4b89e59f9c88091352eecf7b6d2c5481df7bbbef/readme.md
- Repository URL: https://github.com/pijerotechnologies/pijero-time
- Assessment: unconfirmed; do not use or test any credentials.

### 2228. P3_LOW_SIGNAL — pipelinear/trade-notifier

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/pipelinear/trade-notifier/blob/34cee6d4f7e96c9b3e003d1d2e6363cc747322c5/README.md
- Repository URL: https://github.com/pipelinear/trade-notifier
- Assessment: unconfirmed; do not use or test any credentials.

### 2229. P3_LOW_SIGNAL — piyushagarwal08/JU-Notes

- Path: `RPA.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/piyushagarwal08/JU-Notes/blob/ef79adf501fb19e6796bc39981b7fac99f27d93f/RPA.md
- Repository URL: https://github.com/piyushagarwal08/JU-Notes
- Assessment: unconfirmed; do not use or test any credentials.

### 2230. P3_LOW_SIGNAL — pjungwir/manpj

- Path: `aws.md`
- Indicator: `secret_access_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/pjungwir/manpj/blob/4383f1d997146ba0cefda7ec2645da2f57729732/aws.md
- Repository URL: https://github.com/pjungwir/manpj
- Assessment: unconfirmed; do not use or test any credentials.

### 2231. P3_LOW_SIGNAL — pkumar26/demok8s

- Path: `kv.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/pkumar26/demok8s/blob/d42441c596c00f650aea614f0abf3d2a9a4dcc06/kv.md
- Repository URL: https://github.com/pkumar26/demok8s
- Assessment: unconfirmed; do not use or test any credentials.

### 2232. P3_LOW_SIGNAL — planetfederal/spatialconnect-js

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/planetfederal/spatialconnect-js/blob/8e7672c07a5fe913c9b15ff5344f0d0be2830973/API.md
- Repository URL: https://github.com/planetfederal/spatialconnect-js
- Assessment: unconfirmed; do not use or test any credentials.

### 2233. P3_LOW_SIGNAL — platanus/dialers

- Path: `NOTES.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/platanus/dialers/blob/8fd8750c367ec0d058d2adfe25915125d95cb890/NOTES.md
- Repository URL: https://github.com/platanus/dialers
- Assessment: unconfirmed; do not use or test any credentials.

### 2234. P3_LOW_SIGNAL — plengauer/Thoth

- Path: `FORK.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/plengauer/Thoth/blob/5bf7a148fb7111898ec62669806cef5611616864/FORK.md
- Repository URL: https://github.com/plengauer/Thoth
- Assessment: unconfirmed; do not use or test any credentials.

### 2235. P3_LOW_SIGNAL — pmoisontech/Alex-MCP-Proxy

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/pmoisontech/Alex-MCP-Proxy/blob/d7819656255b094e64abe6a34e0315d3e591b410/README.md
- Repository URL: https://github.com/pmoisontech/Alex-MCP-Proxy
- Assessment: unconfirmed; do not use or test any credentials.

### 2236. P3_LOW_SIGNAL — poler-engine-org/poler-os

- Path: `AGENT.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/poler-engine-org/poler-os/blob/d00d3c5c929180500865d9da7d3f3f8069ac2cac/AGENT.md
- Repository URL: https://github.com/poler-engine-org/poler-os
- Assessment: unconfirmed; do not use or test any credentials.

### 2237. P3_LOW_SIGNAL — pradelgorithm/openaura

- Path: `PYPI.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/pradelgorithm/openaura/blob/2aa5a92c8a17938ad6cb676d9e7e1c87e779d693/PYPI.md
- Repository URL: https://github.com/pradelgorithm/openaura
- Assessment: unconfirmed; do not use or test any credentials.

### 2238. P3_LOW_SIGNAL — presidentbeef/github-reminder

- Path: `lib/mail.rb`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/presidentbeef/github-reminder/blob/63e7a85ae585ab4ee3b21739c59fd09e91266edd/lib/mail.rb
- Repository URL: https://github.com/presidentbeef/github-reminder
- Assessment: unconfirmed; do not use or test any credentials.

### 2239. P3_LOW_SIGNAL — prime-radiant-inc/slackline

- Path: `ABOUT.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/prime-radiant-inc/slackline/blob/816217ffabc22091c4a673c6e4ee6a1d21503ff7/ABOUT.md
- Repository URL: https://github.com/prime-radiant-inc/slackline
- Assessment: unconfirmed; do not use or test any credentials.

### 2240. P3_LOW_SIGNAL — prithvi471/opensoirceor

- Path: `TRUST.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/prithvi471/opensoirceor/blob/5508c02444a416340bb77f1dde07ad0b63365fde/TRUST.md
- Repository URL: https://github.com/prithvi471/opensoirceor
- Assessment: unconfirmed; do not use or test any credentials.

### 2241. P3_LOW_SIGNAL — privapps/github-copilot-svcs

- Path: `README.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/privapps/github-copilot-svcs/blob/cb1ef25a4c854afd27b755f1a8b1e39c7404d39a/README.md
- Repository URL: https://github.com/privapps/github-copilot-svcs
- Assessment: unconfirmed; do not use or test any credentials.

### 2242. P3_LOW_SIGNAL — procload/dnd-mcp

- Path: `mcp.md`
- Indicator: `api_key_label;access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/procload/dnd-mcp/blob/97c4cc74b6fc2c8a155c7f6757ec735ea8e9a5c9/mcp.md
- Repository URL: https://github.com/procload/dnd-mcp
- Assessment: unconfirmed; do not use or test any credentials.

### 2243. P3_LOW_SIGNAL — progrmoiz/stripe-pulse

- Path: `SKILL.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/progrmoiz/stripe-pulse/blob/f7c92aed5c1e3d5af818bf100898b72718dc356d/SKILL.md
- Repository URL: https://github.com/progrmoiz/stripe-pulse
- Assessment: unconfirmed; do not use or test any credentials.

### 2244. P3_LOW_SIGNAL — projectarkc/psiphon

- Path: `INSTALL`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/projectarkc/psiphon/blob/df91a52bad7408ef96117f21b066b64350e1c74c/INSTALL
- Repository URL: https://github.com/projectarkc/psiphon
- Assessment: unconfirmed; do not use or test any credentials.

### 2245. P3_LOW_SIGNAL — projen/projen-github-action-typescript

- Path: `API.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/projen/projen-github-action-typescript/blob/7117d19833c70f3be0c6832f2318fb6a644a6b1f/API.md
- Repository URL: https://github.com/projen/projen-github-action-typescript
- Assessment: unconfirmed; do not use or test any credentials.

### 2246. P3_LOW_SIGNAL — proofofexistence/docs

- Path: `faq.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/proofofexistence/docs/blob/57a4104e071cef84256e921d88cc23eb8a0f970e/faq.md
- Repository URL: https://github.com/proofofexistence/docs
- Assessment: unconfirmed; do not use or test any credentials.

### 2247. P3_LOW_SIGNAL — protocyber/opencode-switcher

- Path: `README.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/protocyber/opencode-switcher/blob/0e4b72983a3d20b8b0b4004388b0b100d7c1459f/README.md
- Repository URL: https://github.com/protocyber/opencode-switcher
- Assessment: unconfirmed; do not use or test any credentials.

### 2248. P3_LOW_SIGNAL — psigen/ace

- Path: `NEWS`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/psigen/ace/blob/2845970c894bb350d12d6a32e867d7ddf2487f25/NEWS
- Repository URL: https://github.com/psigen/ace
- Assessment: unconfirmed; do not use or test any credentials.

### 2249. P3_LOW_SIGNAL — punitagrawal/libhugetlbfs

- Path: `alloc.c`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/punitagrawal/libhugetlbfs/blob/343fd6d264f003961ceeef49a8598daf9cc78f24/alloc.c
- Repository URL: https://github.com/punitagrawal/libhugetlbfs
- Assessment: unconfirmed; do not use or test any credentials.

### 2250. P3_LOW_SIGNAL — pypi-ahmad/computer-use

- Path: `USAGE.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/pypi-ahmad/computer-use/blob/b79d02c821e65a4a2d4ddf8bf06eaebc16867005/USAGE.md
- Repository URL: https://github.com/pypi-ahmad/computer-use
- Assessment: unconfirmed; do not use or test any credentials.

### 2251. P3_LOW_SIGNAL — qiniu/openacc

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/qiniu/openacc/blob/f534c0594cb67b80b388cc390fac85cb6c0785fc/API.md
- Repository URL: https://github.com/qiniu/openacc
- Assessment: unconfirmed; do not use or test any credentials.

### 2252. P3_LOW_SIGNAL — qoomon/actions--create-commit

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/qoomon/actions--create-commit/blob/c63b284c04aa45c778d7093a192d5f49332f3c89/README.md
- Repository URL: https://github.com/qoomon/actions--create-commit
- Assessment: unconfirmed; do not use or test any credentials.

### 2253. P3_LOW_SIGNAL — qoomon/actions--create-tag

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/qoomon/actions--create-tag/blob/1c81c15eb223eff410f655b5ac0b08fef35beef9/README.md
- Repository URL: https://github.com/qoomon/actions--create-tag
- Assessment: unconfirmed; do not use or test any credentials.

### 2254. P3_LOW_SIGNAL — quangdangtranvn/petgen

- Path: `nft.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/quangdangtranvn/petgen/blob/da258ff540ee3783b616a66754d5ec88090fb69a/nft.md
- Repository URL: https://github.com/quangdangtranvn/petgen
- Assessment: unconfirmed; do not use or test any credentials.

### 2255. P3_LOW_SIGNAL — quantum-melbourne/qiskit-challenge-22

- Path: `faq.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/quantum-melbourne/qiskit-challenge-22/blob/041662087ba9b3a718a112ac61c0407024697098/faq.md
- Repository URL: https://github.com/quantum-melbourne/qiskit-challenge-22
- Assessment: unconfirmed; do not use or test any credentials.

### 2256. P3_LOW_SIGNAL — r-lib/gh

- Path: `NEWS.md`
- Indicator: `github_pat_prefix;github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/r-lib/gh/blob/0f213cc266882b2a92c7e8380455743436479033/NEWS.md
- Repository URL: https://github.com/r-lib/gh
- Assessment: unconfirmed; do not use or test any credentials.

### 2257. P3_LOW_SIGNAL — r-lib/whoami

- Path: `NEWS.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/r-lib/whoami/blob/2deb67c21d84ed6ff141967cbfc303658cbdf98e/NEWS.md
- Repository URL: https://github.com/r-lib/whoami
- Assessment: unconfirmed; do not use or test any credentials.

### 2258. P3_LOW_SIGNAL — r1cksync/meta-rl-hack

- Path: `ENV.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/r1cksync/meta-rl-hack/blob/062d28a3be0a6232f9139f9d1da1013d720e4f2d/ENV.md
- Repository URL: https://github.com/r1cksync/meta-rl-hack
- Assessment: unconfirmed; do not use or test any credentials.

### 2259. P3_LOW_SIGNAL — rahgozar94725/MTProto-Checker

- Path: `SPEC.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rahgozar94725/MTProto-Checker/blob/3b6c7faa82a2e7508f73de3403a14adb2552a4b1/SPEC.md
- Repository URL: https://github.com/rahgozar94725/MTProto-Checker
- Assessment: unconfirmed; do not use or test any credentials.

### 2260. P3_LOW_SIGNAL — raimohan/utilitytg

- Path: `API.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/raimohan/utilitytg/blob/b95e487085e2de7bd528e567e84fbcbd65112d46/API.md
- Repository URL: https://github.com/raimohan/utilitytg
- Assessment: unconfirmed; do not use or test any credentials.

### 2261. P3_LOW_SIGNAL — rainbowprotocol-xyz/rbo_indexer_testnet

- Path: `FAQ.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rainbowprotocol-xyz/rbo_indexer_testnet/blob/2bfabc7e056ba866fa76df0abc4b548a9f9e0147/FAQ.md
- Repository URL: https://github.com/rainbowprotocol-xyz/rbo_indexer_testnet
- Assessment: unconfirmed; do not use or test any credentials.

### 2262. P3_LOW_SIGNAL — raj921/vulngate

- Path: `PR.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/raj921/vulngate/blob/5e897c2890d4a8466340f4c2c1c7150e86dc2b1e/PR.md
- Repository URL: https://github.com/raj921/vulngate
- Assessment: unconfirmed; do not use or test any credentials.

### 2263. P3_LOW_SIGNAL — raja-jamwal/compass

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/raja-jamwal/compass/blob/1513271c4505ca66e36e9524f300bf736a62246f/README.md
- Repository URL: https://github.com/raja-jamwal/compass
- Assessment: unconfirmed; do not use or test any credentials.

### 2264. P3_LOW_SIGNAL — rajank18/envguard

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rajank18/envguard/blob/eddd8c6f7a4cea5772a25a454fdb4787d6733033/README.md
- Repository URL: https://github.com/rajank18/envguard
- Assessment: unconfirmed; do not use or test any credentials.

### 2265. P3_LOW_SIGNAL — rajasoun/dev-containers

- Path: `SLS.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rajasoun/dev-containers/blob/5ffd3bef4ba42a0afe5fffa210a9843d8120d11c/SLS.md
- Repository URL: https://github.com/rajasoun/dev-containers
- Assessment: unconfirmed; do not use or test any credentials.

### 2266. P3_LOW_SIGNAL — rajdesai17/a0

- Path: `v2.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rajdesai17/a0/blob/a07b2fc5754ec4ad2add6dab4eed27a7d8dc31c6/v2.md
- Repository URL: https://github.com/rajdesai17/a0
- Assessment: unconfirmed; do not use or test any credentials.

### 2267. P3_LOW_SIGNAL — rajeev-chaurasia/leak-proof

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rajeev-chaurasia/leak-proof/blob/d6420a0b8c18cad20c2902021dfaad18f1d48659/README.md
- Repository URL: https://github.com/rajeev-chaurasia/leak-proof
- Assessment: unconfirmed; do not use or test any credentials.

### 2268. P3_LOW_SIGNAL — rajeshkanaka/sdg-skill

- Path: `TASKS.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rajeshkanaka/sdg-skill/blob/3ef0d725ec513d99a05bc44e257efe3adf947b9c/TASKS.md
- Repository URL: https://github.com/rajeshkanaka/sdg-skill
- Assessment: unconfirmed; do not use or test any credentials.

### 2269. P3_LOW_SIGNAL — random1st/secguard

- Path: `README.md`
- Indicator: `github_pat_prefix;stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/random1st/secguard/blob/424b812f075b178792bdffd92a0492378461e01d/README.md
- Repository URL: https://github.com/random1st/secguard
- Assessment: unconfirmed; do not use or test any credentials.

### 2270. P3_LOW_SIGNAL — rattinas/OpenWhispr

- Path: `TODO.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rattinas/OpenWhispr/blob/69d7e21fad1d04b37d81b7d1478cffa67d34a2c6/TODO.md
- Repository URL: https://github.com/rattinas/OpenWhispr
- Assessment: unconfirmed; do not use or test any credentials.

### 2271. P3_LOW_SIGNAL — raxe-ai/raxe-ce

- Path: `FAQ.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/raxe-ai/raxe-ce/blob/f5b4b7054385c4f3e1c30551886b16c8b47d4687/FAQ.md
- Repository URL: https://github.com/raxe-ai/raxe-ce
- Assessment: unconfirmed; do not use or test any credentials.

### 2272. P3_LOW_SIGNAL — rcanzlovar/howto

- Path: `obs.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rcanzlovar/howto/blob/c7d7e011fbf100ba49bb8646c26f51613b5d7832/obs.md
- Repository URL: https://github.com/rcanzlovar/howto
- Assessment: unconfirmed; do not use or test any credentials.

### 2273. P3_LOW_SIGNAL — rconn-cyber/roughriders-golf

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rconn-cyber/roughriders-golf/blob/47753d8781248f8546c033490c09d9ea1eac707c/README.md
- Repository URL: https://github.com/rconn-cyber/roughriders-golf
- Assessment: unconfirmed; do not use or test any credentials.

### 2274. P3_LOW_SIGNAL — rdsthomas/mission-control

- Path: `SKILL.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rdsthomas/mission-control/blob/ed462055763fb272a0acb792ebeb80a52e1bcf18/SKILL.md
- Repository URL: https://github.com/rdsthomas/mission-control
- Assessment: unconfirmed; do not use or test any credentials.

### 2275. P3_LOW_SIGNAL — reaandrew/gg-lambda-extensions-example

- Path: `BLOG.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/reaandrew/gg-lambda-extensions-example/blob/24953c61119bdcd7ea408707735c37fe7e98c8fe/BLOG.md
- Repository URL: https://github.com/reaandrew/gg-lambda-extensions-example
- Assessment: unconfirmed; do not use or test any credentials.

### 2276. P3_LOW_SIGNAL — react18-tools/turborepo-template

- Path: `TODO.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/react18-tools/turborepo-template/blob/8b35ac1df594c54ac263bd3179dc5663a1383d09/TODO.md
- Repository URL: https://github.com/react18-tools/turborepo-template
- Assessment: unconfirmed; do not use or test any credentials.

### 2277. P3_LOW_SIGNAL — readoy-cse/LifeStream

- Path: `any.txt`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/readoy-cse/LifeStream/blob/b5749c680bbc35fc88744fb629c450da3818aebc/any.txt
- Repository URL: https://github.com/readoy-cse/LifeStream
- Assessment: unconfirmed; do not use or test any credentials.

### 2278. P3_LOW_SIGNAL — reassemblydev/reassembly-business-kit

- Path: `STRIPE.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/reassemblydev/reassembly-business-kit/blob/79e3f3149b37e3993d25fe163c06a68717d4d9e8/STRIPE.md
- Repository URL: https://github.com/reassemblydev/reassembly-business-kit
- Assessment: unconfirmed; do not use or test any credentials.

### 2279. P3_LOW_SIGNAL — redhat-france-sa/poc-ocp4-vsphere-terraform

- Path: `machine/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/redhat-france-sa/poc-ocp4-vsphere-terraform/blob/19c06aa4b76e4b97c272f9d489801dbd357a8478/machine/.terraform.tfstate.lock.info
- Repository URL: https://github.com/redhat-france-sa/poc-ocp4-vsphere-terraform
- Assessment: unconfirmed; do not use or test any credentials.

### 2280. P3_LOW_SIGNAL — reematcs/Module2_Project

- Path: `terraform.tfstate 2.backup`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/reematcs/Module2_Project/blob/49166fd7f4f9176d9d801b9386ce4b5416ec7b40/terraform.tfstate 2.backup
- Repository URL: https://github.com/reematcs/Module2_Project
- Assessment: unconfirmed; do not use or test any credentials.

### 2281. P3_LOW_SIGNAL — reematcs/Module2_Project

- Path: `terraform.tfstate 3.backup`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/reematcs/Module2_Project/blob/49166fd7f4f9176d9d801b9386ce4b5416ec7b40/terraform.tfstate 3.backup
- Repository URL: https://github.com/reematcs/Module2_Project
- Assessment: unconfirmed; do not use or test any credentials.

### 2282. P3_LOW_SIGNAL — reematcs/Module2_Project

- Path: `terraform.tfstate 4.backup`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/reematcs/Module2_Project/blob/49166fd7f4f9176d9d801b9386ce4b5416ec7b40/terraform.tfstate 4.backup
- Repository URL: https://github.com/reematcs/Module2_Project
- Assessment: unconfirmed; do not use or test any credentials.

### 2283. P3_LOW_SIGNAL — reewardius/bbFuzzing.txt

- Path: `top.txt`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/reewardius/bbFuzzing.txt/blob/0a2097bfd0b1de3441516083c2b064879ac60d9f/top.txt
- Repository URL: https://github.com/reewardius/bbFuzzing.txt
- Assessment: unconfirmed; do not use or test any credentials.

### 2284. P3_LOW_SIGNAL — reewardius/bbgithub-dorks

- Path: `raw.txt`
- Indicator: `github_token_prefix;github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/reewardius/bbgithub-dorks/blob/dd79e2f0d343fb8aad2d199a1c160165624b4fd2/raw.txt
- Repository URL: https://github.com/reewardius/bbgithub-dorks
- Assessment: unconfirmed; do not use or test any credentials.

### 2285. P3_LOW_SIGNAL — reewardius/confluence-secrets-scanner

- Path: `regex.txt`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/reewardius/confluence-secrets-scanner/blob/c411144fc38212863eebc0343df740a363dca38d/regex.txt
- Repository URL: https://github.com/reewardius/confluence-secrets-scanner
- Assessment: unconfirmed; do not use or test any credentials.

### 2286. P3_LOW_SIGNAL — reewardius/jira-secrets-scanner

- Path: `regex.txt`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/reewardius/jira-secrets-scanner/blob/7db0b307d320cd343762186a7e8970fee0c98b3d/regex.txt
- Repository URL: https://github.com/reewardius/jira-secrets-scanner
- Assessment: unconfirmed; do not use or test any credentials.

### 2287. P3_LOW_SIGNAL — rehacktive/caffeine

- Path: `JWT.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rehacktive/caffeine/blob/27a10d329914d1d8e9cc6576fa5b414beea77476/JWT.md
- Repository URL: https://github.com/rehacktive/caffeine
- Assessment: unconfirmed; do not use or test any credentials.

### 2288. P3_LOW_SIGNAL — renesutton712/crm

- Path: `DB.txt`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/renesutton712/crm/blob/4abd2a18bac276c94f56fde70e0fb21c2a3d4f48/DB.txt
- Repository URL: https://github.com/renesutton712/crm
- Assessment: unconfirmed; do not use or test any credentials.

### 2289. P3_LOW_SIGNAL — reverb256/astral-key

- Path: `HEY.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/reverb256/astral-key/blob/73853e6a9fdd127401e1b00ca627b6920ebec937/HEY.md
- Repository URL: https://github.com/reverb256/astral-key
- Assessment: unconfirmed; do not use or test any credentials.

### 2290. P3_LOW_SIGNAL — reverentgeek/metermaid

- Path: `TODO.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/reverentgeek/metermaid/blob/edb66c6517ec0b312c9c54729c829099cda86142/TODO.md
- Repository URL: https://github.com/reverentgeek/metermaid
- Assessment: unconfirmed; do not use or test any credentials.

### 2291. P3_LOW_SIGNAL — rfxn/brute-force-detection

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rfxn/brute-force-detection/blob/686bb72564116ce8ffb442c28b9d91f992d85ac0/README.md
- Repository URL: https://github.com/rfxn/brute-force-detection
- Assessment: unconfirmed; do not use or test any credentials.

### 2292. P3_LOW_SIGNAL — rh-aiservices-bu/rhai-agentic-demo

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rh-aiservices-bu/rhai-agentic-demo/blob/3fd387acf0f6d86dca4b4d6147fbdf5b2100cdf6/README.md
- Repository URL: https://github.com/rh-aiservices-bu/rhai-agentic-demo
- Assessment: unconfirmed; do not use or test any credentials.

### 2293. P3_LOW_SIGNAL — ribgu/ai-chatbot

- Path: `README.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ribgu/ai-chatbot/blob/aaac285f3715e212db77e14e019ac8a28d2066ec/README.md
- Repository URL: https://github.com/ribgu/ai-chatbot
- Assessment: unconfirmed; do not use or test any credentials.

### 2294. P3_LOW_SIGNAL — ricricucit/genscapes-live

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ricricucit/genscapes-live/blob/15a3650a1aedd8066bc4eef293c663e10397ac99/README.md
- Repository URL: https://github.com/ricricucit/genscapes-live
- Assessment: unconfirmed; do not use or test any credentials.

### 2295. P3_LOW_SIGNAL — ricsv/react-leonardo-ui

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ricsv/react-leonardo-ui/blob/0dafb2dbafd2e26b65527ec06d7030089a583ccf/README.md
- Repository URL: https://github.com/ricsv/react-leonardo-ui
- Assessment: unconfirmed; do not use or test any credentials.

### 2296. P3_LOW_SIGNAL — ridermw/nanopilot-slack

- Path: `CHANGELOG.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ridermw/nanopilot-slack/blob/cdb86d253de9f24caa93b14515511c8dffe4aad7/CHANGELOG.md
- Repository URL: https://github.com/ridermw/nanopilot-slack
- Assessment: unconfirmed; do not use or test any credentials.

### 2297. P3_LOW_SIGNAL — ridewireaihub/ridewire-ai-hub

- Path: `SETUP.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ridewireaihub/ridewire-ai-hub/blob/1b27f71aee76f625c93ba2c04b6c4aea94e754e1/SETUP.md
- Repository URL: https://github.com/ridewireaihub/ridewire-ai-hub
- Assessment: unconfirmed; do not use or test any credentials.

### 2298. P3_LOW_SIGNAL — riferrei/opensearch-for-gophers

- Path: `.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/riferrei/opensearch-for-gophers/blob/4a24ea700e82431e9de61b0ba8d96b517b3d7e0f/.terraform.tfstate.lock.info
- Repository URL: https://github.com/riferrei/opensearch-for-gophers
- Assessment: unconfirmed; do not use or test any credentials.

### 2299. P3_LOW_SIGNAL — rigidus/moto

- Path: `vk.org`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rigidus/moto/blob/112dd74707d334c90de24c93835936c80314d00d/vk.org
- Repository URL: https://github.com/rigidus/moto
- Assessment: unconfirmed; do not use or test any credentials.

### 2300. P3_LOW_SIGNAL — rishik-pulipaka/recorded-by-rishik

- Path: `DEPLOY.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rishik-pulipaka/recorded-by-rishik/blob/fdbaabd7dd12dce04c705933e7d3a361a81076a8/DEPLOY.md
- Repository URL: https://github.com/rishik-pulipaka/recorded-by-rishik
- Assessment: unconfirmed; do not use or test any credentials.

### 2301. P3_LOW_SIGNAL — rkinas/antec

- Path: `prd/07-SECURITY.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rkinas/antec/blob/6b7b24681a5d9cd8f11b0cd937100fdb3211c44e/prd/07-SECURITY.md
- Repository URL: https://github.com/rkinas/antec
- Assessment: unconfirmed; do not use or test any credentials.

### 2302. P3_LOW_SIGNAL — rmzlb/notifyd

- Path: `SPEC.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rmzlb/notifyd/blob/441e402b493fa8898793e2f1007bd169fc084459/SPEC.md
- Repository URL: https://github.com/rmzlb/notifyd
- Assessment: unconfirmed; do not use or test any credentials.

### 2303. P3_LOW_SIGNAL — roariasal/quiniela

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/roariasal/quiniela/blob/6f3608f9cd75950eb5507248c0eb8c7d032678d8/README.md
- Repository URL: https://github.com/roariasal/quiniela
- Assessment: unconfirmed; do not use or test any credentials.

### 2304. P3_LOW_SIGNAL — robertev-ronin/token-tap

- Path: `docs/PRIVACY.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/robertev-ronin/token-tap/blob/bb65eb551c63fb278d1712b50e15e01bc061a51d/docs/PRIVACY.md
- Repository URL: https://github.com/robertev-ronin/token-tap
- Assessment: unconfirmed; do not use or test any credentials.

### 2305. P3_LOW_SIGNAL — rogerchappel/agent-context-pruner-skill

- Path: `SECURITY.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rogerchappel/agent-context-pruner-skill/blob/457349adf7f2a7d0aafbea15eeaf773759b61b50/SECURITY.md
- Repository URL: https://github.com/rogerchappel/agent-context-pruner-skill
- Assessment: unconfirmed; do not use or test any credentials.

### 2306. P3_LOW_SIGNAL — rogerchappel/loglatch

- Path: `docs/REDACTION.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rogerchappel/loglatch/blob/c25dac4075042c57956fbe1ad698a10a02791f3b/docs/REDACTION.md
- Repository URL: https://github.com/rogerchappel/loglatch
- Assessment: unconfirmed; do not use or test any credentials.

### 2307. P3_LOW_SIGNAL — rohanbalixz/NeuralTimeCapsule

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rohanbalixz/NeuralTimeCapsule/blob/51d3fea9ded03ef491ef700e4a34e7626aa37767/README.md
- Repository URL: https://github.com/rohanbalixz/NeuralTimeCapsule
- Assessment: unconfirmed; do not use or test any credentials.

### 2308. P3_LOW_SIGNAL — rokibhasansagar/docker_droid-builder

- Path: `Dockerfile`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rokibhasansagar/docker_droid-builder/blob/d0f3828be42f9ded802e8f5dadd848d9cdea6be6/Dockerfile
- Repository URL: https://github.com/rokibhasansagar/docker_droid-builder
- Assessment: unconfirmed; do not use or test any credentials.

### 2309. P3_LOW_SIGNAL — romica44/PI-DOGS-HENRY

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/romica44/PI-DOGS-HENRY/blob/d375d8abcd0878f0f348240e7eea0f4f3e65b8d1/README.md
- Repository URL: https://github.com/romica44/PI-DOGS-HENRY
- Assessment: unconfirmed; do not use or test any credentials.

### 2310. P3_LOW_SIGNAL — romnovi/github-runner

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/romnovi/github-runner/blob/c69180edbd502ec997cd49af097648cfa3b3497e/README.md
- Repository URL: https://github.com/romnovi/github-runner
- Assessment: unconfirmed; do not use or test any credentials.

### 2311. P3_LOW_SIGNAL — ronael/Reqraft

- Path: `docs/privacy.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ronael/Reqraft/blob/91c0ab622942eb40ffbb96f2d38a644b2aa59069/docs/privacy.md
- Repository URL: https://github.com/ronael/Reqraft
- Assessment: unconfirmed; do not use or test any credentials.

### 2312. P3_LOW_SIGNAL — root-cause/v-labels

- Path: `stats.txt`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/root-cause/v-labels/blob/1c896c487548e49c59fb31691c4279aa84c938b5/stats.txt
- Repository URL: https://github.com/root-cause/v-labels
- Assessment: unconfirmed; do not use or test any credentials.

### 2313. P3_LOW_SIGNAL — ropensci/targets

- Path: `NEWS.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ropensci/targets/blob/06cae18bf0306ee98ce2f6f0a647e26410ddca22/NEWS.md
- Repository URL: https://github.com/ropensci/targets
- Assessment: unconfirmed; do not use or test any credentials.

### 2314. P3_LOW_SIGNAL — ropensci/tic

- Path: `NEWS.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ropensci/tic/blob/14ca9a5ecf7771b8151e681c108fd9992a813858/NEWS.md
- Repository URL: https://github.com/ropensci/tic
- Assessment: unconfirmed; do not use or test any credentials.

### 2315. P3_LOW_SIGNAL — rpcme/aws-and-infineon-xmc4800-workshop

- Path: `Lab2.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rpcme/aws-and-infineon-xmc4800-workshop/blob/b886f937f5feff45d59cda7552a9d5c51f2f06ca/Lab2.md
- Repository URL: https://github.com/rpcme/aws-and-infineon-xmc4800-workshop
- Assessment: unconfirmed; do not use or test any credentials.

### 2316. P3_LOW_SIGNAL — rruiz-s/agile-gscience-2024-rs-flood

- Path: `intro.qmd`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rruiz-s/agile-gscience-2024-rs-flood/blob/f217fdb9a15bb0ddf7cf113d1833de4af036963e/intro.qmd
- Repository URL: https://github.com/rruiz-s/agile-gscience-2024-rs-flood
- Assessment: unconfirmed; do not use or test any credentials.

### 2317. P3_LOW_SIGNAL — rs-001-ai/ai-code-review-extension-copilot

- Path: `BUILD.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rs-001-ai/ai-code-review-extension-copilot/blob/f2e523e3f4d3ecb785f986f0f6326fdd3b3257c6/BUILD.md
- Repository URL: https://github.com/rs-001-ai/ai-code-review-extension-copilot
- Assessment: unconfirmed; do not use or test any credentials.

### 2318. P3_LOW_SIGNAL — rsk-lab/RSKSharedChannels

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rsk-lab/RSKSharedChannels/blob/694b0826f4c2c000bfa945c4834e5b914a4725a1/README.md
- Repository URL: https://github.com/rsk-lab/RSKSharedChannels
- Assessment: unconfirmed; do not use or test any credentials.

### 2319. P3_LOW_SIGNAL — rsmith-nl/GHS-labels

- Path: `README.rst`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rsmith-nl/GHS-labels/blob/5a7b37a6875c151e990d6ba225335ad5c4470fbb/README.rst
- Repository URL: https://github.com/rsmith-nl/GHS-labels
- Assessment: unconfirmed; do not use or test any credentials.

### 2320. P3_LOW_SIGNAL — rstacruz/slack-bot-skill

- Path: `setup.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rstacruz/slack-bot-skill/blob/bafda91b69fc20ba1e3aeff9af169cad56dc2b74/setup.md
- Repository URL: https://github.com/rstacruz/slack-bot-skill
- Assessment: unconfirmed; do not use or test any credentials.

### 2321. P3_LOW_SIGNAL — rundel/checklist

- Path: `NEWS.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/rundel/checklist/blob/677a16fb41121813b37d3e1ac8476213e2b495d2/NEWS.md
- Repository URL: https://github.com/rundel/checklist
- Assessment: unconfirmed; do not use or test any credentials.

### 2322. P3_LOW_SIGNAL — russellmoss/winery-sales-simulator

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/russellmoss/winery-sales-simulator/blob/cf9daee486aaa4be142639ae97a6a5f20fc750b0/API.md
- Repository URL: https://github.com/russellmoss/winery-sales-simulator
- Assessment: unconfirmed; do not use or test any credentials.

### 2323. P3_LOW_SIGNAL — ruvnet/hackerone

- Path: `README.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ruvnet/hackerone/blob/1e3bcde8258d472a733abe9d9de9219f8ae06f16/README.md
- Repository URL: https://github.com/ruvnet/hackerone
- Assessment: unconfirmed; do not use or test any credentials.

### 2324. P3_LOW_SIGNAL — ryansechrest/github-updater-demo

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ryansechrest/github-updater-demo/blob/8d16a84ebeff3374b2881f339f9b10cd8cef9798/README.md
- Repository URL: https://github.com/ryansechrest/github-updater-demo
- Assessment: unconfirmed; do not use or test any credentials.

### 2325. P3_LOW_SIGNAL — s3rv3rnet/credsniff

- Path: `spec.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/s3rv3rnet/credsniff/blob/56846332987d7fd0dc409a673494f296a74b12e0/spec.md
- Repository URL: https://github.com/s3rv3rnet/credsniff
- Assessment: unconfirmed; do not use or test any credentials.

### 2326. P3_LOW_SIGNAL — s4nj1th/secr-cli

- Path: `RULES.md`
- Indicator: `npm_token_prefix;stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/s4nj1th/secr-cli/blob/210928a4d484e47dccd9ac7a4725276dbf504c72/RULES.md
- Repository URL: https://github.com/s4nj1th/secr-cli
- Assessment: unconfirmed; do not use or test any credentials.

### 2327. P3_LOW_SIGNAL — sabbirhasaann/ml

- Path: `file.txt`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sabbirhasaann/ml/blob/3016e356ecb7d7b0bacb153d8502005749afa41d/file.txt
- Repository URL: https://github.com/sabbirhasaann/ml
- Assessment: unconfirmed; do not use or test any credentials.

### 2328. P3_LOW_SIGNAL — sachinyadav3496/evening_batch_codes

- Path: `fb.txt`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sachinyadav3496/evening_batch_codes/blob/29d158ce75839a566efc84013cf9ef0e61c09cf6/fb.txt
- Repository URL: https://github.com/sachinyadav3496/evening_batch_codes
- Assessment: unconfirmed; do not use or test any credentials.

### 2329. P3_LOW_SIGNAL — safeer-maker/EC2_Website_hosting_using_Terraform

- Path: `.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/safeer-maker/EC2_Website_hosting_using_Terraform/blob/7937440d3c43d04353a4c2aaad04068051b4d71f/.terraform.tfstate.lock.info
- Repository URL: https://github.com/safeer-maker/EC2_Website_hosting_using_Terraform
- Assessment: unconfirmed; do not use or test any credentials.

### 2330. P3_LOW_SIGNAL — saikumar2616/Python-from-basics

- Path: `307.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/saikumar2616/Python-from-basics/blob/944e1be38fcb6988d4cb9ca39d56ac01f71c5ae0/307.md
- Repository URL: https://github.com/saikumar2616/Python-from-basics
- Assessment: unconfirmed; do not use or test any credentials.

### 2331. P3_LOW_SIGNAL — saikumar2616/Python-from-basics

- Path: `308.md`
- Indicator: `password_assignment;secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/saikumar2616/Python-from-basics/blob/944e1be38fcb6988d4cb9ca39d56ac01f71c5ae0/308.md
- Repository URL: https://github.com/saikumar2616/Python-from-basics
- Assessment: unconfirmed; do not use or test any credentials.

### 2332. P3_LOW_SIGNAL — salahuddingfx/NYRA_AI

- Path: `FAQ.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/salahuddingfx/NYRA_AI/blob/76b624eee99f4d70f69c9550c93655393863bcd7/FAQ.md
- Repository URL: https://github.com/salahuddingfx/NYRA_AI
- Assessment: unconfirmed; do not use or test any credentials.

### 2333. P3_LOW_SIGNAL — sam-siavoshian/agent-notch

- Path: `PRD.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sam-siavoshian/agent-notch/blob/faeb42bde1ba65de0a770888101bb3373cda5f67/PRD.md
- Repository URL: https://github.com/sam-siavoshian/agent-notch
- Assessment: unconfirmed; do not use or test any credentials.

### 2334. P3_LOW_SIGNAL — samirvithlani/internship-25-nodejs

- Path: `th.txt`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/samirvithlani/internship-25-nodejs/blob/87d7a9630b6a2e8e5349e63d6a376bce4d4098ac/th.txt
- Repository URL: https://github.com/samirvithlani/internship-25-nodejs
- Assessment: unconfirmed; do not use or test any credentials.

### 2335. P3_LOW_SIGNAL — sanif/aiva

- Path: `AUDIT.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sanif/aiva/blob/4fe4c8148429685b17ff9412061b30836eea1001/AUDIT.md
- Repository URL: https://github.com/sanif/aiva
- Assessment: unconfirmed; do not use or test any credentials.

### 2336. P3_LOW_SIGNAL — sapod/Kubectl-UI

- Path: `CICD.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sapod/Kubectl-UI/blob/f7ff40e3583d639073e4fc5bae1fb43f4b3cf7a4/CICD.md
- Repository URL: https://github.com/sapod/Kubectl-UI
- Assessment: unconfirmed; do not use or test any credentials.

### 2337. P3_LOW_SIGNAL — sarcasticdhruv/helix-agent

- Path: `USAGE.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sarcasticdhruv/helix-agent/blob/05f175c4e6cdebd3358185804c53bb78ca4713f5/USAGE.md
- Repository URL: https://github.com/sarcasticdhruv/helix-agent
- Assessment: unconfirmed; do not use or test any credentials.

### 2338. P3_LOW_SIGNAL — sarptandoven/python-sdk-to-mcp-converter

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sarptandoven/python-sdk-to-mcp-converter/blob/2428371c09c22c32121d91539127b9067328fe06/SETUP.md
- Repository URL: https://github.com/sarptandoven/python-sdk-to-mcp-converter
- Assessment: unconfirmed; do not use or test any credentials.

### 2339. P3_LOW_SIGNAL — satheesh18/paarvai-mcp

- Path: `SETUP.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/satheesh18/paarvai-mcp/blob/de430b6f6ed71561dcdb1ee33e964770e7192693/SETUP.md
- Repository URL: https://github.com/satheesh18/paarvai-mcp
- Assessment: unconfirmed; do not use or test any credentials.

### 2340. P3_LOW_SIGNAL — sbeliakou/gha-runners

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sbeliakou/gha-runners/blob/106dd9ee5f03fe60c675bf5b4eee7d0e679b66c1/README.md
- Repository URL: https://github.com/sbeliakou/gha-runners
- Assessment: unconfirmed; do not use or test any credentials.

### 2341. P3_LOW_SIGNAL — seasaltcorp/simplyauthdesktop

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/seasaltcorp/simplyauthdesktop/blob/e03f5af10d57a22beb5e862076ed2cc223d8028a/README.md
- Repository URL: https://github.com/seasaltcorp/simplyauthdesktop
- Assessment: unconfirmed; do not use or test any credentials.

### 2342. P3_LOW_SIGNAL — selectess/fde-consultants-protocoles

- Path: `SECURITY.md`
- Indicator: `github_oauth_prefix;github_app_token_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/selectess/fde-consultants-protocoles/blob/072f005e701b671d1e03a26dae2848e9b492fc32/SECURITY.md
- Repository URL: https://github.com/selectess/fde-consultants-protocoles
- Assessment: unconfirmed; do not use or test any credentials.

### 2343. P3_LOW_SIGNAL — selesnow/rvkstat

- Path: `index.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/selesnow/rvkstat/blob/3b590b7c42915c8d006ff065d07b9515a0fa62fa/index.md
- Repository URL: https://github.com/selesnow/rvkstat
- Assessment: unconfirmed; do not use or test any credentials.

### 2344. P3_LOW_SIGNAL — sentilo/sentilo-client-sample-nodejs

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sentilo/sentilo-client-sample-nodejs/blob/e2323ceef599214249f089d9a041a666fbd3c2ea/README.md
- Repository URL: https://github.com/sentilo/sentilo-client-sample-nodejs
- Assessment: unconfirmed; do not use or test any credentials.

### 2345. P3_LOW_SIGNAL — senzee1984/OSCE3-Notes

- Path: `OSEP.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/senzee1984/OSCE3-Notes/blob/75c98af727c55c3126bfedc0b14d5041f387ec38/OSEP.md
- Repository URL: https://github.com/senzee1984/OSCE3-Notes
- Assessment: unconfirmed; do not use or test any credentials.

### 2346. P3_LOW_SIGNAL — seopanel/Seo-Panel-Docs

- Path: `api.rst`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/seopanel/Seo-Panel-Docs/blob/85614ea3a827497ae3575a9765bf568e97e762ee/api.rst
- Repository URL: https://github.com/seopanel/Seo-Panel-Docs
- Assessment: unconfirmed; do not use or test any credentials.

### 2347. P3_LOW_SIGNAL — seratch/bolt-starter

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/seratch/bolt-starter/blob/774765677e5390be085a32088fd0c20537568705/README.md
- Repository URL: https://github.com/seratch/bolt-starter
- Assessment: unconfirmed; do not use or test any credentials.

### 2348. P3_LOW_SIGNAL — sergiodxa/remix-hono

- Path: `README.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sergiodxa/remix-hono/blob/32e778524d3738c1d485a59a829d29eec6b2c103/README.md
- Repository URL: https://github.com/sergiodxa/remix-hono
- Assessment: unconfirmed; do not use or test any credentials.

### 2349. P3_LOW_SIGNAL — servusdei2018/augur

- Path: `CI.md`
- Indicator: `api_key_label;github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/servusdei2018/augur/blob/bfdc744c72208c1a4ca5b3f125654c499648b3ab/CI.md
- Repository URL: https://github.com/servusdei2018/augur
- Assessment: unconfirmed; do not use or test any credentials.

### 2350. P3_LOW_SIGNAL — seshness/loopmein

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/seshness/loopmein/blob/060dce9fc3e35926d32a2087d12d341e22329b6c/README.md
- Repository URL: https://github.com/seshness/loopmein
- Assessment: unconfirmed; do not use or test any credentials.

### 2351. P3_LOW_SIGNAL — sfluhrer/hybrid-hash-based-signature

- Path: `read.me`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sfluhrer/hybrid-hash-based-signature/blob/f08f5c25f2b5753a6b3fd1a2932009f3bfa64253/read.me
- Repository URL: https://github.com/sfluhrer/hybrid-hash-based-signature
- Assessment: unconfirmed; do not use or test any credentials.

### 2352. P3_LOW_SIGNAL — sguez/incident-manager

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sguez/incident-manager/blob/5824f17e9db6e4327a8a344d01e9fe84ef413504/API.md
- Repository URL: https://github.com/sguez/incident-manager
- Assessment: unconfirmed; do not use or test any credentials.

### 2353. P3_LOW_SIGNAL — sgx-labs/statelessagent

- Path: `CHANGELOG.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sgx-labs/statelessagent/blob/85e7ff20edf0533a499cbd6a7620da50f5989ec2/CHANGELOG.md
- Repository URL: https://github.com/sgx-labs/statelessagent
- Assessment: unconfirmed; do not use or test any credentials.

### 2354. P3_LOW_SIGNAL — shadowsock5/notes

- Path: `SSL.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/shadowsock5/notes/blob/d522842ed7823aa221241c91571e30342ecf1267/SSL.md
- Repository URL: https://github.com/shadowsock5/notes
- Assessment: unconfirmed; do not use or test any credentials.

### 2355. P3_LOW_SIGNAL — sharf-shawon/Awesome-Bangladeshi-Devs

- Path: `PLAN.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sharf-shawon/Awesome-Bangladeshi-Devs/blob/21325061e9f428f9f6ad91df2caeb5a08c111582/PLAN.md
- Repository URL: https://github.com/sharf-shawon/Awesome-Bangladeshi-Devs
- Assessment: unconfirmed; do not use or test any credentials.

### 2356. P3_LOW_SIGNAL — shariyerShazan/Finn-Nestjs-Marketplace-Backend

- Path: `ENV.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/shariyerShazan/Finn-Nestjs-Marketplace-Backend/blob/1a8f2ce4362a3cb64467c93581d1e034324e17be/ENV.md
- Repository URL: https://github.com/shariyerShazan/Finn-Nestjs-Marketplace-Backend
- Assessment: unconfirmed; do not use or test any credentials.

### 2357. P3_LOW_SIGNAL — shiburagi/Drawer-Behavior

- Path: `README.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/shiburagi/Drawer-Behavior/blob/aef31d69a079455bddabadffcee37960709227ca/README.md
- Repository URL: https://github.com/shiburagi/Drawer-Behavior
- Assessment: unconfirmed; do not use or test any credentials.

### 2358. P3_LOW_SIGNAL — shift-labs-ai/markit

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/shift-labs-ai/markit/blob/4197c76a651607421c5dcd05c0f94555ad1d6a9c/README.md
- Repository URL: https://github.com/shift-labs-ai/markit
- Assessment: unconfirmed; do not use or test any credentials.

### 2359. P3_LOW_SIGNAL — shimmicute29-ops/DevLens

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/shimmicute29-ops/DevLens/blob/fedc3cac4d56c3b2ada2d4831746bac4d648c515/API.md
- Repository URL: https://github.com/shimmicute29-ops/DevLens
- Assessment: unconfirmed; do not use or test any credentials.

### 2360. P3_LOW_SIGNAL — shinjuku-lt/timetable-bot

- Path: `README.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/shinjuku-lt/timetable-bot/blob/d742dab0ae1e978b7588f837688efeacdd9070da/README.md
- Repository URL: https://github.com/shinjuku-lt/timetable-bot
- Assessment: unconfirmed; do not use or test any credentials.

### 2361. P3_LOW_SIGNAL — shinyamadasan/Time-audit

- Path: `QA.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/shinyamadasan/Time-audit/blob/bb171a287ac67d76ae27634b5227bc24f66919de/QA.md
- Repository URL: https://github.com/shinyamadasan/Time-audit
- Assessment: unconfirmed; do not use or test any credentials.

### 2362. P3_LOW_SIGNAL — shmilylbelva/Relearn-Modern-PHP

- Path: `2-3.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/shmilylbelva/Relearn-Modern-PHP/blob/ecd770605b5a8ca41ed101057259841f49efc575/2-3.md
- Repository URL: https://github.com/shmilylbelva/Relearn-Modern-PHP
- Assessment: unconfirmed; do not use or test any credentials.

### 2363. P3_LOW_SIGNAL — shmilylbelva/Relearn-Modern-PHP

- Path: `4-4.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/shmilylbelva/Relearn-Modern-PHP/blob/ecd770605b5a8ca41ed101057259841f49efc575/4-4.md
- Repository URL: https://github.com/shmilylbelva/Relearn-Modern-PHP
- Assessment: unconfirmed; do not use or test any credentials.

### 2364. P3_LOW_SIGNAL — shopware/setup-shopware

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/shopware/setup-shopware/blob/aad0796c9e6c36a7603a3319c3725871c16ae212/README.md
- Repository URL: https://github.com/shopware/setup-shopware
- Assessment: unconfirmed; do not use or test any credentials.

### 2365. P3_LOW_SIGNAL — shrivardhan232006/Anchor

- Path: `SETUP.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/shrivardhan232006/Anchor/blob/dd6cf064375dda1e1e082e5ef0b49cf65b0dc36f/SETUP.md
- Repository URL: https://github.com/shrivardhan232006/Anchor
- Assessment: unconfirmed; do not use or test any credentials.

### 2366. P3_LOW_SIGNAL — shu8/linkener

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/shu8/linkener/blob/51fe4ac5073f3478f043ad6604652f00a827d8d1/API.md
- Repository URL: https://github.com/shu8/linkener
- Assessment: unconfirmed; do not use or test any credentials.

### 2367. P3_LOW_SIGNAL — shuryak/StupidSocialNetwork

- Path: `api.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/shuryak/StupidSocialNetwork/blob/15465ba25b7de11e1963bbbda765d97e83228549/api.md
- Repository URL: https://github.com/shuryak/StupidSocialNetwork
- Assessment: unconfirmed; do not use or test any credentials.

### 2368. P3_LOW_SIGNAL — shutterbase/shutterbase

- Path: `TODO.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/shutterbase/shutterbase/blob/56690d31873f5525ee2ca58f907a427132049e58/TODO.md
- Repository URL: https://github.com/shutterbase/shutterbase
- Assessment: unconfirmed; do not use or test any credentials.

### 2369. P3_LOW_SIGNAL — sidex-fun/openclaw-sidex-kit

- Path: `SDK.md`
- Indicator: `private_key_label;api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sidex-fun/openclaw-sidex-kit/blob/763fdda0de50223b19e56ec6d25e6f2edbeeb2e8/SDK.md
- Repository URL: https://github.com/sidex-fun/openclaw-sidex-kit
- Assessment: unconfirmed; do not use or test any credentials.

### 2370. P3_LOW_SIGNAL — siketyan/ghr

- Path: `README.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/siketyan/ghr/blob/1911ecbc65a93cb4aa68ad93877735c3102646c4/README.md
- Repository URL: https://github.com/siketyan/ghr
- Assessment: unconfirmed; do not use or test any credentials.

### 2371. P3_LOW_SIGNAL — siketyan/ghr

- Path: `src/root.rs`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/siketyan/ghr/blob/1911ecbc65a93cb4aa68ad93877735c3102646c4/src/root.rs
- Repository URL: https://github.com/siketyan/ghr
- Assessment: unconfirmed; do not use or test any credentials.

### 2372. P3_LOW_SIGNAL — simplydemo/spring-boot-starter-aws-secrets-manager

- Path: `HELP.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/simplydemo/spring-boot-starter-aws-secrets-manager/blob/4a1c0cde46bd630bd249a014268e30ba063ab815/HELP.md
- Repository URL: https://github.com/simplydemo/spring-boot-starter-aws-secrets-manager
- Assessment: unconfirmed; do not use or test any credentials.

### 2373. P3_LOW_SIGNAL — singer-io/tap-bigcommerce

- Path: `Docs.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/singer-io/tap-bigcommerce/blob/57bde7b3c370647dda5073f6a5725d465a9f62d2/Docs.md
- Repository URL: https://github.com/singer-io/tap-bigcommerce
- Assessment: unconfirmed; do not use or test any credentials.

### 2374. P3_LOW_SIGNAL — sinricpro/nodejs-sdk

- Path: `llms.txt`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sinricpro/nodejs-sdk/blob/83983dee4b16c8c9f125d8e0f732faf0d9019913/llms.txt
- Repository URL: https://github.com/sinricpro/nodejs-sdk
- Assessment: unconfirmed; do not use or test any credentials.

### 2375. P3_LOW_SIGNAL — sinricpro/python-sdk

- Path: `llms.txt`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sinricpro/python-sdk/blob/11415707d8710e048cfaf09cc7711fb57ffba686/llms.txt
- Repository URL: https://github.com/sinricpro/python-sdk
- Assessment: unconfirmed; do not use or test any credentials.

### 2376. P3_LOW_SIGNAL — sirhCC/Sentinel-ScannerRotator

- Path: `API.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sirhCC/Sentinel-ScannerRotator/blob/7051f65335720fb49d64953dfc79cfb91a13b8d8/API.md
- Repository URL: https://github.com/sirhCC/Sentinel-ScannerRotator
- Assessment: unconfirmed; do not use or test any credentials.

### 2377. P3_LOW_SIGNAL — sirolli-org/yaq

- Path: `BUILD.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sirolli-org/yaq/blob/67b5ecedf8730e22725a40ba546e5971d2d42aff/BUILD.md
- Repository URL: https://github.com/sirolli-org/yaq
- Assessment: unconfirmed; do not use or test any credentials.

### 2378. P3_LOW_SIGNAL — sivammarwar/btc-bot

- Path: `siva.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sivammarwar/btc-bot/blob/a804caef373613230a0eafd98727534ceadb10aa/siva.md
- Repository URL: https://github.com/sivammarwar/btc-bot
- Assessment: unconfirmed; do not use or test any credentials.

### 2379. P3_LOW_SIGNAL — siwoo2013/siu-autotrade-gui

- Path: `redact.txt`
- Indicator: `github_app_token_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/siwoo2013/siu-autotrade-gui/blob/f3cca0bf2ea1e942762d2a1f2cf51967aff3440b/redact.txt
- Repository URL: https://github.com/siwoo2013/siu-autotrade-gui
- Assessment: unconfirmed; do not use or test any credentials.

### 2380. P3_LOW_SIGNAL — skills-il/food-and-dining

- Path: `CLAUDE.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/skills-il/food-and-dining/blob/25cffb85623129b3e3cf523253a2467d9b470957/CLAUDE.md
- Repository URL: https://github.com/skills-il/food-and-dining
- Assessment: unconfirmed; do not use or test any credentials.

### 2381. P3_LOW_SIGNAL — slack-samples/bolt-js-reacjilator

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/slack-samples/bolt-js-reacjilator/blob/f0ac764c1328315c50b7bb3cbd0a7c583a25b58a/README.md
- Repository URL: https://github.com/slack-samples/bolt-js-reacjilator
- Assessment: unconfirmed; do not use or test any credentials.

### 2382. P3_LOW_SIGNAL — sleaa17aol/Proxy-

- Path: `2/4.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sleaa17aol/Proxy-/blob/718773cdb8fb918b69f98e769bf238083ce7468e/2/4.md
- Repository URL: https://github.com/sleaa17aol/Proxy-
- Assessment: unconfirmed; do not use or test any credentials.

### 2383. P3_LOW_SIGNAL — sleaa17aol/Proxy-

- Path: `22.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sleaa17aol/Proxy-/blob/718773cdb8fb918b69f98e769bf238083ce7468e/22.md
- Repository URL: https://github.com/sleaa17aol/Proxy-
- Assessment: unconfirmed; do not use or test any credentials.

### 2384. P3_LOW_SIGNAL — sleaa17aol/Proxy-

- Path: `3/4.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sleaa17aol/Proxy-/blob/718773cdb8fb918b69f98e769bf238083ce7468e/3/4.md
- Repository URL: https://github.com/sleaa17aol/Proxy-
- Assessment: unconfirmed; do not use or test any credentials.

### 2385. P3_LOW_SIGNAL — sleaa17aol/Proxy-

- Path: `9.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sleaa17aol/Proxy-/blob/718773cdb8fb918b69f98e769bf238083ce7468e/9.md
- Repository URL: https://github.com/sleaa17aol/Proxy-
- Assessment: unconfirmed; do not use or test any credentials.

### 2386. P3_LOW_SIGNAL — sleaa17aol/Proxy-

- Path: `99.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sleaa17aol/Proxy-/blob/718773cdb8fb918b69f98e769bf238083ce7468e/99.md
- Repository URL: https://github.com/sleaa17aol/Proxy-
- Assessment: unconfirmed; do not use or test any credentials.

### 2387. P3_LOW_SIGNAL — slexx1234/laravel-actions

- Path: `RU.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/slexx1234/laravel-actions/blob/8735053dc00f414a38db27e02ce04b23d0c02261/RU.md
- Repository URL: https://github.com/slexx1234/laravel-actions
- Assessment: unconfirmed; do not use or test any credentials.

### 2388. P3_LOW_SIGNAL — smart-signature/smart-signature-backend

- Path: `doc.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/smart-signature/smart-signature-backend/blob/ab0a2b2e43ae8834262d1a38882545beff96244e/doc.md
- Repository URL: https://github.com/smart-signature/smart-signature-backend
- Assessment: unconfirmed; do not use or test any credentials.

### 2389. P3_LOW_SIGNAL — smyha/smyha

- Path: `SETUP.md`
- Indicator: `github_token_prefix;github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/smyha/smyha/blob/75245a688f6cdbbbe7393dd96b2c96b3245105c8/SETUP.md
- Repository URL: https://github.com/smyha/smyha
- Assessment: unconfirmed; do not use or test any credentials.

### 2390. P3_LOW_SIGNAL — snake-charmer-devs/snake-charmer

- Path: `FAQ.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/snake-charmer-devs/snake-charmer/blob/01265a32a7f542444abd98c55f318275c0dcf671/FAQ.md
- Repository URL: https://github.com/snake-charmer-devs/snake-charmer
- Assessment: unconfirmed; do not use or test any credentials.

### 2391. P3_LOW_SIGNAL — snakemode/ably-space-game-backup

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/snakemode/ably-space-game-backup/blob/19b1f37296b42ee91e20075355410b08dbf306e8/README.md
- Repository URL: https://github.com/snakemode/ably-space-game-backup
- Assessment: unconfirmed; do not use or test any credentials.

### 2392. P3_LOW_SIGNAL — songxitao/demo-to-oss

- Path: `spec.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/songxitao/demo-to-oss/blob/8166666334dd1e1de7e5500b7172a9de72d8972e/spec.md
- Repository URL: https://github.com/songxitao/demo-to-oss
- Assessment: unconfirmed; do not use or test any credentials.

### 2393. P3_LOW_SIGNAL — sonots/slack-notice-action

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sonots/slack-notice-action/blob/3efde474b6c65356e8bfc95d2025762ee0489d85/README.md
- Repository URL: https://github.com/sonots/slack-notice-action
- Assessment: unconfirmed; do not use or test any credentials.

### 2394. P3_LOW_SIGNAL — spacepirate15/quantum-hermes-free-router-kit

- Path: `docs/SECURITY.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/spacepirate15/quantum-hermes-free-router-kit/blob/d7a1b7b71efacbeacc6fc9d25592b0bf9dbbab3b/docs/SECURITY.md
- Repository URL: https://github.com/spacepirate15/quantum-hermes-free-router-kit
- Assessment: unconfirmed; do not use or test any credentials.

### 2395. P3_LOW_SIGNAL — spektre-labs/creation-os

- Path: `CHANGELOG.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/spektre-labs/creation-os/blob/ade7871cc5912ba60120e168a74f47449c27f84f/CHANGELOG.md
- Repository URL: https://github.com/spektre-labs/creation-os
- Assessment: unconfirmed; do not use or test any credentials.

### 2396. P3_LOW_SIGNAL — sphincs/low-ram-sphincsplus

- Path: `read.me`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sphincs/low-ram-sphincsplus/blob/14993cae7688c0b2dd7b65b45b1e824330028042/read.me
- Repository URL: https://github.com/sphincs/low-ram-sphincsplus
- Assessment: unconfirmed; do not use or test any credentials.

### 2397. P3_LOW_SIGNAL — spine/spine.app

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/spine/spine.app/blob/da6dc955b4805272fe3d3a759bdaac34c5f8964c/README.md
- Repository URL: https://github.com/spine/spine.app
- Assessment: unconfirmed; do not use or test any credentials.

### 2398. P3_LOW_SIGNAL — spinov001-art/api-secrets-scanner

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/spinov001-art/api-secrets-scanner/blob/16ca52303c60a14c491576fe14d5de67e5087f78/README.md
- Repository URL: https://github.com/spinov001-art/api-secrets-scanner
- Assessment: unconfirmed; do not use or test any credentials.

### 2399. P3_LOW_SIGNAL — spudtrooper/rdiorb

- Path: `README`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/spudtrooper/rdiorb/blob/e137fd016bfba42d9e50f421b009b2ad3c41baaf/README
- Repository URL: https://github.com/spudtrooper/rdiorb
- Assessment: unconfirmed; do not use or test any credentials.

### 2400. P3_LOW_SIGNAL — spyrae/kronos-agent-os

- Path: `docs/SECURITY.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/spyrae/kronos-agent-os/blob/b0b7bacfecee0772208d443f08ea95af93cfd89d/docs/SECURITY.md
- Repository URL: https://github.com/spyrae/kronos-agent-os
- Assessment: unconfirmed; do not use or test any credentials.

### 2401. P3_LOW_SIGNAL — sragss/apple-illusion-of-thinking

- Path: `SETUP.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sragss/apple-illusion-of-thinking/blob/d0a09457d1374ea487e22e17a298aa412b679165/SETUP.md
- Repository URL: https://github.com/sragss/apple-illusion-of-thinking
- Assessment: unconfirmed; do not use or test any credentials.

### 2402. P3_LOW_SIGNAL — sriramsowmithri9807/claude-cheatcodes-1000

- Path: `INDEX.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sriramsowmithri9807/claude-cheatcodes-1000/blob/c0e92d1fb6aabc2b112aea31587f00e7be074400/INDEX.md
- Repository URL: https://github.com/sriramsowmithri9807/claude-cheatcodes-1000
- Assessment: unconfirmed; do not use or test any credentials.

### 2403. P3_LOW_SIGNAL — srpavani/99food-auto-appeal

- Path: `FAQ.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/srpavani/99food-auto-appeal/blob/620f6e012ae03c5df9d2b5d4889b158f31de173f/FAQ.md
- Repository URL: https://github.com/srpavani/99food-auto-appeal
- Assessment: unconfirmed; do not use or test any credentials.

### 2404. P3_LOW_SIGNAL — ssp21/ssp21-spec

- Path: `ssp21.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ssp21/ssp21-spec/blob/7e34a79ae3b322f5498111efe071e48b156abd84/ssp21.md
- Repository URL: https://github.com/ssp21/ssp21-spec
- Assessment: unconfirmed; do not use or test any credentials.

### 2405. P3_LOW_SIGNAL — stahnma/spotifyquery

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/stahnma/spotifyquery/blob/6998e080aab7f03525d566096e5d62b5c13bde30/README.md
- Repository URL: https://github.com/stahnma/spotifyquery
- Assessment: unconfirmed; do not use or test any credentials.

### 2406. P3_LOW_SIGNAL — star-sg/V8Harvest

- Path: `2016.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/star-sg/V8Harvest/blob/caef160e0de48eaf0fd1dbf83323981b13e1d617/2016.md
- Repository URL: https://github.com/star-sg/V8Harvest
- Assessment: unconfirmed; do not use or test any credentials.

### 2407. P3_LOW_SIGNAL — status-im/status-github-bot

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/status-im/status-github-bot/blob/ff82b146ab91fc5fc52b68c8329e84ce22fe41ab/README.md
- Repository URL: https://github.com/status-im/status-github-bot
- Assessment: unconfirmed; do not use or test any credentials.

### 2408. P3_LOW_SIGNAL — steelkiwi/jwt-python-tutorial

- Path: `post.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/steelkiwi/jwt-python-tutorial/blob/a074b91d3010a93a71936ec26e6d6f8735d53483/post.md
- Repository URL: https://github.com/steelkiwi/jwt-python-tutorial
- Assessment: unconfirmed; do not use or test any credentials.

### 2409. P3_LOW_SIGNAL — stephenfreund/FlowBook

- Path: `AI.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/stephenfreund/FlowBook/blob/7f20bd4d259970239239a4592e4059e02ce45095/AI.md
- Repository URL: https://github.com/stephenfreund/FlowBook
- Assessment: unconfirmed; do not use or test any credentials.

### 2410. P3_LOW_SIGNAL — sterlingwes/gh-pages-deploy-action

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sterlingwes/gh-pages-deploy-action/blob/1186bb6a9ebbaa83d7168843f1081c45f0fda782/README.md
- Repository URL: https://github.com/sterlingwes/gh-pages-deploy-action
- Assessment: unconfirmed; do not use or test any credentials.

### 2411. P3_LOW_SIGNAL — stevenwilliamson/sandboxed-copilot

- Path: `AGENTS.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/stevenwilliamson/sandboxed-copilot/blob/86c028423b5c041e3e770ce08ef8305158243d7b/AGENTS.md
- Repository URL: https://github.com/stevenwilliamson/sandboxed-copilot
- Assessment: unconfirmed; do not use or test any credentials.

### 2412. P3_LOW_SIGNAL — stevenwilliamson/sandboxed-copilot

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/stevenwilliamson/sandboxed-copilot/blob/86c028423b5c041e3e770ce08ef8305158243d7b/README.md
- Repository URL: https://github.com/stevenwilliamson/sandboxed-copilot
- Assessment: unconfirmed; do not use or test any credentials.

### 2413. P3_LOW_SIGNAL — sttts/slagent

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sttts/slagent/blob/4b959bdf2a8207daeb597ed8f2ed360b2c7f51a9/README.md
- Repository URL: https://github.com/sttts/slagent
- Assessment: unconfirmed; do not use or test any credentials.

### 2414. P3_LOW_SIGNAL — subhamg/docs-generator

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/subhamg/docs-generator/blob/b520c0eedb0a9bd68b79d96709a145bef8778545/README.md
- Repository URL: https://github.com/subhamg/docs-generator
- Assessment: unconfirmed; do not use or test any credentials.

### 2415. P3_LOW_SIGNAL — suchintan/dotfiles

- Path: `AGENTS.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/suchintan/dotfiles/blob/b28b1203ec4e55dcb78a1357570cf3724bb0c945/AGENTS.md
- Repository URL: https://github.com/suchintan/dotfiles
- Assessment: unconfirmed; do not use or test any credentials.

### 2416. P3_LOW_SIGNAL — sudheerimmidisetti/Build-a-Multi-Tenant-API-Key-Gateway-with-Rate-Limiting-and-Rotation-using-Redis

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sudheerimmidisetti/Build-a-Multi-Tenant-API-Key-Gateway-with-Rate-Limiting-and-Rotation-using-Redis/blob/aa40b9d8b884e8504e61ee4eba9970715e3fc420/README.md
- Repository URL: https://github.com/sudheerimmidisetti/Build-a-Multi-Tenant-API-Key-Gateway-with-Rate-Limiting-and-Rotation-using-Redis
- Assessment: unconfirmed; do not use or test any credentials.

### 2417. P3_LOW_SIGNAL — sudorook/snippets

- Path: `ssh.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sudorook/snippets/blob/f0816018020decb6bc0c142293393776f96ce85b/ssh.md
- Repository URL: https://github.com/sudorook/snippets
- Assessment: unconfirmed; do not use or test any credentials.

### 2418. P3_LOW_SIGNAL — supersheep/huixiang

- Path: `api.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/supersheep/huixiang/blob/7d209681ed6699ef7f28383b982f4e4a74c6eb37/api.md
- Repository URL: https://github.com/supersheep/huixiang
- Assessment: unconfirmed; do not use or test any credentials.

### 2419. P3_LOW_SIGNAL — sushanshetty1/cachet-cli

- Path: `Plan.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sushanshetty1/cachet-cli/blob/b6048d9926c682a986bdb96fd29e342858786887/Plan.md
- Repository URL: https://github.com/sushanshetty1/cachet-cli
- Assessment: unconfirmed; do not use or test any credentials.

### 2420. P3_LOW_SIGNAL — suveshmoza/diffy

- Path: `README.md`
- Indicator: `github_pat_prefix;github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/suveshmoza/diffy/blob/cffefec03e96f420493084fd3d4e050ad14a03b1/README.md
- Repository URL: https://github.com/suveshmoza/diffy
- Assessment: unconfirmed; do not use or test any credentials.

### 2421. P3_LOW_SIGNAL — sym804/ai-squad

- Path: `SETUP.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/sym804/ai-squad/blob/ef4832476ed15e8dab909e2093103fa8b8f9ac0e/SETUP.md
- Repository URL: https://github.com/sym804/ai-squad
- Assessment: unconfirmed; do not use or test any credentials.

### 2422. P3_LOW_SIGNAL — symfony/slack-notifier

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/symfony/slack-notifier/blob/f4944e572d3cb96eb8494705c4059e0ad7e8c291/README.md
- Repository URL: https://github.com/symfony/slack-notifier
- Assessment: unconfirmed; do not use or test any credentials.

### 2423. P3_LOW_SIGNAL — syxc/gh-repo-cli

- Path: `README.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/syxc/gh-repo-cli/blob/60b313fb5191f65d15d0493adb61f5e19b4710c0/README.md
- Repository URL: https://github.com/syxc/gh-repo-cli
- Assessment: unconfirmed; do not use or test any credentials.

### 2424. P3_LOW_SIGNAL — syxc/gh-repo-cli

- Path: `README.zh-CN.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/syxc/gh-repo-cli/blob/60b313fb5191f65d15d0493adb61f5e19b4710c0/README.zh-CN.md
- Repository URL: https://github.com/syxc/gh-repo-cli
- Assessment: unconfirmed; do not use or test any credentials.

### 2425. P3_LOW_SIGNAL — szattila98/binge_at_home

- Path: `DEV.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/szattila98/binge_at_home/blob/2e36fafa712be21d7e151cb6f93197928fda63a6/DEV.md
- Repository URL: https://github.com/szattila98/binge_at_home
- Assessment: unconfirmed; do not use or test any credentials.

### 2426. P3_LOW_SIGNAL — tablelandnetwork/js-tableland

- Path: `API.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/tablelandnetwork/js-tableland/blob/eb10ec9d401592050c55c9761339fb956c4e9b71/API.md
- Repository URL: https://github.com/tablelandnetwork/js-tableland
- Assessment: unconfirmed; do not use or test any credentials.

### 2427. P3_LOW_SIGNAL — tag1consulting/tag1bot

- Path: `INFRA.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/tag1consulting/tag1bot/blob/239e87b7c7ff1b41c5ab35439402ac7bb8ee0f23/INFRA.md
- Repository URL: https://github.com/tag1consulting/tag1bot
- Assessment: unconfirmed; do not use or test any credentials.

### 2428. P3_LOW_SIGNAL — tahmidbintaslim/firebase-ai-mvp

- Path: `.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/tahmidbintaslim/firebase-ai-mvp/blob/b0f5b17465a856666cb66fba49817e3a81a43971/.terraform.tfstate.lock.info
- Repository URL: https://github.com/tahmidbintaslim/firebase-ai-mvp
- Assessment: unconfirmed; do not use or test any credentials.

### 2429. P3_LOW_SIGNAL — tarekziade/tinap

- Path: `DNS.rst`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/tarekziade/tinap/blob/bc77a9d81c25e4b292ba71ef995f89f667ba68f5/DNS.rst
- Repository URL: https://github.com/tarekziade/tinap
- Assessment: unconfirmed; do not use or test any credentials.

### 2430. P3_LOW_SIGNAL — tarlepp/links-of-the-week

- Path: `2019.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/tarlepp/links-of-the-week/blob/65a196849002d0a7ba45f45f989604a87105dea9/2019.md
- Repository URL: https://github.com/tarlepp/links-of-the-week
- Assessment: unconfirmed; do not use or test any credentials.

### 2431. P3_LOW_SIGNAL — tcnksm/ghr

- Path: `README.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/tcnksm/ghr/blob/43083d3bbef04a78a967370c11cc760fe19badb6/README.md
- Repository URL: https://github.com/tcnksm/ghr
- Assessment: unconfirmed; do not use or test any credentials.

### 2432. P3_LOW_SIGNAL — tcnksm/ghr

- Path: `cli.go`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/tcnksm/ghr/blob/43083d3bbef04a78a967370c11cc760fe19badb6/cli.go
- Repository URL: https://github.com/tcnksm/ghr
- Assessment: unconfirmed; do not use or test any credentials.

### 2433. P3_LOW_SIGNAL — tebeka/forging-python

- Path: `TODO.md`
- Indicator: `secret_access_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/tebeka/forging-python/blob/434db065e044e7a661d267ee0cd77b3a1cd2dacf/TODO.md
- Repository URL: https://github.com/tebeka/forging-python
- Assessment: unconfirmed; do not use or test any credentials.

### 2434. P3_LOW_SIGNAL — teccod/Demo-Pandas-Analytics

- Path: `dev.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/teccod/Demo-Pandas-Analytics/blob/8edce606c953426ef67c9a4b2403a236ea511f58/dev.md
- Repository URL: https://github.com/teccod/Demo-Pandas-Analytics
- Assessment: unconfirmed; do not use or test any credentials.

### 2435. P3_LOW_SIGNAL — techenthusiast167/D4rk_Intel-OSINT-Investigative-Toolkit

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/techenthusiast167/D4rk_Intel-OSINT-Investigative-Toolkit/blob/c494a64f8f95a49ec0365150f6131089abc9bf69/README.md
- Repository URL: https://github.com/techenthusiast167/D4rk_Intel-OSINT-Investigative-Toolkit
- Assessment: unconfirmed; do not use or test any credentials.

### 2436. P3_LOW_SIGNAL — tedsungjinhwang-stack/Youtube-tiktok-trend-finder

- Path: `SPEC.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/tedsungjinhwang-stack/Youtube-tiktok-trend-finder/blob/b25429a48810bdbfb8b262fff1b5a947e343d02d/SPEC.md
- Repository URL: https://github.com/tedsungjinhwang-stack/Youtube-tiktok-trend-finder
- Assessment: unconfirmed; do not use or test any credentials.

### 2437. P3_LOW_SIGNAL — teemulehtinen/llama-cli

- Path: `PyPI.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/teemulehtinen/llama-cli/blob/ab5e54c454e405d0651e54134aa1d1c99988d5ad/PyPI.md
- Repository URL: https://github.com/teemulehtinen/llama-cli
- Assessment: unconfirmed; do not use or test any credentials.

### 2438. P3_LOW_SIGNAL — teemulehtinen/qlcpy

- Path: `PyPI.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/teemulehtinen/qlcpy/blob/ed4f37193d44ddf5bd20ab0ef545d0242c56e628/PyPI.md
- Repository URL: https://github.com/teemulehtinen/qlcpy
- Assessment: unconfirmed; do not use or test any credentials.

### 2439. P3_LOW_SIGNAL — th30d4y/OpenLearnX

- Path: `dev.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/th30d4y/OpenLearnX/blob/375a6cec8440f06b3935d80ab6eb5cc3a58b2adf/dev.md
- Repository URL: https://github.com/th30d4y/OpenLearnX
- Assessment: unconfirmed; do not use or test any credentials.

### 2440. P3_LOW_SIGNAL — th3Wheel/nmapping-plus

- Path: `gh-auth.txt`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/th3Wheel/nmapping-plus/blob/3cf699ca1a59f582e0ac5751ab3e7586eccdaf9f/gh-auth.txt
- Repository URL: https://github.com/th3Wheel/nmapping-plus
- Assessment: unconfirmed; do not use or test any credentials.

### 2441. P3_LOW_SIGNAL — thecodix/terrabook

- Path: `.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/thecodix/terrabook/blob/43aa0059332a6e95a5de75ebd60b258ed6c9ccba/.terraform.tfstate.lock.info
- Repository URL: https://github.com/thecodix/terrabook
- Assessment: unconfirmed; do not use or test any credentials.

### 2442. P3_LOW_SIGNAL — thedapperdev/deep-research-hub-mcp

- Path: `FAQ.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/thedapperdev/deep-research-hub-mcp/blob/b5afba7ed9f33b3cfd96b69b1e1accd072488e25/FAQ.md
- Repository URL: https://github.com/thedapperdev/deep-research-hub-mcp
- Assessment: unconfirmed; do not use or test any credentials.

### 2443. P3_LOW_SIGNAL — themalwarenews/Trinetra

- Path: `api.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/themalwarenews/Trinetra/blob/6a3f6de00e662d9fa0f963db63a5b0498d072168/api.md
- Repository URL: https://github.com/themalwarenews/Trinetra
- Assessment: unconfirmed; do not use or test any credentials.

### 2444. P3_LOW_SIGNAL — themrsami/advanced-markdown

- Path: `SETUP.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/themrsami/advanced-markdown/blob/157a8b42786afc43fcddce2da7be50850aa15c95/SETUP.md
- Repository URL: https://github.com/themrsami/advanced-markdown
- Assessment: unconfirmed; do not use or test any credentials.

### 2445. P3_LOW_SIGNAL — theprideofwolves/creddrift

- Path: `spec.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/theprideofwolves/creddrift/blob/34b0f1938c6a52dda54a221e8d465a9d6b997783/spec.md
- Repository URL: https://github.com/theprideofwolves/creddrift
- Assessment: unconfirmed; do not use or test any credentials.

### 2446. P3_LOW_SIGNAL — thrashr888/AllBeads

- Path: `demo.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/thrashr888/AllBeads/blob/e85caf14e6aa658fd159ad7559901be29f14e7a1/demo.md
- Repository URL: https://github.com/thrashr888/AllBeads
- Assessment: unconfirmed; do not use or test any credentials.

### 2447. P3_LOW_SIGNAL — tian0o0/booji

- Path: `FAQ.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/tian0o0/booji/blob/c5ae8d0bca58155d598567c8c5d1dffa29338ca5/FAQ.md
- Repository URL: https://github.com/tian0o0/booji
- Assessment: unconfirmed; do not use or test any credentials.

### 2448. P3_LOW_SIGNAL — tianmingyun/MasterBitcoin2CN

- Path: `ch04.md`
- Indicator: `private_key_label;secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/tianmingyun/MasterBitcoin2CN/blob/4dfc1564b68a48004cb317281352b55f60810c9a/ch04.md
- Repository URL: https://github.com/tianmingyun/MasterBitcoin2CN
- Assessment: unconfirmed; do not use or test any credentials.

### 2449. P3_LOW_SIGNAL — tidal-music/cw-alert-router

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/tidal-music/cw-alert-router/blob/be831093548902026ea5f8e2c09360d14cdc34cb/README.md
- Repository URL: https://github.com/tidal-music/cw-alert-router
- Assessment: unconfirmed; do not use or test any credentials.

### 2450. P3_LOW_SIGNAL — timboudreau/acteur

- Path: `FAQ.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/timboudreau/acteur/blob/1b273e55ab5ae7e387fc7452b0a956f41122709f/FAQ.md
- Repository URL: https://github.com/timboudreau/acteur
- Assessment: unconfirmed; do not use or test any credentials.

### 2451. P3_LOW_SIGNAL — tinabme/up-wrytr

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/tinabme/up-wrytr/blob/4f91904794af07b4bdaf70d121744d12b48564d4/SETUP.md
- Repository URL: https://github.com/tinabme/up-wrytr
- Assessment: unconfirmed; do not use or test any credentials.

### 2452. P3_LOW_SIGNAL — tiy-sat/fee-boilerplate

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/tiy-sat/fee-boilerplate/blob/7a86d49939b24de8ba8e61e3ac38846086b5d4fc/README.md
- Repository URL: https://github.com/tiy-sat/fee-boilerplate
- Assessment: unconfirmed; do not use or test any credentials.

### 2453. P3_LOW_SIGNAL — tiy-sat/fee-boilerplate-react-rails

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/tiy-sat/fee-boilerplate-react-rails/blob/f0ddf95f13391c3494782ee8c23dcf4bf6f7218c/README.md
- Repository URL: https://github.com/tiy-sat/fee-boilerplate-react-rails
- Assessment: unconfirmed; do not use or test any credentials.

### 2454. P3_LOW_SIGNAL — tlsfuzzer/python-ecdsa

- Path: `NEWS`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/tlsfuzzer/python-ecdsa/blob/bff40c6cf2340148d410d5b3def0e949c547caf1/NEWS
- Repository URL: https://github.com/tlsfuzzer/python-ecdsa
- Assessment: unconfirmed; do not use or test any credentials.

### 2455. P3_LOW_SIGNAL — toadsage01/job-scraper

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/toadsage01/job-scraper/blob/3f211988f550fcacbd3bf9825322b8587584f406/README.md
- Repository URL: https://github.com/toadsage01/job-scraper
- Assessment: unconfirmed; do not use or test any credentials.

### 2456. P3_LOW_SIGNAL — toba/about

- Path: `usage.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/toba/about/blob/b19ad52059727dd05a29db82e64af9951be1e01b/usage.md
- Repository URL: https://github.com/toba/about
- Assessment: unconfirmed; do not use or test any credentials.

### 2457. P3_LOW_SIGNAL — tomeraitz/claude-slack-bridge

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/tomeraitz/claude-slack-bridge/blob/003b0ae8e2a64f49d6d9d563583779b109fedb62/README.md
- Repository URL: https://github.com/tomeraitz/claude-slack-bridge
- Assessment: unconfirmed; do not use or test any credentials.

### 2458. P3_LOW_SIGNAL — tomerhakak/agentprobe

- Path: `SPEC.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/tomerhakak/agentprobe/blob/e813615a5aeacd68810a033bedf1aae5bcef8398/SPEC.md
- Repository URL: https://github.com/tomerhakak/agentprobe
- Assessment: unconfirmed; do not use or test any credentials.

### 2459. P3_LOW_SIGNAL — tonistiigi/go-actions-cache

- Path: `api.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/tonistiigi/go-actions-cache/blob/afe8013b5ac4e896742874e352edceff974e6fec/api.md
- Repository URL: https://github.com/tonistiigi/go-actions-cache
- Assessment: unconfirmed; do not use or test any credentials.

### 2460. P3_LOW_SIGNAL — toshvelaga/wavvy-clean

- Path: `env.txt`
- Indicator: `password_assignment;secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/toshvelaga/wavvy-clean/blob/ea0970628597c858996321846d54c8fef7911064/env.txt
- Repository URL: https://github.com/toshvelaga/wavvy-clean
- Assessment: unconfirmed; do not use or test any credentials.

### 2461. P3_LOW_SIGNAL — tphzero/tphzero-copilot

- Path: `SPEC.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/tphzero/tphzero-copilot/blob/d7e0c3f71db447329f44d3908d9c3c33927a6adf/SPEC.md
- Repository URL: https://github.com/tphzero/tphzero-copilot
- Assessment: unconfirmed; do not use or test any credentials.

### 2462. P3_LOW_SIGNAL — trackstarhq/react-trackstar-link

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/trackstarhq/react-trackstar-link/blob/9ff75299f39bfcd300273a230038355d70198205/README.md
- Repository URL: https://github.com/trackstarhq/react-trackstar-link
- Assessment: unconfirmed; do not use or test any credentials.

### 2463. P3_LOW_SIGNAL — traksha-tattvashila/Traksha-Backend

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/traksha-tattvashila/Traksha-Backend/blob/694bd945f9b27760aa3da16b8e70b47b5db08113/API.md
- Repository URL: https://github.com/traksha-tattvashila/Traksha-Backend
- Assessment: unconfirmed; do not use or test any credentials.

### 2464. P3_LOW_SIGNAL — travis-ci/travis-yaml

- Path: `SPEC.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/travis-ci/travis-yaml/blob/5b5fe819ac789bfc238bd3c82331e36a1cb0ca1b/SPEC.md
- Repository URL: https://github.com/travis-ci/travis-yaml
- Assessment: unconfirmed; do not use or test any credentials.

### 2465. P3_LOW_SIGNAL — travis-ci/travis-yml

- Path: `TIPS.md`
- Indicator: `secret_access_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/travis-ci/travis-yml/blob/8d6f36f765b0c03da73afe4f8d493d290de06296/TIPS.md
- Repository URL: https://github.com/travis-ci/travis-yml
- Assessment: unconfirmed; do not use or test any credentials.

### 2466. P3_LOW_SIGNAL — travisghansen/external-auth-server

- Path: `HOWTO.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/travisghansen/external-auth-server/blob/c3337e05ebc581dc5e79d31b9d844076439ecc85/HOWTO.md
- Repository URL: https://github.com/travisghansen/external-auth-server
- Assessment: unconfirmed; do not use or test any credentials.

### 2467. P3_LOW_SIGNAL — treyorr/pocket-agents

- Path: `PRD.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/treyorr/pocket-agents/blob/79647efa24bb4fcccf4f69492fe0bd4812cb6903/PRD.md
- Repository URL: https://github.com/treyorr/pocket-agents
- Assessment: unconfirmed; do not use or test any credentials.

### 2468. P3_LOW_SIGNAL — trilogy-group/Lyncas

- Path: `rules.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/trilogy-group/Lyncas/blob/cbd433c3f7ce8611ff5b2c994c6af1c456d83598/rules.md
- Repository URL: https://github.com/trilogy-group/Lyncas
- Assessment: unconfirmed; do not use or test any credentials.

### 2469. P3_LOW_SIGNAL — truval-dev/truval-mcp-server

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/truval-dev/truval-mcp-server/blob/4dd066ac797a6ae206192e87c2833818c791ee03/README.md
- Repository URL: https://github.com/truval-dev/truval-mcp-server
- Assessment: unconfirmed; do not use or test any credentials.

### 2470. P3_LOW_SIGNAL — tsehla42/copilot-quota-planner

- Path: `README.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/tsehla42/copilot-quota-planner/blob/bd123ef486ca49c7beff9b371d002f532e19187a/README.md
- Repository URL: https://github.com/tsehla42/copilot-quota-planner
- Assessment: unconfirmed; do not use or test any credentials.

### 2471. P3_LOW_SIGNAL — tsutoringo/github-app-proxy

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/tsutoringo/github-app-proxy/blob/713fd75b65188ab0e8c9da79f904c5dee9e88f8e/README.md
- Repository URL: https://github.com/tsutoringo/github-app-proxy
- Assessment: unconfirmed; do not use or test any credentials.

### 2472. P3_LOW_SIGNAL — ttarvis/hexlock

- Path: `CHANGELOG.md`
- Indicator: `github_oauth_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ttarvis/hexlock/blob/7ae494e73e02776d566a668daefcbe03155c577e/CHANGELOG.md
- Repository URL: https://github.com/ttarvis/hexlock
- Assessment: unconfirmed; do not use or test any credentials.

### 2473. P3_LOW_SIGNAL — tungstenfabric/tf-charms

- Path: `issu.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/tungstenfabric/tf-charms/blob/e4357ffa8ddeffed7d857cd6565a21e500af8d6b/issu.md
- Repository URL: https://github.com/tungstenfabric/tf-charms
- Assessment: unconfirmed; do not use or test any credentials.

### 2474. P3_LOW_SIGNAL — twiced-technology-gmbh/vm-control-center

- Path: `API.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/twiced-technology-gmbh/vm-control-center/blob/9cd0737f57ac8d277d748e88db748adff3ad1951/API.md
- Repository URL: https://github.com/twiced-technology-gmbh/vm-control-center
- Assessment: unconfirmed; do not use or test any credentials.

### 2475. P3_LOW_SIGNAL — twitchax/triage-bot

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/twitchax/triage-bot/blob/1ee0dd56efa9da32e2d927cd1030cab3cdba4067/README.md
- Repository URL: https://github.com/twitchax/triage-bot
- Assessment: unconfirmed; do not use or test any credentials.

### 2476. P3_LOW_SIGNAL — u-k-g/nrp

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/u-k-g/nrp/blob/97633c17eaaa297dab9643904300cdd93501919e/README.md
- Repository URL: https://github.com/u-k-g/nrp
- Assessment: unconfirmed; do not use or test any credentials.

### 2477. P3_LOW_SIGNAL — ucav/mozart-router

- Path: `docs/SECURITY.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ucav/mozart-router/blob/4d46e1086ffef3f2aa5550ced852cb6eebf715ac/docs/SECURITY.md
- Repository URL: https://github.com/ucav/mozart-router
- Assessment: unconfirmed; do not use or test any credentials.

### 2478. P3_LOW_SIGNAL — ucrcyber/vulnerable-site

- Path: `HELP.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ucrcyber/vulnerable-site/blob/f4359b301277b7ff61442ca62eee6f75a4873248/HELP.md
- Repository URL: https://github.com/ucrcyber/vulnerable-site
- Assessment: unconfirmed; do not use or test any credentials.

### 2479. P3_LOW_SIGNAL — umacloud/umadev

- Path: `CHANGELOG.md`
- Indicator: `github_app_token_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/umacloud/umadev/blob/4fe51fa2cd67afd0a170c548984f285133aeb32d/CHANGELOG.md
- Repository URL: https://github.com/umacloud/umadev
- Assessment: unconfirmed; do not use or test any credentials.

### 2480. P3_LOW_SIGNAL — uncenter/learn-eleventy

- Path: `2.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/uncenter/learn-eleventy/blob/c47f8ad2ba2a921d94ed381c70239cc9f0955b0e/2.md
- Repository URL: https://github.com/uncenter/learn-eleventy
- Assessment: unconfirmed; do not use or test any credentials.

### 2481. P3_LOW_SIGNAL — understanding-astro/understanding-astro-book

- Path: `ch7.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/understanding-astro/understanding-astro-book/blob/da59245cebe87c59f994113f4edbf372d898490b/ch7.md
- Repository URL: https://github.com/understanding-astro/understanding-astro-book
- Assessment: unconfirmed; do not use or test any credentials.

### 2482. P3_LOW_SIGNAL — unicef/adt-chat-editor

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/unicef/adt-chat-editor/blob/c5d8d083fbcb21ebc16d733d92ddd2a49f86c470/README.md
- Repository URL: https://github.com/unicef/adt-chat-editor
- Assessment: unconfirmed; do not use or test any credentials.

### 2483. P3_LOW_SIGNAL — universal-mcp/universal-mcp

- Path: `docs/api/client.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/universal-mcp/universal-mcp/blob/2553e33b3e574b7bab5d063ccdecd5c217987258/docs/api/client.md
- Repository URL: https://github.com/universal-mcp/universal-mcp
- Assessment: unconfirmed; do not use or test any credentials.

### 2484. P3_LOW_SIGNAL — uog-cose/cronmon

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/uog-cose/cronmon/blob/e2cb14884ab074cdc68f32659104d7f6b96310d4/API.md
- Repository URL: https://github.com/uog-cose/cronmon
- Assessment: unconfirmed; do not use or test any credentials.

### 2485. P3_LOW_SIGNAL — upendrapanwar/payearth

- Path: `env.txt`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/upendrapanwar/payearth/blob/eb062b04f650d8b7aaa51fbe5c063346cdb3e057/env.txt
- Repository URL: https://github.com/upendrapanwar/payearth
- Assessment: unconfirmed; do not use or test any credentials.

### 2486. P3_LOW_SIGNAL — uris77/tdd_fractions

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/uris77/tdd_fractions/blob/b509f3c7cbbb5c7589753c6199870fb8b7d2d405/README.md
- Repository URL: https://github.com/uris77/tdd_fractions
- Assessment: unconfirmed; do not use or test any credentials.

### 2487. P3_LOW_SIGNAL — usercodeX-creator/Trace-core

- Path: `docs/specs/SPEC_03.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/usercodeX-creator/Trace-core/blob/6aafce96a147c10030d3039c23ac760bc01b6c8d/docs/specs/SPEC_03.md
- Repository URL: https://github.com/usercodeX-creator/Trace-core
- Assessment: unconfirmed; do not use or test any credentials.

### 2488. P3_LOW_SIGNAL — usrz/js-errorlog

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/usrz/js-errorlog/blob/561901146d38abba31bbc52573b86b7edbc94d9f/README.md
- Repository URL: https://github.com/usrz/js-errorlog
- Assessment: unconfirmed; do not use or test any credentials.

### 2489. P3_LOW_SIGNAL — utilarium/offrecord

- Path: `CHANGELOG.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/utilarium/offrecord/blob/72d5bd20a82cb799443eeef9d895627f96654e99/CHANGELOG.md
- Repository URL: https://github.com/utilarium/offrecord
- Assessment: unconfirmed; do not use or test any credentials.

### 2490. P3_LOW_SIGNAL — valinorintelligence/Gridwolf

- Path: `log.txt`
- Indicator: `github_token_prefix;aws_access_key;aws_secret_key_label;private_key_header;secret_access_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/valinorintelligence/Gridwolf/blob/28feff2852985de2bc19cf57f4c902a905945c0d/log.txt
- Repository URL: https://github.com/valinorintelligence/Gridwolf
- Assessment: unconfirmed; do not use or test any credentials.

### 2491. P3_LOW_SIGNAL — valllabh/hush

- Path: `PERF.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/valllabh/hush/blob/eda51ba739d663034217389bb71de1b6c101a41f/PERF.md
- Repository URL: https://github.com/valllabh/hush
- Assessment: unconfirmed; do not use or test any credentials.

### 2492. P3_LOW_SIGNAL — vanshaggarwal27/LeetcodeAI

- Path: `FAQ.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/vanshaggarwal27/LeetcodeAI/blob/1b3dfea121e1a4f44104558ba99ee80ffa24a2d4/FAQ.md
- Repository URL: https://github.com/vanshaggarwal27/LeetcodeAI
- Assessment: unconfirmed; do not use or test any credentials.

### 2493. P3_LOW_SIGNAL — varu3/slack-approval

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/varu3/slack-approval/blob/70949f527f3f68b065978c7fd6fc25ff5dde61b5/README.md
- Repository URL: https://github.com/varu3/slack-approval
- Assessment: unconfirmed; do not use or test any credentials.

### 2494. P3_LOW_SIGNAL — varunsridharan/demo-action-hashnode-blog

- Path: `blog.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/varunsridharan/demo-action-hashnode-blog/blob/29f053bc5c7e27e59888b2ef22816c1a732eaa41/blog.md
- Repository URL: https://github.com/varunsridharan/demo-action-hashnode-blog
- Assessment: unconfirmed; do not use or test any credentials.

### 2495. P3_LOW_SIGNAL — varunsridharan/demo-action-hashnode-blog

- Path: `list.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/varunsridharan/demo-action-hashnode-blog/blob/29f053bc5c7e27e59888b2ef22816c1a732eaa41/list.md
- Repository URL: https://github.com/varunsridharan/demo-action-hashnode-blog
- Assessment: unconfirmed; do not use or test any credentials.

### 2496. P3_LOW_SIGNAL — vbem/multi-runners

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/vbem/multi-runners/blob/4555f518498c28f035bb38e744c98234865c3d1a/README.md
- Repository URL: https://github.com/vbem/multi-runners
- Assessment: unconfirmed; do not use or test any credentials.

### 2497. P3_LOW_SIGNAL — vchrombie/grimoirelab-perceval-zulip

- Path: `NEWS`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/vchrombie/grimoirelab-perceval-zulip/blob/203ec1ad5970b8a856b22738422d8c924799af98/NEWS
- Repository URL: https://github.com/vchrombie/grimoirelab-perceval-zulip
- Assessment: unconfirmed; do not use or test any credentials.

### 2498. P3_LOW_SIGNAL — venumurthy/lo

- Path: `3.md`
- Indicator: `password_assignment;secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/venumurthy/lo/blob/67f1208aa16a08668203ec5c5e74ecac8e73a3d7/3.md
- Repository URL: https://github.com/venumurthy/lo
- Assessment: unconfirmed; do not use or test any credentials.

### 2499. P3_LOW_SIGNAL — venumurthy/lo

- Path: `6.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/venumurthy/lo/blob/67f1208aa16a08668203ec5c5e74ecac8e73a3d7/6.md
- Repository URL: https://github.com/venumurthy/lo
- Assessment: unconfirmed; do not use or test any credentials.

### 2500. P3_LOW_SIGNAL — vercel-labs/trackcn

- Path: `SPEC.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/vercel-labs/trackcn/blob/a58281cf07f35ee9a65fd1b688bc4f4be15656a4/SPEC.md
- Repository URL: https://github.com/vercel-labs/trackcn
- Assessment: unconfirmed; do not use or test any credentials.

### 2501. P3_LOW_SIGNAL — verseles/ask

- Path: `ADR.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/verseles/ask/blob/1cd6a3ac51a2002b9fdd58826668922f2ae13098/ADR.md
- Repository URL: https://github.com/verseles/ask
- Assessment: unconfirmed; do not use or test any credentials.

### 2502. P3_LOW_SIGNAL — vibetemplate/vibecli

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/vibetemplate/vibecli/blob/0a53fdb77a2aa710f16dc8d3eb65a376b7ed8b1a/API.md
- Repository URL: https://github.com/vibetemplate/vibecli
- Assessment: unconfirmed; do not use or test any credentials.

### 2503. P3_LOW_SIGNAL — vincenzo-afk/Proctored-MCQ-Exam-Platform

- Path: `plan.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/vincenzo-afk/Proctored-MCQ-Exam-Platform/blob/263344a6cb8d35fae3a2e8ac79b1e86e40913f1e/plan.md
- Repository URL: https://github.com/vincenzo-afk/Proctored-MCQ-Exam-Platform
- Assessment: unconfirmed; do not use or test any credentials.

### 2504. P3_LOW_SIGNAL — vinkius-labs/mcpfusion

- Path: `llms.txt`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/vinkius-labs/mcpfusion/blob/1dab5017c9ed9f53bc57e57f4a4a6456b586923a/llms.txt
- Repository URL: https://github.com/vinkius-labs/mcpfusion
- Assessment: unconfirmed; do not use or test any credentials.

### 2505. P3_LOW_SIGNAL — vishalmysore/lllmwikiZZ

- Path: `spec.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/vishalmysore/lllmwikiZZ/blob/bfbff42283e9afc9a61d8c2ed9016cb7977e88f5/spec.md
- Repository URL: https://github.com/vishalmysore/lllmwikiZZ
- Assessment: unconfirmed; do not use or test any credentials.

### 2506. P3_LOW_SIGNAL — vishnunandan555/top-contributors-api

- Path: `V2.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/vishnunandan555/top-contributors-api/blob/83619159c2dbad44e30aea4dc38dbc3a88486db0/V2.md
- Repository URL: https://github.com/vishnunandan555/top-contributors-api
- Assessment: unconfirmed; do not use or test any credentials.

### 2507. P3_LOW_SIGNAL — vitalops/openvibe

- Path: `mcp.md`
- Indicator: `access_token_label;github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/vitalops/openvibe/blob/17eb6ecc4e20590aaf03714f2a1f9f6b726ef253/mcp.md
- Repository URL: https://github.com/vitalops/openvibe
- Assessment: unconfirmed; do not use or test any credentials.

### 2508. P3_LOW_SIGNAL — vladkens/ghstats

- Path: `readme.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/vladkens/ghstats/blob/bfa5a13e9a520b695292f307ca774034eb20ceec/readme.md
- Repository URL: https://github.com/vladkens/ghstats
- Assessment: unconfirmed; do not use or test any credentials.

### 2509. P3_LOW_SIGNAL — volt-api/volt

- Path: `docs/security.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/volt-api/volt/blob/9f55fb1a8c13dbe526172af665fbeeedd3571407/docs/security.md
- Repository URL: https://github.com/volt-api/volt
- Assessment: unconfirmed; do not use or test any credentials.

### 2510. P3_LOW_SIGNAL — voxislabs-crypto/Merlin-the-personal-Oracle

- Path: `DEPLOY.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/voxislabs-crypto/Merlin-the-personal-Oracle/blob/8dda8513466297e5f688e98459818f7da43c29d8/DEPLOY.md
- Repository URL: https://github.com/voxislabs-crypto/Merlin-the-personal-Oracle
- Assessment: unconfirmed; do not use or test any credentials.

### 2511. P3_LOW_SIGNAL — voxpelli/eslint-formatter-summary

- Path: `README.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/voxpelli/eslint-formatter-summary/blob/46ddec6236f57a94a39530f52da20e05cdccf05d/README.md
- Repository URL: https://github.com/voxpelli/eslint-formatter-summary
- Assessment: unconfirmed; do not use or test any credentials.

### 2512. P3_LOW_SIGNAL — vs4vijay/gaesuperadmin

- Path: `eg.txt`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/vs4vijay/gaesuperadmin/blob/67f57396ec467e081cb2402eeff86cd5ea2f6938/eg.txt
- Repository URL: https://github.com/vs4vijay/gaesuperadmin
- Assessment: unconfirmed; do not use or test any credentials.

### 2513. P3_LOW_SIGNAL — vtemian/sisif-ai-mcp

- Path: `USAGE.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/vtemian/sisif-ai-mcp/blob/9008ecca86d52354c54ef2335802e286cc7dc061/USAGE.md
- Repository URL: https://github.com/vtemian/sisif-ai-mcp
- Assessment: unconfirmed; do not use or test any credentials.

### 2514. P3_LOW_SIGNAL — w00kie/kagishi

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/w00kie/kagishi/blob/2d62aed4de2e5c8ec057f68c492916a19335d70f/README.md
- Repository URL: https://github.com/w00kie/kagishi
- Assessment: unconfirmed; do not use or test any credentials.

### 2515. P3_LOW_SIGNAL — walterbender/training

- Path: `NEWS`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/walterbender/training/blob/870b88b2611337cd5768fb7db6bd644726bf5123/NEWS
- Repository URL: https://github.com/walterbender/training
- Assessment: unconfirmed; do not use or test any credentials.

### 2516. P3_LOW_SIGNAL — wanth1997/python-wooX

- Path: `README.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/wanth1997/python-wooX/blob/94a7512444f909e1c84806ec49918aa6283a306b/README.md
- Repository URL: https://github.com/wanth1997/python-wooX
- Assessment: unconfirmed; do not use or test any credentials.

### 2517. P3_LOW_SIGNAL — webferrol/technical-trial-junior-react

- Path: `README.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/webferrol/technical-trial-junior-react/blob/f828c793c013a75bac829ffb0c40b2db2c65f199/README.md
- Repository URL: https://github.com/webferrol/technical-trial-junior-react
- Assessment: unconfirmed; do not use or test any credentials.

### 2518. P3_LOW_SIGNAL — webflow/ctxcop

- Path: `docs/detection.md`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/webflow/ctxcop/blob/4f771bdb21ab3266d8b6dbc22c4de62b449c718f/docs/detection.md
- Repository URL: https://github.com/webflow/ctxcop
- Assessment: unconfirmed; do not use or test any credentials.

### 2519. P3_LOW_SIGNAL — wham/github-brain

- Path: `main.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/wham/github-brain/blob/dd4d9b0058e99a6857f9aacb0aa39444f9096848/main.md
- Repository URL: https://github.com/wham/github-brain
- Assessment: unconfirmed; do not use or test any credentials.

### 2520. P3_LOW_SIGNAL — whirlxd/slack-music-status

- Path: `nest.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/whirlxd/slack-music-status/blob/e4bf79f031d1ff0363c6e09774a9c8bebbb567c6/nest.md
- Repository URL: https://github.com/whirlxd/slack-music-status
- Assessment: unconfirmed; do not use or test any credentials.

### 2521. P3_LOW_SIGNAL — williamtu/ovs-ebpf

- Path: `NEWS`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/williamtu/ovs-ebpf/blob/8890b714cbbe4781e5a130d144908b1cebec9740/NEWS
- Repository URL: https://github.com/williamtu/ovs-ebpf
- Assessment: unconfirmed; do not use or test any credentials.

### 2522. P3_LOW_SIGNAL — wilsonwonghk1116/transcendent-comm-project

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/wilsonwonghk1116/transcendent-comm-project/blob/56c0dbcfa4b564535065ec925d508122bb8a420f/API.md
- Repository URL: https://github.com/wilsonwonghk1116/transcendent-comm-project
- Assessment: unconfirmed; do not use or test any credentials.

### 2523. P3_LOW_SIGNAL — win1082576/enough

- Path: `SETUP.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/win1082576/enough/blob/f03ce55ade28306d68983177947d6fe9e0e3f934/SETUP.md
- Repository URL: https://github.com/win1082576/enough
- Assessment: unconfirmed; do not use or test any credentials.

### 2524. P3_LOW_SIGNAL — windmill-labs/windmillhub-helm-charts

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/windmill-labs/windmillhub-helm-charts/blob/7e43ab25c52a32324c10db8cbd1af4301258e4d6/README.md
- Repository URL: https://github.com/windmill-labs/windmillhub-helm-charts
- Assessment: unconfirmed; do not use or test any credentials.

### 2525. P3_LOW_SIGNAL — wiwa1978/blog-hugo-netlify-code

- Path: `Terraform/MSO/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/wiwa1978/blog-hugo-netlify-code/blob/b0fee024cd02131d223ea232b3d930479b9fcfb1/Terraform/MSO/.terraform.tfstate.lock.info
- Repository URL: https://github.com/wiwa1978/blog-hugo-netlify-code
- Assessment: unconfirmed; do not use or test any credentials.

### 2526. P3_LOW_SIGNAL — wizardforcel/android-app-sec-guidebook-zh

- Path: `5.1.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/wizardforcel/android-app-sec-guidebook-zh/blob/6a7c967ea8090e4c3fb1b5f56f5abd5edcd08635/5.1.md
- Repository URL: https://github.com/wizardforcel/android-app-sec-guidebook-zh
- Assessment: unconfirmed; do not use or test any credentials.

### 2527. P3_LOW_SIGNAL — wizardforcel/web-hacking-101-zh

- Path: `11.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/wizardforcel/web-hacking-101-zh/blob/3263d493355f70beae4e2ac5178532ca09bf54c4/11.md
- Repository URL: https://github.com/wizardforcel/web-hacking-101-zh
- Assessment: unconfirmed; do not use or test any credentials.

### 2528. P3_LOW_SIGNAL — wizardforcel/web-hacking-101-zh

- Path: `13.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/wizardforcel/web-hacking-101-zh/blob/3263d493355f70beae4e2ac5178532ca09bf54c4/13.md
- Repository URL: https://github.com/wizardforcel/web-hacking-101-zh
- Assessment: unconfirmed; do not use or test any credentials.

### 2529. P3_LOW_SIGNAL — wongsyrone/LinuxNotes

- Path: `01.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/wongsyrone/LinuxNotes/blob/917d9b81c198756156de783f978dc6a781c3f2ab/01.md
- Repository URL: https://github.com/wongsyrone/LinuxNotes
- Assessment: unconfirmed; do not use or test any credentials.

### 2530. P3_LOW_SIGNAL — woodpecker-ci/plugin-deployments

- Path: `docs.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/woodpecker-ci/plugin-deployments/blob/26a6e5ea3fec716718d05a483092817bc1feae66/docs.md
- Repository URL: https://github.com/woodpecker-ci/plugin-deployments
- Assessment: unconfirmed; do not use or test any credentials.

### 2531. P3_LOW_SIGNAL — woodpecker-ci/plugin-ready-release-go

- Path: `docs.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/woodpecker-ci/plugin-ready-release-go/blob/d0c87ce63b696a4d4afa3cf991f0fc341374b1d1/docs.md
- Repository URL: https://github.com/woodpecker-ci/plugin-ready-release-go
- Assessment: unconfirmed; do not use or test any credentials.

### 2532. P3_LOW_SIGNAL — woori-doweb/server-monitor-deploy

- Path: `CONTRIBUTING.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/woori-doweb/server-monitor-deploy/blob/7e3c3d9795e43eeacebcd8907756f05e87a18917/CONTRIBUTING.md
- Repository URL: https://github.com/woori-doweb/server-monitor-deploy
- Assessment: unconfirmed; do not use or test any credentials.

### 2533. P3_LOW_SIGNAL — workstying-cloud/permitassistpro

- Path: `README.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/workstying-cloud/permitassistpro/blob/171128a6c0e3852d484792af548b56f92b40cee4/README.md
- Repository URL: https://github.com/workstying-cloud/permitassistpro
- Assessment: unconfirmed; do not use or test any credentials.

### 2534. P3_LOW_SIGNAL — worldline/scala-cheatsheet

- Path: `index.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/worldline/scala-cheatsheet/blob/a271930ed5b2019210cb9e892f369bdc3d25f500/index.md
- Repository URL: https://github.com/worldline/scala-cheatsheet
- Assessment: unconfirmed; do not use or test any credentials.

### 2535. P3_LOW_SIGNAL — wwmoraes/dotfiles

- Path: `TODO.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/wwmoraes/dotfiles/blob/f570c1a9ad115313c8cd4dcf30e9bf41ebe53dc1/TODO.md
- Repository URL: https://github.com/wwmoraes/dotfiles
- Assessment: unconfirmed; do not use or test any credentials.

### 2536. P3_LOW_SIGNAL — wyattjoh/ims

- Path: `README.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/wyattjoh/ims/blob/87fc7e1704ba17237affa9edc4d0dcf753f93f42/README.md
- Repository URL: https://github.com/wyattjoh/ims
- Assessment: unconfirmed; do not use or test any credentials.

### 2537. P3_LOW_SIGNAL — xHemera/gem

- Path: `AGENTS.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/xHemera/gem/blob/cba01f573bcfaae6493b3575af97aa2d3d244714/AGENTS.md
- Repository URL: https://github.com/xHemera/gem
- Assessment: unconfirmed; do not use or test any credentials.

### 2538. P3_LOW_SIGNAL — xcat2/terraform-provider-xcat

- Path: `templates/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/xcat2/terraform-provider-xcat/blob/57a9c6730df3414f00bfa00769eb5d3092e37d6a/templates/.terraform.tfstate.lock.info
- Repository URL: https://github.com/xcat2/terraform-provider-xcat
- Assessment: unconfirmed; do not use or test any credentials.

### 2539. P3_LOW_SIGNAL — xcat2/terraform-provider-xcat

- Path: `templates/devcluster/.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/xcat2/terraform-provider-xcat/blob/57a9c6730df3414f00bfa00769eb5d3092e37d6a/templates/devcluster/.terraform.tfstate.lock.info
- Repository URL: https://github.com/xcat2/terraform-provider-xcat
- Assessment: unconfirmed; do not use or test any credentials.

### 2540. P3_LOW_SIGNAL — xiaotianxt/skills

- Path: `SECURITY.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/xiaotianxt/skills/blob/da848a1042545dc707889693efe436cce3cb37d1/SECURITY.md
- Repository URL: https://github.com/xiaotianxt/skills
- Assessment: unconfirmed; do not use or test any credentials.

### 2541. P3_LOW_SIGNAL — xiarimangguo/aLive2D

- Path: `up.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/xiarimangguo/aLive2D/blob/9955f83db0a88144109c997f34eadb6166a9be40/up.md
- Repository URL: https://github.com/xiarimangguo/aLive2D
- Assessment: unconfirmed; do not use or test any credentials.

### 2542. P3_LOW_SIGNAL — xiii-123/AI-Job-Search-Assistant

- Path: `API.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/xiii-123/AI-Job-Search-Assistant/blob/be94da801b5727f6fcef434faa500652391b6800/API.md
- Repository URL: https://github.com/xiii-123/AI-Job-Search-Assistant
- Assessment: unconfirmed; do not use or test any credentials.

### 2543. P3_LOW_SIGNAL — xike110/OpenCode-Python-SDK

- Path: `docs/auth.md`
- Indicator: `github_oauth_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/xike110/OpenCode-Python-SDK/blob/976b4c8cadbcc248fd4936e55b6a61a3a202306a/docs/auth.md
- Repository URL: https://github.com/xike110/OpenCode-Python-SDK
- Assessment: unconfirmed; do not use or test any credentials.

### 2544. P3_LOW_SIGNAL — xkiwilabs/Urika

- Path: `CHANGELOG.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/xkiwilabs/Urika/blob/49775d58bf0ee7822bf4277e0b9dd46885bcfd89/CHANGELOG.md
- Repository URL: https://github.com/xkiwilabs/Urika
- Assessment: unconfirmed; do not use or test any credentials.

### 2545. P3_LOW_SIGNAL — xpeedo/github-copilot-unlimited

- Path: `README.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/xpeedo/github-copilot-unlimited/blob/fb1647b904607cc02cbd210cc77ec9a092a224f4/README.md
- Repository URL: https://github.com/xpeedo/github-copilot-unlimited
- Assessment: unconfirmed; do not use or test any credentials.

### 2546. P3_LOW_SIGNAL — xsa/infosec-events

- Path: `2025.md`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/xsa/infosec-events/blob/a43470a508b5837d14713ea6cb10cb59195f29a8/2025.md
- Repository URL: https://github.com/xsa/infosec-events
- Assessment: unconfirmed; do not use or test any credentials.

### 2547. P3_LOW_SIGNAL — xssnick/ton-payment-network

- Path: `API.md`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/xssnick/ton-payment-network/blob/7de7368563734b291dfac194f791512514631560/API.md
- Repository URL: https://github.com/xssnick/ton-payment-network
- Assessment: unconfirmed; do not use or test any credentials.

### 2548. P3_LOW_SIGNAL — xxfast/kotlin-native-nuget

- Path: `STYLE.md`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/xxfast/kotlin-native-nuget/blob/f3ff75a0ff914d85180f8aa72a9cba6b1c45f44c/STYLE.md
- Repository URL: https://github.com/xxfast/kotlin-native-nuget
- Assessment: unconfirmed; do not use or test any credentials.

### 2549. P3_LOW_SIGNAL — yahav10/claude-code-dashboard

- Path: `README.md`
- Indicator: `github_app_token_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/yahav10/claude-code-dashboard/blob/6cb3691e066224b4e0f87975d9f12dd3cbb925b9/README.md
- Repository URL: https://github.com/yahav10/claude-code-dashboard
- Assessment: unconfirmed; do not use or test any credentials.

### 2550. P3_LOW_SIGNAL — yamadatt/sam-aws-cost-slack

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/yamadatt/sam-aws-cost-slack/blob/eb9efd425e4229218a072757248dda04e632a285/README.md
- Repository URL: https://github.com/yamadatt/sam-aws-cost-slack
- Assessment: unconfirmed; do not use or test any credentials.

### 2551. P3_LOW_SIGNAL — yaojenkuo/r_programming

- Path: `ch3.Rmd`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/yaojenkuo/r_programming/blob/2d3ce7361271b76ba40bdb3544e4ba312eac174c/ch3.Rmd
- Repository URL: https://github.com/yaojenkuo/r_programming
- Assessment: unconfirmed; do not use or test any credentials.

### 2552. P3_LOW_SIGNAL — yazilimcimumin/rx

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/yazilimcimumin/rx/blob/aad9f8d000cebab3587d5708d6be9afe815c369b/README.md
- Repository URL: https://github.com/yazilimcimumin/rx
- Assessment: unconfirmed; do not use or test any credentials.

### 2553. P3_LOW_SIGNAL — ybngf/WP-Auto-Content-Pro

- Path: `DOCS.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ybngf/WP-Auto-Content-Pro/blob/86f3d04e87156ebaf8771101c728e6d39bd4d66f/DOCS.md
- Repository URL: https://github.com/ybngf/WP-Auto-Content-Pro
- Assessment: unconfirmed; do not use or test any credentials.

### 2554. P3_LOW_SIGNAL — yellowback/forgejo-claude-code-action

- Path: `FAQ.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/yellowback/forgejo-claude-code-action/blob/5049057421670cca4e56f99d83087b04b1aaecfa/FAQ.md
- Repository URL: https://github.com/yellowback/forgejo-claude-code-action
- Assessment: unconfirmed; do not use or test any credentials.

### 2555. P3_LOW_SIGNAL — yihong0618/2026

- Path: `FAQ.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/yihong0618/2026/blob/6a9a05f215d98fcb03f995097c7d94adec34ecd7/FAQ.md
- Repository URL: https://github.com/yihong0618/2026
- Assessment: unconfirmed; do not use or test any credentials.

### 2556. P3_LOW_SIGNAL — ykhr53/new-bmo

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ykhr53/new-bmo/blob/585edc7d166086c0cc0c72ead64c89c8488c3542/README.md
- Repository URL: https://github.com/ykhr53/new-bmo
- Assessment: unconfirmed; do not use or test any credentials.

### 2557. P3_LOW_SIGNAL — ymaxgit/libhugetlbfs

- Path: `alloc.c`
- Indicator: `github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ymaxgit/libhugetlbfs/blob/e44180072b796c0e28e53c4d01ef6279caaa2a99/alloc.c
- Repository URL: https://github.com/ymaxgit/libhugetlbfs
- Assessment: unconfirmed; do not use or test any credentials.

### 2558. P3_LOW_SIGNAL — ymman1012/SystemIntegration

- Path: `index.md`
- Indicator: `npm_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ymman1012/SystemIntegration/blob/07746dd5075764509ec406247a9e668f38cdff2e/index.md
- Repository URL: https://github.com/ymman1012/SystemIntegration
- Assessment: unconfirmed; do not use or test any credentials.

### 2559. P3_LOW_SIGNAL — yocxy2/chauffeur-app-v2

- Path: `Tasks.md`
- Indicator: `stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/yocxy2/chauffeur-app-v2/blob/d130e4d00449d1875ff3f959eaf9e3fffa2176c8/Tasks.md
- Repository URL: https://github.com/yocxy2/chauffeur-app-v2
- Assessment: unconfirmed; do not use or test any credentials.

### 2560. P3_LOW_SIGNAL — yogthos/cheatsheets

- Path: `git.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/yogthos/cheatsheets/blob/568b75aaedaaf687c31964d647a4c3ba11f949b5/git.md
- Repository URL: https://github.com/yogthos/cheatsheets
- Assessment: unconfirmed; do not use or test any credentials.

### 2561. P3_LOW_SIGNAL — yonaka15/mcp-server-runner

- Path: `README.md`
- Indicator: `github_pat_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/yonaka15/mcp-server-runner/blob/d0e140e2a8d5b072be04562c84d56d17e02cb8a7/README.md
- Repository URL: https://github.com/yonaka15/mcp-server-runner
- Assessment: unconfirmed; do not use or test any credentials.

### 2562. P3_LOW_SIGNAL — yourbuddyconner/super-cuts

- Path: `MVP.md`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/yourbuddyconner/super-cuts/blob/a433c137b72ec6d25fc8feee96d419a27c2c79d2/MVP.md
- Repository URL: https://github.com/yourbuddyconner/super-cuts
- Assessment: unconfirmed; do not use or test any credentials.

### 2563. P3_LOW_SIGNAL — yungookim/oh-my-pr

- Path: `AGENTS.md`
- Indicator: `github_pat_prefix;github_oauth_prefix;github_app_token_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/yungookim/oh-my-pr/blob/16241a704182e005b6a364d8ac645b30ac10db5d/AGENTS.md
- Repository URL: https://github.com/yungookim/oh-my-pr
- Assessment: unconfirmed; do not use or test any credentials.

### 2564. P3_LOW_SIGNAL — yungookim/oh-my-pr

- Path: `README.md`
- Indicator: `github_oauth_prefix;github_app_token_prefix;github_refresh_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/yungookim/oh-my-pr/blob/16241a704182e005b6a364d8ac645b30ac10db5d/README.md
- Repository URL: https://github.com/yungookim/oh-my-pr
- Assessment: unconfirmed; do not use or test any credentials.

### 2565. P3_LOW_SIGNAL — yunsseong/sparkle

- Path: `PRD.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/yunsseong/sparkle/blob/07f12a48cf7ef727b485ec64a1801356d5deb0fb/PRD.md
- Repository URL: https://github.com/yunsseong/sparkle
- Assessment: unconfirmed; do not use or test any credentials.

### 2566. P3_LOW_SIGNAL — yusuke/ideamugen

- Path: `1.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/yusuke/ideamugen/blob/8c02285b521d89dbe7435f54cdd19920643b5009/1.md
- Repository URL: https://github.com/yusuke/ideamugen
- Assessment: unconfirmed; do not use or test any credentials.

### 2567. P3_LOW_SIGNAL — ywpywpywp/The-Flask-Mega-Tutorial

- Path: `ajax.rst`
- Indicator: `secret_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/ywpywpywp/The-Flask-Mega-Tutorial/blob/fd09cd9929fcb13358c6ba3eb3afe85ae64874f4/ajax.rst
- Repository URL: https://github.com/ywpywpywp/The-Flask-Mega-Tutorial
- Assessment: unconfirmed; do not use or test any credentials.

### 2568. P3_LOW_SIGNAL — yyhao0422/terraform_IaC_lab

- Path: `.terraform.tfstate.lock.info`
- Indicator: `terraform_state`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/yyhao0422/terraform_IaC_lab/blob/7899c0377a52de2415c03e47f57f03b1ce73926e/.terraform.tfstate.lock.info
- Repository URL: https://github.com/yyhao0422/terraform_IaC_lab
- Assessment: unconfirmed; do not use or test any credentials.

### 2569. P3_LOW_SIGNAL — yynxxxxx/outlook_imap_graph_api

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/yynxxxxx/outlook_imap_graph_api/blob/346c6efc1eaad904bb2e80302396766e811e7c7b/API.md
- Repository URL: https://github.com/yynxxxxx/outlook_imap_graph_api
- Assessment: unconfirmed; do not use or test any credentials.

### 2570. P3_LOW_SIGNAL — yzfly/awesome-dsh-skills

- Path: `SPEC.md`
- Indicator: `github_token_prefix;aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/yzfly/awesome-dsh-skills/blob/191d974adc17244b14817666e0efd23eea05eceb/SPEC.md
- Repository URL: https://github.com/yzfly/awesome-dsh-skills
- Assessment: unconfirmed; do not use or test any credentials.

### 2571. P3_LOW_SIGNAL — zabcore/ai-leak-guard

- Path: `docs/PRD.md`
- Indicator: `github_app_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/zabcore/ai-leak-guard/blob/4cea52eebd8c5838604ff3b07fff005805cd6283/docs/PRD.md
- Repository URL: https://github.com/zabcore/ai-leak-guard
- Assessment: unconfirmed; do not use or test any credentials.

### 2572. P3_LOW_SIGNAL — zalando-incubator/authmosphere

- Path: `API.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/zalando-incubator/authmosphere/blob/83778d7943f373effac3ac2729421bd71171c589/API.md
- Repository URL: https://github.com/zalando-incubator/authmosphere
- Assessment: unconfirmed; do not use or test any credentials.

### 2573. P3_LOW_SIGNAL — zapstiko/Bug-Bounty

- Path: `RegeX.md`
- Indicator: `github_token_prefix;rsa_private_key_header;npm_token_prefix;slack_token_prefix;stripe_live_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/zapstiko/Bug-Bounty/blob/20fc0770ea0b6c38db17dcb333db657eb43b959e/RegeX.md
- Repository URL: https://github.com/zapstiko/Bug-Bounty
- Assessment: unconfirmed; do not use or test any credentials.

### 2574. P3_LOW_SIGNAL — zeflq/pi-reviewer

- Path: `CI.md`
- Indicator: `private_key_label;api_key_label;github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/zeflq/pi-reviewer/blob/304c4d927def60c0055244db708f1f5c9a6e0d8c/CI.md
- Repository URL: https://github.com/zeflq/pi-reviewer
- Assessment: unconfirmed; do not use or test any credentials.

### 2575. P3_LOW_SIGNAL — zeflq/pi-reviewer

- Path: `TODO.md`
- Indicator: `github_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/zeflq/pi-reviewer/blob/304c4d927def60c0055244db708f1f5c9a6e0d8c/TODO.md
- Repository URL: https://github.com/zeflq/pi-reviewer
- Assessment: unconfirmed; do not use or test any credentials.

### 2576. P3_LOW_SIGNAL — zemse/yt

- Path: `PLAN.md`
- Indicator: `google_api_key_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/zemse/yt/blob/3d3fd8f78153611a47347533e3ad2f16c9663b34/PLAN.md
- Repository URL: https://github.com/zemse/yt
- Assessment: unconfirmed; do not use or test any credentials.

### 2577. P3_LOW_SIGNAL — zero-skies/goodluck

- Path: `api.md`
- Indicator: `access_token_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/zero-skies/goodluck/blob/1d9c30332c321cd5eee1783facf48a6495e2ed38/api.md
- Repository URL: https://github.com/zero-skies/goodluck
- Assessment: unconfirmed; do not use or test any credentials.

### 2578. P3_LOW_SIGNAL — zeryan/report-mina

- Path: `SETUP.md`
- Indicator: `github_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/zeryan/report-mina/blob/75f49b6933935922f92fa39870f05eb6b590bd40/SETUP.md
- Repository URL: https://github.com/zeryan/report-mina
- Assessment: unconfirmed; do not use or test any credentials.

### 2579. P3_LOW_SIGNAL — zhanglunet/cliproxyapi-usage-dashboard

- Path: `README.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/zhanglunet/cliproxyapi-usage-dashboard/blob/8b63f2397933f5679f08cad5c2a2bdcccd84bd60/README.md
- Repository URL: https://github.com/zhanglunet/cliproxyapi-usage-dashboard
- Assessment: unconfirmed; do not use or test any credentials.

### 2580. P3_LOW_SIGNAL — zhuiyueya/dsh-im-gateway

- Path: `README.md`
- Indicator: `slack_token_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/zhuiyueya/dsh-im-gateway/blob/8e8fbca125dda15b5cdd2ae79ac63a91e21f7c37/README.md
- Repository URL: https://github.com/zhuiyueya/dsh-im-gateway
- Assessment: unconfirmed; do not use or test any credentials.

### 2581. P3_LOW_SIGNAL — zibbadies/homies-app

- Path: `doc.md`
- Indicator: `bearer_auth_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/zibbadies/homies-app/blob/f8f4f73b87df155d37b89a12a7973867c9fe22c8/doc.md
- Repository URL: https://github.com/zibbadies/homies-app
- Assessment: unconfirmed; do not use or test any credentials.

### 2582. P3_LOW_SIGNAL — zielmicha/netd

- Path: `doc.org`
- Indicator: `private_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/zielmicha/netd/blob/86fa786420000da501b23ca7d9e7407a57968dc8/doc.org
- Repository URL: https://github.com/zielmicha/netd
- Assessment: unconfirmed; do not use or test any credentials.

### 2583. P3_LOW_SIGNAL — zinotrust/nextjs-email-tutorial

- Path: `var.txt`
- Indicator: `aws_access_key`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/zinotrust/nextjs-email-tutorial/blob/11d2aa9a25c0797d92ace615f357df245f6035d8/var.txt
- Repository URL: https://github.com/zinotrust/nextjs-email-tutorial
- Assessment: unconfirmed; do not use or test any credentials.

### 2584. P3_LOW_SIGNAL — zjuchenyuan/notebook

- Path: `ETH.md`
- Indicator: `password_assignment`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/zjuchenyuan/notebook/blob/904c0b8488770c364ccbe12452ace4fb742fcc54/ETH.md
- Repository URL: https://github.com/zjuchenyuan/notebook
- Assessment: unconfirmed; do not use or test any credentials.

### 2585. P3_LOW_SIGNAL — zumbov2/deeplr

- Path: `NEWS`
- Indicator: `api_key_label`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/zumbov2/deeplr/blob/2621422b2cc9c9c2cd99591d316321bacdd1248c/NEWS
- Repository URL: https://github.com/zumbov2/deeplr
- Assessment: unconfirmed; do not use or test any credentials.

### 2586. P3_LOW_SIGNAL — zzwjlwwdtg/quant-trading-framework

- Path: `SECURITY.md`
- Indicator: `github_oauth_prefix`
- Heuristic score: 0 (not severity)
- File URL: https://github.com/zzwjlwwdtg/quant-trading-framework/blob/6ba8e143c504613f330e3ed15900c7d7073eb87b/SECURITY.md
- Repository URL: https://github.com/zzwjlwwdtg/quant-trading-framework
- Assessment: unconfirmed; do not use or test any credentials.


## Coverage limitations

- GitHub Code Search is not exhaustive and may omit or rank results.
- Each query searched only page 1; results can be truncated.
- A result is not proof that a secret is valid or exploitable.
- No file contents or secret values were downloaded or stored.
- Bounty eligibility depends on program scope, ownership, and policy.
- Do not test, use, or attempt to authenticate with any discovered credential.
