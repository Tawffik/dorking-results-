# Combined Passive GitHub Exposure Review v5

- Run UTC: `20261017T213653Z`
- Targets configured: 1
- Unique leads: 2560
- A_REVIEW_FIRST total: 76

| Target | Queries | Leads | A_FIRST | Errors | Capped |
|---|---:|---:|---:|---:|---:|
| Capital.com | 416 | 2560 | 76 | 0 | 10 |

Results are passive, metadata-only leads. No secret values were collected or tested.
