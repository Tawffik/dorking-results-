# Shopify Passive GitHub Exposure Review v7.2

Started UTC: 2026-10-18T03:47:55.993920+00:00
Finished UTC: 2026-10-18T06:34:27.802428+00:00
Planned queries: 412
Selected queries this run: 412
Candidates retained: 24657
Official organization matches: 6227
Third-party/unknown-owner leads: 18430
Queries capped by result window: 32
Pending or nonterminal queries: 0
Errors/incomplete queries: 0

## Interpretation

- All candidates are unconfirmed code-search hits.
- An organization search match is not proof of a vulnerability.
- Ownership is classified using available repository metadata.
- Missing metadata does not prove a repository is third-party.
- Public visibility does not automatically mean bounty eligibility.
- No source contents or secret values were saved.
- No discovered credentials were tested.
- GitHub Code Search is not exhaustive.
- A capped query is incomplete.
- Rerun this cell to resume unfinished queries.

## Priority counts
- A_REVIEW_FIRST: 1084
- B_REVIEW: 9766
- C_CONTEXT: 9812
- D_LOW_SIGNAL: 3995

## Query status counts
- COMPLETE: 143
- PAGE_WINDOW_CAPPED: 32
- ZERO_RESULTS: 237

## Manual review order

1. Start with official_shopify_candidates.csv.
2. Confirm repository ownership, visibility and archive status.
3. Check current Shopify bounty scope and exclusions.
4. Review whether the indicator is a placeholder or meaningful exposure.
5. Establish impact without accessing accounts or using discovered credentials.
6. Treat third_party_leads.csv as discovery leads, not automatically in-scope findings.
